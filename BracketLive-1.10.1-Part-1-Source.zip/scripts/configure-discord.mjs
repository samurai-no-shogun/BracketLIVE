import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {configureSecurity} from './configure-security.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),id=process.argv[2];
if(!/^\d{15,22}$/.test(id??'')){console.error('Usage: node scripts/configure-discord.mjs YOUR_DISCORD_APPLICATION_ID');process.exitCode=1;}
else{
 try{const config=await configureSecurity(root);config.vars={...config.vars,DISCORD_APPLICATION_ID:id};await writeFile(resolve(root,'wrangler.json'),JSON.stringify(config,null,2)+'\n');console.log('Discord application ID configured. Existing resources and secrets preserved. Set DISCORD_CLIENT_SECRET and DISCORD_BOT_TOKEN using wrangler secret put.');}
 catch(error){console.error(error.message);process.exitCode=1;}
}
