#!/usr/bin/env python3
"""Package a built update without overwriting the install's configuration.

Run from any directory after the production build and validation have passed:
    python scripts/package-update.py

This packages existing build output; it does not build or deploy anything.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT.parent / "BracketLive-Update-1.10.1.zip"

# Only project source, deployment assets, migrations, and documentation.
DIRECTORIES = {
    "app", "build", "components", "db", "dist", "docs", "drizzle",
    "activity", "hooks", "lib", "public", "scripts", "vendor",
}
FILES = {
    ".gitignore", ".npmrc", "README.md", "README-CLOUDFLARE.txt",
    "README-UPDATE.txt", "START-PREVIEW.cmd", "VERIFICATION.txt", "SECURITY-AUDIT.txt", "cloudflare-env.d.ts",
    "components.json", "drizzle.config.ts", "eslint.config.mjs",
    "next-env.d.ts", "next.config.ts", "package.json", "pnpm-lock.yaml",
    "pnpm-workspace.yaml", "postcss.config.mjs", "tsconfig.json", "vite.config.ts",
}
FORBIDDEN_DIRECTORIES = {
    ".git", ".wrangler", ".preview", ".openai", ".sites-runtime", ".agents", ".codex",
    "node_modules", "__pycache__", ".next", ".vinext", ".venv", "coverage",
}
FORBIDDEN_FILES = {
    "wrangler.json", "wrangler.jsonc", "wrangler.toml", ".admin-key",
    ".DS_Store", "default.toml", "__mobile-review.html", "__ui-review.html", "__studio-review.html",
}
REQUIRED = {
    "README-UPDATE.txt", "package.json", "vite.config.ts", "build/worker.ts",
    "drizzle/0010_discord_activity.sql", "docs/DISCORD-SETUP.txt", "dist/client/discord-activity/index.html",
    "drizzle/0011_discord_media.sql", "docs/ANIME-ARTWORK.json", "lib/activity-results.ts",
    "activity/builder.tsx", "activity/export.ts", "dist/client/templates/anime-hd/exorcism.png",
    "docs/IMPORTING.txt", "lib/bracket-import.ts", "lib/import-visual.ts",
    "components/bracket-import-dialog.tsx", "dist/client/import-assets/pdf.worker.min.mjs",
    "dist/client/import-assets/tesseract-worker.min.js", "dist/client/import-assets/tesseract-lang/eng.traineddata.gz",
    "dist/server/index.js", "dist/client/templates/anime-source.png",
    "drizzle/0004_season_standings.sql", "drizzle/0005_template_format.sql",
    "drizzle/0006_media_access.sql", "drizzle/0007_accounts.sql", "drizzle/0008_featured_bracket.sql",
    "drizzle/0009_voting_schedule.sql", "docs/VOTING-SCHEDULES.txt", "scripts/preview-seed.sql", "docs/AUTH-SETUP.txt", "scripts/configure-security.mjs", "SECURITY-AUDIT.txt",
}


def allowed(relative: Path) -> bool:
    """Never package local configuration or credentials at any depth."""
    return not (
        any(part in FORBIDDEN_DIRECTORIES for part in relative.parts)
        or relative.name in FORBIDDEN_FILES
        or relative.name.startswith((".env", ".dev.vars", ".admin-key"))
        or relative.suffix.lower() in {".pem", ".key", ".p12", ".pfx", ".pyc"}
    )


def collect() -> list[Path]:
    paths: list[Path] = []
    for name in sorted(FILES):
        path = ROOT / name
        if path.is_file() and not path.is_symlink():
            paths.append(path)
    for name in sorted(DIRECTORIES):
        directory = ROOT / name
        if not directory.is_dir() or directory.is_symlink():
            continue
        for current, child_dirs, files in os.walk(directory, followlinks=False):
            current_path = Path(current)
            child_dirs[:] = sorted(
                child for child in child_dirs
                if not (current_path / child).is_symlink()
                and allowed((current_path / child).relative_to(ROOT))
            )
            for filename in sorted(files):
                path = current_path / filename
                if not path.is_symlink() and allowed(path.relative_to(ROOT)):
                    paths.append(path)
    return sorted(paths)


def main() -> None:
    package = json.loads((ROOT / "package.json").read_text())
    if not package["version"].startswith("1.10."):
        raise SystemExit("This packager is for Bracket Live 1.10 only.")
    paths = collect()
    names = {path.relative_to(ROOT).as_posix() for path in paths}
    missing = REQUIRED - names
    if missing:
        raise SystemExit("Missing required update files: " + ", ".join(sorted(missing)))
    if not any(name.startswith("dist/client/_next/") and name.endswith(".js") for name in names):
        raise SystemExit("No built browser JavaScript found. Build the website first.")
    if any(not allowed(Path(name)) for name in names):
        raise SystemExit("Unsafe configuration or credentials found in package list.")

    # Write and verify a temporary ZIP before replacing the update artifact.
    handle, temporary_name = tempfile.mkstemp(prefix="BracketLive-Update-", suffix=".zip", dir=ROOT.parent)
    os.close(handle)
    temporary = Path(temporary_name)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in paths:
                archive.write(path, path.relative_to(ROOT).as_posix())
        with zipfile.ZipFile(temporary) as archive:
            corrupt = archive.testzip()
            if corrupt:
                raise SystemExit("ZIP integrity check failed for " + corrupt)
            if set(archive.namelist()) != names:
                raise SystemExit("ZIP contents differ from the approved file list.")
        temporary.replace(OUTPUT)
    finally:
        temporary.unlink(missing_ok=True)
    digest = hashlib.sha256(OUTPUT.read_bytes()).hexdigest()
    print(f"Created {OUTPUT}")
    print(f"{len(paths)} files; {OUTPUT.stat().st_size:,} bytes")
    print(f"SHA256 {digest}")
    print("Excluded all Wrangler configuration, local credentials, and dependencies.")


if __name__ == "__main__":
    main()
