import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {test,after} from 'node:test';
import {fileURLToPath} from 'node:url';

// Run the actual route handlers and migrations against an isolated SQLite DB.
// Only the Cloudflare D1 transport is adapted; no production records are used.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
let analyticsReadBarrier=0,analyticsReadWaiters=[],beforeMutation;
function commitHook(statements){if(beforeMutation&&statements.some(s=>/^\s*(INSERT|UPDATE|DELETE)/i.test(s.query))){const run=beforeMutation;beforeMutation=undefined;run();}}
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 execute(){const query=sqlite.prepare(this.query);if(query.columns().length)return {results:query.all(...this.values),meta:{changes:0},success:true};const result=query.run(...this.values);return {results:[],meta:{changes:Number(result.changes)},success:true};}
 async first(column){outgoingCalls++;const row=sqlite.prepare(this.query).get(...this.values);if(analyticsReadBarrier&&this.query.startsWith('SELECT COUNT(*) n FROM analytics_events'))await new Promise(resolve=>{analyticsReadWaiters.push(resolve);if(analyticsReadWaiters.length===analyticsReadBarrier){analyticsReadBarrier=0;for(const done of analyticsReadWaiters)done();analyticsReadWaiters=[];}});return column?row?.[column]??null:row??null;}
 async all(){outgoingCalls++;return this.execute();}
 async run(){outgoingCalls++;commitHook([this]);return this.execute();}
}
let outgoingCalls=0;
const db={prepare:query=>new Statement(query),async batch(statements){outgoingCalls++;commitHook(statements);sqlite.exec('BEGIN');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
const modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env:{DB:db}}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);
 return module.exports;
}
const create=loadSource('app/api/brackets/route.ts'),read=loadSource('app/api/brackets/[id]/route.ts'),vote=loadSource('app/api/brackets/[id]/vote/route.ts'),events=loadSource('app/api/brackets/[id]/events/route.ts'),advance=loadSource('app/api/brackets/[id]/advance/route.ts'),appearance=loadSource('app/api/brackets/[id]/appearance/route.ts'),hub=loadSource('app/api/hub/route.ts');
const {makeDraft,deadlineForRound}=loadSource('lib/bracket.ts');
const seasons=loadSource('app/api/seasons/route.ts'),analytics=loadSource('app/api/analytics/events/route.ts');
const seasonEvents=loadSource('app/api/seasons/[id]/events/[eventId]/route.ts'),seasonRead=loadSource('app/api/seasons/[id]/route.ts');
const {hash}=loadSource('lib/server.ts');
const origin='https://bracket.test',owner=`bl_voter=${'1'.repeat(64)}`;
const request=(url,cookie,data,method=data===undefined?'GET':'POST',signal)=>new Request(origin+url,{method,signal,headers:{Origin:origin,...(cookie?{Cookie:cookie}:{}),...(data===undefined?{}:{'Content-Type':'application/json'})},...(data===undefined?{}:{body:JSON.stringify(data)})});
const context=id=>({params:Promise.resolve({id})});
async function json(response,status=200){assert.equal(response.status,status,await response.clone().text());return response.json();}
const cast=(id,cookie,matchId,entryId)=>vote.POST(request(`/api/brackets/${id}/vote`,cookie,{matchId,entryId}),context(id));

after(()=>sqlite.close());
const draftFor=size=>({...makeDraft(size,false),title:`Test ${size}`,entries:makeDraft(size,false).entries.map((entry,i)=>({...entry,name:`Team ${i+1}`}))});


test('parallel bracket creation cannot exceed the daily identity quota or leave orphan rows',async()=>{
 const cookie=`bl_voter=${'3'.repeat(64)}`,who=await hash('3'.repeat(64));
 const responses=await Promise.all(Array.from({length:22},()=>create.POST(request('/api/brackets',cookie,draftFor(2)))));
 assert.equal(responses.filter(r=>r.status===201).length,20);
 assert.equal(responses.filter(r=>r.status===429).length,2);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM brackets WHERE owner_id=?').get(who).n,20);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM entries e LEFT JOIN brackets b ON b.id=e.bracket_id WHERE b.id IS NULL').get().n,0);
});

test('parallel season creation cannot exceed the daily identity quota',async()=>{
 const cookie=`bl_voter=${'4'.repeat(64)}`,who=await hash('4'.repeat(64));
 const data={title:'Quota test',points:[25,18],entrants:['Alpha','Beta']};
 const responses=await Promise.all(Array.from({length:22},()=>seasons.POST(request('/api/seasons',cookie,data))));
 assert.equal(responses.filter(r=>r.status===201).length,20);
 assert.equal(responses.filter(r=>r.status===429).length,2);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM seasons WHERE owner_id=?').get(who).n,20);
});

test('parallel analytics submissions cannot pass the daily identity cap',async()=>{
 const cookie=`bl_voter=${'5'.repeat(64)}`,who=await hash('5'.repeat(64));
 const insert=sqlite.prepare("INSERT INTO analytics_events(id,visitor_id,kind,path,source,campaign,device,is_test,created_at) VALUES(?,?,'view','/','direct','','desktop',0,?)");
 for(let i=0;i<499;i++)insert.run(crypto.randomUUID(),who,Date.now());
 // Model simultaneous D1 count responses; the old read-then-insert cap raced here.
 analyticsReadBarrier=6;
 const responses=await Promise.all(Array.from({length:6},()=>analytics.POST(request('/api/analytics/events',cookie,{id:crypto.randomUUID(),kind:'view',path:'/'}))));
 analyticsReadBarrier=0;
 const results=await Promise.all(responses.map(r=>json(r)));
 assert.equal(results.filter(r=>r.recorded).length,1);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM analytics_events WHERE visitor_id=?').get(who).n,500);
});

test('directory requests bound expiry settlement even with several fully expired 128-entry brackets',async()=>{
 const cookie=`bl_voter=${'6'.repeat(64)}`;
 for(let i=0;i<4;i++){
  const {bracket}=await json(await create.POST(request('/api/brackets',cookie,{...draftFor(128),publish:true,ends_at:Date.now()+70000})),201);
  const ended=Date.now()-10000,started=ended-70000;
  sqlite.prepare('UPDATE brackets SET started_at=?,ends_at=?,round_closes_at=? WHERE id=?').run(started,ended,deadlineForRound(started,ended,128,0),bracket.id);
 }
 outgoingCalls=0;
 await json(await hub.GET());
 assert.ok(outgoingCalls<=32,`public directory used ${outgoingCalls} D1 transport calls`);
 outgoingCalls=0;
 await json(await create.GET(request('/api/brackets',cookie)));
 assert.ok(outgoingCalls<=32,`organizer directory used ${outgoingCalls} D1 transport calls`);
});

test('concurrent votes remain unique, reject foreign contenders, and cannot alter a closed match',async()=>{
 const cookie=`bl_voter=${'7'.repeat(64)}`;
 const {bracket}=await json(await create.POST(request('/api/brackets',cookie,{...draftFor(4),publish:true})),201);
 const m=bracket.matches[0];
 const responses=await Promise.all(Array.from({length:12},(_,i)=>cast(bracket.id,cookie,m.id,i%2?m.a_id:m.b_id)));
 for(const r of responses)await json(r);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM votes WHERE match_id=?').get(m.id).n,1);
 await json(await cast(bracket.id,cookie,m.id,bracket.matches[1].a_id),409);
 const concurrent=await Promise.all(Array.from({length:2},()=>advance.POST(request(`/api/brackets/${bracket.id}/advance`,cookie,{round:0,ties:{[bracket.matches[1].id]:bracket.matches[1].a_id}}),context(bracket.id))));
 assert.equal(concurrent.filter(r=>r.status===200).length,1);
 assert.equal(concurrent.filter(r=>r.status===409).length,1);
 const winner=sqlite.prepare('SELECT winner_id FROM matches WHERE id=?').get(m.id).winner_id;
 await json(await cast(bracket.id,cookie,m.id,m.a_id),409);
 await json(await cast(bracket.id,cookie,m.id,null),409);
 assert.equal(sqlite.prepare('SELECT winner_id FROM matches WHERE id=?').get(m.id).winner_id,winner);
});

test('concurrent season corrections use a single saved version without double-scoring',async()=>{
 const cookie=`bl_voter=${'8'.repeat(64)}`;
 const {season}=await json(await seasons.POST(request('/api/seasons',cookie,{title:'Race test',points:[25,18],entrants:['Alpha','Beta']})),201);
 const eventId=crypto.randomUUID(),ctx={params:Promise.resolve({id:season.id,eventId})};
 const url=`/api/seasons/${season.id}/events/${eventId}`;
 const event={title:'Event',date:'',status:'complete',version:0,results:season.entrants.map((e,i)=>({entrantId:e.id,position:i+1,adjustment:0,note:''}))};
 await json(await seasonEvents.PUT(request(url,cookie,event,'PUT'),ctx));
 const changes=[{...event,version:1,results:[{...event.results[0],position:2},{...event.results[1],position:1}]},{...event,version:1,results:[{...event.results[0],adjustment:2},event.results[1]]}];
 const responses=await Promise.all(changes.map(data=>seasonEvents.PUT(request(url,cookie,data,'PUT'),ctx)));
 assert.equal(responses.filter(r=>r.status===200).length,1);
 assert.equal(responses.filter(r=>r.status===409).length,1);
 const current=await json(await seasonRead.GET(request(`/api/seasons/${season.id}`,cookie),context(season.id)));
 assert.equal(current.events[0].version,2);
 assert.equal(current.events.length,1);
 const saved=current.events[0].results;
 for(const row of current.standings){const result=saved.find(r=>r.entrantId===row.entrant.id);assert.equal(row.points,season.points[result.position-1]+result.adjustment);}
});

test('SQL-shaped identifiers remain data and cannot select or change unrelated records',async()=>{
 const cookie=`bl_voter=${'9'.repeat(64)}`;
 const {bracket}=await json(await create.POST(request('/api/brackets',cookie,{...draftFor(2),publish:true})),201);
 const count=sqlite.prepare('SELECT COUNT(*) n FROM brackets').get().n;
 const payload="' OR 1=1; DELETE FROM brackets; --";
 await json(await read.GET(request('/api/brackets/invalid',cookie),context(payload)),404);
 await json(await cast(bracket.id,cookie,payload,bracket.entries[0].id),409);
 await json(await cast(bracket.id,cookie,bracket.matches[0].id,payload),409);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM brackets').get().n,count);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM votes WHERE match_id=?').get(bracket.matches[0].id).n,0);
});

test('revoking a manager before commit blocks bracket edits, appearance, advancement and private test votes',async()=>{
 const cookie=`bl_voter=${'a'.repeat(64)}`,actor=`bl_voter=${'b'.repeat(64)}`,actorId=await hash('b'.repeat(64));
 const {bracket:draft}=await json(await create.POST(request('/api/brackets',cookie,draftFor(2))),201);
 const {bracket:live}=await json(await create.POST(request('/api/brackets',cookie,{...draftFor(2),publish:true})),201);
 const {bracket:privateTest}=await json(await create.POST(request('/api/brackets',cookie,{...draftFor(2),publish:true,is_test:true})),201);
 const revokeAtCommit=id=>{sqlite.prepare('INSERT OR IGNORE INTO managers(bracket_id,identity_id) VALUES(?,?)').run(id,actorId);beforeMutation=()=>sqlite.prepare('DELETE FROM managers WHERE bracket_id=? AND identity_id=?').run(id,actorId);};
 revokeAtCommit(draft.id);
 await json(await read.PUT(request(`/api/brackets/${draft.id}`,actor,{...draftFor(2),title:'Revoked edit'},'PUT'),context(draft.id)),403);
 assert.equal(sqlite.prepare('SELECT title FROM brackets WHERE id=?').get(draft.id).title,draft.title);
 assert.deepEqual(sqlite.prepare('SELECT id FROM entries WHERE bracket_id=? ORDER BY seed').all(draft.id).map(e=>e.id),draft.entries.map(e=>e.id));
 revokeAtCommit(live.id);
 await json(await appearance.PUT(request(`/api/brackets/${live.id}/appearance`,actor,{accent:'red'},'PUT'),context(live.id)),403);
 assert.equal(sqlite.prepare('SELECT accent FROM brackets WHERE id=?').get(live.id).accent,live.accent);
 revokeAtCommit(live.id);
 await json(await advance.POST(request(`/api/brackets/${live.id}/advance`,actor,{round:0,ties:{[live.matches[0].id]:live.matches[0].a_id}}),context(live.id)),403);
 assert.equal(sqlite.prepare('SELECT status FROM brackets WHERE id=?').get(live.id).status,'live');
 assert.equal(sqlite.prepare('SELECT winner_id FROM matches WHERE id=?').get(live.matches[0].id).winner_id,null);
 revokeAtCommit(privateTest.id);
 await json(await cast(privateTest.id,actor,privateTest.matches[0].id,privateTest.matches[0].a_id),409);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM votes WHERE match_id=?').get(privateTest.matches[0].id).n,0);
});

test('revoking a manager before commit blocks season settings and event creation, changes and deletion',async()=>{
 const cookie=`bl_voter=${'c'.repeat(64)}`,actor=`bl_voter=${'d'.repeat(64)}`,actorId=await hash('d'.repeat(64));
 const {season}=await json(await seasons.POST(request('/api/seasons',cookie,{title:'Revocation test',points:[25,18],entrants:['Alpha','Beta']})),201);
 const revokeAtCommit=()=>{sqlite.prepare('INSERT OR IGNORE INTO season_managers(season_id,identity_id) VALUES(?,?)').run(season.id,actorId);beforeMutation=()=>sqlite.prepare('DELETE FROM season_managers WHERE season_id=? AND identity_id=?').run(season.id,actorId);};
 revokeAtCommit();
 await json(await seasonRead.PUT(request(`/api/seasons/${season.id}`,actor,{title:'Revoked edit',description:'',points:[100],entrants:season.entrants,version:1},'PUT'),context(season.id)),403);
 assert.equal(sqlite.prepare('SELECT title,version FROM seasons WHERE id=?').get(season.id).title,season.title);
 const eventId=crypto.randomUUID(),ctx={params:Promise.resolve({id:season.id,eventId})},url=`/api/seasons/${season.id}/events/${eventId}`;
 const event={title:'Event',date:'',status:'complete',version:0,results:season.entrants.map((e,i)=>({entrantId:e.id,position:i+1,adjustment:0,note:''}))};
 revokeAtCommit();
 await json(await seasonEvents.PUT(request(url,actor,event,'PUT'),ctx),403);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM season_events WHERE id=?').get(eventId).n,0);
 await json(await seasonEvents.PUT(request(url,cookie,event,'PUT'),ctx));
 revokeAtCommit();
 await json(await seasonEvents.PUT(request(url,actor,{...event,title:'Revoked change',version:1},'PUT'),ctx),403);
 assert.equal(sqlite.prepare('SELECT title FROM season_events WHERE id=?').get(eventId).title,'Event');
 revokeAtCommit();
 await json(await seasonEvents.DELETE(request(url,actor,{version:1},'DELETE'),ctx),403);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM season_events WHERE id=?').get(eventId).n,1);
});
