import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {after,test} from 'node:test';
import {fileURLToPath} from 'node:url';

// Real handlers and SQL, with deterministic hooks to reproduce token/reset races.
// All data is isolated in memory; this never contacts the deployed service.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
after(()=>sqlite.close());
let beforeRun=null,beforeBatch=null;
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 execute(){const query=sqlite.prepare(this.query);return query.columns().length?{results:query.all(...this.values),meta:{changes:0}}:{results:[],meta:{changes:Number(query.run(...this.values).changes)}};}
 async first(){return sqlite.prepare(this.query).get(...this.values)??null;}
 async all(){return this.execute();}
 async run(){if(beforeRun){const hook=beforeRun;beforeRun=null;hook(this.query);}return this.execute();}
}
const db={prepare:query=>new Statement(query),async batch(statements){
 if(beforeBatch){const hook=beforeBatch;beforeBatch=null;hook();}
 sqlite.exec('BEGIN');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}
}};
const modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env:{DB:db}}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);return module.exports;
}
const {hash,identity,boundary}=loadSource('lib/server.ts'),{makeDraft}=loadSource('lib/bracket.ts');
const origin='https://bracket.test',owner=`bl_voter=${'1'.repeat(64)}`,second=`bl_voter=${'2'.repeat(64)}`,third=`bl_voter=${'3'.repeat(64)}`;
const request=(pathname,cookie,data,headers={})=>new Request(origin+pathname,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{}),...headers},body:JSON.stringify(data)});
async function result(response,status=200){assert.equal(response.status,status,await response.clone().text());return response.json();}

for(const kind of ['brackets','seasons']){
 const collection=loadSource(`app/api/${kind}/route.ts`),manage=loadSource(`app/api/${kind}/[id]/manage/route.ts`);
 const table=kind==='brackets'?'managers':'season_managers',idColumn=kind==='brackets'?'bracket_id':'season_id';
 const submit=(id,data,cookie=owner,headers)=>manage.POST(request(`/api/${kind}/${id}/manage`,cookie,data,headers),{params:Promise.resolve({id})});
 const create=async()=>{const data=kind==='brackets'?{...makeDraft(2,false),title:'Security test'}:{title:'Security test',entrants:['A','B'],points:[10,5]};const value=await result(await collection.POST(request(`/api/${kind}`,owner,data)),201);return {id:(value.bracket??value.season).id,token:value.manageToken};};
 const hasManager=async(id,cookie)=>!!sqlite.prepare(`SELECT 1 FROM ${table} WHERE ${idColumn}=? AND identity_id=?`).get(id,await hash(cookie.split('=')[1]));

 test(`${kind}: explicit reset revokes other browsers and old tokens while ordinary link copying retains devices`,async()=>{
  const current=await create(),unrelated=await create();
  await result(await submit(current.id,{token:current.token},second));
  await result(await submit(current.id,{token:current.token},second));
  await result(await submit(unrelated.id,{token:unrelated.token},second));
  const rotated=await result(await submit(current.id,{}));
  assert.equal(rotated.revokedOthers,false);assert.equal(await hasManager(current.id,second),true);
  await result(await submit(current.id,{token:current.token},third),403);
  await result(await submit(current.id,{revokeOthers:true},third),403);
  await result(await submit(current.id,{token:rotated.manageToken,revokeOthers:true},third),400);
  await result(await submit(current.id,{revokeOthers:true},owner,{Origin:'https://evil.example'}),403);
  const fresh=await result(await submit(current.id,{revokeOthers:true}));
  assert.equal(fresh.revokedOthers,true);assert.notEqual(fresh.manageToken,rotated.manageToken);
  assert.equal(await hasManager(current.id,owner),true);assert.equal(await hasManager(current.id,second),false);
  assert.equal(await hasManager(unrelated.id,second),true,'reset is scoped to this tournament');
  await result(await submit(current.id,{},second),403);
  await result(await submit(current.id,{token:rotated.manageToken},second),403);
  await result(await submit(current.id,{token:fresh.manageToken},third));
  assert.equal(await hasManager(current.id,third),true);
 });

 test(`${kind}: token revoked immediately before insertion cannot regain organizer access`,async()=>{
  const current=await create();
  beforeRun=query=>{assert.match(query,/INSERT INTO (season_)?managers/);sqlite.prepare(`UPDATE ${kind} SET manage_hash=? WHERE id=?`).run('revoked',current.id);};
  await result(await submit(current.id,{token:current.token},second),403);
  assert.equal(await hasManager(current.id,second),false);
 });

 test(`${kind}: an in-flight reset rechecks authorization atomically before changing tokens`,async()=>{
  const current=await create();await result(await submit(current.id,{token:current.token},second));
  const oldHash=sqlite.prepare(`SELECT manage_hash FROM ${kind} WHERE id=?`).get(current.id).manage_hash;
  const secondId=await hash(second.split('=')[1]);
  beforeBatch=()=>sqlite.prepare(`DELETE FROM ${table} WHERE ${idColumn}=? AND identity_id=?`).run(current.id,secondId);
  await result(await submit(current.id,{revokeOthers:true},second),403);
  assert.equal(sqlite.prepare(`SELECT manage_hash FROM ${kind} WHERE id=?`).get(current.id).manage_hash,oldHash);
  assert.equal(await hasManager(current.id,owner),true);
 });
}

// Keep established organizer/voter identities stable, but never choose one of
// two conflicting cookie values based on browser/path ordering.
test('voter identity rejects duplicate cookies without replacing a valid session',async()=>{
 const one=await identity(request('/api/session',owner,{}));
 assert.equal(one.id,await hash(owner.split('=')[1]));assert.equal(one.cookie,null);
 for(const cookie of [owner+'; '+second,owner+'; '+owner,'bl_voter=invalid; '+owner]){
  const response=await boundary(async()=>{await identity(request('/api/session',cookie,{}));return new Response('unexpected');});
  assert.equal(response.status,400);assert.equal(response.headers.get('set-cookie'),null);
 }
 const newSession=await identity(request('/api/session',undefined,{}));
 assert.match(newSession.cookie,/^bl_voter=[a-f0-9]{64}; HttpOnly; SameSite=Lax; Path=\/; Max-Age=31536000; Secure$/);
});
