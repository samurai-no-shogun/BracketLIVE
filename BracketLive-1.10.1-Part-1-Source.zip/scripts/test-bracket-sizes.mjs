import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {test,after} from 'node:test';
import {fileURLToPath} from 'node:url';

// Run the actual route handlers and migrations against an isolated SQLite DB.
// Only the Cloudflare D1 transport is adapted; no production records are used.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 execute(){const query=sqlite.prepare(this.query);if(query.columns().length)return {results:query.all(...this.values),meta:{changes:0},success:true};const result=query.run(...this.values);return {results:[],meta:{changes:Number(result.changes)},success:true};}
 async first(column){outgoingCalls++;const row=sqlite.prepare(this.query).get(...this.values);return column?row?.[column]??null:row??null;}
 async all(){outgoingCalls++;return this.execute();}
 async run(){outgoingCalls++;return this.execute();}
}
let outgoingCalls=0;
const db={prepare:query=>new Statement(query),async batch(statements){outgoingCalls++;sqlite.exec('BEGIN');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
const modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env:{DB:db}}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);
 return module.exports;
}
const create=loadSource('app/api/brackets/route.ts'),read=loadSource('app/api/brackets/[id]/route.ts'),vote=loadSource('app/api/brackets/[id]/vote/route.ts'),events=loadSource('app/api/brackets/[id]/events/route.ts'),advance=loadSource('app/api/brackets/[id]/advance/route.ts'),appearance=loadSource('app/api/brackets/[id]/appearance/route.ts'),hub=loadSource('app/api/hub/route.ts');
const {makeDraft,deadlineForRound}=loadSource('lib/bracket.ts');
const origin='https://bracket.test',owner=`bl_voter=${'1'.repeat(64)}`;
const request=(url,cookie,data,method=data===undefined?'GET':'POST',signal)=>new Request(origin+url,{method,signal,headers:{Origin:origin,...(cookie?{Cookie:cookie}:{}),...(data===undefined?{}:{'Content-Type':'application/json'})},...(data===undefined?{}:{body:JSON.stringify(data)})});
const context=id=>({params:Promise.resolve({id})});
async function json(response,status=200){assert.equal(response.status,status,await response.clone().text());return response.json();}
const cast=(id,cookie,matchId,entryId)=>vote.POST(request(`/api/brackets/${id}/vote`,cookie,{matchId,entryId}),context(id));

after(()=>sqlite.close());
const draftFor=size=>({...makeDraft(size,false),title:`Test ${size}`,entries:makeDraft(size,false).entries.map((entry,i)=>({...entry,name:`Team ${i+1}`}))});

test('a 1v1 bracket votes, closes its only match, and crowns a champion',async()=>{
 const {bracket}=await json(await create.POST(request('/api/brackets',owner,{...draftFor(2),publish:true})),201);
 assert.equal(bracket.matches.length,1);assert.equal(bracket.matches[0].round,0);
 const match=bracket.matches[0];await json(await cast(bracket.id,owner,match.id,match.b_id));
 const complete=await json(await advance.POST(request(`/api/brackets/${bracket.id}/advance`,owner,{round:0}),context(bracket.id)));
 assert.equal(complete.status,'complete');assert.equal(complete.matches[0].winner_id,match.b_id);
 assert.equal(complete.matches[0].total,1);assert.equal(complete.current_round,0);
});

test('128 entrants produce 127 matches and all seven rounds can be advanced through the API',async()=>{
 const {bracket}=await json(await create.POST(request('/api/brackets',owner,{...draftFor(128),publish:true})),201);
 assert.equal(bracket.entries.length,128);assert.equal(bracket.matches.length,127);
 assert.deepEqual(Array.from({length:7},(_,round)=>bracket.matches.filter(m=>m.round===round).length),[64,32,16,8,4,2,1]);
 let current=bracket;
 for(let round=0;round<7;round++){
  const open=current.matches.filter(m=>m.status==='open');assert.equal(open.length,64/2**round);
  const ties=Object.fromEntries(open.map(m=>[m.id,m.a_id]));
  current=await json(await advance.POST(request(`/api/brackets/${bracket.id}/advance`,owner,{round,ties}),context(bracket.id)));
 }
 assert.equal(current.status,'complete');assert.equal(current.current_round,6);
 assert.ok(current.matches.every(m=>m.status==='closed'&&m.winner_id));
 assert.equal(current.matches.at(-1).winner_id,bracket.entries[0].id);
});

test('a missed 128-team closing deadline settles all seven rounds to a final champion',async()=>{
 assert.deepEqual(Array.from({length:7},(_,round)=>deadlineForRound(0,7000,128,round)),[1000,2000,3000,4000,5000,6000,7000]);
 const {bracket}=await json(await create.POST(request('/api/brackets',owner,{...draftFor(128),publish:true,ends_at:Date.now()+70000})),201);
 assert.equal(bracket.round_closes_at,deadlineForRound(bracket.started_at,bracket.ends_at,128,0));
 const ended=Date.now()-10000,started=ended-70000;
 sqlite.prepare('UPDATE brackets SET started_at=?,ends_at=?,round_closes_at=? WHERE id=?').run(started,ended,deadlineForRound(started,ended,128,0),bracket.id);
 const complete=await json(await read.GET(request(`/api/brackets/${bracket.id}`,owner),context(bracket.id)));
 assert.equal(complete.status,'complete');assert.equal(complete.current_round,6);assert.equal(complete.round_closes_at,null);
 assert.ok(complete.matches.every(m=>m.status==='closed'&&m.winner_id));
 assert.equal(complete.matches.at(-1).winner_id,complete.entries[0].id,'automatic tie handling preserves the earlier entry');
});

test('128 uploaded images are authorized in a batch, and foreign uploads remain rejected',async()=>{
 const {hash}=loadSource('lib/server.ts'),ownerId=await hash('1'.repeat(64)),draft=draftFor(128);
 for(const entry of draft.entries){
  const key=`${crypto.randomUUID()}.png`;
  sqlite.prepare('INSERT INTO media (id,owner_id,content_type,size,created_at) VALUES (?,?,?,?,?)').run(key,ownerId,'image/png',1,Date.now());
  entry.image=`/api/media/${key}`;
 }
 outgoingCalls=0;
 const {bracket}=await json(await create.POST(request('/api/brackets',owner,draft)),201);
 assert.equal(bracket.entries.length,128);assert.ok(outgoingCalls<10,`${outgoingCalls} D1 calls should stay below the Worker subrequest budget`);
 const foreign=`${crypto.randomUUID()}.png`;
 sqlite.prepare('INSERT INTO media (id,owner_id,content_type,size,created_at) VALUES (?,?,?,?,?)').run(foreign,'another-owner','image/png',1,Date.now());
 draft.entries[127].image=`/api/media/${foreign}`;
 const rejected=await json(await create.POST(request('/api/brackets',owner,draft)),400);
 assert.match(rejected.error,/Upload that image again/);
});

test('expanded standard sizes retain the 64-team guard for both regional formats',async()=>{
 for(const format of ['basketball','ncaa2026'])for(const size of [2,128])await json(await create.POST(request('/api/brackets',owner,{...draftFor(size),format})),400);
 for(const size of [1,3,256])await json(await create.POST(request('/api/brackets',owner,draftFor(size))),400);
});
