import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {test} from 'node:test';
import {fileURLToPath} from 'node:url';

// Run the actual route handlers and migrations against an isolated SQLite DB.
// Only the Cloudflare D1 transport is adapted; no production records are used.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 execute(){const query=sqlite.prepare(this.query);if(query.columns().length)return {results:query.all(...this.values),meta:{changes:0},success:true};const result=query.run(...this.values);return {results:[],meta:{changes:Number(result.changes)},success:true};}
 async first(column){const row=sqlite.prepare(this.query).get(...this.values);return column?row?.[column]??null:row??null;}
 async all(){return this.execute();}
 async run(){return this.execute();}
}
const db={prepare:query=>new Statement(query),async batch(statements){sqlite.exec('BEGIN');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
const modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env:{DB:db}}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);
 return module.exports;
}
const create=loadSource('app/api/brackets/route.ts'),read=loadSource('app/api/brackets/[id]/route.ts'),vote=loadSource('app/api/brackets/[id]/vote/route.ts'),events=loadSource('app/api/brackets/[id]/events/route.ts'),advance=loadSource('app/api/brackets/[id]/advance/route.ts'),appearance=loadSource('app/api/brackets/[id]/appearance/route.ts'),hub=loadSource('app/api/hub/route.ts');
const {makeDraft,makeTemplateDraft,publicVotingDraft,votePercent,displaySeed,entryRegion}=loadSource('lib/bracket.ts');
const {basketballEntries}=loadSource('lib/basketball-template.ts');
const origin='https://bracket.test',owner=`bl_voter=${'1'.repeat(64)}`;
const request=(url,cookie,data,method=data===undefined?'GET':'POST',signal)=>new Request(origin+url,{method,signal,headers:{Origin:origin,...(cookie?{Cookie:cookie}:{}),...(data===undefined?{}:{'Content-Type':'application/json'})},...(data===undefined?{}:{body:JSON.stringify(data)})});
const context=id=>({params:Promise.resolve({id})});
async function json(response,status=200){assert.equal(response.status,status,await response.clone().text());return response.json();}
const cast=(id,cookie,matchId,entryId)=>vote.POST(request(`/api/brackets/${id}/vote`,cookie,{matchId,entryId}),context(id));

test('publish a private test as a fresh public bracket, then vote as independent guests',async()=>{
 try{
  const template=makeDraft();template.appearance={glass_tint:'#a591d8',glass_opacity:72};
  const {bracket:privateTest}=await json(await create.POST(request('/api/brackets',owner,{...template,publish:true,is_test:true})),201);
  const originalMatch=privateTest.matches[0];
  const picked=await json(await cast(privateTest.id,owner,originalMatch.id,originalMatch.a_id));
  assert.equal(picked.totalVotes,1);
  await json(await read.GET(request(`/api/brackets/${privateTest.id}`),context(privateTest.id)),404);
  await json(await cast(privateTest.id,undefined,originalMatch.id,originalMatch.a_id),403);

  const {bracket:publicBracket,manageToken}=await json(await create.POST(request('/api/brackets',owner,{...publicVotingDraft(picked),publish:true,is_test:false})),201);
  assert.notEqual(publicBracket.id,privateTest.id);assert.ok(manageToken);
  assert.equal(publicBracket.is_test,false);assert.equal(publicBracket.listed,true);assert.equal(publicBracket.isOwner,true);
  assert.equal(publicBracket.current_round,0);assert.equal(publicBracket.totalVotes,0);assert.equal(publicBracket.ends_at,null);
  assert.equal(publicBracket.matches.filter(m=>m.status==='open').length,32);
  assert.deepEqual(publicBracket.entries.map(({id,...entry})=>entry),privateTest.entries.map(({id,...entry})=>entry));
  assert.deepEqual(publicBracket.appearance,privateTest.appearance);

  const first=await read.GET(request(`/api/brackets/${publicBracket.id}`),context(publicBracket.id));
  const visitorA=first.headers.get('Set-Cookie').split(';')[0],initial=await json(first);
  assert.equal(initial.isOwner,false);assert.equal(initial.matches[0].counts,null);
  assert.ok(!('manageToken' in initial)&&!('manage_hash' in initial)&&!('owner_id' in initial));
  const second=await read.GET(request(`/api/brackets/${publicBracket.id}`),context(publicBracket.id));
  const visitorB=second.headers.get('Set-Cookie').split(';')[0];await json(second);assert.notEqual(visitorA,visitorB);
  const match=publicBracket.matches[0];
  const afterA=await json(await cast(publicBracket.id,visitorA,match.id,match.a_id));
  assert.equal(votePercent(afterA.matches[0],match.a_id),100);
  const afterB=await json(await cast(publicBracket.id,visitorB,match.id,match.b_id));
  assert.equal(afterB.matches[0].total,2);assert.equal(votePercent(afterB.matches[0],match.a_id),50);assert.equal(votePercent(afterB.matches[0],match.b_id),50);
  assert.equal((await json(await read.GET(request(`/api/brackets/${publicBracket.id}`,visitorA),context(publicBracket.id)))).matches[0].total,2);

  const stream=await events.GET(request(`/api/brackets/${publicBracket.id}/events`,visitorB),context(publicBracket.id));
  assert.equal(stream.status,200);const reader=stream.body.getReader(),decoder=new TextDecoder();
  try{
   const initialEvent=decoder.decode((await reader.read()).value);assert.match(initialEvent,/^data: /);
   const changed=await json(await cast(publicBracket.id,visitorA,match.id,match.b_id));
   assert.equal(changed.matches[0].total,2);assert.equal(votePercent(changed.matches[0],match.b_id),100);
   const update=decoder.decode((await reader.read()).value),updated=JSON.parse(update.slice('data: '.length).trim());
   assert.equal(updated.matches[0].counts[match.b_id],2,'the second visitor receives the changed global total over SSE');
  }finally{await reader.cancel();}
  const undone=await json(await cast(publicBracket.id,visitorA,match.id,null));assert.equal(undone.matches[0].myVote,null);
  const remaining=await json(await read.GET(request(`/api/brackets/${publicBracket.id}`,visitorB),context(publicBracket.id)));
  assert.equal(remaining.matches[0].total,1);assert.equal(remaining.matches[0].counts[match.b_id],1);
  await json(await advance.POST(request(`/api/brackets/${publicBracket.id}/advance`,visitorA,{round:0,ties:{}}),context(publicBracket.id)),403);
  await json(await appearance.PUT(request(`/api/brackets/${publicBracket.id}/appearance`,visitorA,{},'PUT'),context(publicBracket.id)),403);
  const directory=await json(await hub.GET());assert.ok(directory.brackets.some(b=>b.id===publicBracket.id));assert.ok(!directory.brackets.some(b=>b.id===privateTest.id));
  assert.equal((await json(await read.GET(request(`/api/brackets/${privateTest.id}`,owner),context(privateTest.id)))).totalVotes,1,'the original test and its votes remain unchanged');
  const basketball=makeTemplateDraft('basketball');
  const {bracket:savedBasketball}=await json(await create.POST(request('/api/brackets',owner,basketball)),201);
  assert.equal(savedBasketball.format,'ncaa2026');
  assert.equal(savedBasketball.entries[0].name,'Duke');
  assert.deepEqual([0,16,32,48].map(i=>entryRegion(savedBasketball.entries[i],savedBasketball.format)),['East','South','West','Midwest']);
  assert.deepEqual(savedBasketball.entries.map(e=>e.seed),Array.from({length:64},(_,i)=>i+1),'repeated display seeds must not change storage order');
  const edited={...basketball,title:'My basketball bracket',entries:basketball.entries.map((entry,i)=>({...entry,name:i===0?'My team':entry.name}))};
  const {bracket:updatedBasketball}=await json(await read.PUT(request(`/api/brackets/${savedBasketball.id}`,owner,edited,'PUT'),context(savedBasketball.id)));
  assert.equal(updatedBasketball.format,'ncaa2026');assert.equal(updatedBasketball.entries[0].name,'My team');
  assert.deepEqual(updatedBasketball.entries.slice(0,2).map(e=>displaySeed(e,updatedBasketball.format)),[1,16]);
  const reloadedBasketball=await json(await read.GET(request(`/api/brackets/${savedBasketball.id}`,owner),context(savedBasketball.id)));
  assert.equal(reloadedBasketball.title,'My basketball bracket');assert.equal(reloadedBasketball.format,'ncaa2026');
  assert.deepEqual(reloadedBasketball.entries.map(({id,...entry})=>entry),edited.entries);
  await json(await create.POST(request('/api/brackets',owner,{...basketball,size:32,entries:basketball.entries.slice(0,32)})),400);
  const legacy={...makeDraft(64,false),title:'Existing basketball bracket',format:'basketball',entries:basketballEntries()};
  const {bracket:savedLegacy}=await json(await create.POST(request('/api/brackets',owner,legacy)),201);
  const reloadedLegacy=await json(await read.GET(request(`/api/brackets/${savedLegacy.id}`,owner),context(savedLegacy.id)));
  assert.equal(reloadedLegacy.format,'basketball');
  assert.deepEqual([0,16,32,48].map(i=>entryRegion(reloadedLegacy.entries[i],reloadedLegacy.format)),['East','West','South','Midwest'],'updating the example must not reinterpret saved regional brackets');
 }finally{sqlite.close();}
});
