import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {after,test} from 'node:test';
import {fileURLToPath} from 'node:url';

// Exercise real SQL and handlers, including owner authorization. All rows live
// in memory and no requests are sent to the deployed application.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(name=>name.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
after(()=>sqlite.close());
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 async first(){return sqlite.prepare(this.query).get(...this.values)??null;}
 async all(){return {results:sqlite.prepare(this.query).all(...this.values)};}
 async run(){return {meta:{changes:Number(sqlite.prepare(this.query).run(...this.values).changes)}};}
}
const env={ADMIN_KEY:'ae'.repeat(32),DB:{prepare:query=>new Statement(query)}},modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env}:id==='next/headers'?{headers:async()=>new Headers()}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);return module.exports;
}
const featured=loadSource('lib/featured-server.ts'),publicApi=loadSource('app/api/featured/route.ts'),adminApi=loadSource('app/api/admin/featured/route.ts'),auth=loadSource('lib/admin-auth.ts');
const origin='https://bracket.example';
const request=(body,cookie='',otherOrigin=origin)=>new Request(origin+'/api/admin/featured',{method:body===undefined?'GET':'PUT',headers:{Origin:otherOrigin,Cookie:cookie,'Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
const ids={public:'00000000-0000-4000-8000-000000000001',complete:'00000000-0000-4000-8000-000000000002',draft:'00000000-0000-4000-8000-000000000003',test:'00000000-0000-4000-8000-000000000004',unknown:'00000000-0000-4000-8000-000000000005'};
for(const [name,id] of Object.entries(ids).filter(([name])=>name!=='unknown'))sqlite.prepare('INSERT INTO brackets(id,title,size,status,is_test,owner_id,manage_hash,created_at) VALUES(?,?,?,?,?,?,?,?)').run(id,name,64,name==='draft'?'draft':name==='complete'?'complete':'live',name==='test'?1:0,'owner','private-secret',0);
const current=()=>sqlite.prepare('SELECT value FROM site_settings WHERE key=?').get(featured.FEATURED_BRACKET_KEY)?.value??null;

test('public lookup reveals only an explicitly selected published, non-test bracket',async()=>{
 assert.equal(await featured.getFeaturedBracketId(),null);
 assert.deepEqual(await (await publicApi.GET()).json(),{bracket:null});
 for(const name of ['public','complete','draft','test','unknown']){
  sqlite.prepare('INSERT INTO site_settings(key,value,updated_at) VALUES(?,?,0) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(featured.FEATURED_BRACKET_KEY,ids[name]);
  const response=await publicApi.GET(),value=await response.json();
  assert.equal(response.status,200);assert.equal(response.headers.get('cache-control'),'no-store');
  assert.equal(value.bracket?.id??null,['public','complete'].includes(name)?ids[name]:null);
  assert.ok(!JSON.stringify(value).includes('private-secret'));
 }
 sqlite.prepare('DELETE FROM site_settings').run();
});

test('only signed site owner sessions can read choices or set the homepage',async()=>{
 assert.equal((await adminApi.GET(request())).status,403);
 assert.equal((await adminApi.PUT(request({bracketId:ids.public}))).status,403);
 assert.equal(current(),null);
 const cookie=`bl_admin=${await auth.createAdminSession()}`;
 const list=await adminApi.GET(request(undefined,cookie));assert.equal(list.status,200);
 assert.deepEqual((await list.json()).brackets.map(bracket=>bracket.id).sort(),[ids.public,ids.complete].sort());
 assert.equal((await adminApi.PUT(request({bracketId:ids.public},cookie,'https://evil.example'))).status,403);
 assert.equal(current(),null);
 const saved=await adminApi.PUT(request({bracketId:ids.public},cookie));assert.equal(saved.status,200);assert.equal((await saved.json()).featured.id,ids.public);assert.equal(current(),ids.public);
});

test('invalid, missing and private targets cannot replace an existing public feature',async()=>{
 const cookie=`bl_admin=${await auth.createAdminSession()}`;
 for(const bracketId of [ids.draft,ids.test,ids.unknown,'bad-id',"' OR 1=1 --"]){
  const response=await adminApi.PUT(request({bracketId},cookie));assert.equal(response.status,400);assert.equal(current(),ids.public);
 }
 const oversized=await adminApi.PUT(request({bracketId:'x'.repeat(2048)},cookie));assert.equal(oversized.status,413);assert.equal(current(),ids.public);
 // A setting does not bypass a later visibility change.
 sqlite.prepare('UPDATE brackets SET is_test=1 WHERE id=?').run(ids.public);
 assert.equal(await featured.getFeaturedBracketId(),null);
 sqlite.prepare('UPDATE brackets SET is_test=0 WHERE id=?').run(ids.public);
 const cleared=await adminApi.PUT(request({bracketId:null},cookie));assert.equal(cleared.status,200);assert.equal(current(),null);assert.deepEqual(await cleared.json(),{featured:null});
});
