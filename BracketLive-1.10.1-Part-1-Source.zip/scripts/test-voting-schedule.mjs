import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {test} from 'node:test';

const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const code=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',code)(localRequire,module,module.exports);return module.exports;
}
const {resolveSchedule,readVotingSchedule,zonedDateTimeToTimestamp,formatZonedDateTime,formatScheduleDeadline,nextFutureWeeklyDeadline,rollRemainingWeeklyDeadlines,scheduleInputFromResolved}=loadSource('lib/voting-schedule.ts');
const {makeDraft,draftBracket,toDraft,publicVotingDraft}=loadSource('lib/bracket.ts');
const minute=60_000,hour=60*minute,ny='America/New_York',instant=(local,timezone=ny)=>zonedDateTimeToTimestamp(local,timezone);
const weekly=(first)=>({mode:'weekly',timezone:ny,tie_policy:'pause',first_closes_at:instant(first)});

test('weekly Sunday closing preserves local noon across spring DST, with a 167-hour interval',()=>{
 const schedule=resolveSchedule(weekly('2026-03-01T12:00'),8,0,instant('2026-02-28T12:00'));
 assert.deepEqual(schedule.deadlines.map(date=>formatZonedDateTime(date,ny)),['2026-03-01T12:00','2026-03-08T12:00','2026-03-15T12:00']);
 assert.equal(schedule.deadlines[1]-schedule.deadlines[0],167*hour);
 assert.equal(schedule.deadlines[2]-schedule.deadlines[1],168*hour);
 assert.match(formatScheduleDeadline(schedule.deadlines[1],ny),/Sun.*12:00 PM.*EDT/);
});

test('weekly Sunday closing preserves local noon across fall DST, with a 169-hour interval',()=>{
 const schedule=resolveSchedule(weekly('2026-10-25T12:00'),8,0,instant('2026-10-24T12:00'));
 assert.deepEqual(schedule.deadlines.map(date=>formatZonedDateTime(date,ny)),['2026-10-25T12:00','2026-11-01T12:00','2026-11-08T12:00']);
 assert.equal(schedule.deadlines[1]-schedule.deadlines[0],169*hour);
 assert.equal(schedule.deadlines[2]-schedule.deadlines[1],168*hour);
});

test('date input rejects missing or repeated local clock times instead of silently moving voting',()=>{
 assert.throws(()=>instant('2026-03-08T02:30'),/does not exist/);
 assert.throws(()=>instant('2026-11-01T01:30'),/occurs twice/);
 assert.throws(()=>instant('2026-10-04T02:15','Australia/Lord_Howe'),/does not exist/);
 assert.throws(()=>instant('2011-12-30T12:00','Pacific/Apia'),/does not exist/);
 assert.throws(()=>resolveSchedule(weekly('2026-03-01T02:30'),4,0,instant('2026-02-28T12:00')),/does not exist/);
 assert.throws(()=>resolveSchedule(weekly('2026-10-25T01:30'),4,0,instant('2026-10-24T12:00')),/occurs twice/);
});

test('calendar conversion handles fractional UTC offsets and rejects malformed dates and zones',()=>{
 assert.equal(instant('2026-10-11T12:15','Asia/Kolkata'),Date.parse('2026-10-11T06:45:00Z'));
 assert.equal(formatZonedDateTime(Date.parse('2026-10-11T06:45:00Z'),'Asia/Kolkata'),'2026-10-11T12:15');
 for(const local of ['2026-02-29T12:00','2026-13-01T12:00','2026-10-11T24:00','2026-10-11T12:60','today','0000-01-01T12:00'])assert.throws(()=>instant(local),/valid/);
 for(const timezone of ['No/Such_Zone','+05:30','',null,'a'.repeat(101)])assert.throws(()=>instant('2026-10-11T12:00',timezone),/valid/);
});

test('every supported size schedules precisely one deadline per remaining round',()=>{
 for(const size of [2,4,8,16,32,64,128]){
  const schedule=resolveSchedule(weekly('2026-10-11T12:00'),size,0,instant('2026-10-10T12:00'));
  assert.equal(schedule.deadlines.length,Math.log2(size));
  assert.ok(schedule.deadlines.every((deadline,round)=>round===0||deadline>schedule.deadlines[round-1]));
 }
 for(const size of [0,1,3,129,256])assert.throws(()=>resolveSchedule(weekly('2026-10-11T12:00'),size,0,instant('2026-10-10T12:00')),/bracket/);
 for(const round of [-1,1.5,7])assert.throws(()=>resolveSchedule(weekly('2026-10-11T12:00'),128,round,instant('2026-10-10T12:00')),/round/);
});

test('editing a current weekly round preserves completed history and starts from the new current date',()=>{
 const original=resolveSchedule(weekly('2026-10-04T12:00'),16,0,instant('2026-10-03T12:00'));
 const edited=resolveSchedule(weekly('2026-10-18T15:00'),16,1,instant('2026-10-12T12:00'),original);
 assert.equal(edited.deadlines[0],original.deadlines[0]);
 assert.deepEqual(edited.deadlines.slice(1).map(date=>formatZonedDateTime(date,ny)),['2026-10-18T15:00','2026-10-25T15:00','2026-11-01T15:00']);
 const input=scheduleInputFromResolved(edited,1);
 assert.equal(input.first_closes_at,edited.deadlines[1]);
 assert.deepEqual(resolveSchedule(input,16,1,instant('2026-10-12T12:00'),edited),edited);
 assert.deepEqual(original.deadlines.map(date=>formatZonedDateTime(date,ny)),['2026-10-04T12:00','2026-10-11T12:00','2026-10-18T12:00','2026-10-25T12:00']);
});

test('custom remaining dates must be full, future, increasing, and at least one minute apart',()=>{
 const now=instant('2026-10-10T12:00'),base={mode:'custom',timezone:ny,tie_policy:'seed'};
 const good=resolveSchedule({...base,deadlines:[now+minute,now+2*minute,now+3*minute]},8,0,now);
 assert.equal(good.tie_policy,'seed');
 for(const deadlines of [[now,now+minute,now+2*minute],[now+minute,now+minute,now+2*minute],[now+minute,now+minute+1,now+2*minute],[now+3*minute,now+2*minute,now+4*minute],[null,now+minute,now+2*minute],[now+minute],Array(3)])assert.throws(()=>resolveSchedule({...base,deadlines},8,0,now),/closing|close|minute|future/);
 assert.throws(()=>resolveSchedule({...base,deadlines:[now+minute,now+2*minute,now+6*366*24*hour]},8,0,now),/five years/);
 assert.throws(()=>resolveSchedule({...base,tie_policy:'coin',deadlines:good.deadlines},8,0,now),/tied/);
 const edited=resolveSchedule({...base,deadlines:[null,now+minute,now+2*minute]},8,1,now,{...good,deadlines:[now+10*minute,null,null]});
 assert.equal(edited.deadlines[0],now+10*minute,'an early manual advance does not rewrite its historical planned deadline');
 assert.deepEqual(readVotingSchedule(edited,8),edited,'persisted validation permits a historical planned date after a revised current date');
});

test('finish scheduling splits from the actual edit time, respecting one minute per remaining round',()=>{
 const now=instant('2026-10-10T12:00'),old={mode:'weekly',timezone:ny,tie_policy:'pause',deadlines:[now-2*minute,now-minute,now+minute]};
 const result=resolveSchedule({mode:'finish',timezone:ny,tie_policy:'pause',ends_at:now+4*minute},8,1,now,old,now-100*minute);
 assert.deepEqual(result.deadlines,[old.deadlines[0],now+2*minute,now+4*minute]);
 assert.equal(scheduleInputFromResolved(result,1).ends_at,now+4*minute);
 assert.throws(()=>resolveSchedule({mode:'finish',timezone:ny,tie_policy:'pause',ends_at:now+2*minute-1},8,1,now,old),/at least one minute/);
});

test('manual scheduling removes all remaining deadlines while preserving completed history and safe tie default',()=>{
 const now=instant('2026-10-10T12:00'),old={mode:'weekly',timezone:ny,tie_policy:'seed',deadlines:[now-minute,now+minute,now+2*minute]};
 const result=resolveSchedule({mode:'manual',timezone:ny},8,1,now,old);
 assert.deepEqual(result.deadlines,[old.deadlines[0],null,null]);assert.equal(result.tie_policy,'pause');
});

test('a missed weekly slot rebases unplayed rounds to a future Sunday without fabricating catch-up results',()=>{
 const schedule=resolveSchedule(weekly('2026-06-07T12:00'),16,0,instant('2026-06-06T12:00'));
 const now=instant('2026-06-29T12:00'),rolled=rollRemainingWeeklyDeadlines(schedule,1,now);
 assert.equal(rolled.deadlines[0],schedule.deadlines[0]);
 assert.deepEqual(rolled.deadlines.slice(1).map(date=>formatZonedDateTime(date,ny)),['2026-07-05T12:00','2026-07-12T12:00','2026-07-19T12:00']);
 assert.ok(rolled.deadlines.slice(1).every(date=>date>now));
 assert.equal(schedule.deadlines[1],instant('2026-06-14T12:00'),'the input schedule remains unchanged');
 assert.equal(nextFutureWeeklyDeadline(schedule.deadlines[0],ny,schedule.deadlines[0]),schedule.deadlines[1],'exactly closed means next week');
 assert.equal(nextFutureWeeklyDeadline(schedule.deadlines[0],ny,schedule.deadlines[0]-1),schedule.deadlines[0]);
 assert.deepEqual(rollRemainingWeeklyDeadlines({...schedule,mode:'custom'},1,now),{...schedule,mode:'custom'},'fixed custom deadlines never move implicitly');
});

test('persisted schedules require valid shapes and safe timestamps, without treating elapsed dates as malformed',()=>{
 const old={mode:'weekly',timezone:ny,tie_policy:'pause',deadlines:[instant('2020-10-04T12:00'),instant('2020-10-11T12:00')]};
 assert.deepEqual(readVotingSchedule(JSON.stringify(old),4),old);
 for(const value of [null,'not json',[],{}, {...old,timezone:'unknown'}, {...old,deadlines:[Infinity,NaN]}, {...old,deadlines:[1.5,2.5]}, {...old,deadlines:[null]}, {...old,deadlines:Array(8).fill(null)}])assert.equal(readVotingSchedule(value,4),null);
});

test('bracket copies preserve schedule edits but public practice publishing starts with fresh voting dates',()=>{
 const draft=makeDraft(8,false),bracket=draftBracket(draft),schedule=resolveSchedule(weekly('2026-10-11T12:00'),8,0,instant('2026-10-10T12:00'));
 bracket.voting_schedule=schedule;bracket.current_round=1;bracket.ends_at=schedule.deadlines.at(-1);
 const copied=toDraft(bracket);
 assert.equal(copied.voting_schedule.first_closes_at,schedule.deadlines[1]);
 assert.deepEqual(copied.voting_schedule.deadlines,schedule.deadlines);
 assert.notEqual(copied.voting_schedule.deadlines,schedule.deadlines);
 const published=publicVotingDraft(bracket);
 assert.equal(published.ends_at,null);assert.equal(published.voting_schedule,undefined);assert.equal(published.listed,true);
 assert.equal(draftBracket({...draft,voting_schedule:copied.voting_schedule}).voting_schedule,null);
});
