import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {test} from 'node:test';

const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
function load(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id.startsWith('.')?load(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);return module.exports;
}
const {bracketSnapshot,renderBracketSvg,bracketSnapshotCsv,artworkSources,exportFilename}=load('lib/bracket-export.ts');
const {makeDraft,makeTemplateDraft,draftBracket}=load('lib/bracket.ts');
const {basketballEntries}=load('lib/basketball-template.ts');
const {animeSource,animeLogo}=load('lib/anime-roster.ts');
const legacyDraft=size=>{const d=makeDraft(size,true);d.entries=d.entries.map((e,i)=>({...e,image:`${animeSource}#slot=${i+1}`}));return d;};
const at=new Date('2026-10-05T04:00:00.000Z');
function completed(size=64){
 const b=draftBracket(makeDraft(size,true));b.status='complete';b.current_round=Math.log2(size)-1;
 for(const m of b.matches){
  if(m.round){m.a_id=b.matches.find(x=>x.round===m.round-1&&x.position===m.position*2).winner_id;m.b_id=b.matches.find(x=>x.round===m.round-1&&x.position===m.position*2+1).winner_id;}
  m.winner_id=m.a_id;m.counts={[m.a_id]:3,[m.b_id]:1};m.total=4;m.status='closed';
 }
 return b;
}

test('64-entry final export includes all 63 matches, every round, complete names, champion and timestamp',()=>{
 const b=completed(),snap=bracketSnapshot(b,at),{svg,width,height}=renderBracketSvg(snap);
 assert.equal((svg.match(/data-match-id=/g)||[]).length,63);
 assert.equal(snap.matches.length,63);assert.equal(snap.entries.length,64);
 for(const match of b.matches)assert.ok(svg.includes(`data-match-id="${match.id}"`));
 assert.ok(svg.includes('63 / 63 matches decided'));
 assert.ok(svg.includes('CHAMPION'));assert.ok(svg.includes('Hollowfication'));
 assert.ok(svg.includes('75%'));assert.ok(svg.includes('25%'));assert.ok(svg.includes('2026-10-05 04:00:00 UTC'));
 assert.ok(width>3000&&height>2600,'whole export is independent of viewport zoom');
 assert.equal(snap.tournament.format,'standard');
});
test('draft and partial-round exports retain pending paths without leaking hidden vote totals',()=>{
 const b=draftBracket(legacyDraft(64));b.matches[0].total=987654;
 const snap=bracketSnapshot(b,at),{svg}=renderBracketSvg(snap);
 assert.equal((svg.match(/data-match-id=/g)||[]).length,63);
 assert.ok(svg.includes('Winner of match 1'));assert.ok(svg.includes('To be decided'));
 assert.ok(!svg.includes('987654'));assert.ok(!svg.includes('0 votes'));assert.ok(!svg.includes('0%'));
 assert.equal(snap.matches[0].total,null);assert.equal(snap.matches[0].counts,null);
 const csv=bracketSnapshotCsv(snap);assert.ok(!csv.includes('987654'));assert.ok(csv.includes('"","","","",""'));
 const final=completed();final.matches.at(-1).winner_id=null;final.matches.at(-1).status='open';
 const partial=renderBracketSvg(bracketSnapshot(final,at)).svg;
 assert.ok(partial.includes('62 / 63 matches decided'));assert.ok(!partial.includes('>CHAMPION<'));
});
test('snapshot is detached from future live updates and contains no organizer access metadata',()=>{
 const b=completed(4),snap=bracketSnapshot(b,at);b.entries[0].name='Changed after export';b.matches[0].counts[b.matches[0].a_id]=500;
 assert.notEqual(snap.entries[0].name,b.entries[0].name);assert.equal(snap.matches[0].counts[snap.matches[0].a_id],3);
 assert.equal(snap.tournament.isOwner,undefined);assert.equal(snap.tournament.manage_key,undefined);
 assert.match(exportFilename(snap,'svg'),/complete-r2-2026-10-05T04-00-00-000Z\.svg$/);
});
test('SVG escapes untrusted text, asset addresses, and colors; CSV protects formula-like names',()=>{
 const b=completed(4);b.title='A & B <script>alert("x")</script>';b.entries[0].name='=HYPERLINK("evil")';b.description='" onload="alert(1)';b.appearance.colors={card:'" onload="alert(1)'};
 const snap=bracketSnapshot(b,at),{svg}=renderBracketSvg(snap,{images:{[animeSource]:'javascript:alert(1)'},warnings:[]});
 assert.ok(!svg.includes('<script>'));assert.ok(svg.includes('&lt;script&gt;'));assert.ok(!svg.includes(' onload="'));assert.ok(!svg.includes('javascript:'));
 assert.ok(bracketSnapshotCsv(snap).includes('"\'=HYPERLINK(""evil"")"'));
});
test('artwork preserves all 64 original sprite crops and embeds each source only once',()=>{
 const b=draftBracket(legacyDraft(64));b.brand_image='/api/media/brand.png';b.appearance.images={board_background:'/api/media/bg.png',center_logo:'/api/media/brand.png'};
 const snap=bracketSnapshot(b,at),sources=artworkSources(snap),png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB';
 assert.equal(sources.filter(x=>x===animeSource).length,1);assert.equal(sources.length,3);
 const artwork={images:Object.fromEntries(sources.map(x=>[x,png])),dimensions:{'/api/media/brand.png':{width:120,height:40},'/api/media/bg.png':{width:400,height:300}},warnings:[]};
 const {svg}=renderBracketSvg(snap,artwork);
 assert.equal((svg.match(/data:image\/png/g)||[]).length,3);
 for(const entry of b.entries){const crop=animeLogo(entry.image);assert.ok(svg.includes(`viewBox="${crop.x} ${crop.y} ${crop.width} ${crop.height}"`));}
 assert.ok(svg.includes('viewBox="0 0 120 40"'));assert.ok(!svg.includes('href="/api/media/'));assert.ok(!svg.includes('href="/templates/'));
 const failed=renderBracketSvg(snap,{images:{},warnings:['Missing image']}).svg;
 assert.ok(failed.includes('1 image was unavailable'));assert.ok(failed.includes('×'));
});
test('2026 NCAA example exports its real field, regional seeds, round labels, and undecided results',()=>{
 const b=draftBracket(makeTemplateDraft('basketball')),snap=bracketSnapshot(b,at),{svg}=renderBracketSvg(snap);
 assert.equal(snap.tournament.format,'ncaa2026');
 for(const region of ['EAST','SOUTH','WEST','MIDWEST'])assert.ok(svg.includes(`>${region}<`));
 assert.ok(svg.indexOf('>SOUTH<')<svg.indexOf('>WEST<'),'export follows 2026 regional semifinal pairing order');
 for(const round of ['Round of 64','Sweet 16','Elite Eight','Final Four'])assert.ok(svg.includes(round));
 const csv=bracketSnapshotCsv(snap);
 for(const name of ['Duke','Florida','Arizona','Michigan','Howard','Texas','Prairie View A&M','Miami (Ohio)'])assert.ok(csv.includes(`"${name}"`));
 assert.ok(csv.includes('"Duke","Siena"'));assert.ok(csv.includes('"Tennessee","Miami (Ohio)"'));
 assert.ok(svg.includes('0 / 63 matches decided'));
 assert.ok(snap.matches.every(m=>m.winner_id===null));
 assert.ok(!svg.includes('>64</text>'),'display seeds repeat 1–16, rather than ordinal positions');
 assert.equal((svg.match(/>16<\/text>/g)||[]).length,4);
});
test('legacy basketball exports retain their original four-region order and 1–16 seeds',()=>{
 const draft={...makeDraft(64,false),format:'basketball',entries:basketballEntries()};
 const snap=bracketSnapshot(draftBracket(draft),at),{svg}=renderBracketSvg(snap);
 assert.equal(snap.tournament.format,'basketball');
 const order=['EAST','WEST','SOUTH','MIDWEST'].map(region=>svg.indexOf(`>${region}<`));
 assert.ok(order.every(i=>i>=0));assert.deepEqual([...order].sort((a,b)=>a-b),order);
 assert.equal((svg.match(/>16<\/text>/g)||[]).length,4);
});
test('sprite crops clip their exact source rectangles, including repeated winners and letterboxed image slots',()=>{
 const b=completed(64);b.entries.forEach((e,i)=>{e.image=`${animeSource}#slot=${i+1}`;});const snap=bracketSnapshot(b,at),png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB';
 const {svg}=renderBracketSvg(snap,{images:{[animeSource]:png},warnings:[]});
 const sprites=[...svg.matchAll(/<svg\b[^>]*viewBox="(\d+) (\d+) (\d+) (\d+)"[^>]*preserveAspectRatio="xMidYMid meet"[^>]*>(.*?)<\/svg>/gs)];
 // 126 match contenders plus the champion artwork. Repeated winner logos
 // need their own clip IDs, not duplicate IDs referring to another crop.
 assert.equal(sprites.length,127);
 const clipIds=[];
 for(const [,x,y,width,height,content] of sprites){
  const clip=content.match(/<clipPath id="([^"]+)" clipPathUnits="userSpaceOnUse"><rect x="(\d+)" y="(\d+)" width="(\d+)" height="(\d+)"\/><\/clipPath>/);
  assert.ok(clip,'each sprite needs an explicit source-coordinate clip');
  assert.deepEqual(clip.slice(2),[x,y,width,height]);
  assert.ok(content.includes(`<g clip-path="url(#${clip[1]})"><use href="#export-image-0"`),'the actual image use must be inside the clipping group');
  clipIds.push(clip[1]);
 }
 assert.equal(new Set(clipIds).size,clipIds.length);
});
test('personal picks exports are labeled predictions, omit global counts, and identify the chosen champion',()=>{
 const snap=bracketSnapshot(completed(64),at,'picks'),{svg}=renderBracketSvg(snap);
 assert.equal(snap.kind,'picks');assert.ok(snap.matches.every(m=>m.counts===null&&m.total===null));
 assert.ok(svg.includes('YOUR CHAMPION'));assert.ok(svg.includes('63 / 63 personal picks filled'));
 assert.ok(!svg.includes('75%'));assert.ok(!svg.includes('Unrevealed vote totals'));
 assert.ok(bracketSnapshotCsv(snap).includes('"Predicted winner"'));
});
for(const size of [2,128])test(`${size}-entry exports preserve all matches and the complete winner path`,()=>{
 const b=completed(size),snap=bracketSnapshot(b,at),{svg,width,height}=renderBracketSvg(snap);
 assert.equal((svg.match(/data-match-id=/g)||[]).length,size-1);
 assert.ok(svg.includes(`${size-1} / ${size-1} matches decided`));assert.ok(svg.includes('CHAMPION'));
 assert.ok(width>=1000&&height>0,'small brackets retain enough room for the export header');
 const scale=Math.min(1.5,Math.sqrt(20000000/(width*height)),8192/Math.max(width,height));
 assert.ok(Math.round(width*scale)*Math.round(height*scale)<=20005000,'PNG stays within the intended memory budget');
 const pending=renderBracketSvg(bracketSnapshot(draftBracket(makeDraft(size,false)),at)).svg;
 assert.equal((pending.match(/data-match-id=/g)||[]).length,size-1);
});
test('two-entry export fits a long wide-glyph title and description without colliding with the timestamp',()=>{
 const b=draftBracket(makeDraft(2,false));b.title='W'.repeat(100);b.description='W'.repeat(400);b.brand_image='/media/brand.png';
 const {svg,width}=renderBracketSvg(bracketSnapshot(b,at));
 assert.equal(width,1000);
 const title=svg.match(/<text x="(\d+)" y="53"[^>]*font-size="29"[^>]*>([^<]+)<\/text>/);
 const description=svg.match(/<text x="(\d+)" y="133"[^>]*font-size="12"[^>]*>([^<]+)<\/text>/);
 assert.ok(title&&description);assert.ok(title[2].endsWith('…'));assert.ok(description[2].endsWith('…'));
 assert.ok(Number(title[1])+Array.from(title[2]).length*29<=width-26);
 assert.ok(Number(description[1])+Array.from(description[2]).length*12<=width-26);
 assert.match(svg,/<text[^>]* y="107"[^>]*>Snapshot:/,'timestamp stays on its own row');
 assert.ok(svg.includes(`<title id="export-title">${b.title}</title>`),'full title remains available in SVG metadata');
});
