// Build-time only. The generated SQL is executed ONLY by the isolated --local
// preview launcher, never by migrations or production deployment.
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
function load(file){file=path.resolve(root,file);if(!path.extname(file))file+='.ts';if(modules.has(file))return modules.get(file).exports;const module={exports:{}};modules.set(file,module);const source=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;new Function('require','module','exports',source)(id=>id.startsWith('.')?load(path.resolve(path.dirname(file),id)):require(id),module,module.exports);return module.exports;}
const draft=load('lib/bracket.ts').makeTemplateDraft('trial');
const id='00000000-0000-4000-8000-000000000064';
const q=value=>value===null?'NULL':typeof value==='number'?String(value):"'"+String(value).replaceAll("'","''")+"'";
const insert=(table,values)=>`INSERT OR IGNORE INTO ${table} (${Object.keys(values).join(',')}) VALUES (${Object.values(values).map(q).join(',')});`;
const lines=['-- ISOLATED LOCAL PREVIEW ONLY. Never execute this file against a remote DB.','PRAGMA foreign_keys=ON;',insert('brackets',{id,title:draft.title,description:draft.description,size:64,format:draft.format,accent:draft.accent,brand_color:draft.brand_color,brand_image:draft.brand_image,appearance:JSON.stringify(draft.appearance),status:'live',current_round:0,owner_id:'preview-only-no-owner',manage_hash:'disabled-local-preview',created_at:1791244800000,listed:1,is_test:0,started_at:1791244800000})];
const eid=i=>`10000000-0000-4000-8000-${String(i+1).padStart(12,'0')}`;
draft.entries.forEach((entry,i)=>lines.push(insert('entries',{id:eid(i),bracket_id:id,...entry})));
let number=0;
for(let round=0;round<6;round++)for(let pos=0;pos<64/2**(round+1);pos++)lines.push(insert('matches',{id:`20000000-0000-4000-8000-${String(++number).padStart(12,'0')}`,bracket_id:id,round,position:pos,a_id:round===0?eid(pos*2):null,b_id:round===0?eid(pos*2+1):null,status:round===0?'open':'pending'}));
lines.push(insert('site_settings',{key:'featured_bracket_id',value:id,updated_at:1791244800000}));
fs.writeFileSync(path.join(root,'scripts/preview-seed.sql'),lines.join('\n')+'\n');
