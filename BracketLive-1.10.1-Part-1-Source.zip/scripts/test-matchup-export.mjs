import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {test} from 'node:test';

const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
function load(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 new Function('require','module','exports',compiled)(id=>id.startsWith('.')?load(path.resolve(path.dirname(file),id)):require(id),module,module.exports);return module.exports;
}
const {matchupSnapshot,renderMatchupSvg,matchupArtworkSource,matchupArtworkSources,prepareMatchupArtwork,prepareLocalMatchupImage,matchupFilename,matchupSizes}=load('lib/matchup-export.ts');
const {makeDraft,draftBracket}=load('lib/bracket.ts');
const {animeSource,animeLogo}=load('lib/anime-roster.ts');
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB';
const media='/api/media/12345678-abcd-1234-abcd-123456789abc.png';
function fixture(){const bracket=draftBracket(makeDraft(4,true));bracket.entries.forEach((e,i)=>{e.image=`${animeSource}#slot=${i+1}`;});return {bracket,match:bracket.matches[0]};}

test('all video/social sizes are exact, deterministic and independent of the viewport',()=>{
 const {bracket,match}=fixture(),snapshot=matchupSnapshot(bracket,match);
 for(const [format,{width,height}] of Object.entries(matchupSizes)){
  const rendered=renderMatchupSvg(snapshot,{format});
  assert.equal(rendered.width,width);assert.equal(rendered.height,height);
  assert.ok(rendered.svg.includes(`viewBox="0 0 ${width} ${height}"`));
  assert.equal(rendered.svg,renderMatchupSvg(snapshot,{format}).svg);
  assert.equal((rendered.svg.match(/data-side=/g)||[]).length,2);
 }
});
test('unrevealed and personal-pick vote counts never enter snapshots or artwork',()=>{
 const {bracket,match}=fixture();match.total=7654321;match.counts=null;
 for(const kind of ['results','picks']){
  const snapshot=matchupSnapshot(bracket,match,{},kind);
  assert.equal(snapshot.results,null);
  const {svg}=renderMatchupSvg(snapshot,{format:'landscape',showResults:true});
  assert.ok(!svg.includes('7654321'));assert.ok(!svg.includes('>0%'));assert.ok(!svg.includes('VOTE RESULTS'));
 }
 match.counts={[match.a_id]:3,[match.b_id]:1};match.total=4;
 const snapshot=matchupSnapshot(bracket,match),visible=renderMatchupSvg(snapshot,{format:'square',showResults:true}).svg;
 assert.deepEqual(snapshot.results,{a:3,b:1,total:4});assert.ok(visible.includes('75%'));assert.ok(visible.includes('25%'));
 assert.ok(!renderMatchupSvg(snapshot,{format:'square'}).svg.includes('>75%'));
 assert.equal(matchupSnapshot(bracket,match,{},'picks').results,null);
});
test('local design overrides never mutate contenders or include organizer identity data',()=>{
 const {bracket,match}=fixture();bracket.manage_key='secret';bracket.identity='secret';
 const snapshot=matchupSnapshot(bracket,match,{a:{name:'Local design',image:null},title:'A separate image',background:media});
 assert.equal(snapshot.a.name,'Local design');assert.equal(snapshot.a.image,null);
 assert.notEqual(bracket.entries[0].name,'Local design');assert.ok(bracket.entries[0].image);
 assert.equal(snapshot.title,'A separate image');assert.equal(snapshot.background,media);
 assert.ok(!JSON.stringify(snapshot).includes('secret'));
 bracket.entries[1].name='After snapshot';assert.notEqual(snapshot.b.name,'After snapshot');
});
test('future matches and text-only contenders render useful artwork without inventing winners or results',()=>{
 const {bracket}=fixture(),match=bracket.matches.at(-1),snapshot=matchupSnapshot(bracket,match);
 assert.equal(snapshot.a.name,'Winner of match 1');assert.equal(snapshot.b.name,'Winner of match 2');assert.equal(snapshot.results,null);
 const overridden=matchupSnapshot(bracket,match,{a:{name:'North',subtitle:'Club A'},b:{name:'South',subtitle:'Club B'}});
 assert.equal(overridden.a.id,null);assert.equal(overridden.a.name,'North');
 const {svg}=renderMatchupSvg(overridden,{format:'portrait',showResults:true});
 for(const label of ['North','South','Club A','Club B'])assert.ok(svg.includes(label));
 assert.ok(!svg.includes('>0%'));assert.ok(!svg.includes('Winner:'));
});
test('SVG escapes text and rejects hostile colors, external images, SVG data URLs and unsafe image dimensions',()=>{
 const {bracket,match}=fixture();bracket.title='<script>alert("x")</script>';
 const snapshot=matchupSnapshot(bracket,match,{a:{name:'A & B <img onerror="bad">',image:'https://evil.example/image.png'},accent:'url(https://evil.example)'});
 snapshot.cardColor='" onload="evil';
 const {svg}=renderMatchupSvg(snapshot,{format:'landscape'},{images:{'https://evil.example/image.png':png,[media]:'data:image/svg+xml;base64,AAAA',[animeSource]:png},dimensions:{[animeSource]:{width:'" onload="x',height:1}},warnings:[]});
 assert.ok(!svg.includes('<script>'));assert.ok(svg.includes('&lt;script&gt;'));
 assert.ok(!svg.includes('<img'));assert.ok(!svg.includes(' onload="'));assert.ok(!svg.includes('onerror="'));
 assert.ok(!svg.includes('evil.example'));assert.ok(!svg.includes('data:image/svg'));
 for(const bad of ['//evil.example/test.png','https://example.test'+media,'blob:https://example.test/a','data:image/png;base64,AAAA','/api/media/../private','/api/media/x.svg','/templates/arbitrary.png',media+'?redirect=evil'])assert.equal(matchupArtworkSource(bad),null);
 assert.equal(matchupArtworkSource(media),media);assert.equal(matchupArtworkSource(bracket.entries[0].image),animeSource);
});
test('artwork shares one safe sprite and clips each logo without neighboring rows',()=>{
 const {bracket,match}=fixture(),snapshot=matchupSnapshot(bracket,match,{logo:media,background:media});
 assert.deepEqual(matchupArtworkSources(snapshot),[animeSource,media]);
 const {svg}=renderMatchupSvg(snapshot,{format:'landscape'},{images:{[animeSource]:png,[media]:png},dimensions:{[media]:{width:500,height:100}},warnings:[]});
 assert.equal((svg.match(/data:image\/png/g)||[]).length,2);
 for(const side of [snapshot.a,snapshot.b]){
  const crop=animeLogo(side.image);assert.ok(svg.includes(`viewBox="${crop.x} ${crop.y} ${crop.width} ${crop.height}"`));
  assert.ok(svg.includes(`x="${crop.x}" y="${crop.y}" width="${crop.width}" height="${crop.height}"`));
 }
 assert.equal((svg.match(/id="vs-crop-/g)||[]).length,2);
 assert.ok(svg.includes('preserveAspectRatio="xMidYMid meet"'));assert.ok(!svg.includes('href="/api/media'));
});
test('transparent video overlays omit all canvas backgrounds while preserving contender panels',()=>{
 const {bracket,match}=fixture(),snapshot=matchupSnapshot(bracket,match,{background:media});
 const {svg}=renderMatchupSvg(snapshot,{format:'landscape',transparent:true},{images:{[media]:png},warnings:[]});
 assert.ok(!svg.includes('<rect x="0" y="0" width="1920" height="1080"'));
 assert.ok(!svg.includes('aria-label="Background"'));assert.ok(svg.includes('data-side="a"'));
 assert.match(matchupFilename(snapshot,{format:'landscape',transparent:true},'png'),/-landscape-transparent\.png$/);
});
test('extreme labels are fitted to bounded lines while retaining full accessible descriptions',()=>{
 const {bracket,match}=fixture(),name='W'.repeat(500),subtitle='界'.repeat(250),snapshot=matchupSnapshot(bracket,match,{title:name,a:{name,subtitle}});
 for(const format of Object.keys(matchupSizes)){
  const {svg,width,height}=renderMatchupSvg(snapshot,{format});
  assert.ok(svg.includes(`<title>${name} — ${subtitle}</title>`));
  assert.ok(svg.includes('…'));
  for(const [,x,y,fontSize,value] of svg.matchAll(/<text x="([\d.]+)" y="([\d.]+)" font-size="([\d.]+)"[^>]*>([^<]*)<\/text>/g)){
   assert.ok(+x>0&&+x<width);assert.ok(+y>0&&+y<height);
   if(/^[W…]+$/.test(value))assert.ok(Array.from(value).length*+fontSize<=width-100,'wide glyph text stays inside the export');
  }
 }
});
test('unsupported image addresses never result in a fetch, including external redirects',async()=>{
 const {bracket,match}=fixture(),snapshot=matchupSnapshot(bracket,match,{a:{image:'https://evil.example/a.png'},b:{image:null}});
 let fetched=0;const priorFetch=globalThis.fetch;globalThis.fetch=async()=>{fetched++;throw new Error('Should not fetch');};
 try{const artwork=await prepareMatchupArtwork(snapshot);assert.equal(fetched,0);assert.equal(artwork.warnings.length,1);}finally{globalThis.fetch=priorFetch;}
});
test('local artwork rejects SVG and oversized files before decoding or creating an object URL',async()=>{
 await assert.rejects(prepareLocalMatchupImage(new Blob(['<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'],{type:'image/png'})),/damaged or unsupported/);
 await assert.rejects(prepareLocalMatchupImage(new Blob([new Uint8Array(5*1024*1024+1)])),/smaller than 5 MB/);
 assert.equal(matchupArtworkSource('blob:https://bracket.example/forged-local-file'),null);
});
