import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtemp, readFile, writeFile, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { configureCloudflare } from './configure-cloudflare.mjs';
import { configureSecurity } from './configure-security.mjs';

const realId = '12345678-1234-4234-9234-123456789abc';
const originalConfig = {
  name: 'bracketlive', main: 'dist/server/index.js', workers_dev: true,
  d1_databases: [{ binding: 'DB', database_name: 'bracketlive', database_id: '00000000-0000-4000-8000-000000000000', migrations_dir: 'drizzle' }],
  r2_buckets: [{ binding: 'BUCKET', bucket_name: 'bracketlive-media' }],
};

async function withProject(fn) {
  const root = await mkdtemp(join(tmpdir(), 'bracket-cloudflare-'));
  try {
    await writeFile(join(root, 'wrangler.json'), JSON.stringify(originalConfig));
    await fn(root);
  } finally { await rm(root, { recursive: true, force: true }); }
}

test('configure saves the DB ID, preserves deployment settings, and reuses the private key', async () => {
  await withProject(async (root) => {
    assert.deepEqual(await configureCloudflare(root, `  ${realId.toUpperCase()}  `), { createdKey: true });
    const key = await readFile(join(root, '.admin-key'), 'utf8');
    assert.match(key, /^[0-9a-f]{64}\n$/);
    const config = JSON.parse(await readFile(join(root, 'wrangler.json'), 'utf8'));
    assert.equal(config.ratelimits.length, 5);
    assert.deepEqual(config.triggers,{crons:['* * * * *']});
    assert.deepEqual(config.assets.run_worker_first,['/','/discord','/discord/','/api/discord/*']);
    const {ratelimits, triggers, assets, ...deployment} = config;
    assert.deepEqual(deployment, { ...originalConfig, d1_databases: [{ ...originalConfig.d1_databases[0], database_id: realId }] });
    if (process.platform !== 'win32') assert.equal((await stat(join(root, '.admin-key'))).mode & 0o777, 0o600);
    assert.deepEqual(await configureCloudflare(root, realId), { createdKey: false });
    assert.equal(await readFile(join(root, '.admin-key'), 'utf8'), key);
  });
});

test('scheduler setup preserves existing cron triggers and is idempotent', async()=>{
 await withProject(async root=>{
  const original={...originalConfig,triggers:{crons:['0 2 * * *'],custom:'preserve'},routes:['example.com/*'],vars:{AUTH_ORIGIN:'https://example.com'}};
  await writeFile(join(root,'wrangler.json'),JSON.stringify(original));
  const configured=await configureSecurity(root);
  assert.deepEqual(configured.triggers,{crons:['0 2 * * *','* * * * *'],custom:'preserve'});
  assert.deepEqual(configured.routes,original.routes);assert.deepEqual(configured.vars,original.vars);
  assert.deepEqual(await configureSecurity(root),configured);
 });
});

test('invalid IDs and placeholders do not change the config or create a key', async () => {
  await withProject(async (root) => {
    const original = await readFile(join(root, 'wrangler.json'), 'utf8');
    for (const id of ['', '1234567890abcdef1234567890abcdef', 'DATABASE_UUID', '00000000-0000-4000-8000-000000000000', '00000000-0000-0000-0000-000000000000']) {
      await assert.rejects(configureCloudflare(root, id), /real database_id/);
      assert.equal(await readFile(join(root, 'wrangler.json'), 'utf8'), original);
      await assert.rejects(readFile(join(root, '.admin-key')), { code: 'ENOENT' });
    }
  });
});

test('an unexpected existing key is preserved and setup fails without changing config', async () => {
  await withProject(async (root) => {
    const original = await readFile(join(root, 'wrangler.json'), 'utf8');
    await writeFile(join(root, '.admin-key'), 'do-not-replace');
    await assert.rejects(configureCloudflare(root, realId), /will not overwrite/);
    assert.equal(await readFile(join(root, '.admin-key'), 'utf8'), 'do-not-replace');
    assert.equal(await readFile(join(root, 'wrangler.json'), 'utf8'), original);
  });
});

test('a missing or duplicate DB binding fails before creating a key', async () => {
  await withProject(async (root) => {
    for (const databases of [[], [...originalConfig.d1_databases, ...originalConfig.d1_databases]]) {
      await writeFile(join(root, 'wrangler.json'), JSON.stringify({ ...originalConfig, d1_databases: databases }));
      await assert.rejects(configureCloudflare(root, realId), /exactly one D1/);
      await assert.rejects(readFile(join(root, '.admin-key')), { code: 'ENOENT' });
    }
  });
});
