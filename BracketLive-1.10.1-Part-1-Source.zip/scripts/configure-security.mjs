import {readFile,writeFile} from 'node:fs/promises';
import {randomInt} from 'node:crypto';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

export const limits={SECURITY_READ_LIMIT:1200,SECURITY_WRITE_LIMIT:300,SECURITY_AUTH_LIMIT:20,SECURITY_CREATE_LIMIT:12,SECURITY_UPLOAD_LIMIT:90};
export async function configureSecurity(root){
 const file=resolve(root,'wrangler.json');
 const config=JSON.parse(await readFile(file,'utf8'));
 if(!config.d1_databases?.some(d=>d.binding==='DB')||!config.r2_buckets?.some(d=>d.binding==='BUCKET'))throw Error('Expected the existing Bracket Live wrangler.json with DB and BUCKET bindings.');
 const rateLimits=config.ratelimits??=[];
 if(!Array.isArray(rateLimits))throw Error('Invalid ratelimits in wrangler.json.');
 const used=new Set(rateLimits.map(x=>String(x.namespace_id)));
 for(const [name,limit] of Object.entries(limits)){
  const matching=rateLimits.filter(x=>x.name===name);
  if(matching.length>1)throw Error(`Duplicate binding: ${name}`);
  if(matching.length){matching[0].simple={limit,period:60};continue;}
  let id;do{id=String(randomInt(100000000,2147483647));}while(used.has(id));used.add(id);
  rateLimits.push({name,namespace_id:id,simple:{limit,period:60}});
 }
 config.ratelimits=rateLimits;
 // The Activity document must reach the Worker even when asset routing wins.
 const assets={...(config.assets??{}),binding:'ASSETS'};
 config.assets=assets;
 const first=assets.run_worker_first;
 if(first!==true)config.assets={...assets,run_worker_first:Array.from(new Set([...(Array.isArray(first)?first:[]),'/', '/discord','/discord/','/api/discord/*']))};
 // Poll due tournaments independently of visits. App deadlines remain UTC
 // instants calculated from each tournament's chosen timezone.
 const triggers=config.triggers??{};
 if(typeof triggers!=='object'||Array.isArray(triggers)||triggers===null)throw Error('Invalid triggers in wrangler.json.');
 const crons=triggers.crons??[];
 if(!Array.isArray(crons)||crons.some(x=>typeof x!=='string'))throw Error('Invalid cron triggers in wrangler.json.');
 config.triggers={...triggers,crons:Array.from(new Set([...crons,'* * * * *']))};
 await writeFile(file,JSON.stringify(config,null,2)+'\n');
 return config;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 configureSecurity(resolve(dirname(fileURLToPath(import.meta.url)),'..')).then(()=>console.log('Security limits and tournament scheduler configured. Existing database, bucket, routes, and secrets preserved.')).catch(e=>{console.error(e.message);process.exitCode=1;});
}
