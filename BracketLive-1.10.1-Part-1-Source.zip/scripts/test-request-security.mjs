import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {test} from 'node:test';
import {mkdtemp,readFile,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {configureSecurity,limits} from './configure-security.mjs';
const require=createRequire(import.meta.url),ts=require('typescript'),module={exports:{}};
const source=fs.readFileSync(new URL('../lib/request-security.ts',import.meta.url),'utf8');
new Function('module','exports',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(module,module.exports);
const {secureRequest}=module.exports,origin='https://bracket.example';
const request=(path='/',method='GET',extra={})=>new Request(origin+path,{method,...(method==='GET'?{}:{body:'{}'}),headers:{Origin:origin,'Content-Type':'application/json','cf-connecting-ip':'203.0.113.4',...extra}});
const environment=()=>Object.fromEntries(Object.keys(limits).map(name=>[name,{limit:async()=>({success:true})}]));

test('boundary rejects unsupported actions, foreign origins, encoded routing and oversized bodies before handler',async()=>{
 const blocked=[
  [request('/','POST'),405],
  [request('/api/brackets','POST',{'next-action':'attacker'}),400],
  [request('/api/brackets','POST',{'rsc-action':'attacker'}),400],
  [request('/api/brackets','POST',{Origin:'https://evil.example'}),403],
  [request('/api/brackets','POST',{'sec-fetch-site':'same-site'}),403],
  [request('/api/brackets','POST',{'Content-Type':'text/plain'}),415],
  [request('/api/media','POST',{'Content-Type':'multipart/form-data; boundary=attack'}),415],
  [request('/api/media','POST',{'Content-Type':'application/x-www-form-urlencoded'}),415],
  [request('/api/brackets','POST',{'Content-Length':'150001'}),413],
  [request('/api/media','POST',{'Content-Length':String(5*1024*1024+1)}),413],
  [request('/api/brackets%2F123','POST'),400],
 ];
 const missing=request('/api/brackets','POST');missing.headers.delete('Origin');blocked.push([missing,403]);
 for(const [req,status] of blocked){const response=await secureRequest(req,environment(),()=>{throw Error('Boundary bypass');});assert.equal(response.status,status);assert.equal(response.headers.get('X-Frame-Options'),'DENY');}
});

test('untrusted internal headers removed, navigation headers retained, fresh nonces and security headers applied',async()=>{
 const seen=[];
 const handler=req=>{seen.push(req);return new Response('<html></html>',{headers:{'Content-Type':'text/html','Cache-Control':'public,max-age=999','X-Powered-By':'test'}});};
 const headers={'x-vinext-prerender-secret':'spoof','x-middleware-subrequest':'spoof','oai-authenticated-user-id':'spoof','x-matched-path':'/admin','content-security-policy':"script-src 'nonce-spoof'",rsc:'1','next-router-state-tree':'[]'};
 const a=await secureRequest(request('/','GET',headers),environment(),handler),b=await secureRequest(request(),environment(),handler);
 for(const key of ['x-vinext-prerender-secret','x-middleware-subrequest','oai-authenticated-user-id','x-matched-path'])assert.equal(seen[0].headers.has(key),false);
 assert.equal(seen[0].headers.get('rsc'),'1');assert.equal(seen[0].headers.get('next-router-state-tree'),'[]');
 assert.equal(a.headers.get('Content-Security-Policy'),seen[0].headers.get('Content-Security-Policy'));
 assert.notEqual(a.headers.get('Content-Security-Policy'),b.headers.get('Content-Security-Policy'));
 assert.doesNotMatch(a.headers.get('Content-Security-Policy'),/spoof|'unsafe-eval'/);
 assert.match(a.headers.get('Content-Security-Policy'),/script-src 'self' 'nonce-[^']+' 'wasm-unsafe-eval'/);
 assert.match(a.headers.get('Content-Security-Policy'),/worker-src 'self' blob:/);
 assert.match(a.headers.get('Content-Security-Policy'),/connect-src 'self';/);
 assert.match(a.headers.get('Content-Security-Policy'),/frame-ancestors 'none'/);
 assert.equal(a.headers.get('X-Powered-By'),null);assert.equal(a.headers.get('Cache-Control'),'private, no-store');
 assert.equal(a.headers.get('X-Content-Type-Options'),'nosniff');assert.match(a.headers.get('Strict-Transport-Security'),/max-age/);
});

test('rate limits bind to connecting IP across cookie changes; missing or failed bindings fail closed',async()=>{
 const env=environment(),keys=[];let calls=0;
 env.SECURITY_CREATE_LIMIT={limit:async({key})=>{keys.push(key);return {success:++calls===1};}};
 let handled=0;const handler=()=>{handled++;return new Response('{}');};
 assert.equal((await secureRequest(request('/api/brackets','POST',{Cookie:'bl_voter=abc'}),env,handler)).status,200);
 const blocked=await secureRequest(request('/api/seasons','POST',{Cookie:'bl_voter=different','x-forwarded-for':'8.8.8.8'}),env,handler);
 assert.equal(blocked.status,429);assert.equal(blocked.headers.get('Retry-After'),'60');assert.equal(handled,1);assert.equal(keys[0],keys[1]);
 assert.equal((await secureRequest(request(),{},handler)).status,503);
 env.SECURITY_READ_LIMIT={limit:async()=>{throw Error('binding offline');}};
 assert.equal((await secureRequest(request(),env,handler)).status,503);assert.equal(handled,1);
});

test('media sandbox and streaming response body survive security wrapper',async()=>{
 const response=await secureRequest(request('/api/media/x.png'),environment(),()=>new Response('image',{headers:{'Content-Type':'image/png','Content-Security-Policy':"default-src 'none'; sandbox",'Cache-Control':'private,no-store'}}));
 assert.equal(await response.text(),'image');assert.equal(response.headers.get('Content-Security-Policy'),"default-src 'none'; sandbox");assert.equal(response.headers.get('Cache-Control'),'private,no-store');
});

test('schedule changes pass only the same-origin JSON PUT boundary',async()=>{
 let handled=0;const handler=()=>{handled++;return new Response('{}');};
 const path='/api/brackets/sample/schedule';
 assert.equal((await secureRequest(request(path,'PUT'),environment(),handler)).status,200);
 assert.equal((await secureRequest(request(path,'PUT',{Origin:'https://evil.example'}),environment(),handler)).status,403);
 assert.equal((await secureRequest(request(path,'PUT',{'Content-Type':'text/plain'}),environment(),handler)).status,415);
 assert.equal((await secureRequest(request(path,'POST'),environment(),handler)).status,405);
 assert.equal(handled,1);
});

test('security config preserves real database, routes and existing rate namespaces across repeated updates',async()=>{
 const root=await mkdtemp(join(tmpdir(),'bracket-security-'));
 try{
  const original={name:'bracketlive',assets:{directory:'dist/client',run_worker_first:['/existing/*']},routes:['brackets.example/*'],d1_databases:[{binding:'DB',database_id:'real-db'}],r2_buckets:[{binding:'BUCKET',bucket_name:'real-bucket'}],ratelimits:[{name:'OTHER_APP_LIMIT',namespace_id:'123',simple:{limit:8,period:10}}]};
  await writeFile(join(root,'wrangler.json'),JSON.stringify(original));await writeFile(join(root,'.admin-key'),'preserve-me');
  const first=await configureSecurity(root),second=await configureSecurity(root);
  assert.deepEqual(first,second);assert.equal(first.assets.binding,'ASSETS');assert.equal(first.assets.directory,'dist/client');assert.ok(first.assets.run_worker_first.includes('/existing/*'));assert.deepEqual(first.d1_databases,original.d1_databases);assert.deepEqual(first.r2_buckets,original.r2_buckets);assert.deepEqual(first.routes,original.routes);
  assert.deepEqual(first.ratelimits[0],original.ratelimits[0]);assert.equal(new Set(first.ratelimits.map(x=>x.namespace_id)).size,6);assert.equal(await readFile(join(root,'.admin-key'),'utf8'),'preserve-me');
 }finally{await rm(root,{recursive:true,force:true});}
});

test('Google start/callback GETs use auth limits and account mutations remain same-origin JSON only',async()=>{
 const env=environment();let hits=0,handled=0;
 env.SECURITY_AUTH_LIMIT={limit:async()=>({success:++hits<=1})};
 const handler=()=>{handled++;return new Response('{}');};
 assert.equal((await secureRequest(request('/api/auth/google'),env,handler)).status,200);
 assert.equal((await secureRequest(request('/api/auth/google/callback?state=x'),env,handler)).status,429);
 assert.equal(handled,1);
 for(const [url,method] of [['/api/account','PATCH'],['/api/auth/email','POST'],['/api/auth/email/verify','POST'],['/api/auth/logout','POST']]){
  assert.equal((await secureRequest(request(url,method),environment(),handler)).status,200);
  assert.equal((await secureRequest(request(url,method,{Origin:'https://evil.example'}),environment(),handler)).status,403);
  assert.equal((await secureRequest(request(url,method,{'Content-Type':'application/x-www-form-urlencoded'}),environment(),handler)).status,415);
 }
 const noAuth=environment();delete noAuth.SECURITY_AUTH_LIMIT;
 assert.equal((await secureRequest(request('/api/auth/google'),noAuth,handler)).status,503);
});
