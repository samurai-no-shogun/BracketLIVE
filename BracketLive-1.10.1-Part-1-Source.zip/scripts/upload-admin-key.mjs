import { spawn } from 'node:child_process';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');

async function main() {
  const key = (await readFile(resolve(root, '.admin-key'), 'utf8')).trim();
  if (!/^[0-9a-f]{64}$/.test(key)) throw new Error('Run node scripts/configure-cloudflare.mjs first to create a valid .admin-key.');

  // Windows needs a command shell to invoke npx.cmd. The command is constant:
  // no key, path, or user input is interpolated into shell text.
  const child = process.platform === 'win32'
    ? spawn('npx.cmd --yes wrangler@4.147.0 secret put ADMIN_KEY --config wrangler.json', {
        cwd: root, shell: true, stdio: ['pipe', 'inherit', 'inherit'],
      })
    : spawn('npx', ['--yes', 'wrangler@4.147.0', 'secret', 'put', 'ADMIN_KEY', '--config', 'wrangler.json'], {
        cwd: root, stdio: ['pipe', 'inherit', 'inherit'],
      });

  await new Promise((resolvePromise, reject) => {
    child.once('error', reject);
    child.stdin.once('error', reject);
    child.once('close', (code, signal) => {
      if (code === 0) resolvePromise();
      else reject(new Error(`Wrangler did not upload the key (${signal || `exit ${code}`}).`));
    });
    child.stdin.end(`${key}\n`);
  });
  console.log('Administrator key uploaded. Your local copy remains in .admin-key.');
}

main().catch((error) => { console.error(`Key upload failed: ${error.message}`); process.exitCode = 1; });
