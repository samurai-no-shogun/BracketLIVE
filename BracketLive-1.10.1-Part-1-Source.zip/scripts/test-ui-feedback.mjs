import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {test} from 'node:test';

const require=createRequire(import.meta.url),ts=require('typescript');
function load(){
 const module={exports:{}};
 const source=fs.readFileSync(new URL('../lib/ui-feedback.ts',import.meta.url),'utf8');
 const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 new Function('module','exports',compiled)(module,module.exports);return module.exports;
}
function environment(){
 const previous=Object.fromEntries(['window','document','navigator'].map(key=>[key,Object.getOwnPropertyDescriptor(globalThis,key)]));
 const store=new Map(),calls={contexts:0,notes:[],gains:[],stops:0,closed:0};
 const window=new EventTarget(),document=new EventTarget();
 document.hidden=false;document.documentElement={dataset:{}};
 window.localStorage={getItem:key=>store.get(key)??null};
 class AudioContext{
  state='running';currentTime=0;destination={};
  constructor(){calls.contexts++;}
  resume(){this.state='running';return Promise.resolve();}
  close(){this.state='closed';calls.closed++;return Promise.resolve();}
  createOscillator(){return {frequency:{setValueAtTime(value){calls.notes.push(value);}},connect(){},disconnect(){},start(){},stop(){calls.stops++;}};}
  createGain(){return {gain:{setValueAtTime(){},linearRampToValueAtTime(value){calls.gains.push(value);},exponentialRampToValueAtTime(){}},connect(){},disconnect(){}};}
 }
 window.AudioContext=AudioContext;
 const navigator={userActivation:{isActive:true}};
 for(const [key,value] of Object.entries({window,document,navigator}))Object.defineProperty(globalThis,key,{value,configurable:true,writable:true});
 return {window,document,navigator,store,calls,restore(){for(const key of Object.keys(previous)){if(previous[key])Object.defineProperty(globalThis,key,previous[key]);else delete globalThis[key];}}};
}

test('only the confirmed requested selection earns feedback; changes and round completion are supported',()=>{
 const {voteFeedbackFor}=load(),matches=[{id:'one',status:'open',myVote:'A'},{id:'two',status:'open',myVote:null}];
 assert.deepEqual(voteFeedbackFor(matches,'one','A'),{kind:'vote',complete:false});
 assert.equal(voteFeedbackFor(matches,'one','B'),null);
 assert.equal(voteFeedbackFor(matches,'missing','A'),null);
 assert.equal(voteFeedbackFor(matches,'one',null),null);
 matches[0].myVote='B';matches[1].myVote='C';
 assert.deepEqual(voteFeedbackFor(matches,'one','B'),{kind:'vote',complete:true});
 matches[0].myVote=null;
 assert.deepEqual(voteFeedbackFor(matches,'one',null),{kind:'undo',complete:false});
});
test('audio is silent until a real gesture primes it, with a low bounded volume and no network dependency',()=>{
 const env=environment(),audio=load();
 try{
  audio.playFeedbackSound('vote');assert.equal(env.calls.contexts,0);
  env.navigator.userActivation.isActive=false;audio.primeFeedbackAudio();assert.equal(env.calls.contexts,0);
  env.navigator.userActivation.isActive=true;audio.primeFeedbackAudio();assert.equal(env.calls.contexts,1);
  audio.playFeedbackSound('vote');assert.deepEqual(env.calls.notes,[523.25,659.25]);assert.ok(env.calls.gains.every(value=>value>0&&value<=.018));
  audio.playFeedbackSound('undo');assert.equal(env.calls.notes.at(-1),392);assert.equal(env.calls.contexts,1);
 }finally{audio.disposeFeedbackAudio();env.restore();}
});
test('both stored mute formats prevent priming and the preference event immediately stops active cues',()=>{
 const env=environment(),audio=load();
 try{
  for(const value of ['1','true']){env.store.set('bl_muted',value);audio.primeFeedbackAudio();assert.equal(env.calls.contexts,0);}
  env.store.set('bl_muted','0');audio.primeFeedbackAudio();audio.playFeedbackSound('vote');
  const before=env.calls.stops,event=new Event('bl-preferences-change');event.detail={muted:true};env.window.dispatchEvent(event);
  assert.ok(env.calls.stops>before);const notes=env.calls.notes.length;audio.playFeedbackSound('vote');assert.equal(env.calls.notes.length,notes);
  const unmute=new Event('bl-preferences-change');unmute.detail={muted:false};env.window.dispatchEvent(unmute);audio.playFeedbackSound('undo');assert.equal(env.calls.notes.length,notes+1);
 }finally{audio.disposeFeedbackAudio();env.restore();}
});
test('hidden tabs stay silent, cleanup releases audio, and unsupported or blocked audio never throws',()=>{
 const env=environment(),audio=load();
 try{
  audio.primeFeedbackAudio();env.document.hidden=true;audio.playFeedbackSound('vote');assert.equal(env.calls.notes.length,0);
  audio.disposeFeedbackAudio();assert.equal(env.calls.closed,1);
  env.window.AudioContext=class{constructor(){throw new Error('Audio blocked');}};
  assert.doesNotThrow(()=>audio.primeFeedbackAudio());assert.doesNotThrow(()=>audio.playFeedbackSound('vote'));
  env.window.AudioContext=undefined;assert.doesNotThrow(()=>audio.primeFeedbackAudio());
 }finally{audio.disposeFeedbackAudio();env.restore();}
});
test('mute keeps working when storage is blocked by the browser',()=>{
 const env=environment(),audio=load();
 try{
  env.window.localStorage.getItem=()=>{throw new Error('Storage denied');};env.document.documentElement.dataset.muted='true';
  assert.equal(audio.isFeedbackMuted(),true);audio.primeFeedbackAudio();assert.equal(env.calls.contexts,0);
 }finally{audio.disposeFeedbackAudio();env.restore();}
});
