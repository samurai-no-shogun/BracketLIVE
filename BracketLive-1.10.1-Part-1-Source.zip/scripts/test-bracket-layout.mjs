import assert from 'node:assert/strict';
import {test} from 'node:test';
import {bracketLayout,fitScale,measureViewport,stageGeometry,worldPoint,scrollToPoint,NODE_WIDTH,NODE_HEIGHT} from '../lib/bracket-layout.ts';

const sizes=[2,4,8,16,32,64,128];
const viewports=[{width:288,height:360},{width:375,height:500},{width:760,height:360},{width:1280,height:680},{width:2400,height:900}];
const matches=size=>Array.from({length:Math.log2(size)},(_,round)=>Array.from({length:size/2**(round+1)},(_,position)=>({round,position}))).flat();

for(const size of sizes){
 test(`${size} entries: every match fits, keeps its seed order, and reaches a centered final`,()=>{
  const layout=bracketLayout(size),nodes=matches(size);
  assert.equal(nodes.length,size-1);
  for(const m of nodes){
   const p=layout.position(m);
   assert.ok(p.x>=0&&p.y>=32&&p.x+NODE_WIDTH<=layout.width&&p.y+NODE_HEIGHT<=layout.height);
   if(m.round<layout.depth){
    const next=layout.position({round:m.round+1,position:Math.floor(m.position/2)});
    assert.ok(p.right?next.x<p.x:next.x>p.x,'winners move toward the final');
   }
   for(const other of nodes.filter(n=>n!==m)){
    const q=layout.position(other);
    assert.ok(p.x+NODE_WIDTH<=q.x||q.x+NODE_WIDTH<=p.x||p.y+NODE_HEIGHT<=q.y||q.y+NODE_HEIGHT<=p.y,'match cards must not overlap');
   }
  }
  for(let round=0;round<layout.depth;round++){
   const count=size/2**(round+1),half=count/2;
   for(let position=0;position<half;position++){
    const left=layout.position({round,position}),right=layout.position({round,position:position+half});
    assert.equal(left.y,right.y);
    assert.equal(left.x+right.x+NODE_WIDTH,layout.width);
    if(position>0)assert.ok(left.y>layout.position({round,position:position-1}).y,'original match order stays top to bottom');
   }
  }
  const final=layout.position(nodes.at(-1));
  assert.equal(final.x+NODE_WIDTH/2,layout.width/2);
  assert.equal(final.y+NODE_HEIGHT/2,layout.height/2);
 });
 test(`${size} entries: Fit all has no horizontal or vertical overflow on phone, laptop, or wide screens`,()=>{
  const layout=bracketLayout(size);
  for(const viewport of viewports){
   const zoom=fitScale(layout,viewport),stage=stageGeometry(layout,viewport,zoom);
   assert.equal(stage.width,viewport.width);
   assert.equal(stage.height,viewport.height);
   assert.ok(stage.left>=15.99&&stage.top>=15.99,'leave a visible margin on every side');
   assert.deepEqual(scrollToPoint(layout,viewport,zoom,{x:layout.width/2,y:layout.height/2},{x:0,y:0}),{x:0,y:0});
   for(const m of matches(size)){
    const p=layout.position(m);
    assert.ok(stage.left+p.x*zoom>=0&&stage.top+p.y*zoom>=0);
    assert.ok(stage.left+(p.x+NODE_WIDTH)*zoom<=viewport.width);
    assert.ok(stage.top+(p.y+NODE_HEIGHT)*zoom<=viewport.height);
   }
  }
 });
}
test('zooming preserves the point under the pointer and the current center',()=>{
 const layout=bracketLayout(64),viewport={width:1280,height:680};
 for(const screen of [{x:640,y:340},{x:430,y:210}]){
  const anchor={x:layout.width/2,y:layout.height/2};
  for(const zoom of [.5,1,1.5,2]){
   const scroll=scrollToPoint(layout,viewport,zoom,anchor,screen);
   const actual=worldPoint(layout,viewport,zoom,scroll,screen);
   assert.ok(Math.abs(actual.x-anchor.x)<.001&&Math.abs(actual.y-anchor.y)<.001);
  }
 }
});
test('jumping to every match at readable size keeps the whole card in the viewport',()=>{
 const layout=bracketLayout(64);
 for(const viewport of viewports){
  const stage=stageGeometry(layout,viewport,1);
  for(const m of matches(64)){
   const p=layout.position(m),scroll=scrollToPoint(layout,viewport,1,{x:p.x+NODE_WIDTH/2,y:p.y+NODE_HEIGHT/2},{x:viewport.width/2,y:viewport.height/2});
   const x=stage.left+p.x-scroll.x,y=stage.top+p.y-scroll.y;
   assert.ok(x>=0&&y>=0&&x+NODE_WIDTH<=viewport.width&&y+NODE_HEIGHT<=viewport.height);
  }
 }
});

function viewportElement(width,height,gutter=0,bars={x:false,y:false}){
 return {getBoundingClientRect:()=>({width,height}),offsetWidth:Math.round(width),offsetHeight:Math.round(height),clientWidth:Math.round(width)-(bars.y?gutter:0),clientHeight:Math.round(height)-(bars.x?gutter:0)};
}

test('fractional viewport measurements never create rounding overflow',()=>{
 for(const width of [375.2,1200.25,1337.8])for(const height of [599.9,850.75])for(const gutter of [0,10,17]){
  const viewport=measureViewport(viewportElement(width,height,gutter,{x:true,y:true}));
  assert.ok(viewport.width<=width-gutter&&viewport.height<=height-gutter);
  assert.ok(width-gutter-viewport.width<1/64&&height-gutter-viewport.height<1/64);
  const world=bracketLayout(64),stage=stageGeometry(world,viewport,fitScale(world,viewport));
  assert.ok(stage.width<=width-gutter&&stage.height<=height-gutter,'fitting must not create another scrollbar');
 }
});

test('the 31% scrollbar feedback reproduction settles instead of alternating positions',()=>{
 const world=bracketLayout(64),outer={width:1200.25,height:850.75},gutter=10;
 function simulate(measure,reserveGutters){
  let bars={x:reserveGutters,y:reserveGutters};const frames=[];
  for(let frame=0;frame<60;frame++){
   const viewport=measure(viewportElement(outer.width,outer.height,gutter,bars)),zoom=fitScale(world,viewport),stage=stageGeometry(world,viewport,zoom);
   assert.equal(Math.round(zoom*100),31,'both sides of the old oscillation display 31%');
   frames.push(JSON.stringify({viewport,zoom,left:stage.left,top:stage.top}));
   let next={x:reserveGutters,y:reserveGutters};
   for(let pass=0;pass<3;pass++)next={x:reserveGutters||stage.width>outer.width-(next.y?gutter:0),y:reserveGutters||stage.height>outer.height-(next.x?gutter:0)};
   bars=next;
  }
  return frames;
 }
 const oldFrames=simulate(el=>({width:el.clientWidth,height:el.clientHeight}),false);
 assert.notEqual(oldFrames[0],oldFrames[1]);assert.equal(oldFrames[0],oldFrames[2],'the fixture reproduces the original two-position loop');
 for(const reserveGutters of [false,true]){
  const frames=simulate(measureViewport,reserveGutters);
  assert.equal(new Set(frames).size,1,'position and actual zoom stay constant across repeated measurements');
 }
});
