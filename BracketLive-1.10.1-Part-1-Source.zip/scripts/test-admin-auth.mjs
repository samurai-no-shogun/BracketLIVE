import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {test} from 'node:test';

// Exercise the real auth module and API handlers. Only Workers bindings and
// Next's request-header transport are replaced for this isolated Node test.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const key='7d'.repeat(32),env={ADMIN_KEY:key},modules=new Map();
let headerContext=new Headers(),databaseCalls=0;
env.DB={prepare(){return {bind(){return this;},async first(){return null;}};},async batch(){databaseCalls++;return [
 {results:[{views:0,visitors:0,shares:0}]},{results:[{votes:0,voters:0}]},{results:[{converted:0}]},
 {results:[]},{results:[]},{results:[]},{results:[]},{results:[]},{results:[{total:0,live:0,complete:0}]},
 ];}};
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env}:id==='next/headers'?{headers:async()=>headerContext}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);return module.exports;
}
const auth=loadSource('lib/admin-auth.ts'),session=loadSource('app/api/admin/session/route.ts'),analytics=loadSource('app/api/analytics/route.ts');
const origin='https://bracket.example';
const req=(pathname,{method='GET',body,cookie,headers={}}={})=>new Request(origin+pathname,{method,headers:{Origin:origin,...(cookie?{Cookie:cookie}:{}),...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});
const login=(candidate=key,headers={})=>session.POST(req('/api/admin/session',{method:'POST',body:{key:candidate},headers}));
const cookieOf=response=>response.headers.get('set-cookie').split(';')[0];

test('owner login creates a signed session, rejects forgery/expiry, and supports logout',async()=>{
 const wrong=await login('bad-key');assert.equal(wrong.status,401);assert.equal(wrong.headers.get('set-cookie'),null);
 const response=await login();assert.equal(response.status,200);assert.equal(await response.text(),'{"ok":true}');
 const cookie=cookieOf(response),setCookie=response.headers.get('set-cookie');
 assert.match(setCookie,/HttpOnly/);assert.match(setCookie,/SameSite=Strict/);assert.match(setCookie,/Secure/);assert.match(setCookie,/Max-Age=28800/);assert.ok(!setCookie.includes(key));
 assert.equal(await auth.isSiteAdmin(req('/admin',{cookie})),true);
 headerContext=new Headers({cookie});assert.equal(await auth.isSiteAdmin(),true,'server-rendered owner page accepts the same signed cookie');
 const altered=cookie.slice(0,-1)+(cookie.endsWith('a')?'b':'a');
 assert.equal(await auth.isSiteAdmin(req('/admin',{cookie:altered})),false);
 assert.equal(await auth.isSiteAdmin(req('/admin',{cookie:`${cookie}; ${cookie}`})),false,'ambiguous cookies fail closed');
 const previousNow=Date.now;try{Date.now=()=>previousNow()+8*60*60*1000+1000;assert.equal(await auth.isSiteAdmin(req('/admin',{cookie})),false);}finally{Date.now=previousNow;}
 env.ADMIN_KEY='8e'.repeat(32);assert.equal(await auth.isSiteAdmin(req('/admin',{cookie})),false,'key rotation revokes prior sessions');env.ADMIN_KEY=key;
 const logout=await session.DELETE(req('/api/admin/session',{method:'DELETE',cookie}));assert.equal(logout.status,200);assert.match(logout.headers.get('set-cookie'),/^bl_admin=;.*Max-Age=0/);
 assert.equal(await auth.isSiteAdmin(req('/admin',{cookie:cookieOf(logout)})),false);
});

test('missing or weak configuration fails closed, and Sites headers never grant admin access',async()=>{
 for(const secret of [undefined,'short']){
  env.ADMIN_KEY=secret;assert.equal(auth.adminConfigured(),false);
  assert.equal((await login()).status,503);
  assert.equal(await auth.isSiteAdmin(req('/admin',{headers:{'oai-authenticated-user-id':'spoof','oai-authenticated-user-email':'owner@example.com'}})),false);
 }
 env.ADMIN_KEY=key;
 const spoof=await analytics.GET(req('/api/analytics',{headers:{'oai-authenticated-user-id':'spoof','oai-authenticated-user-email':'owner@example.com'}}));
 assert.equal(spoof.status,403);assert.equal(databaseCalls,0,'unauthorized analytics cannot read platform totals');
 const cookie=cookieOf(await login()),allowed=await analytics.GET(req('/api/analytics',{cookie}));
 assert.equal(allowed.status,200);assert.equal((await allowed.json()).scope,'site');assert.equal(databaseCalls,1);
 const otherBracket=await analytics.GET(req('/api/analytics?bracket=someone-elses-bracket',{cookie}));
 assert.equal(otherBracket.status,403,'site admin does not bypass bracket organizer ownership');
});

test('cross-site login/logout and oversized input are rejected',async()=>{
 assert.equal((await login(key,{Origin:'https://other.example'})).status,403);
 assert.equal((await login(key,{'sec-fetch-site':'cross-site'})).status,403);
 assert.equal((await session.DELETE(req('/api/admin/session',{method:'DELETE',headers:{Origin:'https://other.example'}}))).status,403);
 assert.equal((await login('x'.repeat(2048))).status,413);
});
