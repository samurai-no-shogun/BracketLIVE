import { configureSecurity } from './configure-security.mjs';
import { randomBytes } from 'node:crypto';
import { readFile, writeFile, chmod } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createInterface } from 'node:readline/promises';

const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PLACEHOLDER_ID = '00000000-0000-4000-8000-000000000000';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function configureCloudflare(projectRoot, databaseId) {
  const id = String(databaseId ?? '').trim().toLowerCase();
  if (!UUID.test(id) || id === PLACEHOLDER_ID || /^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(id)) {
    throw new Error('Enter the real database_id UUID printed by wrangler d1 create, not an account ID or placeholder.');
  }

  const configPath = resolve(projectRoot, 'wrangler.json');
  const config = JSON.parse(await readFile(configPath, 'utf8'));
  const databases = config.d1_databases?.filter((binding) => binding.binding === 'DB');
  if (databases?.length !== 1) throw new Error('wrangler.json must contain exactly one D1 binding named DB.');

  const keyPath = resolve(projectRoot, '.admin-key');
  let createdKey = false;
  try {
    const existing = (await readFile(keyPath, 'utf8')).trim();
    if (!/^[0-9a-f]{64}$/.test(existing)) {
      throw new Error('The existing .admin-key is not a valid generated key. Preserve it and resolve the file before rerunning; this script will not overwrite it.');
    }
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    await writeFile(keyPath, `${randomBytes(32).toString('hex')}\n`, { flag: 'wx', mode: 0o600 });
    createdKey = true;
  }
  // On Windows, access is controlled by the containing user profile's ACL.
  if (process.platform !== 'win32') await chmod(keyPath, 0o600);

  databases[0].database_id = id;
  await writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`);
  await configureSecurity(projectRoot);
  return { createdKey };
}

async function main() {
  if (process.argv.length > 3) throw new Error('Usage: node scripts/configure-cloudflare.mjs DATABASE_UUID');
  let id = process.argv[2];
  if (!id) {
    const prompt = createInterface({ input: process.stdin, output: process.stdout });
    try { id = await prompt.question('Paste the database_id from wrangler d1 create: '); }
    finally { prompt.close(); }
  }
  const result = await configureCloudflare(PROJECT_ROOT, id);
  console.log('Configured the DB binding in wrangler.json.');
  console.log(result.createdKey ? 'Created your private administrator key in .admin-key.' : 'Kept your existing administrator key in .admin-key.');
  console.log('Next: apply the database migrations, deploy, then run node scripts/upload-admin-key.mjs.');
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch((error) => { console.error(`Setup failed: ${error.message}`); process.exitCode = 1; });
}
