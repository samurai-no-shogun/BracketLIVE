// Copy pinned browser-only OCR/PDF dependencies. Importing a file never needs
// a third-party CDN, and prebuilt update ZIPs carry these same assets.
import {createRequire} from 'node:module';
import {cp,mkdir,readFile,writeFile} from 'node:fs/promises';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url));
const require=createRequire(import.meta.url);
const packageRoot=name=>dirname(require.resolve(`${name}/package.json`));
const tesseract=packageRoot('tesseract.js'),pdf=packageRoot('pdfjs-dist'),language=packageRoot('@tesseract.js-data/eng');
const nested=createRequire(join(tesseract,'package.json'));
const core=dirname(nested.resolve('tesseract.js-core/package.json'));
const output=join(root,'public','import-assets');
await mkdir(join(output,'tesseract-core'),{recursive:true});
await mkdir(join(output,'tesseract-lang'),{recursive:true});
await cp(join(tesseract,'dist','worker.min.js'),join(output,'tesseract-worker.min.js'));
await cp(join(pdf,'build','pdf.worker.min.mjs'),join(output,'pdf.worker.min.mjs'));
for(const variant of ['lstm','simd-lstm','relaxedsimd-lstm']){
  for(const suffix of ['wasm.js','wasm']){
    const file=`tesseract-core-${variant}.${suffix}`;
    await cp(join(core,file),join(output,'tesseract-core',file));
  }
}
// Integer LSTM model keeps first-use download and mobile memory modest.
await cp(join(language,'4.0.0_best_int','eng.traineddata.gz'),join(output,'tesseract-lang','eng.traineddata.gz'));
await cp(join(pdf,'cmaps'),join(output,'pdf-cmaps'),{recursive:true});
await cp(join(pdf,'standard_fonts'),join(output,'pdf-fonts'),{recursive:true});
await mkdir(join(output,'pdf-wasm'),{recursive:true});
// Scan decoders only. Do not distribute the optional PDF JavaScript evaluator.
for(const file of ['jbig2_nowasm_fallback.js','openjpeg_nowasm_fallback.js']){
  await cp(join(pdf,'wasm',file),join(output,'pdf-wasm',file));
}
for(const file of ['LICENSE_JBIG2','LICENSE_OPENJPEG','LICENSE_PDFJS_JBIG2','LICENSE_PDFJS_OPENJPEG']){
  await cp(join(pdf,'wasm',file),join(output,'pdf-wasm',file+'.txt'));
}
await cp(join(tesseract,'LICENSE.md'),join(output,'TESSERACT-LICENSE.txt'));
await cp(join(core,'LICENSE'),join(output,'TESSERACT-CORE-LICENSE.txt'));
await cp(join(pdf,'LICENSE'),join(output,'PDFJS-LICENSE.txt'));
await writeFile(join(output,'LANGUAGE-NOTICE.txt'),
  'English OCR data: @tesseract.js-data/eng 1.0.0 (MIT), from naptha/tessdata.\n'+
  'Copyright the package authors. Distributed under the MIT License:\n'+
  'Permission is hereby granted, free of charge, to any person obtaining a copy '+
  'of this software and associated documentation files (the "Software"), to deal '+
  'in the Software without restriction, including without limitation the rights '+
  'to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies '+
  'of the Software, and to permit persons to whom the Software is furnished to do '+
  'so, subject to the following conditions: The above copyright notice and this '+
  'permission notice shall be included in all copies or substantial portions of '+
  'the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, '+
  'EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, '+
  'FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS '+
  'OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER '+
  'IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION '+
  'WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n');
const versions={};
for(const [name,path] of [['tesseract.js',tesseract],['tesseract.js-core',core],['pdfjs-dist',pdf],['@tesseract.js-data/eng',language]]){
  versions[name]=JSON.parse(await readFile(join(path,'package.json'),'utf8')).version;
}
await writeFile(join(output,'versions.json'),JSON.stringify(versions,null,2)+'\n');
console.log('Copied local OCR and PDF assets:',JSON.stringify(versions));
