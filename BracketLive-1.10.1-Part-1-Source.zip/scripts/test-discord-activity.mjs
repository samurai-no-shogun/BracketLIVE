import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {DatabaseSync} from 'node:sqlite';
import {test,after} from 'node:test';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
let beforeMutation;
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 execute(){const q=sqlite.prepare(this.query);if(q.columns().length)return {results:q.all(...this.values),meta:{changes:0},success:true};return {results:[],meta:{changes:Number(q.run(...this.values).changes)},success:true};}
 async first(){return sqlite.prepare(this.query).get(...this.values)??null;}
 async all(){return this.execute();}
 async run(){hook([this]);return this.execute();}
}
function hook(statements){if(beforeMutation&&statements.some(s=>/^\s*(UPDATE|DELETE|INSERT)/.test(s.query))){const fn=beforeMutation;beforeMutation=undefined;fn();}}
const DB={prepare:q=>new Statement(q),async batch(statements){hook(statements);sqlite.exec('BEGIN');try{const r=statements.map(s=>s.execute());sqlite.exec('COMMIT');return r;}catch(e){sqlite.exec('ROLLBACK');throw e;}}};
const modules=new Map();function load(file){file=path.resolve(root,file);if(!path.extname(file))file+='.ts';if(modules.has(file))return modules.get(file).exports;const m={exports:{}};modules.set(file,m);new Function('require','module','exports',ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(id=>id.startsWith('.')?load(path.resolve(path.dirname(file),id)):require(id),m,m.exports);return m.exports;}
const {discordAPI,runDiscordScheduler}=load('lib/discord-server.ts'),{newActivityState,advanceActivity,activitySnapshot,votingMatch}=load('lib/discord-engine.ts'),{makeDraft}=load('lib/bracket.ts'),{secureRequest}=load('lib/request-security.ts');
const app='123456789012345678',alice='223456789012345678',bob='323456789012345678',eve='423456789012345678';
const objects=new Map();let failStorage=false;
const BUCKET={async put(key,bytes){if(failStorage)throw Error('storage offline');objects.set(key,new Uint8Array(bytes));},async get(key){const bytes=objects.get(key);return bytes?{body:bytes}:null;},async delete(key){objects.delete(key);}};
const env={DB,BUCKET,DISCORD_APPLICATION_ID:app,DISCORD_CLIENT_SECRET:'test-only-secret',DISCORD_BOT_TOKEN:'test-only-bot',...Object.fromEntries(['READ','WRITE','AUTH','CREATE','UPLOAD'].map(n=>['SECURITY_'+n+'_LIMIT',{limit:async()=>({success:true})}]))};
const nativeFetch=global.fetch;
global.fetch=async(url,init)=>{
 if(url.endsWith('/oauth2/token'))return Response.json({access_token:new URLSearchParams(init.body).get('code'),expires_in:3600});
 if(url.endsWith('/users/@me'))return Response.json({id:new Headers(init.headers).get('Authorization').replace('Bearer ',''),username:'Test voter'});
 const id=decodeURIComponent(url.split('/').pop());return Response.json({application_id:app,instance_id:id,location:{id:'location',channel_id:id==='other'?'823456789012345678':'923456789012345678',guild_id:'723456789012345678'},users:id==='other'?[eve]:[alice,bob]});
};
after(()=>{sqlite.close();global.fetch=nativeFetch;});
const call=(p,token,data)=>discordAPI(new Request('https://bracket.test/api/discord'+p,{method:data===undefined?'GET':'POST',headers:{...(token?{Authorization:'Bearer '+token}:{}),'Content-Type':'application/json'},...(data===undefined?{}:{body:JSON.stringify(data)})}),env);
async function json(r,status=200){assert.equal(r.status,status,await r.clone().text());return r.json();}
async function login(user,instance='same'){return (await json(await call('/auth',null,{code:user,instanceId:instance}))).token;}
const draftFor=n=>({...makeDraft(n,false),title:'Friends bracket',entries:Array.from({length:n},(_,i)=>({name:'Team '+(i+1),subtitle:'',image:null,seed:i+1}))});
const create=async(token,n=4,roundMinutes=0)=>{const d=draftFor(n);return (await json(await call('/tournaments',token,{title:d.title,entries:d.entries,roundMinutes}),201)).id;};

test('all Discord requests identify the app with a valid User-Agent, preserve OAuth form encoding, and use the documented instance endpoint',async()=>{
 const previous=global.fetch,requests=[];global.fetch=async(url,init)=>{requests.push({url,init});return previous(url,init);};
 try{await login(alice,'header-check');assert.equal(requests.length,3);
  for(const {init} of requests){const headers=new Headers(init.headers);assert.match(headers.get('User-Agent'),/^DiscordBot \(https:\/\/bracketlive\.goyfundmenow\.workers\.dev, 1\.10\.1\)$/);assert.equal(headers.get('Accept'),'application/json');}
  assert.equal(requests[0].url,'https://discord.com/api/v10/oauth2/token');assert.equal(new Headers(requests[0].init.headers).get('Content-Type'),'application/x-www-form-urlencoded');assert.equal(new URLSearchParams(requests[0].init.body).get('grant_type'),'authorization_code');
  assert.equal(requests[1].url,'https://discord.com/api/v10/users/@me');assert.equal(requests[2].url,`https://discord.com/api/applications/${app}/activity-instances/header-check`);assert.equal(new Headers(requests[2].init.headers).get('Authorization'),'Bot test-only-bot');
 }finally{global.fetch=previous;}
 const config=await json(await call('/config'));assert.equal(config.version,'1.10.1');assert.equal(config.configured,true);
});

test('OAuth, bot, identity, rate and network failures are specific, fail closed and never log or return upstream secrets',async()=>{
 const previous=global.fetch,originalLog=console.error,logs=[];console.error=(...values)=>logs.push(values);
 const cases=[
  {suffix:'/oauth2/token',status:401,body:{error:'invalid_client',error_description:'test-only-secret'},message:/DISCORD_CLIENT_SECRET/,code:'discord_oauth_exchange_401_invalid_client'},
  {suffix:'/oauth2/token',status:400,body:{error:'invalid_grant',message:'test-only-secret'},message:/fresh code/,code:'discord_oauth_exchange_400_invalid_grant'},
  {suffix:'/users/@me',status:401,body:{code:0,message:'secret-echo'},message:/authorized user token/,code:'discord_identity_401_0'},
  {instance:true,status:401,body:{code:0,message:'test-only-bot'},message:/DISCORD_BOT_TOKEN/,code:'discord_activity_instance_401_0'},
  {instance:true,status:403,body:{code:50001,message:'secret-echo'},message:/configured BracketLIVE application/,code:'discord_activity_instance_403_50001'},
  {instance:true,status:404,body:{code:0,message:'secret-echo'},message:/active Activity instance/,code:'discord_activity_instance_404_0'},
  {suffix:'/oauth2/token',status:429,body:{message:'secret-echo'},message:/rate limiting/,code:'discord_oauth_exchange_429_unknown'},
  {suffix:'/oauth2/token',status:403,text:'error code: 1010 secret-echo',message:/blocked the server request/,code:'discord_oauth_exchange_403_request_blocked'},
  {suffix:'/oauth2/token',status:400,body:{error:'test-only-secret'},message:/HTTP 400/,code:'discord_oauth_exchange_400_unknown'},
  {suffix:'/oauth2/token',status:400,text:'secret-echo '.repeat(1000),message:/HTTP 400/,code:'discord_oauth_exchange_400_unknown'},
  {suffix:'/oauth2/token',network:true,message:/could not be reached/,code:'discord_oauth_exchange_unavailable'},
  {suffix:'/oauth2/token',status:200,text:'not JSON secret-echo',message:/invalid oauth exchange response/,code:'discord_oauth_exchange_invalid_response'},
 ];
 try{for(const [i,c] of cases.entries()){
  const before=sqlite.prepare('SELECT COUNT(*) n FROM discord_sessions').get().n;
  global.fetch=async(url,init)=>{if(c.instance?url.includes('/activity-instances/'):url.endsWith(c.suffix)){if(c.network)throw Error('secret-echo');return c.body?Response.json(c.body,{status:c.status}):new Response(c.text,{status:c.status});}return previous(url,init);};
  const r=await json(await call('/auth',null,{code:alice,instanceId:'rejection-'+i}),c.status===429?429:503);assert.match(r.error,c.message);assert.equal(r.code,c.code);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM discord_sessions').get().n,before);assert.ok(!JSON.stringify(r).includes('secret-echo'));assert.ok(!JSON.stringify(r).includes('test-only-secret'));assert.ok(!JSON.stringify(r).includes('test-only-bot'));
 }
 assert.ok(logs.length>=cases.length);const recorded=JSON.stringify(logs);for(const value of ['secret-echo','test-only-secret','test-only-bot',alice,'rejection-'])assert.ok(!recorded.includes(value));
 }finally{global.fetch=previous;console.error=originalLog;}
});

test('every supported size advances to exactly one champion, preserving pairings',()=>{
 for(const n of [2,4,8,16,32,64,128]){let s=newActivityState(draftFor(n),'id');for(let r=0;r<Math.log2(n);r++){const votes=s.bracket.matches.filter(m=>m.round===r).map(m=>({match_id:m.id,entry_id:m.a_id,user_id:alice}));s=advanceActivity(s,votes);}assert.equal(s.bracket.status,'completed');assert.equal(s.bracket.matches.at(-1).winner_id,'entry-0');}
});
test('ties and zero-vote matches require a valid creator choice, percentages remain hidden before voting',()=>{
 const s=newActivityState(draftFor(2),'id'),m=s.bracket.matches[0];assert.throws(()=>advanceActivity(s,[]),/Tied/);assert.throws(()=>advanceActivity(s,[],{[m.id]:'invalid'}),/Tied/);
 const votes=[{match_id:m.id,entry_id:m.a_id,user_id:alice}];assert.equal(activitySnapshot(s,votes,bob,false).matches[0].counts,null);assert.equal(activitySnapshot(s,votes,alice,false).matches[0].counts[m.a_id],1);assert.equal(advanceActivity(s,[],{[m.id]:m.b_id}).bracket.matches[0].decided_by,'creator_tiebreak');
});
test('session requires actual Discord instance membership, stores only token hashes, and rejects expired tokens',async()=>{
 await json(await call('/auth',null,{code:eve,instanceId:'same'}),403);
 await json(await call('/room',null),401);
 const token=await login(alice);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM discord_sessions WHERE token_hash=?').get(token).n,0);
 const hash=createHash('sha256').update(token).digest('hex');sqlite.prepare('UPDATE discord_sessions SET expires_at=0 WHERE token_hash=?').run(hash);await json(await call('/room',token),401);
});
test('friends share results; duplicate votes replace, undo removes; other channels and non-owners cannot interfere',async()=>{
 const a=await login(alice),b=await login(bob),e=await login(eve,'other'),id=await create(a),url='/tournaments/'+id;
 assert.equal((await json(await call('/room',b))).tournaments.some(t=>t.id===id),true);
 await json(await call(url,e),404);await json(await call(url+'/advance',b,{}),403);
 let snapshot=await json(await call(url,b)),m=snapshot.bracket.matches[0];assert.equal(m.counts,null);
 await json(await call(url+'/vote',a,{matchId:m.id,entryId:m.a_id}));await json(await call(url+'/vote',a,{matchId:m.id,entryId:m.a_id}));
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM discord_votes WHERE tournament_id=?').get(id).n,1);
 await json(await call(url+'/vote',b,{matchId:m.id,entryId:m.b_id}));snapshot=await json(await call(url,b));assert.equal(snapshot.bracket.matches[0].total,2);
 await json(await call(url+'/vote',a,{matchId:m.id,entryId:m.b_id}));snapshot=await json(await call(url,b));assert.equal(snapshot.bracket.matches[0].counts[m.b_id],2);
 await json(await call(url+'/vote',a,{matchId:m.id,entryId:null}));snapshot=await json(await call(url,b));assert.equal(snapshot.bracket.matches[0].total,1);
 await json(await call(url+'/vote',b,{matchId:'preview-1-0',entryId:m.b_id}),409);
});
test('simultaneous vote and advance cannot lose an accepted vote',async()=>{
 const a=await login(alice),id=await create(a,2),url='/tournaments/'+id;const {bracket}=await json(await call(url,a)),m=bracket.matches[0];
 await json(await call(url+'/vote',a,{matchId:m.id,entryId:m.a_id}));
 beforeMutation=()=>{sqlite.prepare('UPDATE discord_tournaments SET revision=revision+1 WHERE id=?').run(id);sqlite.prepare('INSERT INTO discord_votes VALUES(?,?,?,?)').run(id,m.id,bob,m.b_id);};
 await json(await call(url+'/advance',a,{}),409);
 assert.equal(JSON.parse(sqlite.prepare('SELECT state_json FROM discord_tournaments WHERE id=?').get(id).state_json).bracket.status,'live');
});
test('deadlines reject further votes; cron advances winners once and pauses ties',async()=>{
 const a=await login(alice),id=await create(a,2,5),url='/tournaments/'+id;const {bracket}=await json(await call(url,a)),m=bracket.matches[0];await json(await call(url+'/vote',a,{matchId:m.id,entryId:m.a_id}));
 function expire(id){const row=sqlite.prepare('SELECT state_json FROM discord_tournaments WHERE id=?').get(id),state=JSON.parse(row.state_json);state.bracket.round_closes_at=Date.now()-1000;sqlite.prepare('UPDATE discord_tournaments SET state_json=?,closes_at=? WHERE id=?').run(JSON.stringify(state),state.bracket.round_closes_at,id);}
 expire(id);await json(await call(url+'/vote',a,{matchId:m.id,entryId:m.b_id}),409);await runDiscordScheduler(env);await runDiscordScheduler(env);assert.equal((await json(await call(url,a))).bracket.status,'completed');
 const tie=await create(a,2,5);expire(tie);await runDiscordScheduler(env);const paused=await json(await call('/tournaments/'+tie,a));assert.equal(paused.bracket.schedule_blocked,true);assert.equal(paused.bracket.status,'live');
});
test('only configured Discord proxy may mutate Activity API; website CSRF stays enforced; framing is narrowly scoped',async()=>{
 const req=(p,origin)=>new Request('https://bracket.test'+p,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:'{}'}),ok=()=>Response.json({ok:true});
 assert.equal((await secureRequest(req('/api/discord/auth',`https://${app}.discordsays.com`),env,ok)).status,200);
 assert.equal((await secureRequest(req('/api/discord/auth','https://999999999999999999.discordsays.com'),env,ok)).status,403);
 assert.equal((await secureRequest(req('/api/brackets',`https://${app}.discordsays.com`),env,ok)).status,403);
 const html=()=>new Response('<html/>',{headers:{'Content-Type':'text/html','X-Frame-Options':'DENY'}});
 const activity=await secureRequest(new Request('https://bracket.test/discord'),env,html);assert.equal(activity.headers.get('X-Frame-Options'),null);assert.match(activity.headers.get('Content-Security-Policy'),/frame-ancestors https:\/\/discord.com/);
 const web=await secureRequest(new Request('https://bracket.test/'),env,html);assert.equal(web.headers.get('X-Frame-Options'),'DENY');
});

const pngBytes=Buffer.from(JSON.parse(fs.readFileSync(path.join(root,'scripts/security-image-fixtures.json'),'utf8')).png,'base64');
const binary=(path,token,bytes=pngBytes,type='image/png')=>discordAPI(new Request('https://bracket.test/api/discord'+path,{method:'POST',headers:{...(token?{Authorization:'Bearer '+token}:{}),'Content-Type':type},body:bytes}),env);
test('raster uploads validate bytes, authenticate membership, isolate channel images and reject forged image references',async()=>{
 const a=await login(alice),b=await login(bob),e=await login(eve,'other');
 await json(await binary('/media',null),401);
 await json(await binary('/media',a,new TextEncoder().encode('<svg onload="evil()"/>')),400);
 const uploaded=await json(await binary('/media',a),201);
 const member=await call(uploaded.image.replace('/api/discord',''),b);assert.equal(member.status,200);assert.equal(member.headers.get('Content-Type'),'image/png');assert.deepEqual(Buffer.from(await member.arrayBuffer()),pngBytes);
 await json(await call(uploaded.image.replace('/api/discord',''),e),404);
 const d=draftFor(2);d.entries[0].image=uploaded.image;
 await json(await call('/tournaments',e,{title:'forged',entries:d.entries}),400);
 const id=(await json(await call('/tournaments',a,{title:'with image',entries:d.entries}),201)).id;
 assert.equal((await json(await call('/tournaments/'+id,b))).bracket.entries[0].image,uploaded.image);
 const before=sqlite.prepare('SELECT COUNT(*) n FROM discord_media').get().n;
 failStorage=true;await json(await binary('/media',a),503);failStorage=false;
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM discord_media').get().n,before,'failed storage releases upload reservation');
 await json(await binary('/media',a,new Uint8Array(5*1024*1024+1)),413);
});
test('export links are explicit one-day image capabilities, contain no auth token, and expire with stored bytes',async()=>{
 const a=await login(alice);await json(await binary('/exports',null),401);
 const exported=await json(await binary('/exports',a),201);assert.match(exported.url,/^https:\/\/bracket.test\/api\/discord\/download\/[a-f0-9-]{36}$/);assert.ok(!exported.url.includes(a));
 const path=exported.url.replace('https://bracket.test/api/discord','');const download=await call(path,null);assert.equal(download.status,200);assert.match(download.headers.get('Content-Disposition'),/attachment/);assert.deepEqual(Buffer.from(await download.arrayBuffer()),pngBytes);
 const id=path.split('/').pop();sqlite.prepare('UPDATE discord_exports SET expires_at=0 WHERE id=?').run(id);
 await json(await call(path,null),404);await runDiscordScheduler(env);assert.equal(objects.has('discord-exports/'+id),false);
});
test('raster boundary accepts only authorized upload routes and configured proxy origin',async()=>{
 const req=(path,origin=`https://${app}.discordsays.com`,type='image/png')=>new Request('https://bracket.test'+path,{method:'POST',headers:{Origin:origin,'Content-Type':type},body:pngBytes});let reached=0;const next=()=>{reached++;return Response.json({ok:true});};
 assert.equal((await secureRequest(req('/api/discord/media'),env,next)).status,200);
 assert.equal((await secureRequest(req('/api/discord/exports'),env,next)).status,200);
 assert.equal((await secureRequest(req('/api/discord/media','https://evil.test'),env,next)).status,403);
 assert.equal((await secureRequest(req('/api/discord/media',undefined,'image/svg+xml'),env,next)).status,415);
 assert.equal(reached,2);
});
