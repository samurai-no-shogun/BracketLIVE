import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {test} from 'node:test';
import {DatabaseSync} from 'node:sqlite';

const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 async first(){return sqlite.prepare(this.query).get(...this.values)??null;}
 async run(){const result=sqlite.prepare(this.query).run(...this.values);return {meta:{changes:Number(result.changes)}};}
}
const stored=new Map();let writes=0,failStorage=false;
const env={DB:{prepare:query=>new Statement(query)},BUCKET:{async put(key,bytes,options){if(failStorage)throw new Error('Simulated storage error');writes++;stored.set(key,{body:bytes,size:bytes.length,httpMetadata:options.httpMetadata,async arrayBuffer(){return Uint8Array.from(this.body).buffer;}});},async get(key){return stored.get(key);},async delete(key){stored.delete(key);}}};
function load(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env}:id.startsWith('@/')?load(id.slice(2)):id.startsWith('.')?load(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);return module.exports;
}
const {validateImage}=load('lib/image-validation.ts'),{csvCell}=load('lib/csv.ts');
const upload=load('app/api/media/route.ts'),download=load('app/api/media/[key]/route.ts'),{hash}=load('lib/server.ts');
const owner=`bl_voter=${'1'.repeat(64)}`,manager=`bl_voter=${'2'.repeat(64)}`,stranger=`bl_voter=${'3'.repeat(64)}`;
const post=(bytes,type='image/png',cookie=owner)=>upload.POST(new Request('https://bracket.example/api/media',{method:'POST',headers:{Origin:'https://bracket.example','Content-Type':type,Cookie:cookie},body:bytes}));
const get=(key,cookie)=>download.GET(new Request(`https://bracket.example/api/media/${key}`,{headers:cookie?{Cookie:cookie}:{}}),{params:Promise.resolve({key})});
const fixtures=Object.fromEntries(Object.entries(JSON.parse(fs.readFileSync(new URL('./security-image-fixtures.json',import.meta.url),'utf8'))).map(([k,v])=>[k,Buffer.from(v,'base64')]));
test('real still and animated PNG/GIF/WebP and JPEG headers stay supported',()=>{
 for(const [name,bytes] of Object.entries(fixtures)){
  const image=validateImage(bytes);assert.equal(image.width,3,name);assert.equal(image.height,2,name);assert.equal(image.type,`image/${name.replace('animated_','')}`,name);
 }
 const original=fs.readFileSync(path.join(root,'public/templates/anime-source.png'));assert.equal(validateImage(original).width,2048);
});
test('truncated headers and disguised SVG/HTML are rejected',()=>{
 for(const bytes of Object.values(fixtures))for(const cut of [4,12,bytes.length-1])assert.throws(()=>validateImage(bytes.subarray(0,cut)));
 for(const text of ['<svg onload="alert(1)"></svg>','<html><script>alert(1)</script>','GIF89a<html>','RIFFxxxxWEBP<html>'])assert.throws(()=>validateImage(Buffer.from(text)));
});
test('huge decoded image dimensions and excessive animation frames are rejected before storage',()=>{
 const png=Buffer.from(fixtures.png);png.writeUInt32BE(65535,16);assert.throws(()=>validateImage(png),/8,192/);
 const pixels=Buffer.from(fixtures.png);pixels.writeUInt32BE(6000,16);pixels.writeUInt32BE(6000,20);assert.throws(()=>validateImage(pixels),/megapixels/);
 const gif=Buffer.from(fixtures.gif);gif.writeUInt16LE(65535,6);assert.throws(()=>validateImage(gif),/8,192/);
 const jpeg=Buffer.from(fixtures.jpeg),sof=jpeg.indexOf(Buffer.from([255,192]));jpeg.writeUInt16BE(65535,sof+5);assert.throws(()=>validateImage(jpeg),/8,192/);
 const webp=Buffer.from(fixtures.webp),vp8=webp.indexOf('VP8 ');webp.writeUInt16LE(16383,vp8+14);assert.throws(()=>validateImage(webp),/8,192/);
 const apng=Buffer.from(fixtures.animated_png),actl=apng.indexOf('acTL');apng.writeUInt32BE(301,actl+4);assert.throws(()=>validateImage(apng),/animation is too large/);
 const agif=Buffer.from(fixtures.animated_gif);agif.writeUInt16LE(8000,6);agif.writeUInt16LE(3000,8);
 const firstImage=agif.indexOf(0x2c),lastImage=agif.lastIndexOf(0x2c);const firstFrame=agif.subarray(firstImage,lastImage-8),extension=agif.subarray(lastImage-8,lastImage);
 const bomb=Buffer.concat([agif.subarray(0,firstImage),...Array.from({length:5},()=>Buffer.concat([firstFrame,extension])),agif.subarray(lastImage)]);
 assert.throws(()=>validateImage(bomb),/animation is too large/);
});
test('upload route validates binary content independently of supplied MIME and keeps 5MB body limit',async()=>{
 const before=writes;const bad=await post(Buffer.from('GIF89a<script>alert(1)</script>'),'image/gif');assert.equal(bad.status,400);assert.equal(writes,before);
 const huge=Buffer.from(fixtures.png);huge.writeUInt32BE(65535,16);assert.equal((await post(huge)).status,400);assert.equal(writes,before);
 assert.equal((await post(new Uint8Array(5*1024*1024+1))).status,413);assert.equal(writes,before);
 const valid=await post(fixtures.png,'text/html');assert.equal(valid.status,201);const {url}=await valid.json();assert.match(url,/\.png$/);assert.equal(stored.get(url.split('/').pop()).httpMetadata.contentType,'image/png');
});
test('private uploads require uploader or referencing-bracket manager; only posted public references make them public',async()=>{
 const ownerId=await hash('1'.repeat(64)),managerId=await hash('2'.repeat(64));
 for(const kind of ['entry','brand','page_background','board_background','center_logo','champion_logo','footer_logo']){
  const response=await post(fixtures.png),{url}=await response.json(),key=url.split('/').pop();
  assert.equal((await get(key,stranger)).status,404);assert.equal((await get(key)).status,404);
  const own=await get(key,owner);assert.equal(own.status,200);assert.equal(own.headers.get('cache-control'),'private,no-store');
  const id=crypto.randomUUID();
  sqlite.prepare("INSERT INTO brackets(id,title,size,accent,status,owner_id,manage_hash,created_at,brand_image,appearance,is_test) VALUES(?,'Private test',2,'purple','draft',?,'test',?, ?, ?,1)").run(id,ownerId,Date.now(),kind==='brand'?url:null,JSON.stringify({images:kind!=='entry'&&kind!=='brand'?{[kind]:url}:{}}));
  if(kind==='entry')sqlite.prepare("INSERT INTO entries(id,bracket_id,name,subtitle,image,seed) VALUES(?,?,'Entry','',?,1)").run(crypto.randomUUID(),id,url);
  sqlite.prepare('INSERT INTO managers(bracket_id,identity_id) VALUES(?,?)').run(id,managerId);
  const manage=await get(key,manager);assert.equal(manage.status,200,kind);assert.equal(manage.headers.get('cache-control'),'private,no-store');
  assert.equal((await get(key,stranger)).status,404,kind);
  sqlite.prepare("UPDATE brackets SET status='live' WHERE id=?").run(id);assert.equal((await get(key,stranger)).status,404,'test uploads remain private even when live');
  sqlite.prepare('UPDATE brackets SET is_test=0 WHERE id=?').run(id);
  stored.get(key).httpMetadata.contentType='text/html';
  const pub=await get(key,stranger);assert.equal(pub.status,200,kind);assert.equal(pub.headers.get('content-type'),'image/png');assert.equal(pub.headers.get('cache-control'),'public,max-age=300');assert.equal(pub.headers.get('x-content-type-options'),'nosniff');assert.match(pub.headers.get('content-security-policy'),/sandbox/);
  if(kind==='entry')sqlite.prepare('UPDATE entries SET image=NULL WHERE bracket_id=?').run(id);else if(kind==='brand')sqlite.prepare('UPDATE brackets SET brand_image=NULL WHERE id=?').run(id);else sqlite.prepare("UPDATE brackets SET appearance='{}' WHERE id=?").run(id);
  assert.equal((await get(key,stranger)).status,404,'removed references are no longer authorized at the origin');
 }
 assert.equal((await get('../../test',owner)).status,404);
});
test('parallel uploads cannot exceed the daily quota, and failed storage releases its reservation',async()=>{
 const token='4'.repeat(64),cookie=`bl_voter=${token}`,id=await hash(token),now=Date.now();
 const insert=sqlite.prepare('INSERT INTO media(id,owner_id,content_type,size,created_at) VALUES(?,?,?,?,?)');
 for(let i=0;i<149;i++)insert.run(`${crypto.randomUUID()}.png`,id,'image/png',1,now);
 const responses=await Promise.all(Array.from({length:6},()=>post(fixtures.png,'image/png',cookie)));
 assert.equal(responses.filter(r=>r.status===201).length,1);assert.equal(responses.filter(r=>r.status===429).length,5);
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM media WHERE owner_id=?').get(id).n,150);
 const failToken='5'.repeat(64),failId=await hash(failToken);failStorage=true;
 const originalError=console.error;console.error=()=>{};
 try{assert.equal((await post(fixtures.png,'image/png',`bl_voter=${failToken}`)).status,503);}finally{failStorage=false;console.error=originalError;}
 assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM media WHERE owner_id=?').get(failId).n,0);
});
test('legacy uploads are dimension-checked once and invalid legacy images remain blocked without deletion',async()=>{
 const ownerId=await hash('1'.repeat(64)),insert=sqlite.prepare('INSERT INTO media(id,owner_id,content_type,size,created_at) VALUES(?,?,?,?,?)');
 for(const valid of [true,false]){
  const key=`${crypto.randomUUID()}.png`,bytes=Buffer.from(fixtures.png);if(!valid)bytes.writeUInt32BE(65535,16);
  insert.run(key,ownerId,'image/png',bytes.length,Date.now());let reads=0;
  stored.set(key,{body:bytes,size:bytes.length,httpMetadata:{contentType:'image/png'},async arrayBuffer(){reads++;return Uint8Array.from(bytes).buffer;}});
  assert.equal((await get(key,stranger)).status,404);assert.equal(reads,0,'authorization runs before fetching private bytes');
  const first=await get(key,owner);assert.equal(first.status,valid?200:400);assert.equal(reads,1);
  assert.equal(sqlite.prepare('SELECT validation_version FROM media WHERE id=?').get(key).validation_version,valid?1:0);
  assert.equal((await get(key,owner)).status,valid?200:400);assert.equal(reads,valid?1:2);
  assert.ok(stored.has(key),'original uploads are never deleted by inspection');
 }
 const large=`${crypto.randomUUID()}.png`;insert.run(large,ownerId,'image/png',6*1024*1024,Date.now());
 stored.set(large,{body:fixtures.png,size:6*1024*1024,async arrayBuffer(){assert.fail('must reject oversized object before reading bytes');}});
 assert.equal((await get(large,owner)).status,400);
});
test('all CSV exports use one formula-safe encoder including leading whitespace and control prefixes',()=>{
 for(const value of ['=1+1','+cmd','-cmd','@SUM(A1)','\t=1+1','\r=1+1','\n=1+1','  =1+1','\u0000\t=1+1','\uFEFF=1+1','＝1+1'])assert.ok(csvCell(value).startsWith('"\''),JSON.stringify(value));
 assert.equal(csvCell(-12),'"-12"');assert.equal(csvCell('Team "A", B'),'"Team ""A"", B"');assert.equal(csvCell('Ordinary name'),'"Ordinary name"');
 for(const file of ['components/analytics-dashboard.tsx','components/season-app.tsx','lib/bracket-export.ts'])assert.match(fs.readFileSync(path.join(root,file),'utf8'),/row\.map\(csvCell\)/,file);
});
