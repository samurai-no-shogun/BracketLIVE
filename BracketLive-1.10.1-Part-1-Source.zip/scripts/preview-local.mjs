import {access, mkdir, writeFile} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {dirname, resolve} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {limits} from './configure-security.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

// Deliberately independent of the production wrangler.json and its resources.
export function previewConfig() {
  return {
    name: 'bracketlive-ui-preview',
    main: '../dist/server/index.js',
    compatibility_date: '2026-05-15',
    compatibility_flags: ['nodejs_compat'],
    workers_dev: false,
    triggers: {crons: ['* * * * *']},
    assets: {directory: '../dist/client', binding: 'ASSETS'},
    d1_databases: [{
      binding: 'DB',
      database_name: 'bracketlive-ui-preview',
      database_id: '00000000-0000-4000-8000-000000000128',
      migrations_dir: '../drizzle',
    }],
    r2_buckets: [{binding: 'BUCKET', bucket_name: 'bracketlive-ui-preview-media'}],
    ratelimits: Object.entries(limits).map(([name, limit], index) => ({
      name,
      namespace_id: String(128000001 + index),
      simple: {limit, period: 60},
    })),
    dev: {ip: '127.0.0.1', port: 8787, local_protocol: 'http'},
  };
}

// All command arguments are fixed. No file paths or user input enter cmd.exe.
export function previewCommand(stage, platform = process.platform) {
  const common = ['--config', 'wrangler.json', '--persist-to', './state'];
  let args;
  if (stage === 'migrate') args = ['d1', 'migrations', 'apply', 'DB', '--local', ...common];
  else if (stage === 'seed') args = ['d1', 'execute', 'DB', '--local', '--file', '../scripts/preview-seed.sql', ...common];
  else if (stage === 'serve') args = ['dev', '--local', '--test-scheduled', '--ip', '127.0.0.1', '--port', '8787', ...common];
  else throw new Error('Unknown preview stage.');
  const npxArgs = ['--yes', 'wrangler@4.147.0', ...args];
  return platform === 'win32'
    ? {command: 'cmd.exe', args: ['/d', '/s', '/c', `npx.cmd ${npxArgs.join(' ')}`]}
    : {command: 'npx', args: npxArgs};
}

// Wrangler's local-only test hook changed names across versions. Never target
// a production origin, and never add a publicly accessible scheduler API.
export async function triggerPreviewScheduler(fetcher = fetch) {
  // Workers Assets can route the native hook to an asset router without a
  // scheduled handler. Wrangler's --test-scheduled middleware reaches the app.
  for (const path of ['/__scheduled?cron=*+*+*+*+*', '/cdn-cgi/local/scheduled?cron=*+*+*+*+*', '/cdn-cgi/handler/scheduled?cron=*+*+*+*+*']) {
    const response = await fetcher(`http://127.0.0.1:8787${path}`, {signal: AbortSignal.timeout(10000)});
    if (response.status === 404) continue;
    if (!response.ok) throw new Error('The local scheduler could not complete.');
    return;
  }
  throw new Error('This Wrangler version does not expose its local scheduler hook.');
}

async function run(stage, cwd) {
  const {command, args} = previewCommand(stage);
  return new Promise((resolveExit, reject) => {
    const child = spawn(command, args, {
      cwd,
      stdio: 'inherit',
      shell: false,
      env: {
        ...process.env,
        WRANGLER_SEND_METRICS: 'false',
        CLOUDFLARE_LOAD_DEV_VARS_FROM_DOT_ENV: 'false',
        CLOUDFLARE_INCLUDE_PROCESS_ENV: 'false',
      },
    });
    let ticking = false;
    const timer = stage === 'serve' ? setInterval(async () => {
      if (ticking) return;
      ticking = true;
      try { await triggerPreviewScheduler(); }
      catch { /* startup/shutdown may briefly have no listening server */ }
      finally { ticking = false; }
    }, 15000) : null;
    const stopTimer = () => { if (timer) clearInterval(timer); };
    child.once('error', error => { stopTimer(); reject(error); });
    child.once('exit', (code, signal) => { stopTimer(); resolveExit(signal === 'SIGINT' ? 0 : code ?? 1); });
  });
}

export async function preparePreview(root = ROOT) {
  try {
    await Promise.all([
      access(resolve(root, 'dist/server/index.js')),
      access(resolve(root, 'dist/client')),
      access(resolve(root, 'drizzle/0006_media_access.sql')),
    ]);
  } catch {
    throw new Error('The built website is missing. Extract the complete Bracket Live update ZIP, then run this command again.');
  }
  const preview = resolve(root, '.preview');
  await mkdir(preview, {recursive: true});
  await writeFile(resolve(preview, '.gitignore'), '*\n');
  await writeFile(resolve(preview, 'wrangler.json'), JSON.stringify(previewConfig(), null, 2) + '\n');
  return preview;
}

async function main() {
  if (process.argv.length > 2) throw new Error('Usage: node scripts/preview-local.mjs');
  const preview = await preparePreview();
  console.log('Preparing your local Bracket Live preview. Its votes and images stay in .preview/state.');
  const migrated = await run('migrate', preview);
  if (migrated !== 0) throw new Error(`Local database setup exited with code ${migrated}. The preview was not started.`);
  const seeded = await run('seed', preview);
  if (seeded !== 0) throw new Error(`Local sample setup exited with code ${seeded}. The preview was not started.`);
  console.log('\nOpen http://127.0.0.1:8787 after Wrangler reports Ready. Press Ctrl+C to stop.');
  console.log('Local scheduled rounds are checked every 15 seconds while this terminal stays open. Email sending is not configured in this preview.');
  process.exitCode = await run('serve', preview);
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  main().catch(error => {
    console.error(`Preview failed: ${error.message}`);
    process.exitCode = 1;
  });
}
