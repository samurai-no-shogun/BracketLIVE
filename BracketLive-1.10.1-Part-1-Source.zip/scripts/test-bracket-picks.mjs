import assert from 'node:assert/strict';
import {test} from 'node:test';
import {changeBracketPick,parseStoredPicks,picksStorageKey,projectBracketPicks,serializeStoredPicks} from '../lib/bracket-picks.ts';

function fixture(size=64){
 const entries=Array.from({length:size},(_,i)=>({id:`e${i+1}`,name:`Team ${i+1}`,seed:i+1,subtitle:'',image:null}));
 const matches=[];
 for(let round=0;round<Math.log2(size);round++)for(let position=0;position<size/2**(round+1);position++)matches.push({id:`m${round}-${position}`,round,position,a_id:round===0?entries[position*2].id:null,b_id:round===0?entries[position*2+1].id:null,winner_id:null,status:round===0?'open':'pending',myVote:null,counts:null,total:null,decided_by:null});
 return {id:'bracket-demo',title:'Tournament',size,format:size===64?'basketball':'standard',entries,matches,status:'live',current_round:0,totalVotes:0,description:'',accent:'purple',brand_color:null,brand_image:null,appearance:{},listed:true,ends_at:null,created_at:0,started_at:0,round_closes_at:null,is_test:false,isOwner:false};
}
function fill(source){let picks={};for(const original of source.matches){const m=projectBracketPicks(source,picks).bracket.matches.find(m=>m.id===original.id);picks=changeBracketPick(source,picks,m.id,m.a_id);}return picks;}

test('a full 64-team personal bracket reaches a champion across all 63 matches without server results',()=>{
 const source=fixture(),before=structuredClone(source),picks=fill(source),view=projectBracketPicks(source,picks);
 assert.equal(view.completed,63);assert.equal(view.bracket.status,'complete');assert.equal(view.bracket.matches.at(-1).winner_id,'e1');
 assert.deepEqual(view.bracket.matches.map(m=>m.round).reduce((counts,r)=>(counts[r]=(counts[r]||0)+1,counts),{}),{0:32,1:16,2:8,3:4,4:2,5:1});
 assert.ok(view.bracket.matches.every(m=>m.counts===null&&m.total===null));
 assert.deepEqual(source,before,'personal picks never mutate the community bracket');
});

for(const size of [2,128])test(`${size} entrants: complete, undo the champion's opening pick, and rebuild a new champion`,()=>{
 const source=fixture(size),before=structuredClone(source),original=fill(source),full=projectBracketPicks(source,original);
 const rounds=Math.log2(size);
 assert.equal(full.completed,size-1);assert.equal(full.bracket.matches.length,size-1);
 assert.equal(full.bracket.status,'complete');assert.equal(full.bracket.matches.at(-1).winner_id,'e1');
 assert.equal(full.bracket.current_round,rounds-1);
 let picks=changeBracketPick(source,original,'m0-0',null),view=projectBracketPicks(source,picks);
 assert.equal(view.completed,size-1-rounds,'undo clears exactly the dependent path through the final');
 assert.equal(view.bracket.matches.at(-1).winner_id,null);
 assert.equal(view.bracket.matches.at(-1).status,size===2?'open':'pending');
 assert.equal(view.bracket.current_round,0);
 for(let round=0;round<rounds;round++)assert.equal(picks[`m${round}-0`],undefined);
 if(size>2)assert.equal(picks[`m${rounds-2}-1`],original[`m${rounds-2}-1`],'opposite finalist is unchanged');
 picks=changeBracketPick(source,picks,'m0-0','e2');
 for(let round=1;round<rounds;round++)picks=changeBracketPick(source,picks,`m${round}-0`,'e2');
 view=projectBracketPicks(source,picks);
 assert.equal(view.completed,size-1);assert.equal(view.bracket.status,'complete');assert.equal(view.bracket.matches.at(-1).winner_id,'e2');
 assert.deepEqual(source,before);assert.equal(original['m0-0'],'e1');
});

test('changing an early pick clears eliminated downstream winners and preserves the other side',()=>{
 const source=fixture(8),original=fill(source),picks=changeBracketPick(source,original,'m0-0','e2');
 const view=projectBracketPicks(source,picks),next=view.bracket.matches.find(m=>m.id==='m1-0');
 assert.equal(next.a_id,'e2');assert.equal(next.b_id,'e3');assert.equal(next.winner_id,null);
 assert.equal(picks['m2-0'],undefined);assert.equal(picks['m1-1'],'e5');assert.equal(picks['m0-3'],'e7');
 assert.equal(original['m0-0'],'e1','original picks map is unchanged');
});

test('a later pick stays valid when only its losing opponent changes',()=>{
 const source=fixture(4);let picks=fill(source);
 picks=changeBracketPick(source,picks,'m0-1','e4');
 assert.equal(picks['m1-0'],'e1');assert.equal(projectBracketPicks(source,picks).bracket.status,'complete');
});

test('undo makes dependent matches pending and clears their picks even if the opponent was chosen',()=>{
 const source=fixture(4),picks=changeBracketPick(source,fill(source),'m0-1',null),view=projectBracketPicks(source,picks);
 assert.equal(picks['m0-1'],undefined);assert.equal(picks['m1-0'],undefined);
 const final=view.bracket.matches.at(-1);assert.equal(final.a_id,'e1');assert.equal(final.b_id,null);assert.equal(final.status,'pending');
 assert.throws(()=>changeBracketPick(source,picks,final.id,'e1'),/previous-round/);
});

test('community winners, votes and deadlines cannot fill or change personal predictions',()=>{
 const source=fixture(4),picks=fill(source);
 source.matches[0]={...source.matches[0],winner_id:'e2',myVote:'e2',counts:{e2:5},total:5,status:'closed'};
 source.matches[2]={...source.matches[2],a_id:'e2',b_id:'e4',winner_id:'e4',status:'closed'};
 source.status='complete';source.current_round=1;source.totalVotes=15;source.ends_at=1234;source.round_closes_at=1234;
 const blank=projectBracketPicks(source,{}),personal=projectBracketPicks(source,picks);
 assert.equal(blank.completed,0);assert.equal(blank.bracket.matches.at(-1).a_id,null);
 assert.equal(personal.bracket.matches.at(-1).winner_id,'e1');assert.equal(personal.bracket.totalVotes,0);assert.equal(personal.bracket.ends_at,null);
});

test('unknown, foreign and premature picks are dropped; a future match cannot be picked before it exists',()=>{
 const source=fixture(4),view=projectBracketPicks(source,{'m0-0':'outside','m0-1':'e3','m1-0':'e1',junk:'e1'});
 assert.deepEqual(view.picks,{'m0-1':'e3'});
 assert.throws(()=>changeBracketPick(source,{},'m0-0','e3'),/previous-round/);
 assert.throws(()=>changeBracketPick(source,{},'junk','e1'),/not in/);
 assert.deepEqual(projectBracketPicks(source,null).picks,{});
});

test('device persistence is versioned and isolated by bracket ID',()=>{
 const source=fixture(4),picks=fill(source);
 assert.deepEqual(parseStoredPicks(serializeStoredPicks(picks)),picks);
 assert.notEqual(picksStorageKey('one'),picksStorageKey('two'));
 assert.deepEqual(parseStoredPicks(null),{});assert.deepEqual(parseStoredPicks('{"version":2,"picks":{"m":"e"}}'),{});
 assert.deepEqual(parseStoredPicks('{"version":1,"picks":{"good":"e1","bad":24}}'),{good:'e1'});
 assert.throws(()=>parseStoredPicks('broken'));
});
