import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { test } from 'node:test';

const root = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(import.meta.url), ts = require('typescript'), modules = new Map(), externalMocks = new Map();
function load(file) {
  file = path.resolve(root, file);
  if (!path.extname(file)) file += '.ts';
  if (modules.has(file)) return modules.get(file).exports;
  const module = { exports: {} }; modules.set(file, module);
  const source = fs.readFileSync(file, 'utf8').replaceAll('import.meta.url', JSON.stringify(pathToFileURL(file).href));
  const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
  const localRequire = id => externalMocks.has(id) ? externalMocks.get(id) : id.startsWith('.') ? load(path.resolve(path.dirname(file), id)) : require(id);
  new Function('require', 'module', 'exports', compiled)(localRequire, module, module.exports);
  return module.exports;
}
const { inspectVisualImage, assertVisualDimensions, boundVisualText, visualRenderSize, extractVisualImport, VISUAL_IMPORT_LIMITS } = load('lib/import-visual.ts');
const fixtures = Object.fromEntries(Object.entries(JSON.parse(fs.readFileSync(new URL('./security-image-fixtures.json', import.meta.url), 'utf8'))).map(([key, value]) => [key, Buffer.from(value, 'base64')]));

test('visual import validates actual PNG, JPEG, and WebP bytes instead of trusting a filename', () => {
  for (const kind of ['png', 'jpeg', 'webp']) {
    const image = inspectVisualImage(fixtures[kind]);
    assert.equal(image.width, 3, kind); assert.equal(image.height, 2, kind);
  }
  for (const text of ['<svg onload="alert(1)"></svg>', '<html>fake image</html>']) assert.throws(() => inspectVisualImage(Buffer.from(text)));
  assert.throws(() => inspectVisualImage(fixtures.gif), /PNG, JPG, or WebP/);
  assert.throws(() => inspectVisualImage(fixtures.png.subarray(0, 20)));
});

test('image and render pixel bounds reject decompression-sized snapshots before decoding', () => {
  assert.throws(() => assertVisualDimensions(5000, 5000), /20 megapixels/);
  assert.throws(() => assertVisualDimensions(8193, 2), /8,192/);
  assert.throws(() => assertVisualDimensions(0, 2));
  assert.throws(() => assertVisualDimensions(Infinity, 2));
  const png = Buffer.from(fixtures.png); png.writeUInt32BE(5000, 16); png.writeUInt32BE(5000, 20);
  assert.throws(() => inspectVisualImage(png), /20 megapixels/);
  for (const dimensions of [[4000, 4000], [8192, 1], [1, 8192], [5000, 4000], [3, 2]]) {
    const rendered = visualRenderSize(...dimensions);
    assert.ok(rendered.width * rendered.height <= VISUAL_IMPORT_LIMITS.renderPixels);
    assert.ok(Math.max(rendered.width, rendered.height) <= VISUAL_IMPORT_LIMITS.renderDimension);
    assert.ok(rendered.scale <= 1);
  }
});

test('extracted text is bounded and normalized without dropping tabs used for column review', () => {
  assert.equal(boundVisualText('\u0000Orion\t1\r\nNova\u000b\rAtlas\n'), 'Orion\t1\nNova\nAtlas');
  assert.throws(() => boundVisualText('a'.repeat(VISUAL_IMPORT_LIMITS.textCharacters + 1)), /too much text/);
  assert.throws(() => boundVisualText(Array(VISUAL_IMPORT_LIMITS.textLines + 1).fill('x').join('\n')), /too many rows/);
});

function mockedBrowser(onPost, body) {
  const names = ['window', 'document', 'location', 'Worker', 'createImageBitmap'];
  const original = Object.fromEntries(names.map(name => [name, Object.getOwnPropertyDescriptor(globalThis, name)]));
  const workers = []; let closed = 0;
  Object.assign(globalThis, {
    window: {}, location: { origin: 'https://bracket.example' },
    document: { createElement: () => ({ width: 0, height: 0, getContext: () => ({ fillRect() {}, drawImage() {} }), toBlob(callback) { callback(new Blob([fixtures.png], { type: 'image/png' })); } }) },
    createImageBitmap: async () => ({ width: 3, height: 2, close() { closed++; } }),
    Worker: class {
      constructor(url, options) { this.url = url; this.options = options; this.terminated = 0; workers.push(this); }
      terminate() { this.terminated++; }
      postMessage(message) { onPost(this, message); }
    },
  });
  return Promise.resolve().then(() => body(workers, () => closed)).finally(() => {
    for (const name of names) { if (original[name]) Object.defineProperty(globalThis, name, original[name]); else delete globalThis[name]; }
  });
}

test('OCR result review preserves text, warnings, local input blobs, and releases resources', async () => {
  await mockedBrowser((worker, request) => {
    assert.ok(request.blob instanceof Blob);
    assert.equal(request.origin, 'https://bracket.example');
    assert.equal(worker.options.type, 'module');
    queueMicrotask(() => worker.onmessage({ data: { type: 'result', result: { text: 'Orion\nNova', confidence: 55, lines: [{ text: 'Orion', page: 1, x: 1, y: 1, width: 20, height: 8 }] } } }));
  }, async (workers, closes) => {
    const result = await extractVisualImport(new File([fixtures.png], 'disguised.svg', { type: 'text/html' }));
    assert.equal(result.text, 'Orion\nNova');
    assert.ok(result.warnings.some(warning => /confidence is low/.test(warning)));
    assert.ok(result.warnings.some(warning => /not recreated automatically/.test(warning)));
    assert.ok(workers.every(worker => worker.terminated));
    assert.ok(closes() >= 1);
  });
});

test('abort immediately terminates the OCR worker even before initialization returns', async () => {
  const controller = new AbortController();
  await mockedBrowser(() => controller.abort(), async workers => {
    await assert.rejects(extractVisualImport(new File([fixtures.png], 'snapshot.png'), { signal: controller.signal }), error => error.name === 'AbortError');
    assert.equal(workers.length, 1);
    assert.ok(workers[0].terminated);
  });
});

test('pre-cancelled or oversized imports do not create an OCR worker', async () => {
  await mockedBrowser(() => assert.fail('No worker request expected'), async workers => {
    const controller = new AbortController(); controller.abort();
    await assert.rejects(extractVisualImport(new File([fixtures.png], 'snapshot.png'), { signal: controller.signal }), error => error.name === 'AbortError');
    await assert.rejects(extractVisualImport(new File([new Uint8Array(VISUAL_IMPORT_LIMITS.fileBytes + 1)], 'snapshot.png')), /smaller than 10 MB/);
    assert.equal(workers.length, 0);
  });
});

function mockPDF({ pageCount = 2, textItems, cancelStream = () => {}, render = () => assert.fail('Selectable text must not render the page') }) {
  let destroyed = 0;
  const pdf = {
    GlobalWorkerOptions: {}, AnnotationMode: { DISABLE: 0 },
    PDFWorker: { create({ port }) { assert.ok(port); return { destroy() { destroyed++; } }; } },
    getDocument(options) {
      assert.ok(options.data instanceof Uint8Array);
      assert.equal(options.url, undefined);
      assert.equal(options.enableXfa, false);
      assert.equal(options.useWorkerFetch, false);
      assert.equal(options.cMapUrl, '/import-assets/pdf-cmaps/');
      return {
        destroy: async () => { destroyed++; },
        promise: Promise.resolve({ numPages: pageCount, getPage: async () => ({
          getTextContent: () => assert.fail('Must stream PDF text rather than accumulating a whole page'),
          streamTextContent: () => new ReadableStream({
            start(controller) { for (const items of textItems) controller.enqueue({ items }); controller.close(); },
            cancel: cancelStream,
          }),
          getViewport: ({ scale }) => ({ width: 612 * scale, height: 792 * scale }),
          render,
        }) }),
      };
    },
  };
  externalMocks.set('pdfjs-dist', pdf);
  return { close() { externalMocks.delete('pdfjs-dist'); }, destroyed: () => destroyed };
}

test('PDF imports read only the chosen page with bounded text streaming and a page-count warning', async () => {
  const pdf = mockPDF({ textItems: [[
    { str: 'Name', transform: [1, 0, 0, 12, 10, 100], width: 30, height: 12 },
    { str: 'Seed', transform: [1, 0, 0, 12, 100, 100], width: 30, height: 12 },
    { str: 'Orion', transform: [1, 0, 0, 12, 10, 80], width: 40, height: 12 },
    { str: '1', transform: [1, 0, 0, 12, 100, 80], width: 10, height: 12 },
  ]] });
  try {
    await mockedBrowser(() => assert.fail('No OCR needed'), async workers => {
      const result = await extractVisualImport(new File(['%PDF-1.7\n'], 'document.pdf'), { page: 2 });
      assert.equal(result.pageCount, 2);
      assert.equal(result.text, 'Name\tSeed\nOrion\t1');
      assert.ok(result.warnings.some(warning => /Only page 2 of 2/.test(warning)));
      assert.equal(workers.length, 1);
      assert.equal(workers[0].url, '/import-assets/pdf.worker.min.mjs');
      assert.ok(workers[0].terminated);
      assert.ok(pdf.destroyed());
    });
  } finally { pdf.close(); }
});

test('compressed PDF text output and oversized page catalogs fail before rendering', async () => {
  for (const options of [
    { textItems: Array.from({ length: 12 }, () => [{ str: 'x'.repeat(10_000) }]) },
    { pageCount: 201, textItems: [] },
  ]) {
    const pdf = mockPDF(options);
    try {
      await mockedBrowser(() => assert.fail('No OCR needed'), async workers => {
        await assert.rejects(extractVisualImport(new File(['%PDF-1.7\n'], 'document.pdf')), /too much text|200 pages or fewer/);
        assert.ok(workers[0].terminated);
        assert.ok(pdf.destroyed());
      });
    } finally { pdf.close(); }
  }
});

test('scanned PDF pages use bounded OCR and disable annotation rendering', async () => {
  const pdf = mockPDF({ pageCount: 1, textItems: [], render(options) {
    assert.equal(options.annotationMode, 0);
    assert.ok(options.canvas.width * options.canvas.height <= VISUAL_IMPORT_LIMITS.renderPixels);
    return { promise: Promise.resolve(), cancel() {} };
  } });
  try {
    await mockedBrowser((worker, request) => {
      assert.ok(request.blob instanceof Blob);
      queueMicrotask(() => worker.onmessage({ data: { type: 'result', result: { text: 'Orion\nNova', confidence: 90, lines: [] } } }));
    }, async workers => {
      const result = await extractVisualImport(new File(['%PDF-1.7\n'], 'scan.pdf'));
      assert.equal(result.text, 'Orion\nNova');
      assert.ok(result.warnings.some(warning => /Scanned-page recognition/.test(warning)));
      assert.equal(workers.length, 2);
      assert.ok(workers.every(worker => worker.terminated));
    });
  } finally { pdf.close(); }
});
