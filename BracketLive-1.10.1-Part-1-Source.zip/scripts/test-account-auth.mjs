import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {DatabaseSync} from 'node:sqlite';
import {after,before,test} from 'node:test';
import {fileURLToPath} from 'node:url';

// Real route handlers, migrations and SQLite transactions. Providers are mocked
// at the HTTPS boundary; no email is sent and no production resource is used.
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript');
const sqlite=new DatabaseSync(':memory:');sqlite.exec('PRAGMA foreign_keys=ON');
for(const name of fs.readdirSync(path.join(root,'drizzle')).filter(n=>n.endsWith('.sql')).sort())sqlite.exec(fs.readFileSync(path.join(root,'drizzle',name),'utf8'));
class Statement{
 constructor(query,values=[]){this.query=query;this.values=values;}
 bind(...values){return new Statement(this.query,values);}
 execute(){const query=sqlite.prepare(this.query);return query.columns().length?{results:query.all(...this.values),meta:{changes:0}}:{results:[],meta:{changes:Number(query.run(...this.values).changes)}};}
 async first(){return sqlite.prepare(this.query).get(...this.values)??null;}
 async all(){return this.execute();}
 async run(){return this.execute();}
}
let beforeBatch=null;
const database={prepare:query=>new Statement(query),async batch(statements){if(beforeBatch){const hook=beforeBatch;beforeBatch=null;hook();}sqlite.exec('BEGIN');try{const result=statements.map(s=>s.execute());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}}};
const origin='https://bracket.example',env={DB:database,AUTH_ORIGIN:origin,RESEND_API_KEY:'test-provider-secret',AUTH_EMAIL_FROM:'BracketLive <auth@example.com>'},modules=new Map();
function loadSource(file){file=path.resolve(root,file);if(!path.extname(file))file+='.ts';if(modules.has(file))return modules.get(file).exports;const module={exports:{}};modules.set(file,module);const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;const localRequire=id=>id==='cloudflare:workers'?{env}:id.startsWith('@/')?loadSource(id.slice(2)):id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);new Function('require','module','exports',compiled)(localRequire,module,module.exports);return module.exports;}
const auth=loadSource('lib/account-auth.ts'),server=loadSource('lib/server.ts'),accountRoute=loadSource('app/api/account/route.ts'),emailRoute=loadSource('app/api/auth/email/route.ts'),verifyRoute=loadSource('app/api/auth/email/verify/route.ts'),logoutRoute=loadSource('app/api/auth/logout/route.ts'),googleRoute=loadSource('app/api/auth/google/route.ts'),callbackRoute=loadSource('app/api/auth/google/callback/route.ts');
const bracketRoute=loadSource('app/api/brackets/route.ts'),voteRoute=loadSource('app/api/brackets/[id]/vote/route.ts'),{makeDraft}=loadSource('lib/bracket.ts');
const request=(url,{method='GET',cookie='',data,headers={}}={})=>new Request(origin+url,{method,headers:{Origin:origin,'Content-Type':'application/json',Cookie:cookie,...headers},...(data===undefined?{}:{body:JSON.stringify(data)})});
const jar=(...responses)=>{const values=new Map();for(const item of responses){for(const value of typeof item==='string'?item.split('; '):item.headers.getSetCookie().map(v=>v.split(';')[0])){const i=value.indexOf('=');values.set(value.slice(0,i),value.slice(i+1));}}return [...values].map(([k,v])=>`${k}=${v}`).join('; ');};
const guest=()=>`bl_voter=${server.token()}`;
let sentEmail=null,providerFailure=false,googleToken=null,googleJwk=null,tokenRequest=null;
const oldFetch=globalThis.fetch;
globalThis.fetch=async(url,options={})=>{if(url==='https://api.resend.com/emails'){sentEmail=JSON.parse(options.body);return new Response('{}',{status:providerFailure?503:200});}if(url==='https://oauth2.googleapis.com/token'){tokenRequest=options.body;return new Response(JSON.stringify({id_token:googleToken}));}if(url==='https://www.googleapis.com/oauth2/v3/certs')return new Response(JSON.stringify({keys:[googleJwk]}),{headers:{'Cache-Control':'max-age=300'}});throw new Error('Unexpected outbound request: '+url);};
after(()=>{globalThis.fetch=oldFetch;sqlite.close();});
const read=async(response,status=200)=>{assert.equal(response.status,status,await response.clone().text());return response.json();};
async function emailStart(email,cookie=guest(),returnTo='/account'){sentEmail=null;const response=await emailRoute.POST(request('/api/auth/email',{method:'POST',cookie,data:{email,returnTo}}));await read(response);assert.ok(sentEmail);const secret=sentEmail.text.match(/#token=([a-f0-9]{64})/)[1];return {secret,cookie:jar(cookie,response),response};}
async function emailLogin(email,cookie=guest()){const started=await emailStart(email,cookie),response=await verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:started.cookie,data:{token:started.secret}}));const data=await read(response);return {...started,response,data,cookie:jar(started.cookie,response)};}
async function fixture(cookie){return read(await bracketRoute.POST(request('/api/brackets',{method:'POST',cookie,data:{...makeDraft(2,false),title:'Account migration fixture',action:'publish'}})),201);}

 test('providers are explicitly disabled unless origin and provider settings are complete',async()=>{
  const saved={...env};delete env.AUTH_ORIGIN;assert.deepEqual((await read(await accountRoute.GET(request('/api/account')))).providers,{google:false,email:false});assert.equal((await emailRoute.POST(request('/api/auth/email',{method:'POST',data:{email:'person@example.com'}}))).status,503);Object.assign(env,saved);
  assert.deepEqual(auth.accountProviders(request('/api/account')),{google:false,email:true});assert.deepEqual(auth.accountProviders(new Request('https://evil.example/api/account')),{google:false,email:false});
 });
 test('email links require explicit same-browser POST, expire, cannot replay, and never store raw tokens',async()=>{
  const started=await emailStart('bound@example.com'),row=sqlite.prepare("SELECT * FROM account_challenges WHERE kind='email' AND subject_hash=?").get(await server.hash('bound@example.com'));
  assert.ok(!JSON.stringify(row).includes(started.secret));assert.equal(row.consumed_at,null,'email delivery does not sign in');
  assert.equal((await verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:guest(),data:{token:started.secret}}))).status,403);
  assert.equal((await verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:started.cookie,data:{token:started.secret},headers:{Origin:'https://evil.example'}}))).status,403);
  const response=await verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:started.cookie,data:{token:started.secret}})),data=await read(response);assert.equal(data.user.email,'bound@example.com');assert.equal(data.returnTo,'/account');
  assert.match(response.headers.get('set-cookie'),/bl_account=[a-f0-9]{64}; HttpOnly; SameSite=Lax; Path=\/; Max-Age=2592000; Secure/);
  assert.equal((await verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:started.cookie,data:{token:started.secret}}))).status,400);
  const expired=await emailStart('expired@example.com');sqlite.prepare('UPDATE account_challenges SET expires_at=? WHERE token_hash=?').run(Date.now()-1,await server.hash(expired.secret));assert.equal((await verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:expired.cookie,data:{token:expired.secret}}))).status,400);
 });
 test('verified sign-in atomically carries bracket/season/media access and votes across devices, leaving no anonymous organizer grant',async()=>{
  const original=guest(),source=(await server.identity(request('/',{cookie:original}))).id,created=await fixture(original),b=created.bracket,m=b.matches.find(m=>m.round===0);
  // Fixtures use the real schema but are independent of public voting status.
  sqlite.prepare("UPDATE brackets SET status='live' WHERE id=?").run(b.id);sqlite.prepare("UPDATE matches SET status='open' WHERE id=?").run(m.id);
  sqlite.prepare('INSERT INTO votes VALUES(?,?,?,?)').run(m.id,source,m.a_id,100);
  sqlite.prepare('INSERT INTO media(id,owner_id,content_type,size,created_at) VALUES(?,?,?,?,?)').run('media-auth',source,'image/png',32,Date.now());
  sqlite.prepare('INSERT INTO seasons(id,title,points,entrants,owner_id,manage_hash,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)').run('season-auth','Season','[]','[]',source,'hash',Date.now(),Date.now());sqlite.prepare('INSERT INTO season_managers VALUES(?,?)').run('season-auth',source);
  const login=await emailLogin('organizer@example.com',original),identity=(await server.identity(request('/',{cookie:login.cookie}))).id;
  assert.notEqual(identity,source);assert.equal(sqlite.prepare('SELECT owner_id FROM brackets WHERE id=?').get(b.id).owner_id,identity);assert.equal(sqlite.prepare('SELECT owner_id FROM media WHERE id=?').get('media-auth').owner_id,identity);assert.equal(sqlite.prepare('SELECT owner_id FROM seasons WHERE id=?').get('season-auth').owner_id,identity);
  assert.equal(sqlite.prepare('SELECT 1 FROM managers WHERE identity_id=?').get(source),undefined);assert.equal(sqlite.prepare('SELECT 1 FROM season_managers WHERE identity_id=?').get(source),undefined);assert.equal(sqlite.prepare('SELECT 1 FROM votes WHERE voter_id=?').get(source),undefined);assert.equal(sqlite.prepare('SELECT entry_id FROM votes WHERE voter_id=?').get(identity).entry_id,m.a_id);
  assert.equal(await server.owns(b.id,source),false);
  // A late request still bearing a pre-login browser token cannot recreate its vote.
  assert.equal((await voteRoute.POST(request(`/api/brackets/${b.id}/vote`,{method:'POST',cookie:original,data:{matchId:m.id,entryId:m.b_id}}),{params:Promise.resolve({id:b.id})})).status,409);
  // A second browser may have voted differently; the existing account vote wins.
  sqlite.prepare('UPDATE account_challenges SET created_at=created_at-61000 WHERE subject_hash=?').run(await server.hash('organizer@example.com'));
  const other=guest(),otherId=(await server.identity(request('/',{cookie:other}))).id;sqlite.prepare('INSERT INTO votes VALUES(?,?,?,?)').run(m.id,otherId,m.b_id,200);
  const second=await emailLogin('organizer@example.com',other);assert.equal(second.data.user.id,login.data.user.id);assert.equal((await server.identity(request('/',{cookie:second.cookie}))).id,identity);assert.equal((await read(await bracketRoute.GET(request('/api/brackets',{cookie:second.cookie})))).brackets.some(row=>row.id===b.id),true);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM votes WHERE match_id=?').get(m.id).n,1);assert.equal(sqlite.prepare('SELECT entry_id FROM votes WHERE match_id=?').get(m.id).entry_id,m.a_id);
 });
 test('profile edits require login and same origin; sign-out revokes the session and rotates anonymous identity',async()=>{
  const login=await emailLogin('profile@example.com');assert.equal((await accountRoute.PATCH(request('/api/account',{method:'PATCH',cookie:login.cookie,data:{name:'New name'},headers:{Origin:'https://evil.example'}}))).status,403);
  assert.equal((await read(await accountRoute.PATCH(request('/api/account',{method:'PATCH',cookie:login.cookie,data:{name:'New name'}})))).user.name,'New name');
  assert.equal((await emailRoute.POST(request('/api/auth/email',{method:'POST',cookie:login.cookie,data:{email:'different@example.com'}}))).status,409);
  const identity=(await server.identity(request('/',{cookie:login.cookie}))).id,response=await logoutRoute.POST(request('/api/auth/logout',{method:'POST',cookie:login.cookie,data:{}}));await read(response);const signedOut=jar(login.cookie,response);assert.equal(await auth.currentAccount(request('/',{cookie:login.cookie})),null);assert.notEqual((await server.identity(request('/',{cookie:signedOut}))).id,identity);assert.equal((await accountRoute.PATCH(request('/api/account',{method:'PATCH',cookie:signedOut,data:{name:'no'}}))).status,401);
 });
 test('expired, forged or conflicting account cookies cannot grant access',async()=>{
  const login=await emailLogin('session@example.com'),accountCookie=login.cookie.split('; ').find(v=>v.startsWith('bl_account='));assert.equal(await auth.currentAccount(request('/',{cookie:'bl_account='+'1'.repeat(64)})),null);
  await assert.rejects(()=>auth.currentAccount(request('/',{cookie:`${accountCookie}; ${accountCookie}`})),/Conflicting/);
  sqlite.prepare('UPDATE account_sessions SET expires_at=? WHERE account_id=?').run(Date.now()-1,login.data.user.id);assert.equal(await auth.currentAccount(request('/',{cookie:login.cookie})),null);assert.notEqual((await server.identity(request('/',{cookie:login.cookie}))).id,sqlite.prepare('SELECT identity_id FROM accounts WHERE id=?').get(login.data.user.id).identity_id);
 });
 test('email sends are bounded by mailbox cooldown, account existence is not exposed, provider failure consumes the link',async()=>{
  const started=await emailStart('quota@example.com');sentEmail=null;const again=await read(await emailRoute.POST(request('/api/auth/email',{method:'POST',cookie:started.cookie,data:{email:'quota@example.com'}})));assert.equal(again.ok,true);assert.equal(sentEmail,null);
  providerFailure=true;const response=await emailRoute.POST(request('/api/auth/email',{method:'POST',cookie:guest(),data:{email:'failed@example.com'}}));providerFailure=false;assert.equal(response.status,503);assert.notEqual(sqlite.prepare('SELECT consumed_at FROM account_challenges WHERE subject_hash=?').get(await server.hash('failed@example.com')).consumed_at,null);
 });
 test('return URLs and Google claims reject redirects, wrong audiences, nonce/expiry/issuer and third-party email authority',()=>{
  for(const value of ['//evil.example','/\\evil.example','https://evil.example','/api/auth/google','/account/verify','#secret'])assert.equal(auth.safeReturnTo(value),'/account');assert.equal(auth.safeReturnTo('/b/abc?view=vote#secret'),'/b/abc?view=vote');
  const now=Math.floor(Date.now()/1000),claims={iss:'https://accounts.google.com',aud:'client',sub:'123',email:'person@example.com',email_verified:true,exp:now+3600,iat:now,nonce:'nonce'};
  assert.equal(auth.validateGoogleClaims(claims,'client','nonce').sub,'123');assert.equal(auth.googleAuthoritativeEmail(claims),false);assert.equal(auth.googleAuthoritativeEmail({...claims,email:'person@gmail.com'}),true);assert.equal(auth.googleAuthoritativeEmail({...claims,hd:'example.com'}),true);
  for(const change of [{aud:'attacker'},{azp:'attacker'},{iss:'https://evil.example'},{nonce:'wrong'},{exp:now-1},{iat:now+600},{email_verified:false},{sub:''}])assert.throws(()=>auth.validateGoogleClaims({...claims,...change},'client','nonce'));
 });
 let googleKeys;
 before(async()=>{googleKeys=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);googleJwk={...await crypto.subtle.exportKey('jwk',googleKeys.publicKey),kid:'test-signing-key',alg:'RS256',use:'sig'};});
 async function googleLogin(email,sub,{hd,mutateClaims,signatureInvalid=false,beforeCallback}={}){env.GOOGLE_CLIENT_ID='test-client';env.GOOGLE_CLIENT_SECRET='test-secret';const cookie=guest(),start=await googleRoute.GET(request('/api/auth/google?returnTo=/account',{cookie}));assert.equal(start.status,302);const location=new URL(start.headers.get('location'));assert.equal(location.origin,'https://accounts.google.com');assert.equal(location.searchParams.get('code_challenge_method'),'S256');const now=Math.floor(Date.now()/1000),claims={iss:'https://accounts.google.com',aud:'test-client',sub,email,email_verified:true,name:'Google fan',exp:now+3600,iat:now,nonce:location.searchParams.get('nonce'),...(hd?{hd}:{}),...mutateClaims};const encode=obj=>Buffer.from(JSON.stringify(obj)).toString('base64url');const unsigned=encode({alg:'RS256',kid:'test-signing-key'})+'.'+encode(claims);googleToken=unsigned+'.'+Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',googleKeys.privateKey,new TextEncoder().encode(unsigned))).toString('base64url');if(signatureInvalid)googleToken=googleToken.slice(0,-20)+'a'.repeat(20);beforeCallback?.();const response=await callbackRoute.GET(request(`/api/auth/google/callback?state=${location.searchParams.get('state')}&code=one-time-code`,{cookie:jar(cookie,start)}));assert.equal(response.status,303);return {response,cookie:jar(cookie,start,response),location};}
 test('Google callback verifies a real signature and PKCE; authoritative accounts link while third-party emails cannot take over email accounts',async()=>{
  const email=await emailLogin('linked@gmail.com'),google=await googleLogin('linked@gmail.com','google-linked');assert.equal((await auth.currentAccount(request('/',{cookie:google.cookie}))).id,email.data.user.id);assert.ok(tokenRequest.get('code_verifier'));assert.equal(tokenRequest.get('redirect_uri'),origin+'/api/auth/google/callback');assert.equal(google.response.headers.get('location'),origin+'/account');
  const thirdParty=await emailLogin('external@example.com'),untrusted=await googleLogin('external@example.com','google-third-party');assert.notEqual((await auth.currentAccount(request('/',{cookie:untrusted.cookie}))).id,thirdParty.data.user.id,'unverified present-day mailbox ownership does not merge accounts');
  const altered=await googleLogin('forged@gmail.com','google-forged',{signatureInvalid:true});assert.match(altered.response.headers.get('location'),/authError=/);assert.equal(await auth.currentAccount(request('/',{cookie:altered.cookie})),null);
  const wrongAud=await googleLogin('wrong-aud@gmail.com','google-wrong-aud',{mutateClaims:{aud:'attacker'}});assert.match(wrongAud.response.headers.get('location'),/authError=/);assert.equal(await auth.currentAccount(request('/',{cookie:wrongAud.cookie})),null);
 });
 test('Google callback rejects missing/incorrect browser state without creating an account',async()=>{
  const cookie=guest(),start=await googleRoute.GET(request('/api/auth/google',{cookie})),state=new URL(start.headers.get('location')).searchParams.get('state');const before=sqlite.prepare('SELECT COUNT(*) n FROM accounts').get().n;
  const response=await callbackRoute.GET(request(`/api/auth/google/callback?state=${state}&code=one-time-code`,{cookie:guest()}));assert.match(response.headers.get('location'),/authError=/);assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM accounts').get().n,before);
 });

 test('concurrent first email signup is resolved inside the Google credential transaction without splitting accounts',async()=>{
  const email='concurrent-link@gmail.com',emailHash=await server.hash(email),existingId=crypto.randomUUID(),existingIdentity=await server.hash('bracketlive:account:'+existingId);
  let raced=false;
  const google=await googleLogin(email,'google-concurrent-link',{beforeCallback(){beforeBatch=()=>{
   raced=true;
   // Model another request committing mailbox verification immediately before
   // the Google account-creation batch acquires its transaction.
   sqlite.prepare('INSERT INTO accounts(id,identity_id,name,email,created_at) VALUES(?,?,?,?,?)').run(existingId,existingIdentity,'Concurrent email fan',email,Date.now());
   sqlite.prepare('INSERT INTO account_credentials(provider,subject_hash,account_id) VALUES(?,?,?)').run('email',emailHash,existingId);
  };}});
  assert.equal(raced,true);assert.equal((await auth.currentAccount(request('/',{cookie:google.cookie}))).id,existingId);
  assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM accounts WHERE email=?').get(email).n,1,'the unused candidate account is removed');
  assert.equal(sqlite.prepare('SELECT COUNT(DISTINCT account_id) n FROM account_credentials WHERE subject_hash IN (?,?)').get(emailHash,await server.hash('google-concurrent-link')).n,1);
 });
 test('a previously claimed anonymous cookie cannot transfer the first account’s private bracket into another account',async()=>{
  const original=guest(),created=await fixture(original),first=await emailLogin('claim-first@example.com',original),second=await emailLogin('claim-second@example.com',original);
  const firstIdentity=(await server.identity(request('/',{cookie:first.cookie}))).id,secondIdentity=(await server.identity(request('/',{cookie:second.cookie}))).id;
  assert.notEqual(firstIdentity,secondIdentity);assert.equal(await server.owns(created.bracket.id,firstIdentity),true);assert.equal(await server.owns(created.bracket.id,secondIdentity),false);
  assert.equal(sqlite.prepare('SELECT owner_id FROM brackets WHERE id=?').get(created.bracket.id).owner_id,firstIdentity);
  await assert.rejects(()=>server.snapshot(created.bracket.id,secondIdentity),/private/);
  sqlite.prepare('UPDATE account_sessions SET expires_at=? WHERE account_id=?').run(Date.now()-1,first.data.user.id);
  const expiredIdentity=(await server.identity(request('/',{cookie:first.cookie}))).id;
  assert.notEqual(expiredIdentity,firstIdentity);assert.equal(await server.owns(created.bracket.id,expiredIdentity),false);
  await assert.rejects(()=>server.snapshot(created.bracket.id,expiredIdentity),/private/);
 });
 test('two simultaneous confirmation requests consume a mailbox link only once',async()=>{
  const started=await emailStart('parallel-confirm@example.com');
  const responses=await Promise.all([0,1].map(()=>verifyRoute.POST(request('/api/auth/email/verify',{method:'POST',cookie:started.cookie,data:{token:started.secret}}))));
  assert.deepEqual(responses.map(response=>response.status).sort(),[200,400]);
  const user=await read(responses.find(response=>response.status===200));
  assert.equal(sqlite.prepare('SELECT COUNT(*) n FROM account_sessions WHERE account_id=?').get(user.user.id).n,1);
 });

test('account merge preserves closed and deadline-locked vote tallies while moving nonconflicting historical votes',async()=>{
 const login=await emailLogin('locked-tallies@example.com'),target=(await server.identity(request('/',{cookie:login.cookie}))).id;
 const sourceCookie=guest(),source=(await server.identity(request('/',{cookie:sourceCookie}))).id;
 const fixtures=[];
 for(const mode of ['closed-conflict','deadline-conflict','closed-single','open-conflict']){
  const result=await fixture(sourceCookie),b=result.bracket,m=b.matches.find(m=>m.round===0);
  sqlite.prepare("UPDATE brackets SET status=?,current_round=0,round_closes_at=? WHERE id=?").run(mode.startsWith('closed')?'complete':'live',mode==='deadline-conflict'?Date.now()-10000:null,b.id);
  sqlite.prepare('UPDATE matches SET status=?,winner_id=? WHERE id=?').run(mode.startsWith('closed')?'closed':'open',mode.startsWith('closed')?m.b_id:null,m.id);
  sqlite.prepare('INSERT INTO votes VALUES(?,?,?,?)').run(m.id,source,m.a_id,100);
  if(mode!=='closed-single')sqlite.prepare('INSERT INTO votes VALUES(?,?,?,?)').run(m.id,target,m.b_id,200);
  fixtures.push({mode,b,m});
 }
 sqlite.prepare('UPDATE account_challenges SET created_at=created_at-61000 WHERE subject_hash=?').run(await server.hash('locked-tallies@example.com'));
 const second=await emailLogin('locked-tallies@example.com',sourceCookie);assert.equal(second.data.user.id,login.data.user.id);
 for(const {mode,m} of fixtures){
  const votes=sqlite.prepare('SELECT voter_id,entry_id FROM votes WHERE match_id=? ORDER BY voter_id').all(m.id);
  assert.equal(votes.length,['closed-conflict','deadline-conflict'].includes(mode)?2:1,mode);
  assert.equal(votes.some(v=>v.voter_id===source),['closed-conflict','deadline-conflict'].includes(mode),mode);
  assert.equal(votes.find(v=>v.voter_id===target).entry_id,mode==='closed-single'?m.a_id:m.b_id,mode);
  if(mode.startsWith('closed'))assert.equal(sqlite.prepare('SELECT winner_id FROM matches WHERE id=?').get(m.id).winner_id,m.b_id);
 }
});
