import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {test} from 'node:test';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
function load(file){file=path.resolve(root,file);if(!path.extname(file))file+='.ts';if(modules.has(file))return modules.get(file).exports;const module={exports:{}};modules.set(file,module);new Function('require','module','exports',ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(id=>id.startsWith('.')?load(path.resolve(path.dirname(file),id)):require(id),module,module.exports);return module.exports;}
const {renderResultsSvg,tournamentResult}=load('lib/activity-results.ts'),{newActivityState,advanceActivity,activitySnapshot}=load('lib/discord-engine.ts'),{makeDraft,makeTemplateDraft}=load('lib/bracket.ts');
const {isSuppliedAnimeArtwork}=load('lib/anime-artwork.ts');
test('all 64 original slots stay in order; only exact supplied originals are assigned, including corrected Blue Exorcist and Claymore',()=>{
 const b=makeTemplateDraft('trial');assert.equal(b.entries.length,64);assert.equal(b.entries[15].name,'Ki');assert.equal(b.entries[15].image,null);assert.equal(b.entries[0].image,null);
 assert.equal(b.entries[37].subtitle,'Blue Exorcist');assert.equal(b.entries[37].image,'/templates/anime-hd/exorcism.png');assert.equal(b.entries[51].subtitle,'Claymore');assert.equal(b.entries[51].image,'/templates/anime-hd/yoki.png');
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'docs/ANIME-ARTWORK.json'),'utf8')).artwork;
 assert.equal(manifest.length,27);
 for(const asset of manifest){assert.equal(b.entries[asset.slot-1].image,asset.path);const bytes=fs.readFileSync(path.join(root,'public',asset.path));assert.equal(createHash('sha256').update(bytes).digest('hex'),asset.sha256);assert.equal(isSuppliedAnimeArtwork(asset.path),true);}
 assert.equal(isSuppliedAnimeArtwork('/templates/anime-hd/../unknown.png'),false);
});
test('winner card preserves real results, distinct runner-up, full landscape dimensions, safe text and no identity data',()=>{
 const draft=makeDraft(2,false);draft.title='<script>Test</script>';draft.entries[0].name='Winner & one';draft.entries[1].name='Runner-up';let state=newActivityState(draft,'test');const m=state.bracket.matches[0],votes=[{match_id:m.id,entry_id:m.a_id,user_id:'private-a'},{match_id:m.id,entry_id:m.a_id,user_id:'private-b'},{match_id:m.id,entry_id:m.b_id,user_id:'private-c'}];state=advanceActivity(state,votes);const b=activitySnapshot(state,votes,'private-a',true);b.manageToken='secret';const r=tournamentResult(b);assert.equal(r.runnerUp.name,'Runner-up');assert.equal(r.percentage,67);const {svg,width,height}=renderResultsSvg(b,undefined,true);assert.equal(width,1920);assert.equal(height,1080);assert.ok(svg.includes('67%'));assert.ok(svg.includes('Winner &amp; one'));assert.ok(svg.includes('&lt;script&gt;'));assert.ok(!svg.includes('<script>'));assert.ok(!svg.includes('private-a'));assert.ok(!svg.includes('secret'));assert.ok(svg.includes('LOCAL PRACTICE'));
});
test('unfinished tournament has no winner card and malicious SVG or image data is never embedded',()=>{
 const d=makeDraft(2,false);d.entries[0].name='A';d.entries[1].name='B';let state=newActivityState(d,'test');assert.throws(()=>renderResultsSvg(state.bracket),/Finish/);const m=state.bracket.matches[0];state=advanceActivity(state,[],{[m.id]:m.a_id});const b=activitySnapshot(state,[],'a',true);b.entries[0].image='evil';const svg=renderResultsSvg(b,{images:{evil:'data:image/svg+xml;base64,evil'},warnings:[]}).svg;assert.ok(!svg.includes('data:image/svg'));assert.ok(svg.includes('Final decided by creator tiebreak'));
});
