import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { DatabaseSync } from 'node:sqlite';
import { after, test } from 'node:test';
import { fileURLToPath } from 'node:url';

// Exercise real handlers with every migration. Only the Cloudflare D1 transport
// is replaced with isolated SQLite; these tests never contact a live account.
const root = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(import.meta.url), ts = require('typescript');
const sqlite = new DatabaseSync(':memory:');
sqlite.exec('PRAGMA foreign_keys=ON');
for (const name of fs.readdirSync(path.join(root, 'drizzle')).filter(name => name.endsWith('.sql')).sort()) {
  sqlite.exec(fs.readFileSync(path.join(root, 'drizzle', name), 'utf8'));
}
after(() => sqlite.close());
class Statement {
  constructor(query, values = []) { this.query = query; this.values = values; }
  bind(...values) { return new Statement(this.query, values); }
  execute() {
    const statement = sqlite.prepare(this.query);
    if (statement.columns().length) return { results: statement.all(...this.values), meta: { changes: 0 }, success: true };
    return { results: [], meta: { changes: Number(statement.run(...this.values).changes) }, success: true };
  }
  async first(column) { const row = sqlite.prepare(this.query).get(...this.values); return column ? row?.[column] ?? null : row ?? null; }
  async all() { return this.execute(); }
  async run() { return this.execute(); }
}
const db = {
  prepare: query => new Statement(query),
  async batch(statements) {
    sqlite.exec('BEGIN');
    try { const result = statements.map(statement => statement.execute()); sqlite.exec('COMMIT'); return result; }
    catch (error) { sqlite.exec('ROLLBACK'); throw error; }
  },
};
const modules = new Map();
function loadSource(file) {
  file = path.resolve(root, file); if (!path.extname(file)) file += '.ts';
  if (modules.has(file)) return modules.get(file).exports;
  const module = { exports: {} }; modules.set(file, module);
  const compiled = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const localRequire = id => id === 'cloudflare:workers' ? { env: { DB: db } }
    : id.startsWith('@/') ? loadSource(id.slice(2))
    : id.startsWith('.') ? loadSource(path.resolve(path.dirname(file), id)) : require(id);
  new Function('require', 'module', 'exports', compiled)(localRequire, module, module.exports);
  return module.exports;
}
const collection = loadSource('app/api/seasons/route.ts');
const seasonRoute = loadSource('app/api/seasons/[id]/route.ts');
const eventRoute = loadSource('app/api/seasons/[id]/events/[eventId]/route.ts');
const manageRoute = loadSource('app/api/seasons/[id]/manage/route.ts');
const { calculateStandings, motorsportPoints, parsePoints } = loadSource('lib/standings.ts');
const origin = 'https://bracket.test';
const owner = `bl_voter=${'a'.repeat(64)}`, outsider = `bl_voter=${'b'.repeat(64)}`;
const request = (url, cookie, data, method = data === undefined ? 'GET' : 'POST', extraHeaders = {}) => new Request(origin + url, {
  method,
  headers: { Origin: origin, ...(cookie ? { Cookie: cookie } : {}), ...(data === undefined ? {} : { 'Content-Type': 'application/json' }), ...extraHeaders },
  ...(data === undefined ? {} : { body: JSON.stringify(data) }),
});
const context = (id, eventId) => ({ params: Promise.resolve({ id, eventId }) });
async function json(response, status = 200) { assert.equal(response.status, status, await response.clone().text()); return response.json(); }
const read = (id, cookie = owner) => seasonRoute.GET(request(`/api/seasons/${id}`, cookie), context(id));
const save = (id, eventId, data, cookie = owner, headers) => eventRoute.PUT(request(`/api/seasons/${id}/events/${eventId}`, cookie, data, 'PUT', headers), context(id, eventId));
const remove = (id, eventId, version, cookie = owner, headers) => eventRoute.DELETE(request(`/api/seasons/${id}/events/${eventId}`, cookie, { version }, 'DELETE', headers), context(id, eventId));
const settings = season => ({ title: season.title, description: season.description, points: season.points, entrants: season.entrants, version: season.version });
const update = (id, data, cookie = owner, headers) => seasonRoute.PUT(request(`/api/seasons/${id}`, cookie, data, 'PUT', headers), context(id));
const manage = (id, data, cookie = owner, headers) => manageRoute.POST(request(`/api/seasons/${id}/manage`, cookie, data, 'POST', headers), context(id));
const pointsByName = season => Object.fromEntries(season.standings.map(row => [row.entrant.name, row.points]));

test('season API validates results, replaces corrections, recalculates points, and enforces organizer access', async () => {
  const data = { title: 'Weekly series', description: 'Four competitors', points: motorsportPoints, entrants: ['Alpha', 'Beta', 'Gamma', 'Delta'] };
  await json(await collection.POST(request('/api/seasons', owner, { ...data, entrants: ['Alpha', 'alpha'] })), 400);
  await json(await collection.POST(request('/api/seasons', owner, data, 'POST', { Origin: 'https://elsewhere.test' })), 403);
  let { season, manageToken } = await json(await collection.POST(request('/api/seasons', owner, data)), 201);
  const id = season.id;
  assert.equal(season.isOwner, true);
  assert.match(manageToken, /^[a-f0-9]{64}$/);
  assert.deepEqual(pointsByName(season), { Alpha: 0, Beta: 0, Delta: 0, Gamma: 0 });
  const visitor = await json(await read(id, outsider));
  assert.equal(visitor.isOwner, false);
  const snapshotText = JSON.stringify(visitor);
  for (const secretName of ['manageToken', 'manage_hash', 'owner_id', 'identity_id']) assert.ok(!snapshotText.includes(secretName));
  assert.ok(!snapshotText.includes(manageToken));
  assert.equal((await json(await read(crypto.randomUUID(), outsider), 404)).error.length > 0, true);
  const entrants = Object.fromEntries(season.entrants.map(entrant => [entrant.name, entrant.id]));
  const result = (name, position, adjustment = 0, note = '') => ({ entrantId: entrants[name], position, adjustment, note });
  const firstId = crypto.randomUUID();
  const first = { title: 'Opening event', date: '2026-10-05', status: 'complete', version: 0,
    results: [result('Alpha', 1, 2, 'Bonus'), result('Beta', 2, -3, 'Penalty'), result('Gamma', 3), result('Delta', null, -1)] };
  await json(await update(id, settings(season), outsider), 403);
  await json(await save(id, firstId, first, outsider), 403);
  await json(await remove(id, firstId, 1, outsider), 403);
  await json(await manage(id, {}, outsider), 403);
  for (const headers of [{ Origin: 'https://elsewhere.test' }, { 'Sec-Fetch-Site': 'cross-site' }]) {
    await json(await update(id, settings(season), owner, headers), 403);
    await json(await save(id, firstId, first, owner, headers), 403);
    await json(await remove(id, firstId, 1, owner, headers), 403);
    await json(await manage(id, {}, owner, headers), 403);
  }
  const invalid = [
    { ...first, results: [result('Alpha', 1), result('Beta', 1)] },
    { ...first, results: [result('Alpha', 1), result('Alpha', 2)] },
    { ...first, results: [{ entrantId: crypto.randomUUID(), position: 1 }] },
    { ...first, results: [result('Alpha', 5)] },
    { ...first, results: [result('Alpha', null)] },
    { ...first, date: '2026-02-30' },
  ];
  for (const invalidEvent of invalid) await json(await save(id, crypto.randomUUID(), invalidEvent), 400);
  assert.equal((await json(await read(id))).events.length, 0, 'rejected mutations must not create events');
  season = await json(await save(id, firstId, first));
  assert.deepEqual(pointsByName(season), { Alpha: 27, Beta: 15, Gamma: 15, Delta: -1 });
  assert.equal(season.standings.find(row => row.entrant.name === 'Alpha').wins, 1);
  assert.equal(season.standings.find(row => row.entrant.name === 'Delta').starts, 0);
  assert.equal(season.events[0].version, 1);
  assert.equal(season.standings.find(row => row.entrant.name === 'Beta').rank, 2, 'second-place finish breaks a points tie over third place');
  await json(await save(id, firstId, first), 409);

  const draftId = crypto.randomUUID();
  const draft = { title: 'Next event', date: '2026-10-12', status: 'draft', version: 0, results: [result('Delta', 1, 100)] };
  season = await json(await save(id, draftId, draft));
  assert.deepEqual(pointsByName(season), { Alpha: 27, Beta: 15, Gamma: 15, Delta: -1 }, 'draft results do not score');
  assert.ok(!Object.values(season.standings).some(row => draftId in row.eventPoints));
  const corrected = { ...first, version: 1, results: [result('Alpha', 2), result('Beta', 1), result('Gamma', 3), result('Delta', 4)] };
  season = await json(await save(id, firstId, corrected));
  assert.deepEqual(pointsByName(season), { Beta: 25, Alpha: 18, Gamma: 15, Delta: 12 }, 'correction replaces prior points instead of accumulating them');
  assert.equal(season.events.find(event => event.id === firstId).version, 2);
  await json(await save(id, firstId, corrected), 409);
  await json(await remove(id, firstId, 1), 409);
  assert.deepEqual(pointsByName(await json(await read(id))), pointsByName(season), 'stale edits and removals do not change totals');

  const oldSettings = settings(season);
  season = await json(await update(id, { ...oldSettings, points: [10, 6, 3, 1] }));
  assert.deepEqual(pointsByName(season), { Beta: 10, Alpha: 6, Gamma: 3, Delta: 1 }, 'changing the scoring system recalculates past results');
  await json(await update(id, oldSettings), 409);
  await json(await update(id, { ...settings(season), entrants: season.entrants.map((entry, i) => i ? entry : { ...entry, id: crypto.randomUUID() }) }), 400);
  season = await json(await remove(id, firstId, 2));
  assert.ok(season.standings.every(row => row.points === 0 && row.starts === 0 && row.wins === 0));
  assert.equal(season.events.length, 1);
  assert.equal(season.events[0].id, draftId);

  const list = await json(await collection.GET(request('/api/seasons', outsider)));
  assert.ok(list.seasons.some(row => row.id === id && !row.isOwner && row.eventCount === 1 && row.completedCount === 0));
  const mine = await json(await collection.GET(request('/api/seasons?view=mine', outsider)));
  assert.ok(!mine.seasons.some(row => row.id === id));

  await json(await manage(id, { token: '0'.repeat(64) }, outsider), 403);
  const managerResponse = await manage(id, { token: manageToken }, null);
  const managerCookie = managerResponse.headers.get('Set-Cookie')?.split(';')[0];
  await json(managerResponse);
  assert.ok(managerCookie, 'opening an organizer link in a new browser establishes a cookie');
  assert.equal((await json(await read(id, managerCookie))).isOwner, true);
  const fromManager = await json(await save(id, draftId, { ...draft, version: 1, status: 'complete' }, managerCookie));
  assert.equal(fromManager.standings[0].entrant.name, 'Delta');
  assert.equal(fromManager.standings[0].points, 110);
  const rotated = await json(await manage(id, {}, managerCookie));
  assert.notEqual(rotated.manageToken, manageToken);
  await json(await manage(id, { token: manageToken }, outsider), 403);
  await json(await manage(id, { token: rotated.manageToken }, outsider));
  assert.equal((await json(await read(id, outsider))).isOwner, true);
});

test('countback considers every placing and preserves genuine shared ranks', () => {
  const entrants = ['Alpha', 'Beta', 'Gamma', 'Delta'].map(name => ({ id: name.toLowerCase(), name }));
  const event = (id, values) => ({ id, title: id, date: '', status: 'complete', version: 1,
    results: values.map(([entrantId, position, adjustment = 0]) => ({ entrantId, position, adjustment, note: '' })) });
  const countback = calculateStandings(entrants, [
    event('first', [['alpha', 1], ['beta', 2]]),
    event('second', [['beta', 1], ['alpha', 3]]),
  ], [10, 10, 10]);
  assert.equal(countback[0].entrant.id, 'beta', 'equal points and wins are broken by second places');
  assert.deepEqual(countback.map(row => row.rank), [1, 2, 3, 3]);
  const tied = calculateStandings(entrants, [
    event('first', [['alpha', 1], ['beta', 2]]),
    event('second', [['beta', 1], ['alpha', 2]]),
    event('penalty', [['gamma', null, -5]]),
  ], [10, 6]);
  assert.deepEqual(tied.map(row => [row.entrant.name, row.rank, row.points]), [
    ['Alpha', 1, 16], ['Beta', 1, 16], ['Delta', 3, 0], ['Gamma', 4, -5],
  ]);
  assert.equal(tied.find(row => row.entrant.id === 'alpha').podiums, 2);
  assert.equal(tied.find(row => row.entrant.id === 'gamma').starts, 0);
});

test('custom points accept comma or whitespace lists and reject invalid scales', () => {
  assert.equal(parsePoints(Array(128).fill('1').join(',')).length, 128);
  assert.deepEqual(parsePoints('25,18,15, 12\n10 8 6 4 2 1'), motorsportPoints);
  assert.deepEqual(parsePoints('0'), [0]);
  for (const input of ['', '-1,10', '10.5,2', '10001', 'one,2', Array(129).fill('1').join(',')]) {
    assert.throws(() => parsePoints(input));
  }
});

test('seasons accept 128 entrants and classified positions but reject a 129th entrant', async () => {
  const entrants = Array.from({ length: 128 }, (_, index) => `Entrant ${index + 1}`);
  const data = { title: '128 entrant season', points: Array(128).fill(1), entrants };
  await json(await collection.POST(request('/api/seasons', owner, { ...data, entrants: [...entrants, 'Too many'] })), 400);
  const { season } = await json(await collection.POST(request('/api/seasons', owner, data)), 201);
  assert.equal(season.entrants.length, 128);
  const event = { title: 'Full roster event', date: '', status: 'complete', version: 0,
    results: season.entrants.map((entrant, index) => ({ entrantId: entrant.id, position: index + 1, adjustment: 0, note: '' })) };
  const scored = await json(await save(season.id, crypto.randomUUID(), event));
  assert.equal(scored.standings.length, 128);
  assert.equal(scored.standings[127].points, 1);
  assert.equal(scored.standings[127].finishes[127], 1);
});
