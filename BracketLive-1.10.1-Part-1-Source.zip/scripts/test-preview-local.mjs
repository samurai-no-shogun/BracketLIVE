import {test} from 'node:test';
import assert from 'node:assert/strict';
import {previewConfig,previewCommand,triggerPreviewScheduler} from './preview-local.mjs';
test('preview uses only isolated local resources and fixed commands on Windows',()=>{
 const c=previewConfig();assert.equal(c.d1_databases[0].database_id,'00000000-0000-4000-8000-000000000128');assert.equal(c.workers_dev,false);assert.ok(!c.vars&&!c.routes&&!c.account_id);
 for(const stage of ['migrate','seed','serve']){
  const command=previewCommand(stage,'win32');assert.equal(command.command,'cmd.exe');const args=command.args.join(' ');assert.ok(args.includes('--local'));assert.ok(!args.includes('--remote'));assert.ok(args.includes('--config wrangler.json --persist-to ./state'));assert.ok(args.includes('wrangler@4.147.0'));
 }
 assert.throws(()=>previewCommand('deploy'),/Unknown preview stage/);
});
test('local scheduling uses only the fixed loopback Wrangler hooks, including the compatibility fallback',async()=>{
 const urls=[];
 await triggerPreviewScheduler(async(url)=>{urls.push(url);return new Response('',{status:urls.length===1?404:200});});
 assert.deepEqual(urls,['http://127.0.0.1:8787/__scheduled?cron=*+*+*+*+*','http://127.0.0.1:8787/cdn-cgi/local/scheduled?cron=*+*+*+*+*']);
 await assert.rejects(triggerPreviewScheduler(async()=>new Response('',{status:500})),/could not complete/);
 assert.deepEqual(previewConfig().triggers,{crons:['* * * * *']});
 assert.ok(previewCommand('serve','win32').args.join(' ').includes('--test-scheduled'));
});
