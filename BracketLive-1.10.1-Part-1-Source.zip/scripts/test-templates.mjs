import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {test} from 'node:test';
import {fileURLToPath} from 'node:url';

const root=fileURLToPath(new URL('../',import.meta.url)),require=createRequire(import.meta.url),ts=require('typescript'),modules=new Map();
function loadSource(file){
 file=path.resolve(root,file);if(!path.extname(file))file+='.ts';
 if(modules.has(file))return modules.get(file).exports;
 const module={exports:{}};modules.set(file,module);
 const compiled=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
 const localRequire=id=>id==='cloudflare:workers'?{env:{}}:id.startsWith('.')?loadSource(path.resolve(path.dirname(file),id)):require(id);
 new Function('require','module','exports',compiled)(localRequire,module,module.exports);
 return module.exports;
}
const {makeDraft,makeTemplateDraft,draftBracket,publicVotingDraft,displaySeed,entryRegion,roundName}=loadSource('lib/bracket.ts');
const {animeEntries,animeImage}=loadSource('lib/anime-roster.ts');
const {basketballEntries}=loadSource('lib/basketball-template.ts');
const {projectBracketPicks,changeBracketPick}=loadSource('lib/bracket-picks.ts');
const {DraftSchema}=loadSource('lib/server.ts');

test('Trial Bracket preserves all original names, images, and opening matchups',()=>{
 const draft=makeTemplateDraft('trial');
 assert.equal(draft.title,'Trial Bracket');assert.equal(draft.format,'standard');assert.equal(draft.size,64);
 assert.deepEqual(draft.entries.map(e=>[e.name,e.subtitle]),animeEntries);
 assert.deepEqual(draft.entries.map(e=>e.image),animeEntries.map((_,i)=>animeImage(i)));
 const bracket=draftBracket(draft),opening=bracket.matches.filter(m=>m.round===0);
 assert.equal(opening.length,32);
 opening.forEach((match,i)=>assert.deepEqual([match.a_id,match.b_id],[bracket.entries[i*2].id,bracket.entries[i*2+1].id]));
});

// Fixed official 2026 Round of 64 fixture: names are in opening-match order.
// Keep it separate from the implementation's roster so accidental slot changes fail.
const field2026={
 East:['Duke','Siena','Ohio State','TCU',"St. John's",'Northern Iowa','Kansas','Cal Baptist','Louisville','South Florida','Michigan State','North Dakota State','UCLA','UCF','UConn','Furman'],
 South:['Florida','Prairie View A&M','Clemson','Iowa','Vanderbilt','McNeese','Nebraska','Troy','North Carolina','VCU','Illinois','Penn',"Saint Mary's",'Texas A&M','Houston','Idaho'],
 West:['Arizona','Long Island','Villanova','Utah State','Wisconsin','High Point','Arkansas','Hawaii','BYU','Texas','Gonzaga','Kennesaw State','Miami (FL)','Missouri','Purdue','Queens (N.C.)'],
 Midwest:['Michigan','Howard','Georgia','Saint Louis','Texas Tech','Akron','Alabama','Hofstra','Tennessee','Miami (Ohio)','Virginia','Wright State','Kentucky','Santa Clara','Iowa State','Tennessee State'],
};
const expectedPairs=[[1,16],[8,9],[5,12],[4,13],[6,11],[3,14],[7,10],[2,15]];

test('2026 NCAA practice field has the actual 64 teams, regional seeds, and all 32 opening matchups',()=>{
 const draft=makeTemplateDraft('basketball'),bracket=draftBracket(draft);
 assert.equal(draft.format,'ncaa2026');assert.equal(bracket.matches.length,63);
 assert.equal(new Set(draft.entries.map(e=>e.name)).size,64);
 for(const [r,region] of ['East','South','West','Midwest'].entries()){
  const entries=draft.entries.slice(r*16,r*16+16);
  assert.deepEqual(entries.map(e=>e.name),field2026[region]);
  assert.deepEqual(entries.map(e=>displaySeed(e,draft.format)).sort((a,b)=>a-b),Array.from({length:16},(_,i)=>i+1));
  assert.ok(entries.every(e=>entryRegion(e,draft.format)===region));
  assert.deepEqual(Array.from({length:8},(_,i)=>entries.slice(i*2,i*2+2).map(e=>displaySeed(e,draft.format))),expectedPairs);
  assert.ok(entries.every((e,i)=>e.seed===r*16+i+1),'storage slots remain unique and ordered');
  const names=new Map(bracket.entries.map(e=>[e.id,e.name]));
  const opening=bracket.matches.filter(m=>m.round===0).slice(r*8,r*8+8);
  assert.deepEqual(opening.map(m=>[names.get(m.a_id),names.get(m.b_id)]),Array.from({length:8},(_,i)=>field2026[region].slice(i*2,i*2+2)));
 }
 assert.deepEqual(bracket.matches.reduce((counts,m)=>(counts[m.round]=(counts[m.round]||0)+1,counts),[]),[32,16,8,4,2,1]);
 assert.deepEqual(Array.from({length:6},(_,r)=>roundName(r,64,draft.format)),['Round of 64','Round of 32','Sweet 16','Elite Eight','Final Four','Championship']);
 assert.equal(publicVotingDraft(bracket).format,'ncaa2026');
});

test('2026 practice starts after the First Four, with no results or champion preselected',()=>{
 const bracket=draftBracket(makeTemplateDraft('basketball'));
 for(const [name,seed,region,loser] of [['Howard',16,'Midwest','UMBC'],['Texas',11,'West','NC State'],['Prairie View A&M',16,'South','Lehigh'],['Miami (Ohio)',11,'Midwest','SMU']]){
  const winner=bracket.entries.find(e=>e.name===name);assert.ok(winner);
  assert.equal(displaySeed(winner,bracket.format),seed);assert.equal(entryRegion(winner,bracket.format),region);
  assert.ok(!bracket.entries.some(e=>e.name===loser),`${loser} lost its First Four game`);
 }
 assert.ok(bracket.matches.every(m=>m.winner_id===null&&m.myVote===null&&m.counts===null&&m.total===null));
 assert.ok(bracket.matches.filter(m=>m.round>0).every(m=>m.a_id===null&&m.b_id===null));
 assert.equal(projectBracketPicks(bracket).completed,0);
});

test('2026 regional champions feed East versus South and West versus Midwest in the Final Four',()=>{
 const source=draftBracket(makeTemplateDraft('basketball'));let picks={};
 for(let round=0;round<4;round++){
  const projection=projectBracketPicks(source,picks);
  for(const match of projection.bracket.matches.filter(m=>m.round===round))picks=changeBracketPick(source,picks,match.id,match.a_id);
 }
 const projected=projectBracketPicks(source,picks).bracket,entries=new Map(projected.entries.map(e=>[e.id,e]));
 assert.deepEqual(projected.matches.filter(m=>m.round===4).map(m=>[entries.get(m.a_id).name,entries.get(m.b_id).name]),[['Duke','Florida'],['Arizona','Michigan']]);
 assert.deepEqual(projected.matches.filter(m=>m.round===4).map(m=>[entryRegion(entries.get(m.a_id),projected.format),entryRegion(entries.get(m.b_id),projected.format)]),[['East','South'],['West','Midwest']]);
 assert.equal(projected.matches.at(-1).winner_id,null,'practice still needs semifinal and championship picks');
});

test('legacy basketball brackets keep their original East, West, South, Midwest regions',()=>{
 const legacy={...makeDraft(64,false),title:'Existing basketball bracket',format:'basketball',entries:basketballEntries()};
 for(const [r,region] of ['East','West','South','Midwest'].entries()){
  const entries=legacy.entries.slice(r*16,r*16+16);
  assert.ok(entries.every(e=>entryRegion(e,legacy.format)===region));
  assert.deepEqual(entries.map(e=>displaySeed(e,legacy.format)),expectedPairs.flat());
 }
 assert.equal(DraftSchema.parse(legacy).format,'basketball');
 assert.equal(publicVotingDraft(draftBracket(legacy)).format,'basketball');
});

test('template copies are independent and both regional formats require 64 teams',()=>{
 assert.equal(makeTemplateDraft('blank').size,16);
 const a=makeTemplateDraft('basketball');a.entries[0].name='Changed team';a.appearance.glass_tint='#ff0000';
 const b=makeTemplateDraft('basketball');assert.equal(b.entries[0].name,'Duke');assert.equal(b.appearance.glass_tint,undefined);
 assert.equal(DraftSchema.parse({...b,publish:true}).format,'ncaa2026');
 for(const format of ['basketball','ncaa2026'])assert.throws(()=>DraftSchema.parse({...b,format,size:32,entries:b.entries.slice(0,32)}),/four-region basketball format needs 64 teams/);
 const oldDraft=makeTemplateDraft('trial');delete oldDraft.format;
 assert.equal(DraftSchema.parse(oldDraft).format,'standard','old saved drafts retain backward compatibility');
 assert.equal(roundName(4,64),'Semifinals');assert.equal(displaySeed({seed:18}),18);
});
