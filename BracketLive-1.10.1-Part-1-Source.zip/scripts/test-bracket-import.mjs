import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createRequire} from 'node:module';
import {test} from 'node:test';
import {zipSync,strToU8} from 'fflate';
import {DOMParser as XmlDomParser} from '@xmldom/xmldom';
const require=createRequire(import.meta.url),ts=require('typescript'),module={exports:{}};
const source=fs.readFileSync(new URL('../lib/bracket-import.ts',import.meta.url),'utf8');
new Function('require','module','exports',ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText)(require,module,module.exports);
const {parseBracketImport,parseImportText,parseDelimitedImport,mapImportTable,IMPORT_LIMITS}=module.exports;
// Browser DOMParser reports malformed XML as a parsererror document. Mirror
// that behavior for fixtures without shipping this dependency in the app.
globalThis.DOMParser=class {
 parseFromString(text,mime){try{return new XmlDomParser({onError(level,message){if(level!=='warning')throw Error(message);}}).parseFromString(text,mime);}catch{return new XmlDomParser().parseFromString('<parsererror>Invalid XML</parsererror>',mime);}}
};
function file(name,bytes){if(typeof bytes==='string')bytes=strToU8(bytes);return {name,size:bytes.length,arrayBuffer:async()=>bytes.slice().buffer};}
function archive(parts){return zipSync(Object.fromEntries(Object.entries(parts).map(([name,value])=>[name,typeof value==='string'?strToU8(value):value])),{level:6});}
const workbook=(sheets='<sheet name="Roster" sheetId="1" r:id="rId1"/>')=>`<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${sheets}</sheets></workbook>`;
const relationships=(extra='')=>`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Target="worksheets/sheet1.xml" Type="worksheet"/>${extra}</Relationships>`;
const worksheet=rows=>`<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${rows}</sheetData></worksheet>`;
const inline=(reference,value)=>`<c r="${reference}" t="inlineStr"><is><t>${value}</t></is></c>`;
function xlsx(sheet,extra={}){return archive({'[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>','xl/workbook.xml':workbook(),'xl/_rels/workbook.xml.rels':relationships(),'xl/worksheets/sheet1.xml':worksheet(sheet),...extra});}
const ods=(rows)=>`<office:document-content xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0"><office:body><office:spreadsheet><table:table table:name="Teams">${rows}</table:table></office:spreadsheet></office:body></office:document-content>`;
const odsCell=(value,attributes='')=>`<table:table-cell ${attributes}><text:p>${value}</text:p></table:table-cell>`;
const odsRow=(value,attributes='')=>`<table:table-row ${attributes}>${value}</table:table-row>`;
const docx=body=>archive({'[Content_Types].xml':'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"/>','word/document.xml':`<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}</w:body></w:document>`});
const para=text=>`<w:p><w:r><w:t>${text}</w:t></w:r></w:p>`;
const docCell=text=>`<w:tc>${para(text)}</w:tc>`;
const docRow=(a,b)=>`<w:tr>${docCell(a)}${docCell(b)}</w:tr>`;
function mutateCentral(bytes,fn){const out=bytes.slice(),view=new DataView(out.buffer);for(let i=0;i<out.length-46;i++)if(view.getUint32(i,true)===0x02014b50){const length=view.getUint16(i+28,true),name=new TextDecoder().decode(out.subarray(i+46,i+46+length));fn(view,i,name,out);}return out;}

test('CSV retains source order, quoted commas, doubled quotes, and embedded newlines',()=>{
 const doc=parseImportText('\uFEFFName,Subtitle,Seed\r\n"Zulu, Jr.","Says ""hello""",8\r\nAlpha,"Line one\nLine two",1','csv');
 const result=mapImportTable(doc.tables[0]);assert.deepEqual(result.entries.map(e=>[e.name,e.subtitle,e.seed]),[['Zulu, Jr.','Says "hello"',8],['Alpha','Line one\nLine two',1]]);assert.deepEqual(result.issues,[]);assert.ok(result.warnings.some(w=>/do not rearrange/.test(w)));
});
test('CSV rejects malformed quotes and oversized cells instead of silently splitting entrants',()=>{
 assert.throws(()=>parseDelimitedImport('Name\n"unfinished'),/unclosed/);assert.throws(()=>parseDelimitedImport('Name\n"A"extra'),/closing/);assert.throws(()=>parseDelimitedImport('Name\nA"B'),/misplaced/);assert.throws(()=>parseDelimitedImport('x'.repeat(2001)),/2,000/);
});
test('TSV and headerless text support manual review and explicit VS rows',()=>{
 const tsv=mapImportTable(parseImportText('Name\tSubtitle\nOrion\tSpace\nAtlas\tMyth','tsv').tables[0]);assert.deepEqual(tsv.entries.map(e=>e.name),['Orion','Atlas']);
 const paired=parseImportText('Nova vs. Lyra\nSun versus Moon','txt').tables[0],result=mapImportTable(paired);assert.equal(paired.suggested.mode,'paired');assert.deepEqual(result.entries.map(e=>e.name),['Nova','Lyra','Sun','Moon']);
 const plain=parseImportText('Atlas\nOrion\nAtlas','txt').tables[0];assert.deepEqual(mapImportTable(plain).entries.map(e=>e.name),['Atlas','Orion','Atlas']);assert.ok(mapImportTable(plain).warnings.some(w=>/Repeated names/.test(w)));
 const pipes=parseImportText('Name | Subtitle\nOrion | Space\nAtlas | Myth','txt').tables[0];assert.deepEqual(mapImportTable(pipes).entries.map(e=>[e.name,e.subtitle]),[['Orion','Space'],['Atlas','Myth']]);
});
test('paired roster columns preserve A/B sequence and do not reorder source seeds',()=>{
 const table=parseImportText('Opponent A,Seed A,Opponent B,Seed B\nZulu,8,Alpha,1\nBeta,6,Gamma,3','csv').tables[0];
 assert.equal(table.suggested.mode,'paired');assert.deepEqual(mapImportTable(table).entries.map(e=>[e.name,e.seed]),[['Zulu',8],['Alpha',1],['Beta',6],['Gamma',3]]);
});
test('review issues retain missing and long names, invalid seeds, and all >128 entries',()=>{
 const table=parseImportText('Name,Subtitle,Seed\n,Keep me,4\n'+'X'.repeat(101)+',Note,-2','csv').tables[0],result=mapImportTable(table);
 assert.equal(result.entries.length,2);assert.ok(result.issues.some(i=>/add a name/.test(i.message)));assert.ok(result.issues.some(i=>/name exceeds/.test(i.message)));assert.ok(result.issues.some(i=>/source seed/.test(i.message)));
 const many=mapImportTable(parseImportText(Array.from({length:129},(_,i)=>`Team ${i+1}`).join('\n'),'txt').tables[0]);assert.equal(many.entries.length,129);assert.ok(many.issues.some(i=>/at most 128/.test(i.message)));
});
test('BracketLive snapshots import roster/order/title only and drop images, votes, and secrets',()=>{
 const doc=parseImportText(JSON.stringify({schema:'bracketlive.snapshot.v1',tournament:{title:'My bracket',manage_key:'private',ends_at:1},entries:[{id:'one',name:'Zulu',subtitle:'First',seed:2,image:'https://evil.invalid/pixel'},{id:'two',name:'Alpha',subtitle:'',seed:1,image:'/api/media/00000000-0000-0000-0000-000000000000.png'}],matches:[{winner_id:'one',counts:{one:100}}]}),'json');
 const result=mapImportTable(doc.tables[0]);assert.equal(doc.title,'My bracket');assert.deepEqual(result.entries.map(e=>[e.name,e.seed,e.image]),[['Zulu',2,null],['Alpha',1,null]]);assert.ok(!JSON.stringify(doc).includes('private'));assert.ok(!JSON.stringify(doc).includes('evil.invalid'));assert.ok(doc.warnings.some(w=>/Old votes/.test(w)));
 assert.throws(()=>parseImportText('{"entries":[]}','json'),/BracketLive JSON/);
});
test('file parser reads UTF-16 TSV and rejects unsupported legacy/macro formats and >10MB files',async()=>{
 const text='Name\tSubtitle\r\nAlpha\tFirst\r\nBeta\tSecond',utf16=new Uint8Array(2+text.length*2);utf16[0]=255;utf16[1]=254;const view=new DataView(utf16.buffer);for(let i=0;i<text.length;i++)view.setUint16(2+i*2,text.charCodeAt(i),true);
 assert.deepEqual(mapImportTable((await parseBracketImport(file('teams.tsv',utf16))).tables[0]).entries.map(e=>e.name),['Alpha','Beta']);
 for(const name of ['teams.xls','teams.doc','teams.xlsm','teams.xlsb'])await assert.rejects(()=>parseBracketImport(file(name,'x')),/Legacy and macro/);
 await assert.rejects(()=>parseBracketImport({name:'huge.csv',size:IMPORT_LIMITS.fileBytes+1,arrayBuffer(){throw Error('Must not read');}}),/10 MB/);
});
test('real XLSX zip parses shared/rich/inline strings, sparse columns, and numeric source seeds',async()=>{
 const bytes=xlsx('<row r="1">'+inline('A1','Name')+inline('B1','Subtitle')+inline('C1','Seed')+'</row><row r="2"><c r="A2" t="s"><v>0</v></c>'+inline('B2','Space')+'<c r="C2"><v>8</v></c></row><row r="3">'+inline('A3','Alpha')+'<c r="C3"><v>1</v></c></row>',{'xl/sharedStrings.xml':'<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><si><r><t>Zu</t></r><r><t>lu</t></r></si></sst>'});
 const doc=await parseBracketImport(file('teams.xlsx',bytes));assert.equal(doc.kind,'xlsx');assert.equal(doc.tables[0].name,'Roster');assert.deepEqual(mapImportTable(doc.tables[0]).entries.map(e=>[e.name,e.subtitle,e.seed]),[['Zulu','Space',8],['Alpha','',1]]);
});
test('XLSX formula cells are never evaluated or accepted as cached results',async()=>{
 const bytes=xlsx('<row r="1">'+inline('A1','Name')+inline('B1','Subtitle')+'</row><row r="2"><c r="A2" t="str"><f>HYPERLINK("https://evil.invalid","cached")</f><v>Cached result</v></c>'+inline('B2','Review formula')+'</row><row r="3">'+inline('A3','Real entrant')+'</row>');
 const doc=await parseBracketImport(file('formula.xlsx',bytes)),result=mapImportTable(doc.tables[0]);assert.equal(result.entries[0].name,'');assert.ok(result.issues.some(i=>/add a name/.test(i.message)));assert.ok(doc.warnings.some(w=>/Formula cells/.test(w)));assert.ok(!JSON.stringify(doc).includes('Cached result'));
});
test('XLSX lists separate sheets and rejects external sheet relationships',async()=>{
 const bytes=xlsx('<row r="1">'+inline('A1','Alpha')+'</row><row r="2">'+inline('A2','Beta')+'</row>',{'xl/workbook.xml':workbook('<sheet name="One" sheetId="1" r:id="rId1"/><sheet name="Two" sheetId="2" r:id="rId2"/>'),'xl/_rels/workbook.xml.rels':relationships('<Relationship Id="rId2" Target="worksheets/sheet2.xml" Type="worksheet"/>'),'xl/worksheets/sheet2.xml':worksheet('<row r="1">'+inline('A1','Gamma')+'</row><row r="2">'+inline('A2','Delta')+'</row>')});
 const doc=await parseBracketImport(file('two.xlsx',bytes));assert.deepEqual(doc.tables.map(t=>t.name),['One','Two']);
 const external=xlsx('<row r="1">'+inline('A1','Alpha')+'</row>',{'xl/_rels/workbook.xml.rels':'<Relationships><Relationship Id="rId1" Target="https://evil.invalid/sheet.xml" TargetMode="External"/></Relationships>'});await assert.rejects(()=>parseBracketImport(file('external.xlsx',external)),/missing or external/);
});
test('real ODS zip preserves paired tables, bounded repeats, and ignores trailing empty formatting',async()=>{
 const rows=odsRow(odsCell('Opponent A')+odsCell('Opponent B'))+odsRow(odsCell('Alpha')+odsCell('Beta'))+odsRow(odsCell('Gamma')+odsCell('Delta'))+odsRow(odsCell('','table:number-columns-repeated="1000000"'),'table:number-rows-repeated="1000000"');
 const doc=await parseBracketImport(file('teams.ods',archive({'mimetype':'application/vnd.oasis.opendocument.spreadsheet','content.xml':ods(rows)})));
 assert.deepEqual(mapImportTable(doc.tables[0]).entries.map(e=>e.name),['Alpha','Beta','Gamma','Delta']);
 const repeatedRows=ods(odsRow(odsCell('Name'))+odsRow(odsCell('Alpha'),'table:number-rows-repeated="2"'));assert.deepEqual(mapImportTable((await parseBracketImport(file('repeat.ods',archive({'content.xml':repeatedRows})))).tables[0]).entries.map(e=>e.name),['Alpha','Alpha']);
});
test('ODS rejects nonempty row/cell expansion and ignores formula cached values',async()=>{
 for(const rows of [odsRow(odsCell('Alpha'),'table:number-rows-repeated="1001"'),odsRow(odsCell('Alpha','table:number-columns-repeated="65"'))])await assert.rejects(()=>parseBracketImport(file('bomb.ods',archive({'content.xml':ods(rows)}))),/too many repeated/);
 const rows=odsRow(odsCell('Name')+odsCell('Subtitle'))+odsRow(odsCell('Cached','table:formula="of:=1+1"')+odsCell('Review'))+odsRow(odsCell('Alpha'));
 const doc=await parseBracketImport(file('formula.ods',archive({'content.xml':ods(rows)})));assert.ok(doc.warnings.some(w=>/Formula cells/.test(w)));assert.equal(mapImportTable(doc.tables[0]).entries[0].name,'');
 for(const interior of [odsRow(odsCell('','table:number-columns-repeated="1000000"')+odsCell('Hidden far-right entrant')),odsRow(odsCell(''),'table:number-rows-repeated="1000000"')+odsRow(odsCell('Hidden far-down entrant'))])await assert.rejects(()=>parseBracketImport(file('interior.ods',archive({'content.xml':ods(interior)}))),/too many repeated/);
});
test('real DOCX zip exposes table roster and paragraphs as separate review choices',async()=>{
 const bytes=docx(para('Document title')+'<w:tbl>'+docRow('Opponent A','Opponent B')+docRow('Orion','Atlas')+'</w:tbl>'+para('Nova vs Lyra'));
 const doc=await parseBracketImport(file('teams.docx',bytes));assert.equal(doc.tables.length,2);assert.deepEqual(mapImportTable(doc.tables[0]).entries.map(e=>e.name),['Orion','Atlas']);assert.equal(doc.tables[1].name,'Document paragraphs');assert.ok(doc.warnings.some(w=>/embedded artwork/.test(w)));
});
test('Word tabs and ODS explicit spaces preserve text-column and name boundaries',async()=>{
 const tabbed=(a,b)=>`<w:p><w:r><w:t>${a}</w:t><w:tab/><w:t>${b}</w:t></w:r></w:p>`;
 const word=await parseBracketImport(file('tabs.docx',docx(tabbed('Name','Subtitle')+tabbed('Alpha','First')+tabbed('Beta','Second'))));assert.deepEqual(mapImportTable(word.tables[0]).entries.map(e=>[e.name,e.subtitle]),[['Alpha','First'],['Beta','Second']]);
 const rows=odsRow(odsCell('Name'))+odsRow(odsCell('Team<text:s/>Alpha'))+odsRow(odsCell('Team<text:s text:c="2"/>Beta'));
 const sheet=await parseBracketImport(file('spaces.ods',archive({'content.xml':ods(rows)})));assert.deepEqual(mapImportTable(sheet.tables[0]).entries.map(e=>e.name),['Team Alpha','Team  Beta']);
});
test('duplicate XLSX addresses and conflicting cell/row addresses fail instead of losing names',async()=>{
 for(const rows of ['<row r="1">'+inline('A1','Alpha')+inline('A1','Beta')+'</row>','<row r="1">'+inline('A2','Alpha')+'</row>'])await assert.rejects(()=>parseBracketImport(file('addresses.xlsx',xlsx(rows))),/repeated cell|row address/);
});
test('XML DTD/entity and malformed documents fail closed',async()=>{
 const bad='<!DOCTYPE x [<!ENTITY y SYSTEM "https://evil.invalid">]><x>&y;</x>';
 await assert.rejects(()=>parseBracketImport(file('evil.docx',archive({'word/document.xml':bad}))),/entities/);
 await assert.rejects(()=>parseBracketImport(file('bad.docx',archive({'word/document.xml':'<w:document><w:body><w:p></w:body></w:document>'}))),/malformed XML/);
});
test('archive macros, path traversal, duplicate filenames and encrypted entries are rejected',async()=>{
 await assert.rejects(()=>parseBracketImport(file('macro.xlsx',xlsx('',{'xl/vbaProject.bin':'macro'}))),/Macro-enabled/);
 await assert.rejects(()=>parseBracketImport(file('macro.xlsx',xlsx('',{'[Content_Types].xml':'<Types>application/vnd.ms-excel.sheet.macroEnabled.main+xml</Types>'}))),/Macro-enabled/);
 await assert.rejects(()=>parseBracketImport(file('bad.docx',archive({'../word/document.xml':'x'}))),/invalid or duplicate/);
 const dupe=mutateCentral(archive({'a.txt':'a','b.txt':'b'}),(view,index,name,out)=>{if(name==='b.txt')out[index+46]='a'.charCodeAt(0);});await assert.rejects(()=>parseBracketImport(file('dupe.docx',dupe)),/invalid or duplicate|do not match/);
 const encrypted=mutateCentral(docx(para('Alpha')),(view,index)=>view.setUint16(index+8,1,true));await assert.rejects(()=>parseBracketImport(file('encrypted.docx',encrypted)),/Encrypted/);
});
test('actual streaming inflate budget rejects forged tiny expanded sizes before XML parsing',async()=>{
 const bytes=archive({'word/document.xml':'x'.repeat(IMPORT_LIMITS.xmlBytes+100000)}),forged=mutateCentral(bytes,(view,index)=>view.setUint32(index+24,16,true));
 // The central size is intentionally untrustworthy; actual stream output must
 // trigger the budget, regardless of how small metadata claims the file is.
 await assert.rejects(()=>parseBracketImport(file('forged.docx',forged)),/expands beyond|exceeds the import limit/);
});
test('tampered CRC/sizes and too many archive entries cannot be imported',async()=>{
 const bytes=docx(para('Alpha')+para('Beta'));
 const badCrc=mutateCentral(bytes,(view,index)=>view.setUint32(index+16,0,true));await assert.rejects(()=>parseBracketImport(file('crc.docx',badCrc)),/integrity/);
 const badSize=mutateCentral(bytes,(view,index)=>view.setUint32(index+24,1,true));await assert.rejects(()=>parseBracketImport(file('size.docx',badSize)),/expanded size/);
 const tooMany=archive(Object.fromEntries(Array.from({length:513},(_,i)=>[`part${i}.txt`,'x'])));await assert.rejects(()=>parseBracketImport(file('files.docx',tooMany)),/too many files/);
});
test('row, column, text, and XML node bounds stop excessive document work',async()=>{
 assert.throws(()=>parseImportText(Array.from({length:1001},()=> 'Team').join('\n'),'txt'),/1,000 rows/);assert.throws(()=>parseImportText(Array(65).fill('Team').join(','),'csv'),/64 columns/);assert.throws(()=>parseImportText('x'.repeat(IMPORT_LIMITS.textCharacters+1),'txt'),/too much text/);
 const nodes='<document>'+'<p/>'.repeat(IMPORT_LIMITS.xmlNodes+1)+'</document>';await assert.rejects(()=>parseBracketImport(file('nodes.docx',archive({'word/document.xml':nodes}))),/too many XML nodes/);
 await assert.rejects(()=>parseBracketImport(file('wide.xlsx',xlsx('<row r="1">'+inline('BM1','Team')+'</row>'))),/64 columns/);
});
test('manual mapping is validated and formula-looking plain text remains inert roster text',()=>{
 const table=parseImportText('Name\n=HYPERLINK(""evil"")\n+SUM(A1:A2)','txt').tables[0],result=mapImportTable(table,{...table.suggested,startRow:1});assert.equal(result.entries[0].name,'=HYPERLINK(""evil"")');assert.equal(result.entries[0].image,null);
 assert.throws(()=>mapImportTable(table,{...table.suggested,startRow:-1}),/first data row/);assert.throws(()=>mapImportTable(table,{...table.suggested,nameColumn:64}),/valid, different/);
});
