export const motorsportPoints = [25, 18, 15, 12, 10, 8, 6, 4, 2, 1];

export type SeasonEntrant = { id: string; name: string };
export type SeasonResult = { entrantId: string; position: number | null; adjustment: number; note: string };
export type SeasonEvent = {
  id: string; title: string; date: string; status: 'draft' | 'complete'; results: SeasonResult[]; version: number;
};
export type Standing = {
  entrant: SeasonEntrant; rank: number; points: number; wins: number; podiums: number; starts: number;
  finishes: number[]; eventPoints: Record<string, number>;
};
export type Season = {
  id: string; title: string; description: string; points: number[]; entrants: SeasonEntrant[];
  events: SeasonEvent[]; standings: Standing[]; isOwner: boolean; createdAt: number; updatedAt: number; version: number;
};
export type SeasonCard = {
  id: string; title: string; description: string; entrantCount: number; eventCount: number; completedCount: number;
  isOwner: boolean; createdAt: number;
};

/** All totals derive from the current saved events. Replacing an event never adds points twice. */
export function calculateStandings(entrants: SeasonEntrant[], events: SeasonEvent[], points: number[]): Standing[] {
  const rows = entrants.map(entrant => ({ entrant, rank: 0, points: 0, wins: 0, podiums: 0, starts: 0,
    finishes: Array.from({ length: entrants.length }, () => 0), eventPoints: {} as Record<string, number> }));
  const byId = new Map(rows.map(row => [row.entrant.id, row]));
  for (const event of events) {
    if (event.status !== 'complete') continue;
    for (const result of event.results) {
      const row = byId.get(result.entrantId);
      if (!row) continue;
      const scored = (result.position === null ? 0 : points[result.position - 1] ?? 0) + result.adjustment;
      row.points += scored;
      row.eventPoints[event.id] = scored;
      if (result.position !== null) {
        row.starts += 1;
        row.finishes[result.position - 1] = (row.finishes[result.position - 1] ?? 0) + 1;
        if (result.position === 1) row.wins += 1;
        if (result.position <= 3) row.podiums += 1;
      }
    }
  }
  const compareScore = (a: Standing, b: Standing) => {
    if (a.points !== b.points) return b.points - a.points;
    for (let position = 0; position < entrants.length; position++) {
      const diff = b.finishes[position] - a.finishes[position];
      if (diff) return diff;
    }
    return 0;
  };
  rows.sort((a, b) => compareScore(a, b) || a.entrant.name.localeCompare(b.entrant.name) || a.entrant.id.localeCompare(b.entrant.id));
  rows.forEach((row, index) => { row.rank = index && compareScore(rows[index - 1], row) === 0 ? rows[index - 1].rank : index + 1; });
  return rows;
}

export function parsePoints(text: string): number[] {
  const values = text.trim().split(/[\s,]+/).map(value => Number(value));
  if (!text.trim() || values.length > 128 || values.some(value => !Number.isInteger(value) || value < 0 || value > 10000)) {
    throw new Error('Enter 1–128 whole-number points values, from 0 to 10,000, separated by commas.');
  }
  return values;
}
