import {isSuppliedAnimeArtwork} from './anime-artwork';
import {validateImage,ImageValidationError} from './image-validation';
import {z} from 'zod';
import {makeDraft,type Draft} from './bracket';
import {activitySnapshot,advanceActivity,newActivityState,votingMatch,type ActivityState,type ActivityVote} from './discord-engine';
class DiscordError extends Error{constructor(public status:number,message:string,public code?:string){super(message);}}
const result=(data:unknown,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
const hex=(bytes:Uint8Array)=>Array.from(bytes,x=>x.toString(16).padStart(2,'0')).join('');
const digest=async(value:string)=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))));
const snowflake=z.string().regex(/^\d{15,22}$/);
const instanceSchema=z.object({application_id:snowflake,instance_id:z.string(),location:z.object({id:z.string().min(1).max(150),channel_id:snowflake,guild_id:snowflake.nullable().optional()}),users:z.array(snowflake).max(1000)});
type Instance=z.infer<typeof instanceSchema>;
// Bounded per-isolate cache; expired membership is rechecked, and Discord errors
// never fall back to a client claim or expired cache entry.
const instanceCache=new Map<string,{expires:number;data:Instance}>();
type DiscordStage='oauth_exchange'|'identity'|'activity_instance';
const discordRelease='1.10.1';
const discordAgent=`DiscordBot (https://bracketlive.goyfundmenow.workers.dev, ${discordRelease})`;
// Never return or log upstream bodies, credentials, user IDs or instance URLs.
async function rejectionReason(response:Response){
 const reader=response.body?.getReader();if(!reader)return 'unknown';const bytes:Uint8Array[]=[];let length=0;
 try{for(;;){const {done,value}=await reader.read();if(done)break;if(length+value.length>8192){await reader.cancel();return 'unknown';}bytes.push(value);length+=value.length;}}catch{return 'unknown';}
 const joined=new Uint8Array(length);let position=0;for(const chunk of bytes){joined.set(chunk,position);position+=chunk.length;}const body=new TextDecoder().decode(joined);
 if(/\berror code:\s*1010\b/i.test(body))return 'request_blocked';
 try{const data=JSON.parse(body);if(['invalid_client','invalid_grant','invalid_request','invalid_scope','unauthorized_client'].includes(data.error))return data.error;if(Number.isSafeInteger(data.code)&&data.code>=0&&data.code<=999999)return String(data.code);}catch{}
 return 'unknown';
}
async function discordJSON(stage:DiscordStage,path:string,init:RequestInit){
 const headers=new Headers(init.headers);headers.set('User-Agent',discordAgent);headers.set('Accept','application/json');if(!headers.has('Content-Type'))headers.set('Content-Type','application/json');
 // Discord documents the Activity Instance API separately, without /v10.
 const base=stage==='activity_instance'?'https://discord.com/api':'https://discord.com/api/v10';let response:Response;
 try{response=await fetch(base+path,{...init,headers,signal:AbortSignal.timeout(10000)});}catch{
  console.error('Discord request failed',{stage,reason:'network_or_timeout'});throw new DiscordError(503,`Discord could not be reached (${stage}). Try again shortly.`,`discord_${stage}_unavailable`);
 }
 if(!response.ok){
  const reason=await rejectionReason(response);console.error('Discord request rejected',{stage,httpStatus:response.status,reason});
  let message=`Discord rejected ${stage.replaceAll('_',' ')} (HTTP ${response.status}${reason==='unknown'?'':'; '+reason}).`;
  if(response.status===429)message='Discord is rate limiting sign-in. Wait a minute, then reopen the Activity.';
  else if(reason==='request_blocked')message=`Discord blocked the server request (${stage}, HTTP ${response.status}). Share this error with the site owner.`;
  else if(stage==='oauth_exchange'&&(reason==='invalid_client'||response.status===401))message='Discord rejected the application credentials. The owner must replace DISCORD_CLIENT_SECRET with the current OAuth2 Client Secret for this application.';
  else if(stage==='oauth_exchange'&&reason==='invalid_grant')message='Discord rejected the sign-in code. Close this Activity completely and launch it again to get a fresh code.';
  else if(stage==='activity_instance'&&response.status===401)message='Discord rejected the bot credentials. The owner must replace DISCORD_BOT_TOKEN with the current Bot Token for this application.';
  else if(stage==='activity_instance'&&response.status===404)message='Discord could not find this active Activity instance. Close the Activity and launch BracketLIVE again from the App Launcher.';
  else if(stage==='activity_instance'&&response.status===403)message='Discord denied Activity verification. Check that DISCORD_BOT_TOKEN belongs to the configured BracketLIVE application.';
  else if(stage==='identity'&&response.status===401)message='Discord rejected the authorized user token. Close this Activity and sign in again.';
  throw new DiscordError(response.status===429?429:503,message,`discord_${stage}_${response.status}_${reason}`);
 }
 try{return await response.json();}catch{console.error('Discord response invalid',{stage});throw new DiscordError(503,`Discord returned an invalid ${stage.replaceAll('_',' ')} response. Try again shortly.`,`discord_${stage}_invalid_response`);}
}
export async function verifiedInstance(env:Cloudflare.Env,instance:string,userId:string,fresh=false){
 if(!env.DISCORD_APPLICATION_ID||!env.DISCORD_BOT_TOKEN)throw new DiscordError(503,'The creator must finish Discord setup.');
 const key=env.DISCORD_APPLICATION_ID+':'+instance,cached=instanceCache.get(key);
 let data:Instance;
 if(!fresh&&cached&&cached.expires>Date.now())data=cached.data;
 else{
  data=instanceSchema.parse(await discordJSON('activity_instance',`/applications/${env.DISCORD_APPLICATION_ID}/activity-instances/${encodeURIComponent(instance)}`,{headers:{Authorization:`Bot ${env.DISCORD_BOT_TOKEN.trim()}`}}));
  if(instanceCache.size>=200)instanceCache.delete(instanceCache.keys().next().value!);
  instanceCache.set(key,{expires:Date.now()+15000,data});
 }
 if(data.application_id!==env.DISCORD_APPLICATION_ID||data.instance_id!==instance||!data.users.includes(userId))throw new DiscordError(403,'Join this Discord Activity before viewing or voting.');
 return `${data.application_id}:${data.location.guild_id??'dm'}:${data.location.channel_id}`;
}
async function readRaster(req:Request){
 const reader=req.body?.getReader();if(!reader)throw new DiscordError(400,'Choose an image.');let size=0;const chunks:Uint8Array[]=[];
 for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>5*1024*1024){await reader.cancel();throw new DiscordError(413,'Use an image smaller than 5 MB.');}chunks.push(value);}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}return bytes;
}
async function readBody(req:Request){
 const reader=req.body?.getReader();if(!reader)throw new DiscordError(400,'Missing request.');let n=0;const chunks:Uint8Array[]=[];
 for(;;){const {done,value}=await reader.read();if(done)break;n+=value.byteLength;if(n>150000){await reader.cancel();throw new DiscordError(413,'Request too large.');}chunks.push(value);}
 const bytes=new Uint8Array(n);let p=0;for(const c of chunks){bytes.set(c,p);p+=c.length;}
 try{return JSON.parse(new TextDecoder().decode(bytes));}catch{throw new DiscordError(400,'Invalid JSON.');}
}
type Session={user_id:string;display_name:string;instance_id:string;room_key:string;expires_at:number};
type Row={id:string;owner_id:string;state_json:string;revision:number;closes_at:number|null};
async function session(req:Request,env:Cloudflare.Env){
 const bearer=req.headers.get('Authorization')?.match(/^Bearer ([a-f0-9]{64})$/)?.[1];
 if(!bearer)throw new DiscordError(401,'Open this Activity in Discord to sign in.');
 const s=await env.DB!.prepare('SELECT * FROM discord_sessions WHERE token_hash=? AND expires_at>?').bind(await digest(bearer),Date.now()).first<Session>();
 if(!s)throw new DiscordError(401,'Session expired. Reopen the Activity.');
 const room=await verifiedInstance(env,s.instance_id,s.user_id);
 if(room!==s.room_key)throw new DiscordError(403,'This session belongs to another channel.');
 return s;
}
const entrySchema=z.object({name:z.string().trim().min(1).max(100),subtitle:z.string().max(150).default(''),seed:z.number().int(),image:z.union([z.null(),z.string().refine(value=>isSuppliedAnimeArtwork(value)||/^\/templates\/anime-source\.png#slot=\d{1,2}$/.test(value)||/^\/api\/discord\/media\/[a-f0-9-]{36}\.(png|jpg|webp|gif)$/.test(value))]).default(null)}).strict();
const createSchema=z.object({title:z.string().trim().min(1).max(100),description:z.string().max(400).default(''),entries:z.array(entrySchema).min(2).max(128),format:z.enum(['standard','ncaa2026']).default('standard'),roundMinutes:z.number().int().min(0).max(43200).default(0)}).strict();
async function load(db:D1Database,id:string,room:string){
 const rows=await db.batch([
  db.prepare('SELECT * FROM discord_tournaments WHERE id=? AND room_key=?').bind(id,room),
  db.prepare('SELECT match_id,entry_id,user_id FROM discord_votes WHERE tournament_id=? AND EXISTS (SELECT 1 FROM discord_tournaments WHERE id=? AND room_key=?)').bind(id,id,room)
 ]);
 const row=rows[0].results[0] as unknown as Row|undefined;if(!row)throw new DiscordError(404,'Tournament not found in this channel.');
 return {row,state:JSON.parse(row.state_json) as ActivityState,votes:rows[1].results as unknown as ActivityVote[]};
}
async function saveState(db:D1Database,row:Row,state:ActivityState){
 const r=await db.prepare('UPDATE discord_tournaments SET state_json=?,revision=revision+1,closes_at=? WHERE id=? AND revision=?').bind(JSON.stringify(state),state.blocked?null:state.bracket.round_closes_at,row.id,row.revision).run();
 if(r.meta.changes!==1)throw new DiscordError(409,'Votes changed while this round was closing. Review the refreshed results and try again.');
}
export async function discordAPI(req:Request,env:Cloudflare.Env):Promise<Response>{
 try{
  const path=new URL(req.url).pathname;
  if(path==='/api/discord/config'&&req.method==='GET')return result({applicationId:env.DISCORD_APPLICATION_ID??null,configured:!!(env.DISCORD_APPLICATION_ID&&env.DISCORD_CLIENT_SECRET?.trim()&&env.DISCORD_BOT_TOKEN?.trim()),version:discordRelease});
  if(!env.DB)throw new DiscordError(503,'Database is not configured.');
  if(path==='/api/discord/auth'&&req.method==='POST'){
   const {code,instanceId}=z.object({code:z.string().min(1).max(2048),instanceId:z.string().regex(/^[a-zA-Z0-9_-]{1,200}$/)}).strict().parse(await readBody(req));
   if(!env.DISCORD_APPLICATION_ID||!env.DISCORD_CLIENT_SECRET||!env.DISCORD_BOT_TOKEN)throw new DiscordError(503,'The creator must finish Discord setup.');
   const oauth=z.object({access_token:z.string().min(1),expires_in:z.number().positive()}).parse(await discordJSON('oauth_exchange','/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:env.DISCORD_APPLICATION_ID,client_secret:env.DISCORD_CLIENT_SECRET.trim(),grant_type:'authorization_code',code})}));
   const user=z.object({id:snowflake,username:z.string().max(100),global_name:z.string().max(100).nullable().optional()}).parse(await discordJSON('identity','/users/@me',{headers:{Authorization:`Bearer ${oauth.access_token}`}}));
   const room=await verifiedInstance(env,instanceId,user.id,true),token=hex(crypto.getRandomValues(new Uint8Array(32))),name=user.global_name||user.username;
   await env.DB.batch([
    env.DB.prepare('DELETE FROM discord_sessions WHERE expires_at<=?').bind(Date.now()),
    env.DB.prepare('INSERT INTO discord_sessions(token_hash,user_id,display_name,instance_id,room_key,expires_at) VALUES(?,?,?,?,?,?)').bind(await digest(token),user.id,name,instanceId,room,Date.now()+Math.min(oauth.expires_in*1000,8*3600000))
   ]);
   return result({token,access_token:oauth.access_token,user:{id:user.id,name}});
  }
  const download=path.match(/^\/api\/discord\/download\/([a-f0-9-]{36})$/);
  if(download&&req.method==='GET'){
   const row=await env.DB.prepare('SELECT * FROM discord_exports WHERE id=? AND ready=1 AND expires_at>?').bind(download[1],Date.now()).first<{type:string}>();
   if(!row)throw new DiscordError(404,'This download expired or does not exist. Export the results again.');
   const object=await env.BUCKET?.get('discord-exports/'+download[1]);if(!object)throw new DiscordError(404,'Export not found.');
   return new Response(object.body,{headers:{'Content-Type':row.type,'Cache-Control':'private, no-store','Content-Disposition':'attachment; filename="BracketLive-results.png"'}});
  }
  const who=await session(req,env),db=env.DB;
  const media=path.match(/^\/api\/discord\/media\/([a-f0-9-]{36})\.(png|jpg|webp|gif)$/);
  if(media&&req.method==='GET'){
   const row=await db.prepare('SELECT * FROM discord_media WHERE id=? AND room_key=? AND ready=1').bind(media[1],who.room_key).first<{type:string}>();
   if(!row)throw new DiscordError(404,'Image not found in this channel.');
   const object=await env.BUCKET?.get('discord-media/'+media[1]);if(!object)throw new DiscordError(404,'Image not found.');
   return new Response(object.body,{headers:{'Content-Type':row.type,'Cache-Control':'private, no-store'}});
  }
  if((path==='/api/discord/media'||path==='/api/discord/exports')&&req.method==='POST'){
   if(!env.BUCKET)throw new DiscordError(503,'Image storage is not configured.');
   const bytes=await readRaster(req),validated=validateImage(bytes),isExport=path.endsWith('/exports');
   if(isExport&&validated.ext!=='png')throw new DiscordError(400,'Results exports must be PNG images.');
   const id=crypto.randomUUID(),now=Date.now(),table=isExport?'discord_exports':'discord_media',key=(isExport?'discord-exports/':'discord-media/')+id;
   const columns='id,room_key,owner_id,type,bytes,created_at'+(isExport?',expires_at':'');
   const values=[id,who.room_key,who.user_id,validated.type,bytes.length,now,...(isExport?[now+86400000]:[])];
   const inserted=await db.prepare(`INSERT INTO ${table}(${columns}) SELECT ${values.map(()=>'?').join(',')} WHERE (SELECT COUNT(*) FROM ${table} WHERE owner_id=? AND created_at>?)<? AND ?+(SELECT COALESCE(SUM(bytes),0) FROM ${table} WHERE owner_id=? AND created_at>?)<=?`).bind(...values,who.user_id,now-86400000,isExport?40:400,bytes.length,who.user_id,now-86400000,100*1024*1024).run();
   if(!inserted.meta.changes)throw new DiscordError(429,'Image upload allowance reached for today.');
   try{await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:validated.type}});await db.prepare(`UPDATE ${table} SET ready=1 WHERE id=?`).bind(id).run();}
   catch{await Promise.allSettled([env.BUCKET.delete(key),db.prepare(`DELETE FROM ${table} WHERE id=?`).bind(id).run()]);throw new DiscordError(503,'Image upload failed. Please retry.');}
   return result(isExport?{url:new URL('/api/discord/download/'+id,env.AUTH_ORIGIN||req.url).href,expiresAt:now+86400000}:{image:`/api/discord/media/${id}.${validated.ext}`},201);
  }
  if(path==='/api/discord/room'&&req.method==='GET'){
   const {results}=await db.prepare('SELECT id,owner_id,state_json,revision FROM discord_tournaments WHERE room_key=? ORDER BY created_at DESC LIMIT 100').bind(who.room_key).all<Row>();
   return result({user:{id:who.user_id,name:who.display_name},tournaments:results.map(row=>{const {bracket:b}=JSON.parse(row.state_json) as ActivityState;return {id:row.id,title:b.title,size:b.size,status:b.status,currentRound:b.current_round,isOwner:row.owner_id===who.user_id};})});
  }
  if(path==='/api/discord/tournaments'&&req.method==='POST'){
   const data=createSchema.parse(await readBody(req)),size=data.entries.length;
   if(![2,4,8,16,32,64,128].includes(size))throw new DiscordError(400,'Use 2, 4, 8, 16, 32, 64 or 128 contenders.');
   if(data.format==='ncaa2026'&&size!==64)throw new DiscordError(400,'The NCAA example has 64 teams.');
   for(const entry of data.entries){if(entry.image?.startsWith('/api/discord/media/')){const imageId=entry.image.split('/').pop()!.split('.')[0];if(!await db.prepare('SELECT id FROM discord_media WHERE id=? AND room_key=? AND ready=1').bind(imageId,who.room_key).first())throw new DiscordError(400,'Upload that image in this channel first.');}}
   const draft:Draft={...makeDraft(size,false),title:data.title,description:data.description,format:data.format,entries:data.entries.map((e,i)=>({...e,seed:i+1})),listed:false};
   const id=crypto.randomUUID(),state=newActivityState(draft,id,data.roundMinutes),now=Date.now();
   const inserted=await db.prepare('INSERT INTO discord_tournaments(id,room_key,owner_id,state_json,created_at,closes_at) SELECT ?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM discord_tournaments WHERE owner_id=? AND created_at>?)<20').bind(id,who.room_key,who.user_id,JSON.stringify(state),now,state.bracket.round_closes_at,who.user_id,now-86400000).run();
   if(!inserted.meta.changes)throw new DiscordError(429,'You can create up to 20 tournaments per day.');
   return result({id},201);
  }
  const matched=path.match(/^\/api\/discord\/tournaments\/([a-f0-9-]{36})(?:\/(vote|advance))?$/);
  if(!matched)throw new DiscordError(404,'Not found.');
  const [,id,action]=matched,{row,state,votes}=await load(db,id,who.room_key);
  const snapshot=()=>result({bracket:activitySnapshot(state,votes,who.user_id,row.owner_id===who.user_id),revision:row.revision});
  if(!action&&req.method==='GET')return snapshot();
  if(action==='vote'&&req.method==='POST'){
   const data=z.object({matchId:z.string().max(80),entryId:z.string().max(80).nullable()}).strict().parse(await readBody(req));
   try{votingMatch(state,data.matchId,data.entryId);}catch(e){throw new DiscordError(409,(e as Error).message);}
   const mutation=crypto.randomUUID();
   // Every vote increments the same revision used by advancement. The batch is
   // atomic, so a stale advancement cannot silently discard a concurrent vote.
   const condition='EXISTS(SELECT 1 FROM discord_tournaments WHERE id=? AND revision=? AND mutation_id=?)';
   const gate=db.prepare('UPDATE discord_tournaments SET revision=revision+1,mutation_id=? WHERE id=? AND revision=? AND (closes_at IS NULL OR closes_at>?)').bind(mutation,id,row.revision,Date.now());
   const vote=data.entryId===null?db.prepare(`DELETE FROM discord_votes WHERE tournament_id=? AND match_id=? AND user_id=? AND ${condition}`).bind(id,data.matchId,who.user_id,id,row.revision+1,mutation):db.prepare(`INSERT INTO discord_votes(tournament_id,match_id,user_id,entry_id) SELECT ?,?,?,? WHERE ${condition} ON CONFLICT(tournament_id,match_id,user_id) DO UPDATE SET entry_id=excluded.entry_id`).bind(id,data.matchId,who.user_id,data.entryId,id,row.revision+1,mutation);
   const changed=await db.batch([gate,vote]);if(changed[0].meta.changes!==1)throw new DiscordError(409,'The match just changed. Please try your vote again.');
   return result({ok:true});
  }
  if(action==='advance'&&req.method==='POST'){
   if(row.owner_id!==who.user_id)throw new DiscordError(403,'Only the tournament creator can close a round.');
   const {ties}=z.object({ties:z.record(z.string().max(80),z.string().max(80)).default({})}).strict().parse(await readBody(req));
   let next:ActivityState;try{next=advanceActivity(state,votes,ties);}catch(e){throw new DiscordError(409,(e as Error).message);}
   await saveState(db,row,next);return result({ok:true});
  }
  throw new DiscordError(405,'Method not supported.');
 }catch(error){
  if(error instanceof ImageValidationError)return result({error:error.message},400);
  if(error instanceof DiscordError)return result({error:error.message,...(error.code?{code:error.code}:{})},error.status);
  if(error instanceof z.ZodError)return result({error:'The request or Discord response was not valid.'},400);
  console.error('Discord Activity request failed');return result({error:'The Activity is temporarily unavailable. Check migrations and Discord setup.'},503);
 }
}
export async function runDiscordScheduler(env:Cloudflare.Env){
 if(!env.DB||!env.DISCORD_APPLICATION_ID)return;
 const db=env.DB,now=Date.now();
 if(env.BUCKET){const {results:expired}=await db.prepare('SELECT id FROM discord_exports WHERE expires_at<=? LIMIT 50').bind(now).all<{id:string}>();for(const x of expired){await env.BUCKET.delete('discord-exports/'+x.id);await db.prepare('DELETE FROM discord_exports WHERE id=?').bind(x.id).run();}}
 await db.prepare('DELETE FROM discord_sessions WHERE expires_at<=?').bind(now).run();
 const {results}=await db.prepare('SELECT id,room_key FROM discord_tournaments WHERE closes_at<=? ORDER BY closes_at LIMIT 50').bind(now).all<{id:string;room_key:string}>();
 for(const item of results){
  const {row,state,votes}=await load(db,item.id,item.room_key);
  if(!state.bracket.round_closes_at||state.bracket.round_closes_at>now||state.bracket.status!=='live')continue;
  let next:ActivityState;try{next=advanceActivity(state,votes,{},now);}catch{next={...state,blocked:'Voting closed. The creator must resolve tied or unvoted matches.'};}
  try{await saveState(db,row,next);}catch(e){if(!(e instanceof DiscordError&&e.status===409))throw e;}
 }
}
