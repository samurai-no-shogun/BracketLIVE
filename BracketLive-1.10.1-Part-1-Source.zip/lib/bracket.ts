import type {Appearance} from './appearance';
import {scheduleInputFromResolved,type ScheduleInput,type VotingSchedule} from './voting-schedule';
import {animeEntries,animeImage} from './anime-roster';
import {basketballRounds,basketballSlot} from './basketball-template';
import {ncaa2026Entries,ncaa2026Slot} from './ncaa-2026';
export type BracketFormat='standard'|'basketball'|'ncaa2026';
export function isRegionalFormat(format:BracketFormat='standard'){return format==='basketball'||format==='ncaa2026';}
export type TemplateId='blank'|'trial'|'basketball';
export type Entry={id:string;name:string;subtitle:string;image:string|null;seed:number};
export type Match={id:string;round:number;position:number;a_id:string|null;b_id:string|null;winner_id:string|null;status:string;myVote:string|null;counts:Record<string,number>|null;total:number|null;decided_by:string|null};
export type Draft={title:string;description:string;size:number;format:BracketFormat;accent:string;brand_color:string|null;brand_image:string|null;appearance:Appearance;listed:boolean;ends_at:number|null;voting_schedule?:ScheduleInput;entries:Omit<Entry,'id'>[]};
export type Bracket=Omit<Draft,'entries'|'voting_schedule'>&{id:string;status:string;current_round:number;created_at:number;started_at:number|null;round_closes_at:number|null;voting_schedule?:VotingSchedule|null;schedule_blocked?:boolean;schedule_blocked_reason?:string|null;is_test:boolean;isOwner:boolean;entries:Entry[];matches:Match[];totalVotes:number};
export type TournamentCard={id:string;title:string;description:string;size:number;format?:BracketFormat;accent:string;brand_color:string|null;brand_image:string|null;status:string;current_round:number;round_closes_at:number|null;ends_at:number|null;is_test:boolean;created_at:number;totalVotes:number;champion:string|null};
export const sizes=[2,4,8,16,32,64,128];
export function roundName(round:number,size:number,format:BracketFormat='standard'){if(isRegionalFormat(format)&&size===64)return basketballRounds[round]??'Championship';const remain=size/(2**round);return remain===2?'Final':remain===4?'Semifinals':remain===8?'Quarterfinals':`Round of ${remain}`;}
export function displaySeed(entry:Pick<Entry,'seed'>,format:BracketFormat='standard'){return isRegionalFormat(format)?(format==='ncaa2026'?ncaa2026Slot(entry.seed):basketballSlot(entry.seed))?.seed??entry.seed:entry.seed;}
export function entryRegion(entry:Pick<Entry,'seed'>,format:BracketFormat='standard'){return isRegionalFormat(format)?(format==='ncaa2026'?ncaa2026Slot(entry.seed):basketballSlot(entry.seed))?.region??null:null;}
export function votePercent(match:Match,entryId:string){return match.total?Math.round((match.counts?.[entryId]??0)/match.total*100):0;}
export function makeDraft(size=64,anime=true):Draft{return {title:anime?'Trial Bracket':'',description:'',size,format:'standard',accent:'purple',brand_color:null,brand_image:null,appearance:{},listed:true,ends_at:null,entries:Array.from({length:size},(_,i)=>({name:anime&&i<animeEntries.length?animeEntries[i][0]:'',subtitle:anime&&i<animeEntries.length?animeEntries[i][1]:'',image:anime&&i<animeEntries.length?animeImage(i):null,seed:i+1}))};}
export function makeTemplateDraft(template:TemplateId):Draft{
 if(template!=='basketball')return makeDraft(template==='blank'?16:64,template==='trial');
 return {...makeDraft(64,false),title:'2026 NCAA Men’s Basketball — Practice',description:'Real 2026 Round of 64 teams, seeds, and matchups, including the First Four winners. Pick your own winners in this practice bracket.',format:'ncaa2026',entries:ncaa2026Entries()};
}
export function draftBracket(d:Draft):Bracket{const entries=d.entries.map((e,i)=>({...e,id:`entry-${i}`}));const matches:Match[]=[];for(let r=0;r<Math.log2(d.size);r++)for(let p=0;p<d.size/2**(r+1);p++)matches.push({id:`preview-${r}-${p}`,round:r,position:p,a_id:r===0?entries[p*2].id:null,b_id:r===0?entries[p*2+1].id:null,winner_id:null,status:'pending',myVote:null,counts:null,total:null,decided_by:null});const {voting_schedule,...base}=d;void voting_schedule;return {...base,id:'preview',created_at:0,started_at:null,round_closes_at:null,voting_schedule:null,schedule_blocked:false,is_test:false,status:'draft',current_round:0,isOwner:true,entries,matches,totalVotes:0};}
export function deadlineForRound(start:number,end:number,size:number,round:number){return Math.round(start+(end-start)*(round+1)/Math.log2(size));}
export function toDraft(b:Bracket):Draft{return {title:b.title,description:b.description,size:b.size,format:b.format||'standard',accent:b.accent,brand_color:b.brand_color,brand_image:b.brand_image,appearance:b.appearance||{},listed:b.listed,ends_at:b.ends_at,...(b.voting_schedule?{voting_schedule:scheduleInputFromResolved(b.voting_schedule,b.current_round)}:{}),entries:b.entries.map(({id,...e})=>e)};}
export function publicVotingDraft(b:Bracket):Draft{const {voting_schedule,...draft}=toDraft(b);void voting_schedule;return {...draft,listed:true,ends_at:null};}
