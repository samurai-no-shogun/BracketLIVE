/**
 * Actual 2026 NCAA Division I men's Round of 64, after the First Four.
 * Slot ordinals remain unique (1–64); regional seeds repeat (1–16).
 * Pair adjacent regions in the Final Four: East/South and West/Midwest.
 * The original generic basketball format retains its original region order.
 */
export const ncaa2026SourceUrl='https://www.ncaa.com/march-madness-live/bracket';
export const ncaa2026PrintableSourceUrl='https://www.ncaa.com/brackets/print/basketball-men/d1/2026';
export const ncaa2026VerifiedAt='2026-10-05';
export const ncaa2026Seeds=[1,16,8,9,5,12,4,13,6,11,3,14,7,10,2,15] as const;
export const ncaa2026Regions=['East','South','West','Midwest'] as const;
export const ncaa2026Rounds=['Round of 64','Round of 32','Sweet 16','Elite Eight','Final Four','Championship'] as const;
export type Ncaa2026Region=typeof ncaa2026Regions[number];

/** Names in actual first-round matchup order, not seed-number order. */
export const ncaa2026TeamsByRegion={
 East:[
  'Duke','Siena','Ohio State','TCU',
  "St. John's",'Northern Iowa','Kansas','Cal Baptist',
  'Louisville','South Florida','Michigan State','North Dakota State',
  'UCLA','UCF','UConn','Furman',
 ],
 South:[
  'Florida','Prairie View A&M','Clemson','Iowa',
  'Vanderbilt','McNeese','Nebraska','Troy',
  'North Carolina','VCU','Illinois','Penn',
  "Saint Mary's",'Texas A&M','Houston','Idaho',
 ],
 West:[
  'Arizona','Long Island','Villanova','Utah State',
  'Wisconsin','High Point','Arkansas','Hawaii',
  'BYU','Texas','Gonzaga','Kennesaw State',
  'Miami (FL)','Missouri','Purdue','Queens (N.C.)',
 ],
 Midwest:[
  'Michigan','Howard','Georgia','Saint Louis',
  'Texas Tech','Akron','Alabama','Hofstra',
  'Tennessee','Miami (Ohio)','Virginia','Wright State',
  'Kentucky','Santa Clara','Iowa State','Tennessee State',
 ],
} as const;

/** Winners already present in the field. Their play-in games are not simulated. */
export const ncaa2026FirstFourWinners=[
 {name:'Howard',seed:16,region:'Midwest',opponent:'UMBC'},
 {name:'Texas',seed:11,region:'West',opponent:'NC State'},
 {name:'Prairie View A&M',seed:16,region:'South',opponent:'Lehigh'},
 {name:'Miami (Ohio)',seed:11,region:'Midwest',opponent:'SMU'},
] as const;

export function ncaa2026Slot(slot:number){
 if(!Number.isInteger(slot)||slot<1||slot>64)return null;
 const region=ncaa2026Regions[Math.floor((slot-1)/16)];
 const position=(slot-1)%16;
 return {region,seed:ncaa2026Seeds[position],name:ncaa2026TeamsByRegion[region][position]};
}

/** Only the initial teams are populated; practice winners start unselected. */
export function ncaa2026Entries(){
 return Array.from({length:64},(_,i)=>{
  const slot=ncaa2026Slot(i+1)!;
  return {name:slot.name,subtitle:`${slot.region} · Seed ${slot.seed}`,image:null,seed:i+1};
 });
}
