import {suppliedAnimeArtwork} from './anime-artwork';
// Reference order: left column from top to bottom, then right column.
// Consecutive entries are opponents; keep repeated series as separate systems.
export const animeEntries = [
  ['Hollowfication', 'Bleach'],
  ['Innocence', 'D.Gray-man'],
  ['Geass', 'Code Geass'],
  ['Dōjutsu / Eye Techniques', 'Naruto'],
  ['Tier Magic', 'Overlord'],
  ['Magic / Spellcraft', 'Frieren'],
  ['Negator Abilities', 'Undead Unluck'],
  ['Death Note Rules', 'Death Note'],
  ['Stands', 'JoJo’s Bizarre Adventure'],
  ['Furyoku / Over Soul', 'Shaman King'],
  ['System / Leveling / Skills', 'Solo Leveling'],
  ['Sword Skills / Unique Skills', 'Sword Art Online'],
  ['Kaiju Transformation', 'Kaiju No. 8'],
  ['Titan Shifting', 'Attack on Titan'],
  ['Cosmo', 'Saint Seiya'],
  ['Ki', 'Dragon Ball Z'],
  ['Breathing Styles / Nichirin Swords', 'Demon Slayer'],
  ['Enchanted Blades', 'Kagurabachi'],
  ['Soul Wavelength / Resonance', 'Soul Eater'],
  ['Spirit Energy', 'Yu Yu Hakusho'],
  ['Rukh / Magoi / Djinn Equip', 'Magi'],
  ['Abnormalities / Minuses', 'Medaka Box'],
  ['Gourmet Cells', 'Toriko'],
  ['Magic & Supernatural Abilities', 'GetBackers'],
  ['Tao', 'Hell’s Paradise'],
  ['Nen', 'Hunter × Hunter'],
  ['Life Fibers / Kamui', 'Kill la Kill'],
  ['Teigu / Imperial Arms', 'Akame ga Kill!'],
  ['Hamon', 'JoJo’s Bizarre Adventure'],
  ['Haki', 'One Piece'],
  ['Mana + Grimoires', 'Black Clover'],
  ['Mamodo + Spellbooks', 'Zatch Bell!'],
  ['Devils / Contract Powers', 'Black Clover'],
  ['Magic Circles / Ink Magic', 'Witch Hat Atelier'],
  ['Spiral Power', 'Gurren Lagann'],
  ['Demon Powers / Sacred Jewel', 'Inuyasha'],
  ['Devil Contracts', 'Chainsaw Man'],
  ['Exorcism / Demon Flames', 'Blue Exorcist'],
  ['Pokémon', 'Pokémon'],
  ['Digivolution', 'Digimon'],
  ['Quirks', 'My Hero Academia'],
  ['Devil Fruits', 'One Piece'],
  ['Crystal Power / Celestial Magic', 'Sailor Moon'],
  ['Trion + Triggers', 'World Trigger'],
  ['Cursed Energy + Techniques', 'Jujutsu Kaisen'],
  ['Chakra / Ninjutsu', 'Naruto'],
  ['Alchemy', 'Fullmetal Alchemist'],
  ['Ignition Abilities', 'Fire Force'],
  ['Kagune / Kakuja', 'Tokyo Ghoul'],
  ['Branch of Sin', 'Deadman Wonderland'],
  ['Vampirism / Familiars', 'Hellsing Ultimate'],
  ['Yoki / Yoma Powers', 'Claymore'],
  ['Smoke Magic', 'Dorohedoro'],
  ['Apostles / Beherits / Astral World', 'Berserk'],
  ['Hokuto Shinken', 'Fist of the North Star'],
  ['Caster Magic', 'Fairy Tail'],
  ['Zanpakutō / Shikai / Bankai', 'Bleach'],
  ['Magecraft', 'Fate'],
  ['Magic + Sacred Treasures', 'The Seven Deadly Sins'],
  ['Karma / Shinjutsu', 'Boruto'],
  ['Psychic Powers', 'Mob Psycho 100'],
  ['Spiritual Powers / Yokai Abilities', 'Dandadan'],
  ['Air Trecks / Roads', 'Air Gear'],
  ['Dying Will Flames', 'Katekyo Hitman Reborn!'],
] as const;

export const animeSource = '/templates/anime-source.png';
export const animeSourceSize = {width: 2048, height: 1582};

// Display the original logo pixels as sprites; the source PNG is unmodified.
const leftLogoY = [63,94,152,184,242,273,330,361,422,453,510,543,598,630,689,720,780,810,870,900,957,988,1046,1080,1136,1167,1228,1259,1316,1346,1403,1435];
const rightLogoY = [63,95,152,184,239,271,331,364,420,452,511,542,598,630,687,720,780,811,869,900,957,988,1047,1077,1136,1168,1227,1258,1314,1346,1404,1434];
export function animeImage(index: number) { return suppliedAnimeArtwork[index+1]??null; }
export function animeLogo(image: string) {
  const match = /^\/templates\/anime-source\.png#slot=([1-9]|[1-5]\d|6[0-4])$/.exec(image);
  if (!match) return null;
  const index = Number(match[1]) - 1;
  return {x: index < 32 ? 12 : 1869, y: index < 32 ? leftLogoY[index] : rightLogoY[index - 32], width: 84, height: 24};
}

// Old saved sprite references resolve to reviewed originals, without altering picks.
export function reviewedAnimeImage(entry:{name:string;subtitle:string;image:string|null}){
 if(!entry.image||!animeLogo(entry.image))return entry.image;
 const index=animeEntries.findIndex(([name,subtitle])=>name===entry.name&&subtitle===entry.subtitle);
 return index<0?null:animeImage(index);
}
