// The public Worker boundary runs before framework routing/deserialization.
// This application uses JSON routes, not React Server Actions.
type Limiter = { limit(options:{key:string}):Promise<{success:boolean}> };
export type SecurityEnv = {
 DISCORD_APPLICATION_ID?:string;
 SECURITY_READ_LIMIT?:Limiter; SECURITY_WRITE_LIMIT?:Limiter;
 SECURITY_AUTH_LIMIT?:Limiter; SECURITY_CREATE_LIMIT?:Limiter; SECURITY_UPLOAD_LIMIT?:Limiter;
};
const mutationRoutes:[RegExp,string[]][]=[
 [/^\/api\/discord\/(auth|media|exports|tournaments|tournaments\/[a-f0-9-]{36}\/(vote|advance))$/, ['POST']],
 [/^\/api\/(brackets|seasons)\/?$/,['POST']],
 [/^\/api\/brackets\/[^/]+\/?$/,['PUT']],
 [/^\/api\/brackets\/[^/]+\/(manage|advance|vote)\/?$/,['POST']],
 [/^\/api\/brackets\/[^/]+\/(appearance|schedule)\/?$/,['PUT']],
 [/^\/api\/seasons\/[^/]+\/?$/,['PUT']],
 [/^\/api\/seasons\/[^/]+\/manage\/?$/,['POST']],
 [/^\/api\/seasons\/[^/]+\/events\/[^/]+\/?$/,['PUT','DELETE']],
 [/^\/api\/(media|analytics\/events)\/?$/,['POST']],
 [/^\/api\/admin\/session\/?$/,['POST','DELETE']],
 [/^\/api\/admin\/featured\/?$/,['PUT']],
 [/^\/api\/account\/?$/,['PATCH']],
 [/^\/api\/auth\/(email|email\/verify|logout)\/?$/,['POST']],
];
// Local OCR compiles WebAssembly. JavaScript string evaluation and remote
// workers remain blocked; PDF and OCR assets are served from this origin.
export function contentPolicy(nonce:string){return `default-src 'self'; script-src 'self' 'nonce-${nonce}' 'wasm-unsafe-eval'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'`;}
export function securityHeaders(response:Response,request:Request,policy:string){
 const headers=new Headers(response.headers);
 headers.set('X-Content-Type-Options','nosniff');headers.set('X-Frame-Options','DENY');
 headers.set('Referrer-Policy','strict-origin-when-cross-origin');
 headers.set('Permissions-Policy','camera=(), microphone=(), geolocation=(), payment=(), usb=()');
 if(new URL(request.url).protocol==='https:')headers.set('Strict-Transport-Security','max-age=31536000');
 // Media may install a stricter sandbox policy of its own.
 if(!headers.has('Content-Security-Policy'))headers.set('Content-Security-Policy',policy);
 if((headers.get('Content-Type')??'').includes('text/html'))headers.set('Cache-Control','private, no-store');
 const activityURL=new URL(request.url);
 if(activityURL.pathname==='/discord'||activityURL.pathname==='/discord/'||(activityURL.pathname==='/'&&activityURL.searchParams.has('frame_id'))){
  headers.delete('X-Frame-Options');
  headers.set('Content-Security-Policy',policy.replace("frame-ancestors 'none'",'frame-ancestors https://discord.com https://*.discord.com https://discordapp.com https://*.discordapp.com https://*.discordsays.com'));
 }
 headers.delete('X-Powered-By');
 return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
}
function failure(status:number,message:string){return new Response(JSON.stringify({error:message}),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store',...(status===429?{'Retry-After':'60'}:{})}});}
function trustedHeaders(request:Request,policy:string){
 const headers=new Headers(request.headers);
 for(const name of Array.from(headers.keys())){
  if(/^(oai-authenticated-|x-vinext-|x-middleware-|x-prerender-revalidate)/i.test(name)||['x-matched-path','x-now-route-matches','x-nextjs-matched-path','x-nonce','content-security-policy','content-security-policy-report-only'].includes(name.toLowerCase()))headers.delete(name);
 }
 headers.set('Content-Security-Policy',policy);
 return headers;
}
export async function secureRequest(request:Request,env:SecurityEnv,next:(request:Request)=>Promise<Response>|Response){
 const nonce=btoa(String.fromCharCode(...crypto.getRandomValues(new Uint8Array(24)))),policy=contentPolicy(nonce);
 const finish=(response:Response)=>securityHeaders(response,request,policy);
 const url=new URL(request.url),path=url.pathname,mutating=!['GET','HEAD'].includes(request.method);
 if(request.url.length>8192)return finish(failure(414,'The request address is too long.'));
 // Do not let URL normalization turn an unapproved route into an action endpoint.
 if(/%2f|%5c|%00|\\/i.test(path))return finish(failure(400,'Invalid request path.'));
 if(['next-action','rsc-action','x-rsc-action'].some(name=>request.headers.has(name)))return finish(failure(400,'Server actions are not supported.'));
 if(mutating){
  const route=mutationRoutes.find(([pattern])=>pattern.test(path));
  if(!route||!route[1].includes(request.method))return finish(failure(405,'This request method is not supported.'));
  const discordOrigin=env.DISCORD_APPLICATION_ID&&/^\d{15,22}$/.test(env.DISCORD_APPLICATION_ID)?`https://${env.DISCORD_APPLICATION_ID}.discordsays.com`:null;
  const discordProxy=path.startsWith('/api/discord/')&&discordOrigin!==null&&request.headers.get('origin')===discordOrigin;
  if(!discordProxy&&(request.headers.get('origin')!==url.origin||['cross-site','same-site'].includes(request.headers.get('sec-fetch-site')??'')))return finish(failure(403,'This action must come from this site.'));
  const upload=/^\/api\/(media|discord\/(media|exports))\/?$/.test(path),maximum=upload?5*1024*1024:150000;
  const length=request.headers.get('content-length');
  if(length&&(!/^\d+$/.test(length)||Number(length)>maximum))return finish(failure(413,'The uploaded file or request is too large.'));
  // Raw raster bytes only: multipart can invoke the framework's progressive
  // action decoder before API route dispatch even without an action header.
  if(upload&&!['image/png','image/jpeg','image/webp','image/gif','application/octet-stream'].includes((request.headers.get('content-type')??'').split(';')[0].trim().toLowerCase()))return finish(failure(415,'Upload a PNG, JPEG, GIF, or WebP image.'));
  if(request.body&&!upload&&(request.headers.get('content-type')??'').split(';')[0].trim().toLowerCase()!=='application/json')return finish(failure(415,'Send this action as JSON.'));
 }
 // CF-Connecting-IP is supplied by Cloudflare, not X-Forwarded-For or cookies.
 // Broad network caps also cover attackers who repeatedly clear their cookies.
 // Anonymous identities are not proof of one human; distributed abuse still
 // needs verified accounts / a challenge when operating higher-stakes contests.
 const ip=request.headers.get('cf-connecting-ip')??'local',key=`bracketlive:${ip}`;
 const limits:[Exclude<keyof SecurityEnv,'DISCORD_APPLICATION_ID'>,string][]=[['SECURITY_READ_LIMIT',key]];
 if(/^\/api\/auth\//.test(path)||path==='/api/discord/auth')limits.push(['SECURITY_AUTH_LIMIT',key]);
 if(mutating){
  limits.push(['SECURITY_WRITE_LIMIT',key]);
  if(/\/manage\/?$|^\/api\/admin\/session\/?$/.test(path))limits.push(['SECURITY_AUTH_LIMIT',key]);
  if(/^\/api\/(brackets|seasons)\/?$/.test(path)||path==='/api/discord/tournaments')limits.push(['SECURITY_CREATE_LIMIT',key]);
  if(/^\/api\/(media|discord\/(media|exports))\/?$/.test(path))limits.push(['SECURITY_UPLOAD_LIMIT',key]);
 }
 try{
  for(const [name,rateKey] of limits){
   const limiter=env[name];
   if(!limiter)return finish(failure(503,'Security configuration is incomplete. The site owner must run the update setup.'));
   if(!(await limiter.limit({key:rateKey})).success)return finish(failure(429,'Too many requests. Wait a minute and try again.'));
  }
  return finish(await next(new Request(request,{headers:trustedHeaders(request,policy)})));
 }catch(error){
  console.error('Worker request failed',error instanceof Error?error.message:'Unknown error');
  return finish(failure(503,'The service is temporarily unavailable. Please try again.'));
 }
}
