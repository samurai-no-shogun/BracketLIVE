import {isSuppliedAnimeArtwork} from './anime-artwork';
import type {Bracket,Entry,Match} from './bracket';
import {roundName} from './bracket';
import {resolvedColors} from './appearance';
import {animeLogo,animeSource,animeSourceSize} from './anime-roster';
import {escapeSvg} from './bracket-export';
import type {ExportArtwork} from './bracket-export';
import {validateImage} from './image-validation';

export type MatchupExportFormat='landscape'|'portrait'|'square';
export type MatchupExportOptions={format:MatchupExportFormat;transparent?:boolean;showResults?:boolean};
export type MatchupSide={id:string|null;name:string;subtitle:string;image:string|null};
export type MatchupOverrides={title?:string;label?:string;a?:Partial<Omit<MatchupSide,'id'>>;b?:Partial<Omit<MatchupSide,'id'>>;accent?:string;background?:string|null;logo?:string|null;backgroundColor?:string;cardColor?:string;textColor?:string;mutedColor?:string};
/** Deliberately excludes identities, organizer keys, cookies and unrevealed counts. */
export type MatchupSnapshot={schema:'bracketlive.matchup.v1';matchId:string;kind:'results'|'picks';title:string;label:string;a:MatchupSide;b:MatchupSide;winnerId:string|null;results:{a:number;b:number;total:number}|null;accent:string;background:string|null;logo:string|null;backgroundColor:string;cardColor:string;textColor:string;mutedColor:string};
export const matchupSizes:Record<MatchupExportFormat,{width:number;height:number}>={landscape:{width:1920,height:1080},portrait:{width:1080,height:1920},square:{width:1080,height:1080}};
const color=(value:unknown,fallback:string)=>typeof value==='string'&&/^#[\da-f]{6}$/i.test(value)?value:fallback;
const count=(value:unknown)=>typeof value==='number'&&Number.isSafeInteger(value)&&value>=0?value:null;
const cleanText=(value:unknown,fallback='')=>typeof value==='string'?value.slice(0,2000):fallback;
const localArtwork=new Map<string,{data:string;width:number;height:number}>();

/** Local-only image-copy edits never upload a file or change an official contender. */
export async function prepareLocalMatchupImage(file:Blob):Promise<string>{
 if(file.size>5*1024*1024)throw new Error('Use an image smaller than 5 MB.');
 const bytes=new Uint8Array(await file.arrayBuffer()),validated=validateImage(bytes);
 const blob=new Blob([bytes],{type:validated.type});
 const data=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Image could not be read.'));reader.readAsDataURL(blob);});
 const image=new Image();
 await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(new Error('Image could not be decoded.'));image.src=data;});
 if(!image.naturalWidth||!image.naturalHeight||Math.max(image.naturalWidth,image.naturalHeight)>8192||image.naturalWidth*image.naturalHeight>25000000)throw new Error('Use an image no larger than 8,192 pixels per side and 25 megapixels.');
 const source=URL.createObjectURL(blob);localArtwork.set(source,{data,width:image.naturalWidth,height:image.naturalHeight});return source;
}
export function releaseLocalMatchupImage(source:string){if(localArtwork.delete(source))URL.revokeObjectURL(source);}

export function matchupSnapshot(bracket:Bracket,match:Match,overrides:MatchupOverrides={},kind:'results'|'picks'='results'):MatchupSnapshot{
 const colors=resolvedColors(bracket);
 const side=(id:string|null,index:number,override?:MatchupOverrides['a']):MatchupSide=>{
  const entry:Entry|undefined=bracket.entries.find(e=>e.id===id);
  return {id:entry?.id??null,name:cleanText(override?.name,entry?.name||(!match.round?`Contender ${index?'B':'A'}`:`Winner of match ${match.position*2+index+1}`)),subtitle:cleanText(override?.subtitle,entry?.subtitle||''),image:override?.image===undefined?entry?.image??null:override.image};
 };
 const a=side(match.a_id,0,overrides.a),b=side(match.b_id,1,overrides.b);
 const votesA=count(match.counts?.[a.id||'']??0),votesB=count(match.counts?.[b.id||'']??0);
 const visible=kind==='results'&&match.counts!==null&&match.total!==null&&a.id&&b.id&&votesA!==null&&votesB!==null;
 return {schema:'bracketlive.matchup.v1',matchId:match.id,kind,title:cleanText(overrides.title,bracket.title||'Tournament'),label:cleanText(overrides.label,`${roundName(match.round,bracket.size,bracket.format)} · Match ${match.position+1}`),a,b,winnerId:match.winner_id===a.id||match.winner_id===b.id?match.winner_id:null,results:visible?{a:votesA,b:votesB,total:votesA+votesB}:null,accent:color(overrides.accent,colors.button),background:overrides.background===undefined?bracket.appearance?.images?.board_background??null:overrides.background,logo:overrides.logo===undefined?bracket.brand_image:overrides.logo,backgroundColor:color(overrides.backgroundColor,color(colors.page,'#f2eefb')),cardColor:color(overrides.cardColor,color(colors.card,'#ffffff')),textColor:color(overrides.textColor,color(colors.heading,'#211c30')),mutedColor:color(overrides.mutedColor,color(colors.muted,'#6c677c'))};
}

/** Only app uploads and the bundled sprite may enter this export's fetch path. */
export function matchupArtworkSource(source:string):string|null{
 if(localArtwork.has(source)||isSuppliedAnimeArtwork(source))return source;
 if(animeLogo(source)||source===animeSource)return animeSource;
 return /^\/api\/media\/[a-f0-9-]{36}\.(png|jpg|webp|gif)$/.test(source)?source:null;
}
export function matchupArtworkSources(snapshot:MatchupSnapshot){
 return [...new Set([snapshot.a.image,snapshot.b.image,snapshot.background,snapshot.logo].filter((x):x is string=>!!x).map(matchupArtworkSource).filter((x):x is string=>!!x))];
}
export async function prepareMatchupArtwork(snapshot:MatchupSnapshot):Promise<ExportArtwork>{
 const images:ExportArtwork['images']={},dimensions:NonNullable<ExportArtwork['dimensions']>={},warnings:string[]=[];
 const requested=[snapshot.a.image,snapshot.b.image,snapshot.background,snapshot.logo].filter((x):x is string=>!!x);
 if(requested.some(source=>!matchupArtworkSource(source)))warnings.push('An unsupported image address was omitted. Choose a template image or upload an image.');
 await Promise.all(matchupArtworkSources(snapshot).map(async source=>{
  try{
   const local=localArtwork.get(source);
   if(local){images[source]=local.data;dimensions[source]={width:local.width,height:local.height};return;}
   const url=new URL(source,window.location.origin);
   const response=await fetch(url.href,{credentials:'same-origin',mode:'same-origin',redirect:'error',signal:AbortSignal.timeout(15000)});
   if(!response.ok)throw new Error('Image unavailable');
   const blob=await response.blob();
   if(blob.size>8*1024*1024||!/^image\/(png|jpeg|webp|gif)$/i.test(blob.type))throw new Error('Unsupported image');
   const data=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Image unavailable'));reader.readAsDataURL(blob);});
   const image=new Image();
   await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(new Error('Image unavailable'));image.src=data;});
   if(!image.naturalWidth||!image.naturalHeight||Math.max(image.naturalWidth,image.naturalHeight)>8192||image.naturalWidth*image.naturalHeight>25000000)throw new Error('Image too large');
   images[source]=data;dimensions[source]={width:image.naturalWidth,height:image.naturalHeight};
  }catch{warnings.push('An image could not be included. Its contender name is still shown.');}
 }));
 return {images,dimensions,warnings};
}

// Conservative text measurement also works without browser fonts or a canvas.
function textUnits(text:string){return Array.from(text).reduce((sum,char)=>sum+( /[\u2e80-\uffff\p{Extended_Pictographic}]/u.test(char)?1.08:/[MW@#%&]/.test(char)?.98:/[ilI.,:;'!|\s]/.test(char)?.34:.69),0);}
function fitLines(text:string,width:number,maxSize:number,minSize:number,maxLines=2){
 const chars=Array.from(text.trim());
 for(let size=maxSize;size>=minSize;size-=2){
  const lines:string[]=[];let line='';
  for(const char of chars){
   if(line&&textUnits(line+char)*size>width){
    const split=line.lastIndexOf(' ');
    if(split>line.length/3){lines.push(line.slice(0,split).trim());line=line.slice(split+1)+char;}
    else{lines.push(line.trim());line=char.trimStart();}
   }else line+=char;
  }
  if(line)lines.push(line.trim());
  if(lines.length<=maxLines)return {lines:lines.length?lines:[''],size};
 }
 const lines:string[]=[];let cursor=0;
 for(let i=0;i<maxLines;i++){
  let line='';const last=i===maxLines-1;
  while(cursor<chars.length&&textUnits(line+chars[cursor]+(last?'…':''))*minSize<=width)line+=chars[cursor++];
  lines.push(line.trim()+(last&&cursor<chars.length?'…':''));
 }
 return {lines,size:minSize};
}

/** Portable, self-contained artwork: no foreignObject, scripts, fonts or external URLs. */
export function renderMatchupSvg(snapshot:MatchupSnapshot,options:MatchupExportOptions,artwork:ExportArtwork={images:{},warnings:[]}):{svg:string;width:number;height:number}{
 const format=Object.hasOwn(matchupSizes,options.format)?options.format:'landscape',size=matchupSizes[format],{width,height}=size,portrait=format==='portrait',square=format==='square';
 const accent=color(snapshot.accent,'#8452d4'),bg=color(snapshot.backgroundColor,'#f2eefb'),card=color(snapshot.cardColor,'#ffffff'),ink=color(snapshot.textColor,'#211c30'),muted=color(snapshot.mutedColor,'#6c677c');
 const assets=new Map(Object.entries(artwork.images).filter(([source,data])=>matchupArtworkSource(source)===source&&/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=]+$/i.test(data)).map(([source,data],i)=>{
  const d=source===animeSource?animeSourceSize:artwork.dimensions?.[source];
  const valid=d&&Number.isFinite(d.width)&&Number.isFinite(d.height)&&d.width>0&&d.height>0&&d.width<=8192&&d.height<=8192;
  return [source,{id:`vs-image-${i}`,data,width:valid?d.width:100,height:valid?d.height:100}];
 }));
 const rect=(x:number,y:number,w:number,h:number,fill:string,attrs='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" ${attrs}/>`;
 const text=(x:number,y:number,value:string,fontSize:number,fill:string,attrs='')=>`<text x="${x}" y="${y}" font-size="${fontSize}" fill="${fill}" ${attrs}>${escapeSvg(value)}</text>`;
 const centerText=(x:number,y:number,value:string,fontSize:number,fill:string,attrs='')=>text(x,y,value,fontSize,fill,`text-anchor="middle" ${attrs}`);
 const fit=(x:number,y:number,value:string,w:number,maxSize:number,minSize:number,maxLines=2,fill=ink,weight=700)=>{
  const fitted=fitLines(value,w,maxSize,minSize,maxLines);
  return fitted.lines.map((line,i)=>centerText(x,y+i*fitted.size*1.18,line,fitted.size,fill,`font-weight="${weight}"`)).join('');
 };
 let clipIndex=0;
 function art(source:string|null,x:number,y:number,w:number,h:number,label:string,cover=false){
  if(!source)return '';
  const normalized=matchupArtworkSource(source),asset=normalized?assets.get(normalized):undefined;
  if(!asset)return '';
  const crop=animeLogo(source);
  if(crop){
   const clip=`vs-crop-${++clipIndex}`;
   return `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${crop.x} ${crop.y} ${crop.width} ${crop.height}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${escapeSvg(label)}"><defs><clipPath id="${clip}" clipPathUnits="userSpaceOnUse">${rect(crop.x,crop.y,crop.width,crop.height,'#fff')}</clipPath></defs><g clip-path="url(#${clip})"><use href="#${asset.id}"/></g></svg>`;
  }
  return `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="0 0 ${asset.width} ${asset.height}" preserveAspectRatio="xMidYMid ${cover?'slice':'meet'}" overflow="hidden" role="img" aria-label="${escapeSvg(label)}"><use href="#${asset.id}"/></svg>`;
 }
 const headerY=portrait?150:square?100:124,logoWidth=snapshot.logo?100:0;
 const lines=[`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="vs-title vs-description" style="font-family:Arial,Helvetica,sans-serif">`,
  `<title id="vs-title">${escapeSvg(`${snapshot.a.name} vs ${snapshot.b.name}`)}</title><desc id="vs-description">${escapeSvg(`${snapshot.title}. ${snapshot.label}. ${snapshot.a.name}${snapshot.a.subtitle?' — '+snapshot.a.subtitle:''} versus ${snapshot.b.name}${snapshot.b.subtitle?' — '+snapshot.b.subtitle:''}. ${snapshot.kind==='picks'?'Personal picks.':''}`)}</desc>`,
  `<defs><linearGradient id="vs-tint" x1="0" x2="1" y1="0" y2="1"><stop stop-color="${accent}" stop-opacity=".18"/><stop offset="1" stop-color="${bg}" stop-opacity=".08"/></linearGradient><linearGradient id="vs-glass" x1="0" x2=".7" y1="0" y2="1"><stop stop-color="${card}" stop-opacity=".97"/><stop offset="1" stop-color="${card}" stop-opacity=".77"/></linearGradient><linearGradient id="vs-accent" x1="0" x2="1" y1="0" y2="1"><stop stop-color="${accent}"/><stop offset="1" stop-color="${ink}"/></linearGradient><filter id="vs-shadow" x="-30%" y="-30%" width="160%" height="175%"><feDropShadow dx="0" dy="16" stdDeviation="25" flood-color="${accent}" flood-opacity=".12"/></filter>${[...assets.values()].map(asset=>`<image id="${asset.id}" href="${asset.data}" width="${asset.width}" height="${asset.height}"/>`).join('')}</defs>`];
 if(!options.transparent){
  lines.push(rect(0,0,width,height,bg),`<circle cx="${width*.1}" cy="${height*.2}" r="${width*.45}" fill="${accent}" opacity=".07"/><circle cx="${width*.9}" cy="${height*.83}" r="${width*.52}" fill="${accent}" opacity=".065"/>`);
  if(snapshot.background)lines.push(`<g opacity=".35">${art(snapshot.background,0,0,width,height,'Background',true)}</g>`);
  lines.push(rect(0,0,width,height,'url(#vs-tint)'));
 }
 if(snapshot.logo)lines.push(art(snapshot.logo,width/2-50,headerY-96,100,64,'Tournament logo'));
 lines.push(fit(width/2,headerY+(logoWidth?22:0),snapshot.title,width-(square?130:200),portrait?42:square?34:46,26,2),fit(width/2,headerY+(logoWidth?22:0)+(portrait?112:square?88:108),snapshot.label,width-200,portrait?24:square?20:24,18,1,muted,500));
 const cardW=portrait?860:square?420:760,cardH=portrait?510:square?578:584;
 const positions=portrait?[{x:110,y:394},{x:110,y:1084}]:square?[{x:72,y:322},{x:588,y:322}]:[{x:108,y:310},{x:1052,y:310}];
 const showResults=!!options.showResults&&snapshot.kind==='results'&&snapshot.results!==null;
 const results=snapshot.results;
 [snapshot.a,snapshot.b].forEach((side,index)=>{
  const {x,y}=positions[index],cx=x+cardW/2,available=side.image&&matchupArtworkSource(side.image),hasImage=!!available&&assets.has(available);
  const nameWidth=cardW-(square?54:88),imageW=cardW-(square?92:160),imageH=portrait?170:square?164:218,imageY=y+(portrait?65:square?84:76);
  lines.push(`<g data-side="${index?'b':'a'}"><title>${escapeSvg([side.name,side.subtitle].filter(Boolean).join(' — '))}</title>`,rect(x,y,cardW,cardH,'url(#vs-glass)',`rx="38" stroke="${card}" stroke-opacity=".95" stroke-width="2" filter="url(#vs-shadow)"`),rect(x+1,y+1,cardW-2,cardH-2,'url(#vs-tint)','rx="37" opacity=".34"'),rect(cx-27,y+27,54,4,accent,'rx="2" opacity=".4"'));
  if(hasImage)lines.push(art(side.image,x+(cardW-imageW)/2,imageY,imageW,imageH,side.name));
  else{
   const initials=Array.from(side.name.trim().split(/\s+/).slice(0,2).map(word=>Array.from(word)[0]||'').join('')).slice(0,2).join('').toUpperCase()||'?';
   lines.push(`<circle cx="${cx}" cy="${imageY+imageH/2}" r="${square?64:85}" fill="${accent}" opacity=".08"/>`,centerText(cx,imageY+imageH/2+(square?23:31),initials,square?62:82,accent,'font-weight="700"'));
  }
  const nameY=y+(portrait?304:square?318:371),nameSize=portrait?48:square?37:48;
  lines.push(fit(cx,nameY,side.name,nameWidth,nameSize,square?24:28));
  if(side.subtitle)lines.push(fit(cx,nameY+(portrait?100:square?104:112),side.subtitle,nameWidth,square?20:24,18,1,muted,500));
  if(showResults&&results){
   const votes=index?results.b:results.a,pct=results.total?Math.round(votes/results.total*100):0;
   lines.push(rect(x+34,y+cardH-49,cardW-68,5,accent,'rx="2.5" opacity=".12"'),rect(x+34,y+cardH-49,(cardW-68)*pct/100,5,accent,'rx="2.5"'),centerText(cx,y+cardH-68,`${pct}% · ${votes.toLocaleString('en-US')} ${votes===1?'vote':'votes'}`,square?18:21,ink,'font-weight="700"'));
  }
  lines.push('</g>');
 });
 const vsX=width/2,vsY=portrait?994:square?610:602,vsRadius=portrait?64:square?42:62;
 lines.push(`<circle cx="${vsX}" cy="${vsY}" r="${vsRadius+9}" fill="${card}" opacity=".72"/><circle cx="${vsX}" cy="${vsY}" r="${vsRadius}" fill="url(#vs-accent)"/>`,centerText(vsX,vsY+(square?12:17),'VS',square?32:45,'#ffffff','font-weight="800" letter-spacing="-2"'));
 // Footers describe only the supplied snapshot. There is no claim of a live feed.
 const footer=snapshot.kind==='picks'?'PERSONAL PICKS':showResults?'VOTE RESULTS':'THE MATCHUP';
 lines.push(centerText(width/2,height-(portrait?126:95),footer,portrait?19:17,muted,'font-weight="700" letter-spacing="4"'),'</svg>');
 return {svg:lines.join(''),width,height};
}

export async function matchupPngBlob({svg,width,height}:{svg:string;width:number;height:number}):Promise<Blob>{
 if(!Object.values(matchupSizes).some(size=>size.width===width&&size.height===height))throw new Error('Unsupported export size.');
 const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
 try{
  const image=new Image();
  await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(new Error('Image rendering failed. Try SVG instead.'));image.src=url;});
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
  const ctx=canvas.getContext('2d');if(!ctx)throw new Error('This browser could not create the image. Try SVG instead.');
  ctx.drawImage(image,0,0,width,height);
  return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('PNG export failed. Try SVG instead.')),'image/png'));
 }finally{URL.revokeObjectURL(url);}
}
export function matchupFilename(snapshot:MatchupSnapshot,options:MatchupExportOptions,extension:'png'|'svg'){
 const clean=(text:string)=>text.normalize('NFKD').replace(/[^\p{L}\p{N}\s_-]/gu,'').trim().replace(/\s+/g,'-').slice(0,40)||'contender';
 return `${clean(snapshot.a.name)}-vs-${clean(snapshot.b.name)}-${options.format}${options.transparent?'-transparent':''}.${extension}`;
}
export async function downloadMatchupImage(snapshot:MatchupSnapshot,options:MatchupExportOptions,extension:'png'|'svg'='png'){
 const artwork=await prepareMatchupArtwork(snapshot),rendered=renderMatchupSvg(snapshot,options,artwork);
 const blob=extension==='png'?await matchupPngBlob(rendered):new Blob([rendered.svg],{type:'image/svg+xml;charset=utf-8'});
 const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=matchupFilename(snapshot,options,extension);document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
 return {warnings:artwork.warnings,blob,filename:matchupFilename(snapshot,options,extension)};
}
