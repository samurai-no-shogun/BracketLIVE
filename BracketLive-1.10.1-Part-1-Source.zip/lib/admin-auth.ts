import {env} from 'cloudflare:workers';
import {timingSafeEqual} from 'node:crypto';
import {headers} from 'next/headers';

const COOKIE='bl_admin';
const SESSION_SECONDS=8*60*60;
const encoder=new TextEncoder();
const hex=(bytes:ArrayBuffer|Uint8Array)=>Array.from(new Uint8Array(bytes),value=>value.toString(16).padStart(2,'0')).join('');
const unhex=(value:string)=>Uint8Array.from(value.match(/../g)??[],byte=>parseInt(byte,16));

function configuredKey(){
 const key=(env as Cloudflare.Env&{ADMIN_KEY?:string}).ADMIN_KEY;
 return typeof key==='string'&&key.length>=32&&key.length<=512?key:null;
}
export function adminConfigured(){return configuredKey()!==null;}
async function signingKey(secret:string){return crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
export async function verifyAdminKey(candidate:string){
 const secret=configuredKey();if(!secret||candidate.length>512)return false;
 const [actual,expected]=await Promise.all([candidate,secret].map(value=>crypto.subtle.digest('SHA-256',encoder.encode(value))));
 return timingSafeEqual(new Uint8Array(actual),new Uint8Array(expected));
}
export async function createAdminSession(){
 const secret=configuredKey();if(!secret)throw new Error('Owner access is not configured.');
 const expires=Math.floor(Date.now()/1000)+SESSION_SECONDS;
 const payload=`1.${expires}.${hex(crypto.getRandomValues(new Uint8Array(16)))}`;
 const signature=await crypto.subtle.sign('HMAC',await signingKey(secret),encoder.encode(payload));
 return `${payload}.${hex(signature)}`;
}
export async function isSiteAdmin(request?:Request){
 const secret=configuredKey();if(!secret)return false;
 const requestHeaders=request?.headers??await headers();
 const cookies=(requestHeaders.get('cookie')??'').split(';').map(value=>value.trim()).filter(value=>value.startsWith(`${COOKIE}=`));
 if(cookies.length!==1)return false;
 const value=cookies[0].slice(COOKIE.length+1);
 if(!/^1\.[0-9]{10}\.[a-f0-9]{32}\.[a-f0-9]{64}$/.test(value))return false;
 const [version,expiry,nonce,signature]=value.split('.'),expires=Number(expiry),now=Math.floor(Date.now()/1000);
 if(expires<=now||expires>now+SESSION_SECONDS)return false;
 return crypto.subtle.verify('HMAC',await signingKey(secret),unhex(signature),encoder.encode(`${version}.${expiry}.${nonce}`));
}
export function adminCookie(request:Request,session:string|null){
 return `${COOKIE}=${session??''}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${session?SESSION_SECONDS:0}${new URL(request.url).protocol==='https:'?'; Secure':''}`;
}
