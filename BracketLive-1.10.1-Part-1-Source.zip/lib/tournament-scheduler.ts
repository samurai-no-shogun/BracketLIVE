import {deadlineForRound,type Match} from './bracket';
import {readVotingSchedule,rollRemainingWeeklyDeadlines,type VotingSchedule} from './voting-schedule';
import {deliverCreatorAlerts} from './creator-alerts';
export const schedulerSqlNow="CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)";
type ScheduledBracket={id:string;title:string;size:number;status:string;current_round:number;started_at:number|null;ends_at:number|null;round_closes_at:number|null;voting_schedule:string|null;schedule_revision:number;is_test:number;schedule_blocked_reason:string|null};
const ca='(SELECT COUNT(*) FROM votes v WHERE v.match_id=m.id AND v.entry_id=m.a_id)',cb='(SELECT COUNT(*) FROM votes v WHERE v.match_id=m.id AND v.entry_id=m.b_id)';
const tied=(id:string,round:number)=>`EXISTS(SELECT 1 FROM matches m WHERE m.bracket_id=${id} AND m.round=${round} AND ${ca}=${cb})`;
const stamp=()=>Array.from(crypto.getRandomValues(new Uint8Array(24)),n=>n.toString(16).padStart(2,'0')).join('');
export function summarySql(kind:'round'|'blocked'){
 return `json_object('title',b.title,'size',b.size,'round',?,'kind','${kind}','complete',CASE WHEN b.status='complete' THEN json('true') ELSE json('false') END,'next_deadline',b.round_closes_at,'reason',b.schedule_blocked_reason,'timezone',COALESCE(json_extract(b.voting_schedule,'$.timezone'),'UTC'),'matches',json(COALESCE((SELECT json_group_array(json_object('id',m.id,'a',ea.name,'b',eb.name,'a_id',m.a_id,'b_id',m.b_id,'a_votes',${ca},'b_votes',${cb},'winner',ew.name,'winner_id',m.winner_id,'decided_by',m.decided_by)) FROM (SELECT * FROM matches WHERE bracket_id=b.id AND round=? ORDER BY position) m LEFT JOIN entries ea ON ea.id=m.a_id LEFT JOIN entries eb ON eb.id=m.b_id LEFT JOIN entries ew ON ew.id=m.winner_id),'[]')))`;
}
function queueStatement(database:D1Database,resultId:string){
 return database.prepare(`INSERT OR IGNORE INTO creator_alert_outbox(id,bracket_id,account_id,created_at) SELECT r.id,r.bracket_id,a.account_id,${schedulerSqlNow} FROM tournament_round_results r JOIN creator_alert_settings a ON a.bracket_id=r.bracket_id JOIN accounts ac ON ac.id=a.account_id JOIN brackets b ON b.id=r.bracket_id WHERE r.id=? AND a.enabled=1 AND b.is_test=0 AND b.owner_id=ac.identity_id AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=b.id AND identity_id=ac.identity_id) AND EXISTS(SELECT 1 FROM account_credentials WHERE account_id=ac.id)`).bind(resultId);
}
export async function advanceTournamentRound(database:D1Database,id:string,round:number,ties:Record<string,string>={},automatic=false,organizerId?:string):Promise<{advanced:boolean;blocked:boolean}>{
 if(!automatic&&!organizerId)return {advanced:false,blocked:false};
 const b=await database.prepare(`SELECT * FROM brackets WHERE id=?`).bind(id).first<ScheduledBracket>();
 if(!b||b.status!=='live'||b.current_round!==round)return {advanced:false,blocked:false};
 let schedule=readVotingSchedule(b.voting_schedule,b.size);
 if(b.voting_schedule!==null&&!schedule&&automatic){await database.prepare(`UPDATE brackets SET schedule_blocked_reason='The saved voting schedule needs correction. Close this round, then set a new schedule.',schedule_checked_at=${schedulerSqlNow} WHERE id=? AND schedule_revision=? AND round_closes_at IS ?`).bind(id,b.schedule_revision,b.round_closes_at).run();return {advanced:false,blocked:true};}
 if(b.voting_schedule!==null&&!schedule&&!automatic)schedule={mode:'manual',timezone:'UTC',tie_policy:'pause',deadlines:Array(Math.log2(b.size)).fill(null)};
 const ms=(await database.prepare('SELECT * FROM matches WHERE bracket_id=? AND round=? ORDER BY position').bind(id,round).all<Match>()).results;
 for(const [mid,eid] of Object.entries(ties)){const m=ms.find(m=>m.id===mid);if(!m||![m.a_id,m.b_id].includes(eid))throw new Error('Choose one of the contenders for each tie.');}
 const mark=stamp(),final=round===Math.log2(b.size)-1,seed=automatic&&(!schedule||schedule.tie_policy==='seed');
 const keys=Object.keys(ties),tieClause=keys.length?`AND m.id NOT IN (${keys.map(()=>'?').join(',')})`:'';
 const requireNoTies=!seed;
 const timeGate=automatic?`AND round_closes_at IS NOT NULL AND round_closes_at<=${schedulerSqlNow}`:(!schedule?`AND (round_closes_at IS NULL OR round_closes_at>${schedulerSqlNow})`:'');
 const ownerGate=automatic?'':`AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)`;
 const noTieGate=requireNoTies?`AND NOT EXISTS(SELECT 1 FROM matches m WHERE m.bracket_id=? AND m.round=? AND ${ca}=${cb} ${tieClause})`:'';
 let rolled=schedule,ambiguousNext=false;try{if(schedule?.mode==='weekly'&&!final)rolled=rollRemainingWeeklyDeadlines(schedule,round+1,Date.now());}catch{if(!automatic){ambiguousNext=true;}else{await database.prepare(`UPDATE brackets SET schedule_blocked_reason='The next weekly closing time is ambiguous. Close this round, then set a new schedule.',schedule_checked_at=${schedulerSqlNow} WHERE id=? AND status='live' AND current_round=? AND schedule_revision=? AND round_closes_at IS ?`).bind(id,round,b.schedule_revision,b.round_closes_at).run();return {advanced:false,blocked:true};}}
 let nextDeadline=final?null:rolled?rolled.deadlines[round+1]:b.started_at!==null&&b.ends_at!==null?deadlineForRound(b.started_at,b.ends_at,b.size,round+1):null;
 const missedDate=ambiguousNext||!final&&!!rolled&&rolled.mode!=='manual'&&rolled.mode!=='weekly'&&nextDeadline!==null&&nextDeadline<=Date.now();if(missedDate)nextDeadline=null;
 const bindings:(string|number|null)[]=[final?round:round+1,final?'complete':'live',mark,nextDeadline,rolled?JSON.stringify(rolled):null,rolled&&rolled.mode!=='manual'?rolled.deadlines.at(-1)??null:b.ends_at,missedDate?'Set a new closing date for this round.':null,id,round,b.schedule_revision,b.round_closes_at];
 if(!automatic)bindings.push(id,organizerId!);if(requireNoTies)bindings.push(id,round,...keys);
 const futureGate=rolled&&rolled.mode!=='manual'&&!final&&!missedDate?`AND ?>${schedulerSqlNow}`:'';if(futureGate)bindings.push(nextDeadline);
 const gate=`WHERE id=? AND status='live' AND current_round=? AND schedule_revision=? AND round_closes_at IS ? ${timeGate} ${ownerGate} ${noTieGate} ${futureGate}`;
 const statements=[database.prepare(`UPDATE brackets SET current_round=?,status=?,advance_token=?,round_closes_at=?,voting_schedule=?,ends_at=?,schedule_blocked_reason=?,schedule_checked_at=${schedulerSqlNow} ${gate}`).bind(...bindings)];
 const seeded="CASE WHEN (SELECT seed FROM entries WHERE id=m.a_id)<=(SELECT seed FROM entries WHERE id=m.b_id) THEN a_id ELSE b_id END";
 for(const m of ms){
  const winnerBindings:(string|number|null)[]=seed?[]:[ties[m.id]??m.a_id];winnerBindings.push(seed?'seed':'organizer',m.id,id,mark);
  statements.push(database.prepare(`UPDATE matches AS m SET winner_id=CASE WHEN ${ca}>${cb} THEN a_id WHEN ${cb}>${ca} THEN b_id ELSE ${seed?seeded:'?'} END,status='closed',decided_by=CASE WHEN ${ca}<>${cb} THEN 'votes' ELSE ? END WHERE id=? AND EXISTS(SELECT 1 FROM brackets WHERE id=? AND advance_token=?)`).bind(...winnerBindings));
 }
 if(!final)for(let p=0;p<ms.length/2;p++)statements.push(database.prepare("UPDATE matches SET a_id=(SELECT winner_id FROM matches WHERE id=?),b_id=(SELECT winner_id FROM matches WHERE id=?),status=? WHERE bracket_id=? AND round=? AND position=? AND EXISTS(SELECT 1 FROM brackets WHERE id=? AND advance_token=?)").bind(ms[p*2].id,ms[p*2+1].id,missedDate?'pending':'open',id,round+1,p,id,mark));
 const resultId=`${id}:${round}:round:${b.schedule_revision}`;
 statements.push(database.prepare(`INSERT OR IGNORE INTO tournament_round_results(id,bracket_id,round,kind,schedule_revision,summary,created_at) SELECT ?,b.id,?,'round',b.schedule_revision,${summarySql('round')},${schedulerSqlNow} FROM brackets b WHERE b.id=? AND b.advance_token=?`).bind(resultId,round,round,round,id,mark),queueStatement(database,resultId));
 const result=await database.batch(statements);if(result[0].meta.changes)return {advanced:true,blocked:false};
 // A tie pause freezes this round at its deadline. The SQL gate is evaluated in
 // the same transaction as its summary and notification, including late votes.
 if(automatic&&schedule?.tie_policy==='pause'){
  const blockedId=`${id}:${round}:blocked:${b.schedule_revision}`;
  const blockedGate=`b.id=? AND b.status='live' AND b.current_round=? AND b.schedule_revision=? AND b.round_closes_at IS ? AND b.round_closes_at<=${schedulerSqlNow} AND ${tied('b.id',round)}`;
  const blockedBindings=[id,round,b.schedule_revision,b.round_closes_at];
  const blocked=await database.batch([
   database.prepare(`UPDATE brackets AS b SET schedule_blocked_reason='Resolve tied matches to open the next round.',schedule_checked_at=${schedulerSqlNow} WHERE ${blockedGate}`).bind(...blockedBindings),
   database.prepare(`INSERT OR IGNORE INTO tournament_round_results(id,bracket_id,round,kind,schedule_revision,summary,created_at) SELECT ?,b.id,?,'blocked',b.schedule_revision,${summarySql('blocked')},${schedulerSqlNow} FROM brackets b WHERE ${blockedGate}`).bind(blockedId,round,round,round,...blockedBindings),queueStatement(database,blockedId)
  ]);return {advanced:false,blocked:!!blocked[0].meta.changes};
 }
 return {advanced:false,blocked:false};
}
export async function settleTournamentExpired(database:D1Database,id:string){
 // Only legacy evenly-divided overall deadlines catch up through elapsed rounds.
 // New schedules never fabricate votes for unopened elapsed weekly rounds.
 for(let i=0;i<7;i++){
  const b=await database.prepare(`SELECT current_round,voting_schedule FROM brackets WHERE id=? AND status='live' AND round_closes_at IS NOT NULL AND round_closes_at<=${schedulerSqlNow}`).bind(id).first<{current_round:number;voting_schedule:string|null}>();if(!b)return;
  const result=await advanceTournamentRound(database,id,b.current_round,{},true);if(!result.advanced||b.voting_schedule)return;
 }
}
export async function runTournamentScheduler(env:Cloudflare.Env,options:{limit?:number;fetch?:typeof fetch}={}){
 if(!env.DB)return {processed:0,advanced:0,blocked:0,notifications:0};
 const database=env.DB,limit=Math.max(1,Math.min(100,Math.floor(options.limit??40)));
 const due=(await database.prepare(`SELECT id,current_round FROM brackets WHERE status='live' AND round_closes_at IS NOT NULL AND round_closes_at<=${schedulerSqlNow} ORDER BY schedule_checked_at,round_closes_at,id LIMIT ?`).bind(limit).all<{id:string;current_round:number}>()).results;
 let advanced=0,blocked=0;for(const b of due){try{const result=await advanceTournamentRound(database,b.id,b.current_round,{},true);advanced+=Number(result.advanced);blocked+=Number(result.blocked);}catch{await database.prepare(`UPDATE brackets SET schedule_checked_at=${schedulerSqlNow} WHERE id=?`).bind(b.id).run();}}
 const notifications=await deliverCreatorAlerts(env,{limit:Math.min(20,limit),fetch:options.fetch});return {processed:due.length,advanced,blocked,notifications};
}
