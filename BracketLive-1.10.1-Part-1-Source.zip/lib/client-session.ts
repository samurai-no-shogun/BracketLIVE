let session:Promise<void>|null=null;
export function ensureSession(){return session??=(async()=>{try{const r=await fetch('/api/session');if(!r.ok)throw new Error('Could not start your session.');}catch(e){session=null;throw e;}})();}
