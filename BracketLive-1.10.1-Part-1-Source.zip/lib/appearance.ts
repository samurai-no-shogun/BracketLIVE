import type {CSSProperties} from 'react';

export const defaultColors = {
 page:'#f2eefb', header:'#ffffff', panel:'#ffffff', card:'#ffffff', input:'#ffffff', board:'#f1edfa', matchHeader:'#f0edf8', hover:'#f1edf9', selected:'#eee7fb',
 text:'#282536', heading:'#211c30', muted:'#6c677c', link:'#7250b4',
 border:'#e1deea', connector:'#b7aecb', activeBorder:'#8452d4',
 button:'#8452d4', buttonText:'#ffffff', secondaryButton:'#ffffff', secondaryButtonText:'#40394e',
 voteA:'#8452d4', voteB:'#e1d8ef', winner:'#9a6815', progress:'#8452d4', success:'#16866c', error:'#c63b57', shadow:'#514169',
};
export type ColorKey=keyof typeof defaultColors;
export const colorKeys=Object.keys(defaultColors) as [ColorKey,...ColorKey[]];
export const imageKeys=['page_background','board_background','center_logo','champion_logo','footer_logo'] as const;
export type ImageKey=typeof imageKeys[number];
export type ImageSlot=ImageKey|'brand';
export type Appearance={colors?:Partial<Record<ColorKey,string>>;images?:Partial<Record<ImageKey,string|null>>;page_fit?:'cover'|'contain'|'tile';board_fit?:'cover'|'contain'|'tile';page_opacity?:number;board_opacity?:number;glass_tint?:string;glass_opacity?:number;glass_blur?:number};
export type Branding={accent:string;brand_color:string|null;brand_image:string|null;appearance:Appearance};
export const colorGroups:{title:string;fields:[ColorKey,string][]}[]=[
 {title:'Surfaces',fields:[['page','Page background'],['header','Navigation bar'],['panel','Panels & dialogs'],['card','Match cards'],['input','Fields & contender slots'],['board','Bracket background'],['matchHeader','Match headers'],['hover','Hover background'],['selected','Selected background']]},
 {title:'Text',fields:[['text','Main text'],['heading','Headings'],['muted','Secondary text'],['link','Links & icons']]},
 {title:'Lines',fields:[['border','Borders'],['connector','Bracket connectors'],['activeBorder','Active & selected borders']]},
 {title:'Buttons',fields:[['button','Primary buttons'],['buttonText','Primary button text'],['secondaryButton','Secondary buttons'],['secondaryButtonText','Secondary button text']]},
 {title:'Results & status',fields:[['voteA','First contender vote bar'],['voteB','Second contender vote bar'],['winner','Winner & trophy'],['progress','Voting progress'],['success','Live indicator'],['error','Error messages'],['shadow','Shadows & dialog backdrop']]},
];
export function accentColor(b:Pick<Branding,'accent'|'brand_color'>){return b.brand_color||(b.accent==='mint'?'#16866c':b.accent==='red'?'#cb4565':'#8452d4');}
export function contrastText(color:string){const n=parseInt(color.slice(1),16);return .2126*(n>>16)+.7152*(n>>8&255)+.0722*(n&255)>145?'#100d16':'#ffffff';}
export function resolvedColors(b:Branding){const accent=accentColor(b);return {...defaultColors,button:accent,buttonText:contrastText(accent),voteA:accent,progress:accent,activeBorder:accent,link:accent,...b.appearance?.colors};}
export function glassSettings(b:Branding){return {tint:b.appearance?.glass_tint||accentColor(b),opacity:b.appearance?.glass_opacity??72,blur:b.appearance?.glass_blur??24};}
export function imageBackground(image:string|undefined|null,color:string,fit='cover',opacity=65):CSSProperties{
 if(!image)return {};
 return {backgroundImage:`linear-gradient(color-mix(in srgb, ${color} ${100-opacity}%, transparent), color-mix(in srgb, ${color} ${100-opacity}%, transparent)), url("${image}")`,backgroundSize:fit==='tile'?'auto':fit,backgroundRepeat:fit==='tile'?'repeat':'no-repeat',backgroundPosition:'center'};
}
export function appearanceStyle(b:Branding):CSSProperties{
 const c=resolvedColors(b),accent=accentColor(b),n=parseInt(accent.slice(1),16),a=b.appearance||{},glass=glassSettings(b);
 // Unedited designs follow the viewer's light/dark preference. Once a palette
 // is customized, preserve it as a whole so its text/background contrasts stay
 // together. Exporters continue to use resolvedColors(), never UI preferences.
 const followsTheme=Object.keys(a.colors||{}).length===0;
 const accentKeys=new Set(['button','buttonText','voteA','progress','activeBorder','link']);
 const ui=Object.fromEntries(Object.entries(c).map(([k,v])=>[k,followsTheme&&(!accentKeys.has(k)||(!b.brand_color&&b.accent==='purple'))?`var(--site-default-${k}, ${v})`:v])) as typeof c;
 return {...Object.fromEntries(Object.entries(ui).map(([k,v])=>[`--t-${k}`,v])),
 '--highlight':accent,'--highlight-rgb':`${n>>16},${n>>8&255},${n&255}`,
 '--glass-tint':glass.tint,'--glass-opacity':`${glass.opacity}%`,'--glass-blur':`${glass.blur}px`,
 '--background':ui.page,'--foreground':ui.text,'--card':ui.card,'--card-foreground':ui.text,'--popover':ui.panel,'--popover-foreground':ui.text,
 '--primary':ui.button,'--primary-foreground':ui.buttonText,'--button-text':ui.buttonText,'--secondary':ui.secondaryButton,'--secondary-foreground':ui.secondaryButtonText,
 '--muted':ui.matchHeader,'--muted-foreground':ui.muted,'--accent':ui.hover,'--accent-foreground':ui.text,'--border':ui.border,'--input':ui.border,'--ring':ui.activeBorder,'--destructive':ui.error,
 ...imageBackground(a.images?.page_background,'var(--t-page)',a.page_fit,a.page_opacity),backgroundAttachment:'fixed',
 } as CSSProperties;
}
