import {accountIdentity,currentAccount} from './account-auth';
import {advanceTournamentRound,settleTournamentExpired} from './tournament-scheduler';
import {creatorAlertProviderReady} from './creator-alerts';
import {readVotingSchedule,resolveSchedule,type ScheduleInput} from './voting-schedule';
import { env } from 'cloudflare:workers';
import { z } from 'zod';
import type { Bracket, Entry, Match } from './bracket';
import {animeLogo,reviewedAnimeImage} from './anime-roster';
import {isSuppliedAnimeArtwork} from './anime-artwork';
import { deadlineForRound } from './bracket';
import {colorKeys,imageKeys,type Appearance} from './appearance';
export function db(){const binding=(env as Cloudflare.Env).DB;if(!binding)throw new Error('Database unavailable');return binding;}
export function bucket(){const binding=(env as Cloudflare.Env).BUCKET;if(!binding)throw new Error('Image storage unavailable');return binding;}
export class ApiError extends Error{constructor(public status:number,message:string){super(message);}}
export function token(){return Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');}
export async function hash(s:string){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),n=>n.toString(16).padStart(2,'0')).join('');}
export async function anonymousIdentity(req:Request){
 const cookies=(req.headers.get('cookie')??'').split(';').map(part=>part.trim()).filter(part=>part.startsWith('bl_voter='));
 if(cookies.length>1)throw new ApiError(400,'Conflicting browser session cookies. Remove duplicate site cookies, then reopen your private organizer link if needed.');
 let value:string|undefined=cookies[0]?.slice('bl_voter='.length);if(!value||!/^[a-f0-9]{64}$/.test(value))value=undefined;
 const fresh=!value;value??=token();return {id:await hash(value),cookie:fresh?`bl_voter=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000${new URL(req.url).protocol==='https:'?'; Secure':''}`:null};
}
export async function identity(req:Request){
 const account=await accountIdentity(req);
 if(account)return {id:account,cookie:null};
 return anonymousIdentity(req);
}
export function json(data:unknown,status=200,cookie?:string|null){const headers=new Headers({'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});if(cookie)headers.set('Set-Cookie',cookie);return new Response(JSON.stringify(data),{status,headers});}
export async function boundary(fn:()=>Promise<Response>){try{return await fn();}catch(e){if(e instanceof ApiError)return json({error:e.message},e.status);if(e instanceof z.ZodError)return json({error:e.issues[0]?.message||'Check the submitted values.'},400);console.error('Bracket request failed',e);return json({error:'Something went wrong. Your input is still here—please try again.'},503);}}
export function originCheck(req:Request){const origin=req.headers.get('origin');if(origin&&origin!==new URL(req.url).origin)throw new ApiError(403,'This action must come from this site.');if(req.headers.get('sec-fetch-site')==='cross-site')throw new ApiError(403,'Cross-site request rejected.');}
export async function limitedBody(req:Request,max:number){const reader=req.body?.getReader();if(!reader)throw new ApiError(400,'Missing request body.');const chunks:Uint8Array[]=[];let length=0;for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>max){await reader.cancel();throw new ApiError(413,'The uploaded file or request is too large.');}chunks.push(value);}const bytes=new Uint8Array(length);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}return bytes;}
export async function body(req:Request){try{return JSON.parse(new TextDecoder().decode(await limitedBody(req,150000)));}catch(e){if(e instanceof ApiError)throw e;throw new ApiError(400,'Invalid request.');}}
export async function owns(bracketId:string,identityId:string){return !!await db().prepare('SELECT bracket_id FROM managers WHERE bracket_id=? AND identity_id=?').bind(bracketId,identityId).first();}
export async function requireOwner(bracketId:string,identityId:string){if(!await owns(bracketId,identityId))throw new ApiError(403,'Only the organizer can do that. Open your private organizer link or use the browser where you created this bracket.');}
export const sqlNow="CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)";
export async function advanceRound(id:string,round:number,ties:Record<string,string>={},automatic=false,organizerId?:string){
 if(!automatic&&!organizerId)throw new ApiError(403,'Organizer access is required.');
 try{return (await advanceTournamentRound(db(),id,round,ties,automatic,organizerId)).advanced;}catch(error){if(error instanceof Error&&error.message==='Choose one of the contenders for each tie.')throw new ApiError(400,error.message);throw error;}
}
export async function settleExpired(id:string){await settleTournamentExpired(db(),id);}
export async function snapshot(id:string,who:string):Promise<Bracket>{
 await settleExpired(id);
 const database=db();const result=await database.batch([
 database.prepare('SELECT id,title,description,size,format,accent,status,current_round,created_at,brand_color,brand_image,appearance,listed,is_test,started_at,ends_at,round_closes_at,voting_schedule,schedule_blocked_reason FROM brackets WHERE id=?').bind(id),
 database.prepare('SELECT id,name,subtitle,image,seed FROM entries WHERE bracket_id=? ORDER BY seed').bind(id),
 database.prepare('SELECT m.*,v.entry_id AS myVote FROM matches m LEFT JOIN votes v ON v.match_id=m.id AND v.voter_id=? WHERE m.bracket_id=? ORDER BY m.round,m.position').bind(who,id),
 database.prepare('SELECT v.match_id,v.entry_id,COUNT(*) AS n FROM votes v JOIN matches m ON m.id=v.match_id WHERE m.bracket_id=? GROUP BY v.match_id,v.entry_id').bind(id),
 database.prepare('SELECT bracket_id FROM managers WHERE bracket_id=? AND identity_id=?').bind(id,who),
 ]);
 const b=result[0].results[0] as unknown as Bracket;if(!b)throw new ApiError(404,'Bracket not found. Check the link.');const isOwner=result[4].results.length>0;if((b.status==='draft'||b.is_test)&&!isOwner)throw new ApiError(404,'This tournament is private.');
 const totals:Record<string,Record<string,number>>={};let totalVotes=0;for(const c of result[3].results as unknown as {match_id:string;entry_id:string;n:number}[]){(totals[c.match_id]??={})[c.entry_id]=Number(c.n);totalVotes+=Number(c.n);}
 const matches=(result[2].results as unknown as Match[]).map(m=>{const counts=totals[m.id]??{};const reveal=!!m.myVote||m.status==='closed'||(b.status==='live'&&m.round===b.current_round&&b.round_closes_at!==null&&b.round_closes_at<=Date.now())||(isOwner&&!b.is_test);return {id:m.id,round:m.round,position:m.position,a_id:m.a_id,b_id:m.b_id,winner_id:m.winner_id,status:m.status,decided_by:m.decided_by,myVote:m.myVote,counts:reveal?counts:null,total:reveal?Object.values(counts).reduce((a,b)=>a+b,0):null};});
 const votingSchedule=readVotingSchedule(b.voting_schedule,b.size);const blocked=b.status==='live'&&b.round_closes_at!==null&&b.round_closes_at<=Date.now()&&votingSchedule?.tie_policy==='pause'&&matches.some(m=>m.round===b.current_round&&((totals[m.id]?.[m.a_id??'']??0)===(totals[m.id]?.[m.b_id??'']??0)));
 return {...b,voting_schedule:votingSchedule,schedule_blocked:!!blocked||!!b.schedule_blocked_reason,appearance:readAppearance(b.appearance),listed:!!b.listed,is_test:!!b.is_test,isOwner,entries:(result[1].results as unknown as Entry[]).map(e=>({...e,image:reviewedAnimeImage(e)})),matches,totalVotes};
}
const ImageSchema=z.string().refine(value=>/^\/api\/media\/[a-f0-9-]{36}\.(png|jpg|webp|gif)$/.test(value)||isSuppliedAnimeArtwork(value)||!!animeLogo(value),'Choose a template image or upload an image.').nullable().default(null);
const ColorSchema=z.string().regex(/^#[a-fA-F0-9]{6}$/,'Use a six-digit hex color.');
const AppearanceSchema=z.object({
 colors:z.record(z.enum(colorKeys),ColorSchema).default({}),
 images:z.object({page_background:ImageSchema,board_background:ImageSchema,center_logo:ImageSchema,champion_logo:ImageSchema,footer_logo:ImageSchema}).default({}),
 page_fit:z.enum(['cover','contain','tile']).default('cover'),board_fit:z.enum(['cover','contain','tile']).default('cover'),
 page_opacity:z.number().min(0).max(100).default(65),board_opacity:z.number().min(0).max(100).default(65),
 glass_tint:ColorSchema.optional(),glass_opacity:z.number().min(50).max(95).optional(),glass_blur:z.number().min(0).max(32).optional(),
}).default({});
const brandingShape={accent:z.enum(['purple','mint','red']).default('purple'),brand_color:ColorSchema.nullable().default(null),brand_image:ImageSchema,appearance:AppearanceSchema};
export function readAppearance(value:unknown):Appearance{try{return AppearanceSchema.parse(typeof value==='string'?JSON.parse(value):value);}catch{return {};}}
async function validateImages(images:(string|null|undefined)[],who:string){
 const distinct=[...new Set(images.filter((image):image is string=>!!image&&!animeLogo(image)&&!isSuppliedAnimeArtwork(image)))];
 if(!distinct.length)return;
 const checks=distinct.map(image=>db().prepare("SELECT id FROM media WHERE id=? AND (owner_id=? OR EXISTS(SELECT 1 FROM brackets b JOIN managers mg ON mg.bracket_id=b.id WHERE mg.identity_id=? AND (b.brand_image=? OR EXISTS(SELECT 1 FROM entries e WHERE e.bracket_id=b.id AND e.image=?) OR EXISTS(SELECT 1 FROM json_each(b.appearance,'$.images') j WHERE j.value=?))))").bind(image.split('/').pop()!,who,who,image,image,image));
 const allowed=await db().batch(checks);
 if(allowed.some(result=>!result.results.length))throw new ApiError(400,'Upload that image again in this browser.');
}
export async function saveAppearance(req:Request,id:string){
 originCheck(req);const who=await identity(req);await requireOwner(id,who.id);
 const d=z.object(brandingShape).parse(await body(req));
 await validateImages([d.brand_image,...imageKeys.map(k=>d.appearance.images[k])],who.id);
 const saved=await db().prepare('UPDATE brackets SET accent=?,brand_color=?,brand_image=?,appearance=? WHERE id=? AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)').bind(d.accent,d.brand_color,d.brand_image,JSON.stringify(d.appearance),id,id,who.id).run();
 if(!saved.meta.changes)throw new ApiError(403,'Organizer access was removed. Reload this bracket.');
 return json(await snapshot(id,who.id),200,who.cookie);
}
export const ScheduleInputSchema=z.object({mode:z.enum(['manual','weekly','custom','finish']),timezone:z.string().min(1).max(80),tie_policy:z.enum(['pause','seed']).default('pause'),first_closes_at:z.number().int().positive().optional(),deadlines:z.array(z.number().int().positive().nullable()).max(7).optional(),ends_at:z.number().int().positive().optional()}).strict();
export const DraftSchema=z.object({
 title:z.string().trim().min(1,'Give your tournament a title.').max(100),description:z.string().trim().max(400).default(''),
 size:z.union([z.literal(2),z.literal(4),z.literal(8),z.literal(16),z.literal(32),z.literal(64),z.literal(128)]),format:z.enum(['standard','basketball','ncaa2026']).default('standard'),...brandingShape,listed:z.boolean().default(true),is_test:z.boolean().default(false),
 voting_schedule:ScheduleInputSchema.optional(),ends_at:z.number().int().positive().max(8640000000000000).nullable().default(null),publish:z.boolean().default(false),
 entries:z.array(z.object({name:z.string().trim().max(100),subtitle:z.string().trim().max(100).default(''),image:ImageSchema})).min(2).max(128)
}).refine(d=>d.entries.length===d.size,'The entry count must match the bracket size.').refine(d=>d.format==='standard'||d.size===64,'The four-region basketball format needs 64 teams.').refine(d=>!d.publish||d.entries.every(e=>e.name||e.image),'Fill every slot with text or an image before posting.');
export async function saveDraft(req:Request,id?:string){
 originCheck(req);const who=await identity(req);const d=DraftSchema.parse(await body(req));const database=db();if(id){await requireOwner(id,who.id);const previous=await database.prepare('SELECT status FROM brackets WHERE id=?').bind(id).first<{status:string}>();if(previous?.status!=='draft')throw new ApiError(409,'Posted entries cannot be changed. Create a new bracket for a different roster.');}
 const now=Date.now(),startedAt=d.publish?now:null;
 let schedule;try{schedule=d.is_test?null:d.voting_schedule?resolveSchedule(d.voting_schedule as ScheduleInput,d.size,0,now):null;}catch(e){throw new ApiError(400,e instanceof Error?e.message:'Check the voting schedule.');}
 const endsAt=d.is_test?null:schedule?(schedule.mode==='manual'?null:schedule.deadlines.at(-1)??null):d.ends_at;
 if(d.publish&&endsAt!==null&&endsAt<=now+1000)throw new ApiError(400,'Choose a closing date and time in the future.');
 const closesAt=startedAt!==null?(schedule?schedule.deadlines[0]:endsAt!==null?deadlineForRound(startedAt,endsAt,d.size,0):null):null;
 const bracketId=id??crypto.randomUUID();const manageToken=id?null:token();
 await validateImages([...d.entries.map(e=>e.image),d.brand_image,...imageKeys.map(k=>d.appearance.images[k])],who.id);
 const records=d.entries.map((e,i)=>({...e,id:crypto.randomUUID(),seed:i+1}));const statements:D1PreparedStatement[]=[];
 const fields=[d.title,d.description,d.size,d.format,d.accent,d.publish?'live':'draft',d.brand_color,d.brand_image,JSON.stringify(d.appearance),d.is_test?0:Number(d.listed),Number(d.is_test),startedAt,endsAt,closesAt,schedule?JSON.stringify(schedule):null];
 if(id){statements.push(database.prepare("DELETE FROM matches WHERE bracket_id=? AND EXISTS(SELECT 1 FROM brackets WHERE id=? AND status='draft') AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)").bind(id,id,id,who.id),database.prepare("DELETE FROM entries WHERE bracket_id=? AND EXISTS(SELECT 1 FROM brackets WHERE id=? AND status='draft') AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)").bind(id,id,id,who.id),database.prepare("UPDATE brackets SET title=?,description=?,size=?,format=?,accent=?,status=?,brand_color=?,brand_image=?,appearance=?,listed=?,is_test=?,started_at=?,ends_at=?,round_closes_at=?,voting_schedule=?,schedule_revision=schedule_revision+1 WHERE id=? AND status='draft' AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)").bind(...fields,id,id,who.id));}
 else {statements.push(database.prepare('INSERT INTO brackets(id,title,description,size,format,accent,status,brand_color,brand_image,appearance,listed,is_test,started_at,ends_at,round_closes_at,voting_schedule,owner_id,manage_hash,created_at) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM brackets WHERE owner_id=? AND created_at>?)<20').bind(bracketId,...fields,who.id,await hash(manageToken!),now,who.id,now-86400000),database.prepare('INSERT INTO managers(bracket_id,identity_id) SELECT ?,? WHERE EXISTS(SELECT 1 FROM brackets WHERE id=?)').bind(bracketId,who.id,bracketId));}
 // Every dependent insert is gated on the new bracket row, so a rejected quota
 // reservation leaves no partial roster or manager grant. D1 batches are atomic.
 records.forEach(e=>statements.push(database.prepare('INSERT INTO entries(id,bracket_id,name,subtitle,image,seed) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)').bind(e.id,bracketId,e.name,e.subtitle,e.image,e.seed,bracketId,who.id)));
 for(let r=0;r<Math.log2(d.size);r++)for(let p=0;p<d.size/2**(r+1);p++)statements.push(database.prepare('INSERT INTO matches(id,bracket_id,round,position,a_id,b_id,status) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)').bind(`${bracketId}-${r}-${p}`,bracketId,r,p,r===0?records[p*2].id:null,r===0?records[p*2+1].id:null,r===0&&d.publish?'open':'pending',bracketId,who.id));
 const saved=await database.batch(statements);if(id&&!saved[2].meta.changes){await requireOwner(id,who.id);throw new ApiError(409,'This bracket changed in another window. Reload before saving.');}if(!id&&!saved[0].meta.changes)throw new ApiError(429,'You have created 20 brackets today. Try again tomorrow.');
 return json({bracket:await snapshot(bracketId,who.id),manageToken},id?200:201,who.cookie);
}

export async function getVotingSchedule(req:Request,id:string){
 const who=await identity(req);await requireOwner(id,who.id);const account=await currentAccount(req);
 const b=await db().prepare('SELECT size,status,current_round,voting_schedule,owner_id FROM brackets WHERE id=?').bind(id).first<{size:number;status:string;current_round:number;voting_schedule:string|null;owner_id:string}>();if(!b)throw new ApiError(404,'Bracket not found.');
 const alerts=await db().prepare('SELECT s.enabled,s.account_id,a.email,(SELECT status FROM creator_alert_outbox WHERE bracket_id=s.bracket_id ORDER BY created_at DESC LIMIT 1) AS status FROM creator_alert_settings s JOIN accounts a ON a.id=s.account_id WHERE s.bracket_id=?').bind(id).first<{enabled:number;account_id:string;email:string;status:string|null}>();
 const canNotify=!!account&&account.identity_id===b.owner_id;
 return json({schedule:readVotingSchedule(b.voting_schedule,b.size),alerts:{enabled:!!alerts?.enabled,recipient:canNotify&&alerts?.account_id===account?.id?alerts?.email??account?.email:null,provider_ready:creatorAlertProviderReady(env as Cloudflare.Env),status:alerts?.status?({pending:'Email queued',sending:'Email sending',sent:'Last results email sent',failed:'Email delivery failed; check site email settings.',cancelled:'Email alert cancelled'} as Record<string,string>)[alerts.status]??'Email pending':undefined},can_notify:canNotify},200,who.cookie);
}
export async function saveVotingSchedule(req:Request,id:string){
 originCheck(req);const who=await identity(req);await requireOwner(id,who.id);const account=await currentAccount(req);
 const input=z.object({schedule:ScheduleInputSchema.optional(),alerts:z.object({enabled:z.boolean()}).strict().optional()}).strict().refine(v=>!!v.schedule||!!v.alerts,'Choose a voting schedule or alerts setting.').parse(await body(req));
 const b=await db().prepare('SELECT size,status,current_round,started_at,round_closes_at,voting_schedule,schedule_revision,owner_id,is_test FROM brackets WHERE id=?').bind(id).first<{size:number;status:string;current_round:number;started_at:number|null;round_closes_at:number|null;voting_schedule:string|null;schedule_revision:number;owner_id:string;is_test:number}>();if(!b)throw new ApiError(404,'Bracket not found.');if(input.schedule&&b.status==='complete')throw new ApiError(409,'This tournament is complete.');if(b.is_test)throw new ApiError(400,'Practice brackets use manual rounds. Create a public bracket to schedule voting.');
 if(input.alerts&&(!account||account.identity_id!==b.owner_id))throw new ApiError(403,'Sign in with the creator profile to manage email alerts.');
 let schedule=readVotingSchedule(b.voting_schedule,b.size);if(input.schedule)try{schedule=resolveSchedule(input.schedule as ScheduleInput,b.size,b.current_round,Date.now(),schedule??undefined,b.started_at??undefined);}catch(error){throw new ApiError(400,error instanceof Error?error.message:'Check your voting schedule.');}
 const close=input.schedule&&b.status==='live'?schedule!.deadlines[b.current_round]:b.round_closes_at;
 if(input.schedule&&b.status==='live'&&b.round_closes_at!==null&&b.round_closes_at<=Date.now()&&close!==b.round_closes_at)throw new ApiError(409,'This round has reached its deadline. Resolve and advance it before changing its closing time.');
 const marker=token();
 const update=input.schedule?db().prepare(`UPDATE brackets SET voting_schedule=?,ends_at=?,round_closes_at=?,schedule_revision=schedule_revision+1,schedule_checked_at=0,schedule_blocked_reason=NULL,advance_token=? WHERE id=? AND status=? AND current_round=? AND schedule_revision=? AND round_closes_at IS ? AND (status<>'live' OR round_closes_at IS NULL OR round_closes_at>${sqlNow} OR round_closes_at IS ?) AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)`).bind(JSON.stringify(schedule),schedule!.mode==='manual'?null:schedule!.deadlines.at(-1)??null,close,marker,id,b.status,b.current_round,b.schedule_revision,b.round_closes_at,close,id,who.id):db().prepare(`UPDATE brackets SET advance_token=? WHERE id=? AND status=? AND current_round=? AND schedule_revision=? AND round_closes_at IS ? AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)`).bind(marker,id,b.status,b.current_round,b.schedule_revision,b.round_closes_at,id,who.id);
 const statements=[update];
 if(input.schedule)statements.push(db().prepare("UPDATE matches SET status='open' WHERE bracket_id=? AND round=? AND status='pending' AND a_id IS NOT NULL AND b_id IS NOT NULL AND EXISTS(SELECT 1 FROM brackets WHERE id=? AND status='live' AND advance_token=?)").bind(id,b.current_round,id,marker));
 const alertStatementIndex=statements.length;
 if(input.alerts){statements.push(db().prepare(`INSERT INTO creator_alert_settings(bracket_id,account_id,enabled,updated_at) SELECT ?,?,?,${sqlNow} WHERE EXISTS(SELECT 1 FROM brackets b JOIN managers m ON m.bracket_id=b.id JOIN accounts a ON a.identity_id=b.owner_id WHERE b.id=? AND b.owner_id=? AND m.identity_id=? AND a.id=? AND b.advance_token=? AND EXISTS(SELECT 1 FROM account_credentials WHERE account_id=a.id)) ON CONFLICT(bracket_id) DO UPDATE SET account_id=excluded.account_id,enabled=excluded.enabled,updated_at=excluded.updated_at`).bind(id,account!.id,Number(input.alerts.enabled),id,who.id,who.id,account!.id,marker));if(!input.alerts.enabled)statements.push(db().prepare("UPDATE creator_alert_outbox SET status='cancelled',lease_token=NULL,lease_until=NULL WHERE bracket_id=? AND account_id=? AND status IN ('pending','sending') AND EXISTS(SELECT 1 FROM creator_alert_settings s JOIN brackets b ON b.id=s.bracket_id WHERE s.bracket_id=? AND s.account_id=? AND s.enabled=0 AND b.advance_token=?)").bind(id,account!.id,id,account!.id,marker));}
 const saved=await db().batch(statements);if(!saved[0].meta.changes)throw new ApiError(409,'The round or schedule changed. Reload before saving.');if(input.alerts&&!saved[alertStatementIndex].meta.changes)throw new ApiError(403,'Creator access changed. Reload this bracket.');
 return getVotingSchedule(req,id);
}
