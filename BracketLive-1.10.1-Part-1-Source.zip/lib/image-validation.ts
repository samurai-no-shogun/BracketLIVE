/** Bounded container/header inspection. This does not decode compressed pixels. */
export const MAX_IMAGE_DIMENSION = 8192;
export const MAX_IMAGE_PIXELS = 25_000_000;
const MAX_ANIMATION_FRAMES = 300;
const MAX_ANIMATION_PIXELS = 100_000_000;
export type ValidatedImage = { type: string; ext: 'png' | 'jpg' | 'gif' | 'webp'; width: number; height: number };
export class ImageValidationError extends Error {}
const invalid = (): never => { throw new ImageValidationError('This image is damaged or unsupported. Use a PNG, JPG, WebP, or GIF image.'); };
function dimensions(width: number, height: number) {
  if (!width || !height) invalid();
  if (width > MAX_IMAGE_DIMENSION || height > MAX_IMAGE_DIMENSION || width * height > MAX_IMAGE_PIXELS) {
    throw new ImageValidationError('Use an image no larger than 8,192 pixels per side and 25 megapixels.');
  }
  return { width, height };
}
export function validateImage(bytes: Uint8Array): ValidatedImage {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const has = (offset: number, length: number) => offset >= 0 && length >= 0 && offset + length <= bytes.length;
  const ascii = (offset: number, length: number) => String.fromCharCode(...bytes.subarray(offset, offset + length));
  const u16 = (offset: number, little = false) => has(offset, 2) ? view.getUint16(offset, little) : invalid();
  const u24 = (offset: number) => has(offset, 3) ? bytes[offset] + bytes[offset + 1] * 256 + bytes[offset + 2] * 65536 : invalid();
  const u32 = (offset: number, little = false) => has(offset, 4) ? view.getUint32(offset, little) : invalid();
  let frames = 0, framePixels = 0;
  const frame = (width: number, height: number) => {
    dimensions(width, height); frames++; framePixels += width * height;
    if (frames > MAX_ANIMATION_FRAMES || framePixels > MAX_ANIMATION_PIXELS) throw new ImageValidationError('This animation is too large. Use a shorter or smaller animation, or a still image.');
  };
  if (bytes.length >= 8 && [137, 80, 78, 71, 13, 10, 26, 10].every((n, i) => bytes[i] === n)) {
    let offset = 8, width = 0, height = 0, imageData = false, declaredFrames = 0;
    while (has(offset, 12)) {
      const length = u32(offset), kind = ascii(offset + 4, 4), data = offset + 8;
      if (!has(data, length + 4)) invalid();
      if (!width && kind !== 'IHDR') invalid();
      if (kind === 'IHDR') {
        if (offset !== 8 || length !== 13) invalid();
        ({ width, height } = dimensions(u32(data), u32(data + 4)));
        if (![0, 2, 3, 4, 6].includes(bytes[data + 9]) || bytes[data + 10] || bytes[data + 11] || bytes[data + 12] > 1) invalid();
      } else if (kind === 'acTL') {
        if (length !== 8 || imageData || declaredFrames) invalid();
        declaredFrames = u32(data);
        if (!declaredFrames || declaredFrames > MAX_ANIMATION_FRAMES || declaredFrames * width * height > MAX_ANIMATION_PIXELS) throw new ImageValidationError('This animation is too large. Use a shorter or smaller animation, or a still image.');
      } else if (kind === 'fcTL') {
        if (!declaredFrames || length !== 26) invalid();
        const fw = u32(data + 4), fh = u32(data + 8);
        if (u32(data + 12) + fw > width || u32(data + 16) + fh > height) invalid();
        frame(width, height);
      } else if (kind === 'IDAT') imageData = true;
      else if (kind === 'IEND') {
        if (length || !imageData || offset + 12 !== bytes.length || (declaredFrames && frames !== declaredFrames)) invalid();
        return { type: 'image/png', ext: 'png', width, height };
      }
      offset = data + length + 4;
    }
    invalid();
  }
  if (ascii(0, 6) === 'GIF87a' || ascii(0, 6) === 'GIF89a') {
    if (!has(0, 13)) invalid();
    const { width, height } = dimensions(u16(6, true), u16(8, true));
    let offset = 13 + (bytes[10] & 128 ? 3 * 2 ** ((bytes[10] & 7) + 1) : 0);
    const blocks = () => {
      for (;;) { if (!has(offset, 1)) invalid(); const size = bytes[offset++]; if (!size) return; if (!has(offset, size)) invalid(); offset += size; }
    };
    while (has(offset, 1)) {
      const marker = bytes[offset++];
      if (marker === 0x3b) { if (!frames || offset !== bytes.length) invalid(); return { type: 'image/gif', ext: 'gif', width, height }; }
      if (marker === 0x21) { if (!has(offset++, 1)) invalid(); blocks(); }
      else if (marker === 0x2c) {
        if (!has(offset, 9)) invalid();
        const fw = u16(offset + 4, true), fh = u16(offset + 6, true);
        if (u16(offset, true) + fw > width || u16(offset + 2, true) + fh > height) invalid();
        dimensions(fw, fh); frame(width, height);
        offset += 9 + (bytes[offset + 8] & 128 ? 3 * 2 ** ((bytes[offset + 8] & 7) + 1) : 0);
        if (!has(offset, 1) || bytes[offset] < 2 || bytes[offset] > 8) invalid();
        offset++; blocks();
      } else invalid();
    }
    invalid();
  }
  if (bytes[0] === 255 && bytes[1] === 216) {
    let offset = 2, width = 0, height = 0;
    while (has(offset, 2)) {
      if (bytes[offset++] !== 255) invalid();
      while (bytes[offset] === 255) offset++;
      const marker = bytes[offset++];
      if (marker === 0xd9) invalid();
      const length = u16(offset);
      if (length < 2 || !has(offset, length)) invalid();
      if ([0xc0, 0xc1, 0xc2].includes(marker)) {
        if (width || length < 8 || bytes[offset + 2] !== 8) invalid();
        ({ width, height } = dimensions(u16(offset + 5), u16(offset + 3)));
      }
      if (marker === 0xda) {
        if (!width || bytes[bytes.length - 2] !== 255 || bytes[bytes.length - 1] !== 0xd9) invalid();
        return { type: 'image/jpeg', ext: 'jpg', width, height };
      }
      offset += length;
    }
    invalid();
  }
  if (ascii(0, 4) === 'RIFF' && ascii(8, 4) === 'WEBP') {
    if (u32(4, true) + 8 !== bytes.length) invalid();
    let offset = 12, width = 0, height = 0, imageData = false;
    const bitstream = (kind: string, data: number, length: number) => {
      if (kind === 'VP8 ') {
        if (length < 10 || (bytes[data] & 1) || ascii(data + 3, 3) !== '\x9d\x01\x2a') invalid();
        return dimensions(u16(data + 6, true) & 0x3fff, u16(data + 8, true) & 0x3fff);
      }
      if (length < 5 || bytes[data] !== 0x2f || (bytes[data + 4] & 0xe0)) invalid();
      const bits = u32(data + 1, true);
      return dimensions((bits & 0x3fff) + 1, ((bits >>> 14) & 0x3fff) + 1);
    };
    while (has(offset, 8)) {
      const kind = ascii(offset, 4), length = u32(offset + 4, true), data = offset + 8;
      if (!has(data, length + (length & 1))) invalid();
      if (kind === 'VP8X') {
        if (offset !== 12 || length !== 10) invalid();
        ({ width, height } = dimensions(u24(data + 4) + 1, u24(data + 7) + 1));
      } else if (kind === 'VP8 ' || kind === 'VP8L') {
        const size = bitstream(kind, data, length);
        if (width && (size.width !== width || size.height !== height)) invalid();
        ({ width, height } = size); imageData = true;
      } else if (kind === 'ANMF') {
        if (!width || length < 24) invalid();
        const fw = u24(data + 6) + 1, fh = u24(data + 9) + 1;
        if (u24(data) * 2 + fw > width || u24(data + 3) * 2 + fh > height) invalid();
        dimensions(fw, fh); frame(width, height);
        let sub = data + 16, found = false;
        while (sub + 8 <= data + length) {
          const subKind = ascii(sub, 4), subLength = u32(sub + 4, true);
          if (sub + 8 + subLength + (subLength & 1) > data + length) invalid();
          if (subKind === 'VP8 ' || subKind === 'VP8L') { const size = bitstream(subKind, sub + 8, subLength); if (size.width !== fw || size.height !== fh) invalid(); found = true; }
          sub += 8 + subLength + (subLength & 1);
        }
        if (!found || sub !== data + length) invalid();
        imageData = true;
      }
      offset = data + length + (length & 1);
    }
    if (!width || !imageData || offset !== bytes.length) invalid();
    return { type: 'image/webp', ext: 'webp', width, height };
  }
  return invalid();
}
