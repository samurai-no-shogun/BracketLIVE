import type {Match} from './bracket';

export type Point={x:number;y:number};
export type Size={width:number;height:number};
export const NODE_WIDTH=272,NODE_HEIGHT=136,ROUND_GAP=44,ROW_PITCH=160,VIEW_PADDING=16;

// clientWidth/clientHeight round fractional CSS pixels up or down. Rounding up
// makes a fitted stage overflow and can repeatedly toggle both scrollbars.
export function measureViewport(el:Pick<HTMLElement,'getBoundingClientRect'|'offsetWidth'|'offsetHeight'|'clientWidth'|'clientHeight'>):Size{
 const bounds=el.getBoundingClientRect();
 const within=(value:number)=>Math.max(0,Math.floor(value*64)/64);
 return {width:within(bounds.width-(el.offsetWidth-el.clientWidth)),height:within(bounds.height-(el.offsetHeight-el.clientHeight))};
}

export function bracketLayout(size:number){
 const depth=Math.log2(size)-1,rows=size/4,width=2*depth*(NODE_WIDTH+ROUND_GAP)+NODE_WIDTH+48;
 const height=Math.max(520,rows*ROW_PITCH+80),top=(height-rows*ROW_PITCH)/2;
 const position=(match:Pick<Match,'round'|'position'>)=>{
  if(match.round===depth)return {x:(width-NODE_WIDTH)/2,y:(height-NODE_HEIGHT)/2,right:false};
  const half=size/2**(match.round+2),right=match.position>=half,local=match.position%half;
  return {x:right?width-24-NODE_WIDTH-match.round*(NODE_WIDTH+ROUND_GAP):24+match.round*(NODE_WIDTH+ROUND_GAP),y:top+(local+.5)*2**match.round*ROW_PITCH-NODE_HEIGHT/2,right};
 };
 return {width,height,depth,position};
}
export function fitScale(world:Size,viewport:Size){return Math.max(.01,Math.floor(Math.min(1,(viewport.width-VIEW_PADDING*2)/world.width,(viewport.height-VIEW_PADDING*2)/world.height)*1e6)/1e6);}
export function stageGeometry(world:Size,viewport:Size,zoom:number){
 const scaledWidth=world.width*zoom,scaledHeight=world.height*zoom;
 const width=Math.max(viewport.width,scaledWidth+VIEW_PADDING*2),height=Math.max(viewport.height,scaledHeight+VIEW_PADDING*2);
 return {width,height,scaledWidth,scaledHeight,left:(width-scaledWidth)/2,top:(height-scaledHeight)/2};
}
export function worldPoint(world:Size,viewport:Size,zoom:number,scroll:Point,screen:Point):Point{const s=stageGeometry(world,viewport,zoom);return {x:(scroll.x+screen.x-s.left)/zoom,y:(scroll.y+screen.y-s.top)/zoom};}
export function scrollToPoint(world:Size,viewport:Size,zoom:number,point:Point,screen:Point):Point{
 const s=stageGeometry(world,viewport,zoom);
 return {x:Math.max(0,Math.min(s.width-viewport.width,point.x*zoom+s.left-screen.x)),y:Math.max(0,Math.min(s.height-viewport.height,point.y*zoom+s.top-screen.y))};
}
