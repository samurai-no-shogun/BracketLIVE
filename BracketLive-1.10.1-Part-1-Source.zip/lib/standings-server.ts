import { z } from 'zod';
import { ApiError, body, db, hash, identity, json, originCheck, token } from './server';
import { calculateStandings, type Season, type SeasonCard, type SeasonEntrant, type SeasonEvent } from './standings';

const Name = z.string().trim().min(1, 'Enter a name.').max(100);
const Points = z.array(z.number().int().min(0).max(10000)).min(1).max(128);
const Basics = { title: Name, description: z.string().trim().max(400).default(''), points: Points };
const Create = z.object({ ...Basics, entrants: z.array(Name).min(2, 'Add at least two entrants.').max(128) })
  .refine(data => new Set(data.entrants.map(name => name.toLowerCase())).size === data.entrants.length, 'Each entrant needs a different name.');
const Settings = z.object({ ...Basics, version: z.number().int().positive(),
  entrants: z.array(z.object({ id: z.string().uuid(), name: Name })).min(2).max(128) })
  .refine(data => new Set(data.entrants.map(entry => entry.name.toLowerCase())).size === data.entrants.length, 'Each entrant needs a different name.');
const EventSchema = z.object({ title: Name,
  date: z.string().refine(value => value === '' || (/^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(`${value}T00:00:00Z`)) && new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value), 'Choose a valid date.').default(''),
  status: z.enum(['draft', 'complete']), version: z.number().int().nonnegative().default(0),
  results: z.array(z.object({ entrantId: z.string().uuid(), position: z.number().int().min(1).max(128).nullable(),
    adjustment: z.number().int().min(-10000).max(10000).default(0), note: z.string().trim().max(160).default('') })).max(128)
});
type SeasonRow = { id: string; title: string; description: string; points: string; entrants: string; created_at: number; updated_at: number; version: number };
type EventRow = { id: string; title: string; event_date: string; status: 'draft' | 'complete'; results: string; version: number };

export async function requireSeasonOwner(id: string, who: string) {
  if (!await db().prepare('SELECT season_id FROM season_managers WHERE season_id=? AND identity_id=?').bind(id, who).first()) {
    throw new ApiError(403, 'Only the season organizer can edit results. Use your private organizer link or the browser where you created this season.');
  }
}
export async function seasonSnapshot(id: string, who: string): Promise<Season> {
  const results = await db().batch([
    db().prepare('SELECT id,title,description,points,entrants,created_at,updated_at,version FROM seasons WHERE id=?').bind(id),
    db().prepare('SELECT id,title,event_date,status,results,version FROM season_events WHERE season_id=? ORDER BY CASE WHEN event_date=\'\' THEN 1 ELSE 0 END,event_date,created_at,id').bind(id),
    db().prepare('SELECT season_id FROM season_managers WHERE season_id=? AND identity_id=?').bind(id, who)
  ]);
  const row = results[0].results[0] as unknown as SeasonRow | undefined;
  if (!row) throw new ApiError(404, 'Season not found. Check the link.');
  const entrants = JSON.parse(row.entrants) as SeasonEntrant[], points = JSON.parse(row.points) as number[];
  const events = (results[1].results as unknown as EventRow[]).map(event => ({ id: event.id, title: event.title, date: event.event_date,
    status: event.status, results: JSON.parse(event.results), version: event.version })) as SeasonEvent[];
  return { id: row.id, title: row.title, description: row.description, points, entrants, events,
    standings: calculateStandings(entrants, events, points), isOwner: !!results[2].results.length,
    createdAt: row.created_at, updatedAt: row.updated_at, version: row.version };
}
export async function createSeason(req: Request) {
  originCheck(req);
  const who = await identity(req), data = Create.parse(await body(req)), now = Date.now(), database = db();
  const id = crypto.randomUUID(), manageToken = token(), entrants = data.entrants.map(name => ({ id: crypto.randomUUID(), name }));
  const created = await database.batch([
    database.prepare('INSERT INTO seasons(id,title,description,points,entrants,owner_id,manage_hash,created_at,updated_at) SELECT ?,?,?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM seasons WHERE owner_id=? AND created_at>?)<20')
      .bind(id, data.title, data.description, JSON.stringify(data.points), JSON.stringify(entrants), who.id, await hash(manageToken), now, now, who.id, now - 86400000),
    database.prepare('INSERT INTO season_managers(season_id,identity_id) SELECT ?,? WHERE EXISTS(SELECT 1 FROM seasons WHERE id=?)').bind(id, who.id, id)
  ]);
  if (!created[0].meta.changes) throw new ApiError(429, 'You have created 20 seasons today. Try again tomorrow.');
  return json({ season: await seasonSnapshot(id, who.id), manageToken }, 201, who.cookie);
}
export async function listSeasons(req: Request) {
  const who = await identity(req), mine = new URL(req.url).searchParams.get('view') === 'mine';
  const rows = await db().prepare(`SELECT s.id,s.title,s.description,s.created_at AS createdAt,json_array_length(s.entrants) AS entrantCount,
    (SELECT COUNT(*) FROM season_events e WHERE e.season_id=s.id) AS eventCount,
    (SELECT COUNT(*) FROM season_events e WHERE e.season_id=s.id AND e.status='complete') AS completedCount,
    EXISTS(SELECT 1 FROM season_managers m WHERE m.season_id=s.id AND m.identity_id=?) AS isOwner
    FROM seasons s ${mine ? 'WHERE EXISTS(SELECT 1 FROM season_managers m WHERE m.season_id=s.id AND m.identity_id=?)' : ''}
    ORDER BY s.created_at DESC LIMIT 100`).bind(...(mine ? [who.id, who.id] : [who.id])).all<SeasonCard>();
  return json({ seasons: rows.results.map(row => ({ ...row, isOwner: !!row.isOwner })) }, 200, who.cookie);
}
export async function updateSeason(req: Request, id: string) {
  originCheck(req);
  const who = await identity(req); await requireSeasonOwner(id, who.id);
  const data = Settings.parse(await body(req)), previous = await seasonSnapshot(id, who.id);
  const oldIds = new Set(previous.entrants.map(entry => entry.id));
  if (data.entrants.length !== oldIds.size || new Set(data.entrants.map(entry => entry.id)).size !== oldIds.size || data.entrants.some(entry => !oldIds.has(entry.id))) {
    throw new ApiError(400, 'The roster is fixed after creation. You can rename entrants; create a new season to change its size.');
  }
  const updated = await db().prepare('UPDATE seasons SET title=?,description=?,points=?,entrants=?,updated_at=?,version=version+1 WHERE id=? AND version=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)')
    .bind(data.title, data.description, JSON.stringify(data.points), JSON.stringify(data.entrants), Date.now(), id, data.version, id, who.id).run();
  if (!updated.meta.changes) { await requireSeasonOwner(id, who.id); throw new ApiError(409, 'Settings changed in another window. Reload the season before saving.'); }
  return json(await seasonSnapshot(id, who.id), 200, who.cookie);
}
export async function saveSeasonEvent(req: Request, id: string, eventId: string) {
  originCheck(req);
  const who = await identity(req); await requireSeasonOwner(id, who.id);
  if (!z.string().uuid().safeParse(eventId).success) throw new ApiError(400, 'Invalid event.');
  const data = EventSchema.parse(await body(req)), season = await seasonSnapshot(id, who.id);
  const entrantIds = new Set(season.entrants.map(entry => entry.id)), seen = new Set<string>(), positions = new Set<number>();
  for (const result of data.results) {
    if (!entrantIds.has(result.entrantId) || seen.has(result.entrantId)) throw new ApiError(400, 'Each result must belong to a different entrant in this season.');
    seen.add(result.entrantId);
    if (result.position !== null) {
      if (result.position > entrantIds.size || positions.has(result.position)) throw new ApiError(400, 'Use a different finishing place for each entrant, within the roster size.');
      positions.add(result.position);
    }
  }
  if (data.status === 'complete' && !data.results.some(result => result.position !== null || result.adjustment !== 0)) {
    throw new ApiError(400, 'Enter at least one placement or points adjustment before counting this event.');
  }
  const now = Date.now();
  if (data.version === 0) {
    const statements = await db().batch([
      db().prepare('INSERT OR IGNORE INTO season_events(id,season_id,title,event_date,status,results,created_at,updated_at) SELECT ?,?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM season_events WHERE season_id=?)<100 AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)')
        .bind(eventId, id, data.title, data.date, data.status, JSON.stringify(data.results), now, now, id, id, who.id),
      db().prepare('UPDATE seasons SET updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)').bind(now, id, id, who.id)
    ]);
    if (!statements[0].meta.changes) { await requireSeasonOwner(id, who.id); throw new ApiError(409, 'This event already exists or the season has reached its 100-event limit. Reload before trying again.'); }
  } else {
    const statements = await db().batch([
      db().prepare('UPDATE season_events SET title=?,event_date=?,status=?,results=?,updated_at=?,version=version+1 WHERE id=? AND season_id=? AND version=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)')
        .bind(data.title, data.date, data.status, JSON.stringify(data.results), now, eventId, id, data.version, id, who.id),
      db().prepare('UPDATE seasons SET updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)').bind(now, id, id, who.id)
    ]);
    if (!statements[0].meta.changes) { await requireSeasonOwner(id, who.id); throw new ApiError(409, 'This event changed in another window. Reopen it to load the current results.'); }
  }
  return json(await seasonSnapshot(id, who.id), 200, who.cookie);
}
export async function deleteSeasonEvent(req: Request, id: string, eventId: string) {
  originCheck(req);
  const who = await identity(req); await requireSeasonOwner(id, who.id);
  const { version } = z.object({ version: z.number().int().positive() }).parse(await body(req));
  const results = await db().batch([
    db().prepare('DELETE FROM season_events WHERE id=? AND season_id=? AND version=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)').bind(eventId, id, version, id, who.id),
    db().prepare('UPDATE seasons SET updated_at=? WHERE id=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)').bind(Date.now(), id, id, who.id)
  ]);
  if (!results[0].meta.changes) { await requireSeasonOwner(id, who.id); throw new ApiError(409, 'This event changed in another window. Reopen it before removing.'); }
  return json(await seasonSnapshot(id, who.id), 200, who.cookie);
}
export async function manageSeason(req: Request, id: string) {
  originCheck(req);
  const who = await identity(req), data = z.object({ token: z.string().regex(/^[a-f0-9]{64}$/).optional(), revokeOthers: z.boolean().default(false) })
    .refine(value => !value.token || !value.revokeOthers, 'Open your organizer link before resetting access.').parse(await body(req));
  const database = db();
  if (data.token) {
    const result = await database.prepare('INSERT INTO season_managers(season_id,identity_id) SELECT id,? FROM seasons WHERE id=? AND manage_hash=? ON CONFLICT(season_id,identity_id) DO UPDATE SET identity_id=excluded.identity_id')
      .bind(who.id, id, await hash(data.token)).run();
    if (!result.meta.changes) throw new ApiError(403, 'This organizer link is invalid or has been replaced.');
    return json({ ok: true }, 200, who.cookie);
  }
  await requireSeasonOwner(id, who.id);
  const fresh = token(), freshHash = await hash(fresh);
  const statements = [database.prepare('UPDATE seasons SET manage_hash=? WHERE id=? AND EXISTS(SELECT 1 FROM season_managers WHERE season_id=? AND identity_id=?)')
    .bind(freshHash, id, id, who.id)];
  if (data.revokeOthers) statements.push(database.prepare('DELETE FROM season_managers WHERE season_id=? AND identity_id<>? AND EXISTS(SELECT 1 FROM seasons WHERE id=? AND manage_hash=?)')
    .bind(id, who.id, id, freshHash));
  const results = await database.batch(statements);
  if (!results[0].meta.changes) throw new ApiError(403, 'Your organizer access was reset in another browser. Open the current private organizer link.');
  return json({ manageToken: fresh, revokedOthers: data.revokeOthers }, 200, who.cookie);
}
