import type {Bracket,Match} from './bracket';

export type BracketPicks=Record<string,string>;
export type PickProjection={bracket:Bracket;picks:BracketPicks;completed:number};
export const picksStorageKey=(bracketId:string)=>`bracketlive:picks:v1:${bracketId}`;

/** Rebuild from the starting field, never from community votes or actual winners. */
export function projectBracketPicks(source:Bracket,input:unknown={}):PickProjection{
 const raw=input&&typeof input==='object'&&!Array.isArray(input)?input as Record<string,unknown>:{};
 const entries=[...source.entries].sort((a,b)=>a.seed-b.seed),entryIds=new Set(entries.map(e=>e.id));
 const existing=new Map(source.matches.map(m=>[`${m.round}:${m.position}`,m]));
 const rounds=Math.log2(source.size),matches:Match[]=[],bySlot=new Map<string,Match>(),picks:BracketPicks={};
 for(let round=0;round<rounds;round++)for(let position=0;position<source.size/2**(round+1);position++){
  const original=existing.get(`${round}:${position}`),id=original?.id??`pick-${round}-${position}`;
  const initialA=original?.a_id&&entryIds.has(original.a_id)?original.a_id:entries[position*2]?.id??null;
  const initialB=original?.b_id&&entryIds.has(original.b_id)?original.b_id:entries[position*2+1]?.id??null;
  const a_id=round===0?initialA:bySlot.get(`${round-1}:${position*2}`)?.winner_id??null;
  const b_id=round===0?initialB:bySlot.get(`${round-1}:${position*2+1}`)?.winner_id??null;
  const requested=Object.hasOwn(raw,id)?raw[id]:null;
  const winner_id=a_id&&b_id&&typeof requested==='string'&&(requested===a_id||requested===b_id)?requested:null;
  if(winner_id)picks[id]=winner_id;
  const match:Match={id,round,position,a_id,b_id,winner_id,status:winner_id?'closed':a_id&&b_id?'open':'pending',myVote:winner_id,counts:null,total:null,decided_by:winner_id?'personal-pick':null};
  matches.push(match);bySlot.set(`${round}:${position}`,match);
 }
 const completed=Object.keys(picks).length,complete=completed===source.size-1;
 return {picks,completed,bracket:{...source,title:`${source.title} — My picks`,matches,totalVotes:0,isOwner:false,is_test:false,listed:false,ends_at:null,round_closes_at:null,status:complete?'complete':completed?'live':'draft',current_round:matches.find(m=>m.status==='open')?.round??rounds-1}};
}

/** Choosing or undoing a result drops picks whose participants no longer reach that match. */
export function changeBracketPick(source:Bracket,input:BracketPicks,matchId:string,entryId:string|null):BracketPicks{
 const projection=projectBracketPicks(source,input),match=projection.bracket.matches.find(m=>m.id===matchId);
 if(!match)throw new Error('This matchup is not in your bracket.');
 if(entryId!==null&&(!match.a_id||!match.b_id||![match.a_id,match.b_id].includes(entryId)))throw new Error('Choose both previous-round winners first.');
 const next={...projection.picks};
 if(entryId===null)delete next[matchId];else next[matchId]=entryId;
 return projectBracketPicks(source,next).picks;
}

export function parseStoredPicks(value:string|null):BracketPicks{
 if(!value)return {};
 const parsed:unknown=JSON.parse(value);
 if(!parsed||typeof parsed!=='object'||Array.isArray(parsed))return {};
 const record=parsed as {version?:unknown;picks?:unknown};
 if(record.version!==1||!record.picks||typeof record.picks!=='object'||Array.isArray(record.picks))return {};
 return Object.fromEntries(Object.entries(record.picks).filter(([,entryId])=>typeof entryId==='string')) as BracketPicks;
}

export function serializeStoredPicks(picks:BracketPicks){return JSON.stringify({version:1,picks});}
