/** Quote a spreadsheet cell and keep untrusted labels from becoming formulas. */
export function csvCell(value: unknown): string {
  let text = String(value ?? '');
  // Spreadsheet importers can discard leading whitespace/control characters.
  // Guard the first meaningful character as well as raw tab/newline prefixes.
  if (typeof value !== 'number' && (/^[\s\u0000-\u001f]*[=+\-@\uFF1D\uFF0B\uFF0D\uFF20]/u.test(text) || /^[\t\r\n]/.test(text))) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}
