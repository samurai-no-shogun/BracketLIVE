export async function seasonApi<T>(path: string, data?: unknown, method = 'POST'): Promise<T> {
  const response = await fetch(path, { method: data === undefined ? 'GET' : method, cache: 'no-store',
    headers: data === undefined ? undefined : { 'Content-Type': 'application/json' }, body: data === undefined ? undefined : JSON.stringify(data) });
  const value = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(value.error || 'Could not complete this action.');
  return value;
}
export const seasonError = (error: unknown) => error instanceof Error ? error.message : 'Something went wrong. Try again.';
