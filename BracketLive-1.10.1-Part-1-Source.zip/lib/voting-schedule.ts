/** Voting deadlines are stored as absolute instants; weekly repeats use local calendar time. */
export type ScheduleMode='manual'|'weekly'|'custom'|'finish';
export type TiePolicy='pause'|'seed';
export type ScheduleInput={
 mode:ScheduleMode;
 timezone:string;
 tie_policy:TiePolicy;
 first_closes_at?:number;
 deadlines?:Array<number|null>;
 ends_at?:number;
};
export type VotingSchedule={mode:ScheduleMode;timezone:string;tie_policy:TiePolicy;deadlines:Array<number|null>};

const MINUTE=60_000;
const DAY=86_400_000;
const MAX_HORIZON=5*366*DAY;
const modes:ScheduleMode[]=['manual','weekly','custom','finish'];
const formatters=new Map<string,Intl.DateTimeFormat>();
type LocalParts={year:number;month:number;day:number;hour:number;minute:number;second:number};

function formatter(timezone:string){
 if(typeof timezone!=='string'||!timezone||timezone.length>100||/^[+-]/.test(timezone))throw new Error('Choose a valid time zone.');
 let value=formatters.get(timezone);
 if(!value){
  try{value=new Intl.DateTimeFormat('en-CA',{timeZone:timezone,calendar:'iso8601',numberingSystem:'latn',hourCycle:'h23',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'});}
  catch{throw new Error('Choose a valid IANA time zone, such as America/New_York.');}
  if(formatters.size>=64)formatters.delete(formatters.keys().next().value!);
  formatters.set(timezone,value);
 }
 return value;
}

function localParts(timestamp:number,timezone:string):LocalParts{
 if(!Number.isSafeInteger(timestamp)||!Number.isFinite(new Date(timestamp).getTime()))throw new Error('Choose a valid date and time.');
 const parts=Object.fromEntries(formatter(timezone).formatToParts(timestamp).map(part=>[part.type,part.value]));
 return {year:Number(parts.year),month:Number(parts.month),day:Number(parts.day),hour:Number(parts.hour),minute:Number(parts.minute),second:Number(parts.second)};
}

function localUtc(parts:LocalParts){
 // setUTCFullYear handles four-digit years below 0100 without Date.UTC's 1900 offset.
 const date=new Date(0);date.setUTCFullYear(parts.year,parts.month-1,parts.day);date.setUTCHours(parts.hour,parts.minute,parts.second,0);return date.getTime();
}
function sameParts(a:LocalParts,b:LocalParts){return a.year===b.year&&a.month===b.month&&a.day===b.day&&a.hour===b.hour&&a.minute===b.minute&&a.second===b.second;}
function pad(value:number){return String(value).padStart(2,'0');}
function partsString(parts:LocalParts){return `${String(parts.year).padStart(4,'0')}-${pad(parts.month)}-${pad(parts.day)}T${pad(parts.hour)}:${pad(parts.minute)}`;}

function instantForParts(parts:LocalParts,timezone:string){
 formatter(timezone);
 const local=localUtc(parts),offsets=new Set<number>();
 // Sample either side of the requested local date to find both offsets at a DST transition.
 // This also covers 30-minute transitions and skipped calendar days.
 for(let hours=-48;hours<=48;hours+=6){
  const sample=local+hours*60*MINUTE;
  offsets.add(localUtc(localParts(sample,timezone))-sample);
 }
 const candidates=[...offsets].map(offset=>local-offset).filter(candidate=>sameParts(localParts(candidate,timezone),parts));
 const unique=[...new Set(candidates)];
 if(unique.length===0)throw new Error(`That local time does not exist in ${timezone} because the clocks change. Choose a different time.`);
 if(unique.length!==1)throw new Error(`That local time occurs twice in ${timezone} because the clocks change. Choose a different time.`);
 return unique[0];
}

/** Convert a datetime-local input without silently choosing either side of a DST overlap. */
export function zonedDateTimeToTimestamp(local:string,timezone:string):number{
 if(typeof local!=='string')throw new Error('Choose a valid date and time.');
 const match=/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(local);
 if(!match)throw new Error('Choose a valid date and time.');
 const parts={year:Number(match[1]),month:Number(match[2]),day:Number(match[3]),hour:Number(match[4]),minute:Number(match[5]),second:Number(match[6]??0)};
 const date=new Date(localUtc(parts));
 if(parts.year<1||date.getUTCFullYear()!==parts.year||date.getUTCMonth()+1!==parts.month||date.getUTCDate()!==parts.day||date.getUTCHours()!==parts.hour||date.getUTCMinutes()!==parts.minute||date.getUTCSeconds()!==parts.second)throw new Error('Choose a valid calendar date and time.');
 return instantForParts(parts,timezone);
}

/** Format for an HTML datetime-local input in the tournament's selected time zone. */
export function formatZonedDateTime(timestamp:number,timezone:string):string{return partsString(localParts(timestamp,timezone));}
export function formatScheduleDeadline(timestamp:number,timezone:string):string{
 localParts(timestamp,timezone);
 return new Intl.DateTimeFormat('en-US',{timeZone:timezone,weekday:'short',month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}).format(timestamp);
}

function nextCalendarWeek(timestamp:number,timezone:string){
 const parts=localParts(timestamp,timezone),date=new Date(localUtc(parts));
 date.setUTCDate(date.getUTCDate()+7);
 return instantForParts({...parts,year:date.getUTCFullYear(),month:date.getUTCMonth()+1,day:date.getUTCDate()},timezone)+(timestamp%1000+1000)%1000;
}

/** Find the next still-open weekly slot, without deciding any intervening rounds. */
export function nextFutureWeeklyDeadline(reference:number,timezone:string,now:number):number{
 if(!Number.isSafeInteger(now))throw new Error('Choose a valid current time.');
 localParts(reference,timezone);
 let deadline=reference;
 for(let week=0;deadline<=now;week++){
  if(week>=520)throw new Error('The weekly schedule is too old. Set a new first closing date.');
  deadline=nextCalendarWeek(deadline,timezone);
 }
 return deadline;
}

/** Rebase only unplayed weekly rounds after delayed processing or an organizer-resolved tie. */
export function rollRemainingWeeklyDeadlines(schedule:VotingSchedule,nextRound:number,now:number):VotingSchedule{
 if(schedule.mode!=='weekly')return {...schedule,deadlines:[...schedule.deadlines]};
 if(!Number.isInteger(nextRound)||nextRound<0||nextRound>=schedule.deadlines.length)throw new Error('Choose a valid round.');
 const reference=schedule.deadlines[nextRound];
 if(reference===null)throw new Error('The weekly closing date is missing. Set a new schedule.');
 const deadlines=[...schedule.deadlines];
 let deadline=nextFutureWeeklyDeadline(reference,schedule.timezone,now);
 for(let round=nextRound;round<deadlines.length;round++){
  deadlines[round]=deadline;
  if(round<deadlines.length-1)deadline=nextCalendarWeek(deadline,schedule.timezone);
 }
 return {...schedule,deadlines};
}

function roundCount(size:number){
 if(![2,4,8,16,32,64,128].includes(size))throw new Error('Choose a bracket with 2, 4, 8, 16, 32, 64, or 128 entries.');
 return Math.log2(size);
}
function validInstant(value:unknown):value is number{return typeof value==='number'&&Number.isSafeInteger(value)&&Number.isFinite(new Date(value).getTime());}
function metadata(input:unknown):asserts input is ScheduleInput{
 if(!input||typeof input!=='object'||Array.isArray(input))throw new Error('Choose a voting schedule.');
 const value=input as ScheduleInput;
 if(!modes.includes(value.mode))throw new Error('Choose a valid voting schedule.');
 if(value.tie_policy!==undefined&&value.tie_policy!=='pause'&&value.tie_policy!=='seed')throw new Error('Choose how tied matches are decided.');
 formatter(value.timezone);
}

/** Read persisted state independently of today's date. Never repairs malformed schedules. */
export function readVotingSchedule(value:unknown,size?:number):VotingSchedule|null{
 try{
  if(typeof value==='string')value=JSON.parse(value);
  metadata(value);
  const candidate=value as VotingSchedule;
  if(!Array.isArray(candidate.deadlines)||candidate.deadlines.length<1||candidate.deadlines.length>7||(size!==undefined&&candidate.deadlines.length!==roundCount(size)))return null;
  for(const deadline of candidate.deadlines){
   if(deadline!==null&&!validInstant(deadline))return null;
  }
  return {mode:candidate.mode,timezone:candidate.timezone,tie_policy:candidate.tie_policy??'pause',deadlines:[...candidate.deadlines]};
 }catch{return null;}
}

/** Validate a new schedule or an edit; completed rounds retain their historical deadlines. */
export function resolveSchedule(input:ScheduleInput,size:number,currentRound:number,now:number,previous?:VotingSchedule,startedAt?:number|null):VotingSchedule{
 void startedAt; // Existing legacy schedule splitting remains the server's responsibility.
 metadata(input);
 const rounds=roundCount(size);
 if(!Number.isInteger(currentRound)||currentRound<0||currentRound>=rounds)throw new Error('Choose a valid round.');
 if(!validInstant(now))throw new Error('Choose a valid current time.');
 const deadlines:Array<number|null>=Array(rounds).fill(null);
 const past=previous&&readVotingSchedule(previous,size);
 for(let round=0;round<currentRound;round++)deadlines[round]=past?.deadlines[round]??null;
 const remaining=rounds-currentRound;
 if(input.mode==='weekly'){
  let close=input.first_closes_at??input.deadlines?.[currentRound];
  if(!validInstant(close))throw new Error('Set the first weekly closing date and time.');
  for(let round=currentRound;round<rounds;round++){
   deadlines[round]=close;
   if(round<rounds-1)close=nextCalendarWeek(close,input.timezone);
  }
 }else if(input.mode==='custom'){
  if(!Array.isArray(input.deadlines)||input.deadlines.length!==rounds)throw new Error(`Set a closing date for all ${rounds} rounds.`);
  for(let round=currentRound;round<rounds;round++){
   if(!validInstant(input.deadlines[round]))throw new Error(`Set a closing date and time for round ${round+1}.`);
   deadlines[round]=input.deadlines[round];
  }
 }else if(input.mode==='finish'){
  if(!validInstant(input.ends_at))throw new Error('Set the tournament finish date and time.');
  if(input.ends_at-now<remaining*MINUTE)throw new Error('Allow at least one minute of voting for each remaining round.');
  for(let round=currentRound;round<rounds;round++)deadlines[round]=Math.round(now+(input.ends_at-now)*(round-currentRound+1)/remaining);
 }
 let prior:number|null=null;
 for(let round=currentRound;round<rounds;round++){
  const close=deadlines[round];
  if(close===null)continue;
  if(close<=now)throw new Error(`Round ${round+1} must close in the future.`);
  if(close>now+MAX_HORIZON)throw new Error('Voting deadlines must be within five years.');
  if(prior!==null&&close-prior<MINUTE)throw new Error('Round closing times must be in order and at least one minute apart.');
  prior=close;
 }
 return {mode:input.mode,timezone:input.timezone,tie_policy:input.tie_policy??'pause',deadlines};
}

export function scheduleInputFromResolved(schedule:VotingSchedule,currentRound=0):ScheduleInput{
 const value:ScheduleInput={mode:schedule.mode,timezone:schedule.timezone,tie_policy:schedule.tie_policy,deadlines:[...schedule.deadlines]};
 if(schedule.mode==='weekly'&&schedule.deadlines[currentRound]!==null)value.first_closes_at=schedule.deadlines[currentRound];
 if(schedule.mode==='finish'&&schedule.deadlines.at(-1)!==null)value.ends_at=schedule.deadlines.at(-1)!;
 return value;
}
