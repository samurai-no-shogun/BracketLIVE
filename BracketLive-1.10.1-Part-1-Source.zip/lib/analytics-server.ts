import {z} from 'zod';
import {getFeaturedBracketId} from './featured-server';
import {isSiteAdmin} from './admin-auth';
import {ApiError,body,db,identity,json,originCheck,owns,requireOwner} from './server';

export async function recordAnalytics(req:Request){
 originCheck(req);if(req.headers.get('dnt')==='1'||req.headers.get('sec-gpc')==='1')return json({recorded:false});
 const p=z.object({id:z.string().uuid(),kind:z.enum(['view','share']),path:z.string().regex(/^\/$|^\/explore$|^\/create$|^\/b\/[a-f0-9-]{36}$/),source:z.string().regex(/^[a-z0-9.-]{1,160}$/i).default('direct'),campaign:z.string().max(100).default('')}).parse(await body(req));
 const who=await identity(req),bracketId=p.path.startsWith('/b/')?p.path.slice(3):p.path==='/'?await getFeaturedBracketId():null;
 let test=false;
 if(bracketId){const b=await db().prepare('SELECT status,is_test FROM brackets WHERE id=?').bind(bracketId).first<{status:string;is_test:number}>();if(!b||b.status==='draft'||(b.is_test&&!await owns(bracketId,who.id)))return json({recorded:false},200,who.cookie);test=!!b.is_test;}
 else if(p.kind==='share')return json({recorded:false},200,who.cookie);
 const now=Date.now();
 const source=p.source===new URL(req.url).hostname?'internal':p.source.toLowerCase();
 const ua=req.headers.get('user-agent')||'',device=/iPad|Tablet/i.test(ua)?'tablet':/Mobi|Android|iPhone/i.test(ua)?'mobile':'desktop';
 const r=await db().prepare('INSERT INTO analytics_events(id,visitor_id,kind,path,bracket_id,source,campaign,device,is_test,created_at) SELECT ?,?,?,?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM analytics_events WHERE visitor_id=? AND created_at>?)<500 ON CONFLICT(id) DO NOTHING').bind(p.id,who.id,p.kind,p.path,bracketId,source,p.campaign,device,Number(test),now,who.id,now-86400000).run();
 return json({recorded:!!r.meta.changes},200,who.cookie);
}
export async function analytics(req:Request){
 const url=new URL(req.url),id=url.searchParams.get('bracket'),days=Number(url.searchParams.get('days')||30);
 if(![7,30,90].includes(days))throw new ApiError(400,'Choose 7, 30, or 90 days.');
 const who=await identity(req);if(id)await requireOwner(id,who.id);else if(!await isSiteAdmin(req))throw new ApiError(403,'Sign in through Site owner to view site analytics.');
 const today=new Date();today.setUTCHours(0,0,0,0);const since=today.getTime()-(days-1)*86400000;
 const eventWhere=id?'e.bracket_id=?':'e.is_test=0',bracketWhere=id?'b.id=?':'b.is_test=0';
 const args=id?[since,id]:[since];
 const q=(sql:string,bindings:(string|number)[]=args)=>db().prepare(sql).bind(...bindings);
 const out=await db().batch([
  q(`SELECT COUNT(CASE WHEN e.kind='view' THEN 1 END) views,COUNT(DISTINCT CASE WHEN e.kind='view' THEN e.visitor_id END) visitors,COUNT(CASE WHEN e.kind='share' THEN 1 END) shares FROM analytics_events e WHERE e.created_at>=? AND ${eventWhere}`),
  q(`SELECT COUNT(*) votes,COUNT(DISTINCT v.voter_id) voters FROM votes v JOIN matches m ON m.id=v.match_id JOIN brackets b ON b.id=m.bracket_id WHERE v.updated_at>=? AND ${bracketWhere}`),
  q(`SELECT COUNT(DISTINCT e.visitor_id) converted FROM analytics_events e WHERE e.created_at>=? AND ${eventWhere} AND e.kind='view' AND EXISTS(SELECT 1 FROM votes v JOIN matches m ON m.id=v.match_id JOIN brackets b ON b.id=m.bracket_id WHERE v.voter_id=e.visitor_id AND b.is_test=e.is_test ${id?'AND b.id=e.bracket_id':''} AND v.updated_at>=?)`,[...args,since]),
  q(`SELECT date(e.created_at/1000,'unixepoch') day,COUNT(*) views,COUNT(DISTINCT e.visitor_id) visitors FROM analytics_events e WHERE e.created_at>=? AND ${eventWhere} AND e.kind='view' GROUP BY day ORDER BY day`),
  q(`SELECT e.source label,COUNT(*) value FROM analytics_events e WHERE e.created_at>=? AND ${eventWhere} AND e.kind='view' GROUP BY e.source ORDER BY value DESC LIMIT 10`),
  q(`SELECT e.device label,COUNT(*) value FROM analytics_events e WHERE e.created_at>=? AND ${eventWhere} AND e.kind='view' GROUP BY e.device ORDER BY value DESC`),
  q(`SELECT e.campaign label,COUNT(*) value FROM analytics_events e WHERE e.created_at>=? AND ${eventWhere} AND e.kind='view' AND e.campaign<>'' GROUP BY e.campaign ORDER BY value DESC LIMIT 10`),
  q(`SELECT b.id,b.title,b.status,b.size,b.is_test,(SELECT COUNT(*) FROM analytics_events e WHERE e.bracket_id=b.id AND e.kind='view' AND e.created_at>=?) views,(SELECT COUNT(*) FROM votes v JOIN matches m ON m.id=v.match_id WHERE m.bracket_id=b.id AND v.updated_at>=?) votes FROM brackets b WHERE ${bracketWhere} ORDER BY views DESC,votes DESC,b.created_at DESC LIMIT 20`,id?[since,since,id]:[since,since]),
  q(`SELECT COUNT(*) total,SUM(CASE WHEN b.status='live' THEN 1 ELSE 0 END) live,SUM(CASE WHEN b.status='complete' THEN 1 ELSE 0 END) complete FROM brackets b WHERE ${bracketWhere}`,id?[id]:[]),
 ]);
 const traffic=out[0].results[0] as {views:number;visitors:number;shares:number},voting=out[1].results[0] as {votes:number;voters:number},converted=Number((out[2].results[0] as {converted:number})?.converted||0);
 let rounds:unknown[]=[],matches:unknown[]=[];
 if(id){const rows=await db().batch([
  q('SELECT m.round,COUNT(DISTINCT m.id) matches,COUNT(v.entry_id) votes,COUNT(DISTINCT v.voter_id) voters FROM matches m LEFT JOIN votes v ON v.match_id=m.id AND v.updated_at>=? WHERE m.bracket_id=? GROUP BY m.round ORDER BY m.round'),
  q("SELECT m.round,m.position,m.status,COALESCE(NULLIF(a.name,''),'Image contender') a,COALESCE(NULLIF(b.name,''),'Image contender') b,COUNT(v.entry_id) votes FROM matches m LEFT JOIN entries a ON a.id=m.a_id LEFT JOIN entries b ON b.id=m.b_id LEFT JOIN votes v ON v.match_id=m.id AND v.updated_at>=? WHERE m.bracket_id=? GROUP BY m.id ORDER BY votes DESC,m.round,m.position LIMIT 10"),
 ]);rounds=rows[0].results;matches=rows[1].results;}
 return json({scope:id?'tournament':'site',days,since,summary:{...traffic,...voting,converted,conversion:traffic.visitors?Math.round(converted/traffic.visitors*1000)/10:0},daily:out[3].results,sources:out[4].results,devices:out[5].results,campaigns:out[6].results,tournaments:out[7].results,brackets:out[8].results[0],rounds,matches,updatedAt:Date.now()},200,who.cookie);
}
