import {isRegionalFormat} from './bracket';
import type {Bracket,Entry,Match} from './bracket';
import {roundName,displaySeed,entryRegion} from './bracket';
import {resolvedColors} from './appearance';
import {animeLogo,animeSource,animeSourceSize} from './anime-roster';
import {bracketLayout,NODE_WIDTH,NODE_HEIGHT,ROUND_GAP} from './bracket-layout';
import {csvCell} from './csv';

/** A portable point-in-time copy. No organizer links, keys, cookies, or hidden totals. */
export type BracketSnapshot={
 schema:'bracketlive.snapshot.v1';
 kind:'results'|'picks';
 exportedAt:string;
 tournament:Pick<Bracket,'id'|'title'|'description'|'size'|'format'|'status'|'current_round'|'ends_at'|'round_closes_at'|'accent'|'brand_color'|'brand_image'|'appearance'>;
 entries:Entry[];
 matches:Match[];
};
export type ExportArtwork={images:Record<string,string>;dimensions?:Record<string,{width:number;height:number}>;warnings:string[]};
export function bracketSnapshot(bracket:Bracket,now=new Date(),kind:'results'|'picks'='results'):BracketSnapshot{
 const {id,title,description,size,format,status,current_round,ends_at,round_closes_at,accent,brand_color,brand_image,appearance}=bracket;
 return JSON.parse(JSON.stringify({schema:'bracketlive.snapshot.v1',kind,exportedAt:now.toISOString(),tournament:{id,title,description,size,format,status,current_round,ends_at,round_closes_at,accent,brand_color,brand_image,appearance},entries:bracket.entries,matches:bracket.matches.map(m=>({...m,counts:kind==='picks'?null:m.counts,total:kind==='picks'||m.counts===null?null:m.total}))}));
}
export function escapeSvg(value:unknown){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]!));}
function shortText(value:string,length:number){const chars=Array.from(value);return chars.length>length?chars.slice(0,length-1).join('')+'…':value;}
export function exportFilename(snapshot:BracketSnapshot,extension:string){
 const title=snapshot.tournament.title.normalize('NFKD').replace(/[^\p{L}\p{N}\s_-]/gu,'').trim().replace(/\s+/g,'-').slice(0,80)||'bracket';
 return `${title}-${snapshot.tournament.status}-r${snapshot.tournament.current_round+1}-${snapshot.exportedAt.replace(/[:.]/g,'-')}.${extension}`;
}
export function artworkSources(snapshot:BracketSnapshot){
 const b=snapshot.tournament,values=[b.brand_image,...Object.values(b.appearance?.images||{}),...snapshot.entries.map(e=>e.image)];
 return [...new Set(values.filter((v):v is string=>!!v).map(v=>animeLogo(v)?animeSource:v))];
}

/** Fetch and embed assets once, making the saved SVG independent of the live site. */
export async function prepareExportArtwork(snapshot:BracketSnapshot):Promise<ExportArtwork>{
 const images:Record<string,string>={},dimensions:Record<string,{width:number;height:number}>={},warnings:string[]=[];
 const sources=artworkSources(snapshot);let cursor=0;
 const read=async()=>{while(cursor<sources.length){const source=sources[cursor++];try{
  const url=new URL(source,window.location.href);
  if(!['http:','https:','data:','blob:'].includes(url.protocol))throw new Error('Unsupported image address');
  const response=await fetch(url.href,{signal:AbortSignal.timeout(15000)});
  if(!response.ok)throw new Error(`HTTP ${response.status}`);
  const blob=await response.blob();
  if(blob.size>8*1024*1024)throw new Error('Image exceeds export limit');
  if(!/^image\/(png|jpeg|webp|gif|avif)$/i.test(blob.type))throw new Error('Unsupported image format');
  const data=await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result));reader.onerror=()=>reject(new Error('Image could not be read'));reader.readAsDataURL(blob);});
  const image=new Image();
  await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(new Error('Image could not be decoded'));image.src=data;});
  images[source]=data;dimensions[source]={width:image.naturalWidth,height:image.naturalHeight};
 }catch{warnings.push(`Image could not be included: ${source.split('/').pop()?.slice(0,100)||'uploaded image'}`);}}};
 await Promise.all(Array.from({length:Math.min(4,sources.length)},read));
 return {images,dimensions,warnings};
}

/** Render the entire logical bracket, never the browser's cropped or zoomed viewport. */
export function renderBracketSvg(snapshot:BracketSnapshot,artwork:ExportArtwork={images:{},warnings:[]}):{svg:string;width:number;height:number}{
 const b=snapshot.tournament,c=resolvedColors(b),layout=bracketLayout(b.size),header=154,footer=76,width=Math.max(1000,layout.width),height=layout.height+header+footer;
 const entries=new Map(snapshot.entries.map(e=>[e.id,e])),matches=[...snapshot.matches].sort((a,b)=>a.round-b.round||a.position-b.position);
 const assets=new Map(Object.entries(artwork.images).filter(([,value])=>/^data:image\/(png|jpeg|webp|gif|avif);base64,[A-Za-z0-9+/=]+$/i.test(value)).map(([source,data],i)=>[source,{id:`export-image-${i}`,data,...(source===animeSource?animeSourceSize:artwork.dimensions?.[source]||{width:100,height:100})}]));
 const text=(x:number,y:number,value:string,size=13,fill=c.text,attrs='')=>`<text x="${x}" y="${y}" fill="${escapeSvg(fill)}" font-size="${size}" ${attrs}>${escapeSvg(value)}</text>`;
 const rect=(x:number,y:number,w:number,h:number,fill:string,attrs='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${escapeSvg(fill)}" ${attrs}/>`;
 let cropSequence=0;
 function art(source:string|null|undefined,x:number,y:number,w:number,h:number,label='Image',fit='contain'){
  if(!source)return '';
  const crop=animeLogo(source),asset=assets.get(crop?animeSource:source);
  if(!asset)return `<g role="img" aria-label="${escapeSvg(label+' unavailable')}">${rect(x,y,w,h,c.input,'rx="3"')}${text(x+w/2,y+h/2+3,'×',16,c.muted,'text-anchor="middle"')}</g>`;
  if(crop){
   // A viewBox maps the crop but does not clip letterboxed space. Explicitly
   // clip source coordinates so neighboring rows of the sprite cannot bleed.
   const clip=`export-sprite-crop-${++cropSequence}`;
   return `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${crop.x} ${crop.y} ${crop.width} ${crop.height}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${escapeSvg(label)}"><defs><clipPath id="${clip}" clipPathUnits="userSpaceOnUse"><rect x="${crop.x}" y="${crop.y}" width="${crop.width}" height="${crop.height}"/></clipPath></defs><g clip-path="url(#${clip})"><use href="#${asset.id}" xlink:href="#${asset.id}" width="${animeSourceSize.width}" height="${animeSourceSize.height}"/></g></svg>`;
  }
  return `<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="0 0 ${asset.width} ${asset.height}" preserveAspectRatio="xMidYMid ${fit==='cover'?'slice':'meet'}" role="img" aria-label="${escapeSvg(label)}"><use href="#${asset.id}" xlink:href="#${asset.id}"/></svg>`;
 }
 const final=matches.find(m=>m.round===layout.depth),champion=final?.winner_id?entries.get(final.winner_id):undefined;
 const state=snapshot.kind==='picks'?'Personal picks':(b.status==='complete'||b.status==='completed')?'Completed':b.status==='draft'?'Draft':`In progress · ${roundName(b.current_round,b.size,b.format)}`;
 const hidden=matches.some(m=>m.counts===null);
 const lines:string[]=[`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-labelledby="export-title export-description" style="font-family:Arial,Helvetica,sans-serif">`,
  `<title id="export-title">${escapeSvg(b.title||'Tournament bracket')}</title><desc id="export-description">${escapeSvg(`${b.size} entries; ${matches.length} matches. ${state}. Snapshot ${snapshot.exportedAt}. ${champion?'Champion: '+(champion.name||`Entry ${champion.seed}`):'Champion not decided.'}`)}</desc>`,
  `<defs>${[...assets.values()].map(asset=>`<image id="${asset.id}" xlink:href="${asset.data}" width="${asset.width}" height="${asset.height}"/>`).join('')}</defs>`,
  rect(0,0,width,height,c.page),rect(0,header,width,layout.height,c.board)];
 const background=b.appearance?.images?.board_background;
 if(background){
  if(b.appearance.board_fit==='tile'){
   lines.push(`<defs><pattern id="export-board-bg" width="360" height="360" patternUnits="userSpaceOnUse">${art(background,0,0,360,360,'Background','cover')}</pattern></defs><rect x="0" y="${header}" width="${width}" height="${layout.height}" fill="url(#export-board-bg)" opacity="${Math.max(0,Math.min(100,b.appearance.board_opacity??65))/100}"/>`);
  }else lines.push(`<g opacity="${Math.max(0,Math.min(100,b.appearance.board_opacity??65))/100}">${art(background,0,header,width,layout.height,'Background',b.appearance.board_fit||'cover')}</g>`);
 }
 const brandWidth=b.brand_image?112:0;
 // Reserve up to one em per glyph, including wide capitals and CJK text.
 // Small brackets use a wider export sheet so the header never gets cropped.
 lines.push(art(b.brand_image,26,22,88,75,'Tournament logo'),text(26+brandWidth,53,shortText(b.title||'Tournament bracket',Math.min(95,Math.floor((width-52-brandWidth)/29))),29,c.heading,'font-weight="700"'),text(26+brandWidth,80,`${b.size} contenders · ${Math.log2(b.size)} rounds · ${state}`,15,c.muted),text(26+brandWidth,107,`Snapshot: ${snapshot.exportedAt.replace('T',' ').replace('.000Z',' UTC').replace('Z',' UTC')}`,13,c.muted));
 if(b.description)lines.push(text(26+brandWidth,133,shortText(b.description,Math.floor((width-52-brandWidth)/12)),12,c.muted));
 lines.push(`<g transform="translate(${(width-layout.width)/2} ${header})">`);
 for(const m of matches.filter(m=>m.round<layout.depth)){
  const p=layout.position(m),next=matches.find(n=>n.round===m.round+1&&n.position===Math.floor(m.position/2));if(!next)continue;
  const n=layout.position(next),x=p.right?p.x:p.x+NODE_WIDTH,xx=p.right?n.x+NODE_WIDTH:n.x,mid=(x+xx)/2;
  lines.push(`<path d="M ${x} ${p.y+NODE_HEIGHT/2} H ${mid} V ${n.y+NODE_HEIGHT/2} H ${xx}" fill="none" stroke="${escapeSvg(m.winner_id?c.winner:c.connector)}" stroke-width="${m.winner_id?2:1.4}" opacity=".8"/>`);
 }
 for(let r=0;r<layout.depth;r++)for(const x of [24+r*(NODE_WIDTH+ROUND_GAP),layout.width-24-NODE_WIDTH-r*(NODE_WIDTH+ROUND_GAP)])lines.push(text(x+NODE_WIDTH/2,24,roundName(r,b.size,b.format),12,c.muted,'text-anchor="middle" font-weight="700"'));
 const centerX=layout.width/2,centerY=(layout.height-NODE_HEIGHT)/2-110,centerLogo=champion?(b.appearance?.images?.champion_logo||b.appearance?.images?.center_logo):b.appearance?.images?.center_logo;
 lines.push(art(centerLogo,centerX-36,centerY-50,72,44,champion?'Champion logo':'Center logo'),text(centerX,centerY+10,champion?(snapshot.kind==='picks'?'YOUR CHAMPION':'CHAMPION'):(isRegionalFormat(b.format)?'CHAMPIONSHIP':'THE FINAL'),14,c.winner,'text-anchor="middle" font-weight="700"'),text(centerX,centerY+37,shortText(champion?.name||(champion?`Entry ${champion.seed}`:'To be decided'),25),18,c.heading,'text-anchor="middle" font-weight="700"'));
 if(isRegionalFormat(b.format))for(const m of matches.filter(m=>m.round===3)){
  const p=layout.position(m),entry=snapshot.entries[m.position*16],region=entry?entryRegion(entry,b.format):null;
  if(region)lines.push(text(p.x+NODE_WIDTH/2,p.y-15,region.toUpperCase(),14,c.link,'text-anchor="middle" font-weight="700"'));
 }
 if(champion?.image&&!centerLogo)lines.push(art(champion.image,centerX-42,centerY-50,84,36,champion.name));
 for(const m of matches){
  const p=layout.position(m),visible=m.counts!==null;
  lines.push(`<g data-match-id="${escapeSvg(m.id)}"><title>${escapeSvg(`${roundName(m.round,b.size,b.format)} · Match ${m.position+1}`)}</title>`,rect(p.x,p.y,NODE_WIDTH,NODE_HEIGHT,c.card,`rx="9" stroke="${escapeSvg(m.status==='open'?c.activeBorder:c.border)}" stroke-width="1.2"`),rect(p.x+1,p.y+1,NODE_WIDTH-2,28,c.matchHeader,'rx="8"'));
  const status=m.winner_id?(snapshot.kind==='picks'?'Picked':'Result'):m.status==='open'?(snapshot.kind==='picks'?'Pick a winner':'Open'):m.status==='closed'?'Closed':'Upcoming';
  lines.push(text(p.x+11,p.y+19,m.round===layout.depth?roundName(m.round,b.size,b.format):`Match ${m.position+1}`,11,c.muted),text(p.x+NODE_WIDTH-10,p.y+19,visible&&m.total!==null?`${status} · ${m.total} votes`:status,10,c.muted,'text-anchor="end"'));
  [m.a_id,m.b_id].forEach((id,side)=>{
   const entry=id?entries.get(id):undefined,y=p.y+30+side*50,winner=!!id&&m.winner_id===id,picked=!!id&&m.myVote===id;
   if(winner||picked)lines.push(rect(p.x+3,y,NODE_WIDTH-6,49,c.selected,'rx="3"'));
   if(entry){
    const count=visible?m.counts![entry.id]??0:null,pct=visible&&m.total!==null?(m.total?Math.round(count!/m.total*100):0):null;
    if(pct!==null&&pct>0)lines.push(rect(p.x+4,y+46,(NODE_WIDTH-8)*pct/100,3,side===0?c.voteA:c.voteB));
    lines.push(text(p.x+10,y+23,String(displaySeed(entry,b.format)).padStart(2,'0'),10,c.muted),art(entry.image,p.x+28,y+11,38,25,entry.name||`Entry ${entry.seed}`));
    const labelX=p.x+(entry.image?72:31),textRight=p.x+NODE_WIDTH-(visible?60:14),chars=Math.max(12,Math.floor((textRight-labelX)/6.3));
    const marker=winner?(snapshot.kind==='picks'?'Your pick':'Winner'):picked?'Your pick':'';
    lines.push(`<g><title>${escapeSvg([entry.name||`Entry ${entry.seed}`,entry.subtitle,marker].filter(Boolean).join(' · '))}</title>`,text(labelX,y+21,shortText(entry.name||`Entry ${entry.seed}`,chars),12,winner?c.winner:c.text,'font-weight="700"'),text(labelX,y+37,shortText([marker,entry.subtitle].filter(Boolean).join(' · '),chars+2),10,c.muted),'</g>');
    if(pct!==null)lines.push(text(p.x+NODE_WIDTH-10,y+21,`${pct}%`,12,c.text,'text-anchor="end" font-weight="700"'),text(p.x+NODE_WIDTH-10,y+37,`${count} ${count===1?'vote':'votes'}`,9,c.muted,'text-anchor="end"'));
   }else lines.push(text(p.x+13,y+28,m.round===0?'Empty slot':`Winner of match ${m.position*2+side+1}`,12,c.muted));
  });
  lines.push('</g>');
 }
 lines.push('</g>',text(24,height-43,`Bracket Live · ${matches.filter(m=>!!m.winner_id).length} / ${matches.length} ${snapshot.kind==='picks'?'personal picks filled':'matches decided'}${hidden&&snapshot.kind!=='picks'?' · Unrevealed vote totals are omitted':''}`,13,c.muted),text(24,height-20,artwork.warnings.length?`${artwork.warnings.length} image${artwork.warnings.length===1?' was':'s were'} unavailable; marked ×. Names and results are preserved.`:'Point-in-time export. Export again to save the next stage.',12,c.muted),art(b.appearance?.images?.footer_logo,width-118,height-66,92,46,'Footer logo'),'</svg>');
 return {svg:lines.join(''),width,height};
}

/** Machine-readable match history; unrevealed counts stay blank, not zero. */
export function bracketSnapshotCsv(snapshot:BracketSnapshot){
 const entries=new Map(snapshot.entries.map(e=>[e.id,e]));
 const rows:unknown[][]=[['Exported at','Tournament','Round','Match','Status','Contender A','Contender B','Votes A','Votes B','Total votes',snapshot.kind==='picks'?'Predicted winner':'Winner','Your pick']];
 for(const m of [...snapshot.matches].sort((a,b)=>a.round-b.round||a.position-b.position))rows.push([snapshot.exportedAt,snapshot.tournament.title,roundName(m.round,snapshot.tournament.size,snapshot.tournament.format),m.position+1,m.status,entries.get(m.a_id||'')?.name||'',entries.get(m.b_id||'')?.name||'',m.counts===null?'':m.counts[m.a_id||'']??0,m.counts===null?'':m.counts[m.b_id||'']??0,m.counts===null?'':m.total??'',entries.get(m.winner_id||'')?.name||'',entries.get(m.myVote||'')?.name||'']);
 return '\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n');
}
