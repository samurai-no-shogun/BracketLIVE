// Durable, opt-in results mail. Sending is deliberately outside advancement so
// provider outages cannot change votes or hold up a tournament.
const sqlNow="CAST((julianday('now')-2440587.5)*86400000 AS INTEGER)";
type Summary={title:string;size:number;round:number;kind:'round'|'blocked';complete:boolean;next_deadline:number|null;timezone:string;reason?:string|null;matches:{a:string;b:string;a_votes:number;b_votes:number;winner:string|null;decided_by:string|null}[]};
export function creatorAlertProviderReady(env:Cloudflare.Env){try{const u=new URL(env.AUTH_ORIGIN??'');return u.protocol==='https:'&&!u.username&&!u.password&&u.pathname==='/'&&!u.search&&!u.hash&&!!env.RESEND_API_KEY?.trim()&&!!env.AUTH_EMAIL_FROM?.trim();}catch{return false;}}
export function creatorAlertPayload(summary:Summary,bracketId:string,to:string,from:string,origin:string){
 const name=summary.round===Math.log2(summary.size)-1?'Final':`Round of ${summary.size/2**summary.round}`;
 const lines=summary.matches.map(m=>{const total=m.a_votes+m.b_votes,pct=(n:number)=>total?Math.round(n/total*100):0;return `${m.a}: ${m.a_votes} votes (${pct(m.a_votes)}%) vs ${m.b}: ${m.b_votes} votes (${pct(m.b_votes)}%)\n${m.winner?'Winner: '+m.winner+(m.decided_by==='seed'?' (seed tiebreak)':''): m.a_votes===m.b_votes?'Tied — organizer decision required':'Leader: '+(m.a_votes>m.b_votes?m.a:m.b)+' (awaiting tied match resolution)'}`;});
 let next='';if(summary.next_deadline&&summary.kind!=='blocked'){try{next=`\n\nNext round closes: ${new Intl.DateTimeFormat('en-US',{timeZone:summary.timezone,dateStyle:'full',timeStyle:'long'}).format(summary.next_deadline)} (${summary.timezone}).`;}catch{next=`\n\nNext round closes: ${new Date(summary.next_deadline).toISOString()}.`;}}
 if(summary.reason&&summary.kind!=='blocked')next=`\n\nScheduling paused: ${summary.reason}`;
 const champion=summary.complete?summary.matches[0]?.winner:null;
 const subject=summary.kind==='blocked'?`${summary.title}: tied round needs your decision`:summary.complete?`${summary.title}: tournament complete`:`${summary.title}: ${name} results`;
 const text=`${summary.title}\n${name}${summary.kind==='blocked'?' is closed for voting and paused on ties. Resolve the tied matches in your organizer workspace to open the next round.':summary.complete?' is complete.':' is complete and the winners have progressed.'}${champion?'\n\nChampion: '+champion:''}\n\n${lines.join('\n\n')}${next}\n\nPublic results: ${origin}/b/${encodeURIComponent(bracketId)}\n\nManage alerts in your signed-in organizer workspace → Schedule & alerts. You receive this because you enabled creator results alerts.`;
 return {from,to:[to],subject:subject.replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,250),text};
}
export async function deliverCreatorAlerts(env:Cloudflare.Env,options:{limit?:number;fetch?:typeof fetch}={}){
 const database=env.DB;if(!database||!creatorAlertProviderReady(env))return 0;
 const limit=Math.max(1,Math.min(40,Math.floor(options.limit??20)));
 const rows=(await database.prepare(`SELECT o.id FROM creator_alert_outbox o WHERE o.status IN ('pending','sending') AND o.next_attempt_at<=${sqlNow} AND (o.lease_until IS NULL OR o.lease_until<=${sqlNow}) ORDER BY o.next_attempt_at,o.created_at,o.id LIMIT ?`).bind(limit).all<{id:string}>()).results;
 let sent=0;
 for(const item of rows){
  const lease=crypto.randomUUID();
  const eligible=`EXISTS(SELECT 1 FROM creator_alert_settings s JOIN accounts a ON a.id=s.account_id JOIN brackets b ON b.id=s.bracket_id WHERE s.bracket_id=o.bracket_id AND s.account_id=o.account_id AND s.enabled=1 AND b.is_test=0 AND b.owner_id=a.identity_id AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=b.id AND identity_id=a.identity_id) AND EXISTS(SELECT 1 FROM account_credentials WHERE account_id=a.id))`;
  const result=await database.prepare(`UPDATE creator_alert_outbox AS o SET status='sending',lease_token=?,lease_until=${sqlNow}+60000 WHERE o.id=? AND o.status IN ('pending','sending') AND o.next_attempt_at<=${sqlNow} AND (o.lease_until IS NULL OR o.lease_until<=${sqlNow}) AND o.attempts<10 AND (o.first_attempt_at IS NULL OR o.first_attempt_at>${sqlNow}-82800000) AND ${eligible}`).bind(lease,item.id).run();
  if(!result.meta.changes){await database.prepare(`UPDATE creator_alert_outbox AS o SET status=CASE WHEN NOT ${eligible} THEN 'cancelled' ELSE 'failed' END WHERE o.id=? AND status IN ('pending','sending') AND (lease_until IS NULL OR lease_until<=${sqlNow}) AND (NOT ${eligible} OR attempts>=10 OR first_attempt_at<=${sqlNow}-82800000)`).bind(item.id).run();continue;}
  const row=await database.prepare('SELECT o.*,r.summary,a.email FROM creator_alert_outbox o JOIN tournament_round_results r ON r.id=o.id JOIN accounts a ON a.id=o.account_id WHERE o.id=? AND o.lease_token=?').bind(item.id,lease).first<{id:string;bracket_id:string;summary:string;email:string;payload:string|null;attempts:number}>();if(!row)continue;
  let payload=row.payload;
  try{payload??=JSON.stringify(creatorAlertPayload(JSON.parse(row.summary),row.bracket_id,row.email,env.AUTH_EMAIL_FROM!,new URL(env.AUTH_ORIGIN!).origin));}catch{await database.prepare("UPDATE creator_alert_outbox SET status='failed',lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?").bind(item.id,lease).run();continue;}
  const reserved=await database.prepare(`UPDATE creator_alert_outbox AS o SET payload=COALESCE(payload,?),attempts=attempts+1,first_attempt_at=COALESCE(first_attempt_at,${sqlNow}) WHERE id=? AND lease_token=? AND status='sending' AND ${eligible}`).bind(payload,item.id,lease).run();
  if(!reserved.meta.changes){await database.prepare("UPDATE creator_alert_outbox SET status='cancelled',lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?").bind(item.id,lease).run();continue;}
  let ok=false,permanent=false;
  try{const response=await (options.fetch??fetch)('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${env.RESEND_API_KEY}`,'Content-Type':'application/json','Idempotency-Key':`bl-results-${item.id}`},body:payload,signal:AbortSignal.timeout(10000)});ok=response.ok;permanent=!ok&&response.status>=400&&response.status<500&&![408,409,429].includes(response.status);await response.body?.cancel();}catch{/* Retry the exact persisted payload and idempotency key; no private data logs. */}
  if(ok){const updated=await database.prepare(`UPDATE creator_alert_outbox SET status='sent',sent_at=${sqlNow},lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?`).bind(item.id,lease).run();sent+=Number(!!updated.meta.changes);}
  else{const attempts=row.attempts+1,delay=Math.min(3600000,30000*2**Math.min(attempts-1,7));await database.prepare(`UPDATE creator_alert_outbox SET status=?,next_attempt_at=${sqlNow}+?,lease_token=NULL,lease_until=NULL WHERE id=? AND lease_token=?`).bind(permanent||attempts>=10?'failed':'pending',delay,item.id,lease).run();}
 }
 return sent;
}
