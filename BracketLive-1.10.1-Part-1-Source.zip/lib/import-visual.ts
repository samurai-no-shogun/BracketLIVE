import { validateImage } from './image-validation';

/** Original files stay in the browser. This module only reads user-selected bytes. */
export const VISUAL_IMPORT_LIMITS = {
  fileBytes: 10 * 1024 * 1024,
  imagePixels: 20_000_000,
  imageDimension: 8192,
  renderPixels: 4_000_000,
  renderDimension: 3000,
  pdfPages: 200,
  textCharacters: 100_000,
  textLines: 2048,
  operationMilliseconds: 120_000,
} as const;

export type VisualImportOptions = {
  signal?: AbortSignal;
  onProgress?: (message: string, progress?: number) => void;
  /** PDF pages are one-based. Exactly one page is extracted per invocation. */
  page?: number;
  /** false disables scanned-page fallback; true forces OCR of the selected PDF page. */
  ocr?: boolean;
};
export type VisualImportLine = {
  text: string;
  page: number;
  x: number;
  y: number;
  width: number;
  height: number;
  confidence?: number;
};
export type VisualImportResult = {
  text: string;
  warnings: string[];
  pageCount?: number;
  lines?: VisualImportLine[];
};

const OCR_REVIEW_WARNING = 'Text recognition can misread names and combine columns. Review the imported entries and matchup order before applying them. Images and bracket connections are not recreated automatically.';

function cancelled(signal: AbortSignal): never {
  if (signal.reason instanceof Error) throw signal.reason;
  throw new DOMException('Import cancelled.', 'AbortError');
}
function checkSignal(signal: AbortSignal) {
  if (signal.aborted) cancelled(signal);
}
function guard<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  // The promise may already have started before a cancellation reaches this call.
  if (signal.aborted) { void promise.catch(() => {}); cancelled(signal); }
  return new Promise<T>((resolve, reject) => {
    const abort = () => {
      try { cancelled(signal); } catch (error) { reject(error); }
    };
    signal.addEventListener('abort', abort, { once: true });
    promise.then(value => {
      signal.removeEventListener('abort', abort);
      if (signal.aborted) abort(); else resolve(value);
    }, error => {
      signal.removeEventListener('abort', abort);
      reject(error);
    });
  });
}

export function inspectVisualImage(bytes: Uint8Array) {
  if (bytes.length > VISUAL_IMPORT_LIMITS.fileBytes) throw new Error('Use a snapshot smaller than 10 MB.');
  const image = validateImage(bytes);
  if (image.ext === 'gif') throw new Error('Use a PNG, JPG, or WebP snapshot.');
  assertVisualDimensions(image.width, image.height);
  return image;
}
export function assertVisualDimensions(width: number, height: number) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 ||
    width > VISUAL_IMPORT_LIMITS.imageDimension || height > VISUAL_IMPORT_LIMITS.imageDimension ||
    width * height > VISUAL_IMPORT_LIMITS.imagePixels) {
    throw new Error('Use a snapshot no larger than 8,192 pixels per side and 20 megapixels.');
  }
}
export function visualRenderSize(width: number, height: number) {
  const scale = Math.min(1, VISUAL_IMPORT_LIMITS.renderDimension / Math.max(width, height),
    Math.sqrt(VISUAL_IMPORT_LIMITS.renderPixels / (width * height)));
  return { width: Math.max(1, Math.floor(width * scale)), height: Math.max(1, Math.floor(height * scale)), scale };
}
export function boundVisualText(text: string): string {
  if (text.length > VISUAL_IMPORT_LIMITS.textCharacters) throw new Error('This page contains too much text. Crop the snapshot or import a smaller section.');
  const clean = text.replace(/\r\n?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim();
  if (clean.split('\n').length > VISUAL_IMPORT_LIMITS.textLines) throw new Error('This page contains too many rows. Import a smaller section.');
  return clean;
}
function isPDF(bytes: Uint8Array) {
  // PDF headers may have a short leading byte prefix, but never use the filename as proof.
  const header = new TextDecoder('latin1').decode(bytes.subarray(0, 1024));
  return /%PDF-[12]\.[0-9]/.test(header);
}
async function bytesFor(file: File, signal: AbortSignal) {
  if (!file.size || file.size > VISUAL_IMPORT_LIMITS.fileBytes) throw new Error('Choose a nonempty file smaller than 10 MB.');
  return new Uint8Array(await guard(file.arrayBuffer(), signal));
}
function canvas(width: number, height: number) {
  const surface = document.createElement('canvas');
  surface.width = width;
  surface.height = height;
  const context = surface.getContext('2d', { willReadFrequently: false });
  if (!context) throw new Error('Your browser could not prepare this snapshot. Try a PNG or JPG file.');
  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, width, height);
  return { surface, context };
}
async function canvasBlob(surface: HTMLCanvasElement, signal: AbortSignal) {
  return guard(new Promise<Blob>((resolve, reject) => surface.toBlob(blob => {
    if (blob) resolve(blob); else reject(new Error('Your browser could not read this snapshot.'));
  }, 'image/png')), signal);
}
async function normalizeSnapshot(bytes: Uint8Array, signal: AbortSignal) {
  const image = inspectVisualImage(bytes);
  const localBlob = new Blob([new Uint8Array(bytes)], { type: image.type });
  let bitmap: ImageBitmap | null = null;
  let htmlImage: HTMLImageElement | null = null;
  let objectURL: string | null = null;
  let surface: HTMLCanvasElement | null = null;
  try {
    checkSignal(signal);
    if (typeof createImageBitmap === 'function') {
      const decoding = createImageBitmap(localBlob);
      // A browser decode cannot be cancelled; dispose a late result after cancellation.
      decoding.then(result => { if (signal.aborted) result.close(); }, () => {});
      bitmap = await guard(decoding, signal);
      assertVisualDimensions(bitmap.width, bitmap.height);
    } else {
      objectURL = URL.createObjectURL(localBlob);
      htmlImage = new Image();
      const decoded = new Promise<void>((resolve, reject) => {
        htmlImage!.onload = () => resolve();
        htmlImage!.onerror = () => reject(new Error('This snapshot is damaged or cannot be decoded.'));
        htmlImage!.src = objectURL!;
      });
      await guard(decoded, signal);
      assertVisualDimensions(htmlImage.naturalWidth, htmlImage.naturalHeight);
    }
    const width = bitmap?.width ?? htmlImage!.naturalWidth;
    const height = bitmap?.height ?? htmlImage!.naturalHeight;
    const size = visualRenderSize(width, height);
    const drawing = canvas(size.width, size.height);
    surface = drawing.surface;
    drawing.context.drawImage(bitmap ?? htmlImage!, 0, 0, size.width, size.height);
    const blob = await canvasBlob(surface, signal);
    return { blob, width: size.width, height: size.height, scaled: size.scale < 1 };
  } finally {
    bitmap?.close();
    if (htmlImage) htmlImage.src = '';
    if (objectURL) URL.revokeObjectURL(objectURL);
    if (surface) { surface.width = 0; surface.height = 0; }
  }
}

/** An outer worker permits immediate cancellation even while Tesseract initializes. */
async function recognize(blob: Blob, signal: AbortSignal, progress?: VisualImportOptions['onProgress']) {
  checkSignal(signal);
  const worker = new Worker(new URL('./import-ocr.worker.ts', import.meta.url), { type: 'module' });
  try {
    return await new Promise<{ text: string; lines: VisualImportLine[]; confidence: number }>((resolve, reject) => {
      const abort = () => {
        worker.terminate();
        try { cancelled(signal); } catch (error) { reject(error); }
      };
      const cleanup = () => signal.removeEventListener('abort', abort);
      signal.addEventListener('abort', abort, { once: true });
      worker.onmessage = (event: MessageEvent) => {
        if (event.data?.type === 'progress') {
          progress?.(String(event.data.message), Number(event.data.progress));
        } else if (event.data?.type === 'result') {
          cleanup();
          resolve(event.data.result);
        } else if (event.data?.type === 'error') {
          cleanup();
          reject(new Error('Text recognition could not read this snapshot. Try a sharper crop, or paste its names as text.'));
        }
      };
      worker.onerror = event => {
        event.preventDefault();
        cleanup();
        reject(new Error('Text recognition could not start. Try refreshing the page, or import a text or spreadsheet file.'));
      };
      worker.postMessage({ type: 'recognize', blob, origin: location.origin });
      if (signal.aborted) abort();
    });
  } finally {
    worker.terminate();
  }
}

async function extractSnapshot(bytes: Uint8Array, options: VisualImportOptions, signal: AbortSignal): Promise<VisualImportResult> {
  options.onProgress?.('Preparing snapshot', 0.05);
  const image = await normalizeSnapshot(bytes, signal);
  const result = await recognize(image.blob, signal, options.onProgress);
  const text = boundVisualText(result.text);
  if (!text) throw new Error('No readable names were found. Try a sharper crop or paste the names as text.');
  const warnings = [OCR_REVIEW_WARNING, 'Snapshot recognition currently reads English text.'];
  if (image.scaled) warnings.push('The snapshot was reduced to fit browser memory limits. Crop smaller text for more accurate recognition.');
  if (result.confidence < 65) warnings.push('Recognition confidence is low. Check every extracted name carefully.');
  options.onProgress?.('Snapshot ready for review', 1);
  return { text, warnings, lines: result.lines };
}

function pdfTextLines(items: unknown[], page: number): VisualImportLine[] {
  const lines: VisualImportLine[] = [];
  for (const item of items) {
    const candidate = item as { str?: unknown; transform?: unknown; width?: unknown; height?: unknown; hasEOL?: unknown };
    if (typeof candidate.str !== 'string' || !candidate.str.trim()) continue;
    const transform = Array.isArray(candidate.transform) ? candidate.transform : [];
    const x = Number(transform[4]) || 0, y = Number(transform[5]) || 0;
    const width = Number(candidate.width) || 0, height = Number(candidate.height) || Math.abs(Number(transform[3])) || 12;
    lines.push({ text: candidate.str, page, x, y, width, height });
    if (lines.length > VISUAL_IMPORT_LIMITS.textLines * 8) throw new Error('This PDF page contains too much text. Import a smaller section.');
  }
  // PDF coordinates increase upward. Preserve rows and column gaps as plain text hints.
  return lines.sort((a, b) => Math.abs(a.y - b.y) < Math.max(2, Math.min(a.height, b.height) * 0.3) ? a.x - b.x : b.y - a.y);
}
function textFromPDFLines(items: VisualImportLine[]) {
  const rows: { y: number; height: number; parts: VisualImportLine[] }[] = [];
  for (const item of items) {
    const last = rows[rows.length - 1];
    if (last && Math.abs(last.y - item.y) <= Math.max(2, Math.min(last.height, item.height) * 0.3)) last.parts.push(item);
    else rows.push({ y: item.y, height: item.height, parts: [item] });
  }
  return rows.map(row => {
    const sorted = row.parts.sort((a, b) => a.x - b.x);
    return sorted.map((part, index) => {
      if (!index) return part.text;
      const previous = sorted[index - 1];
      const gap = part.x - (previous.x + previous.width);
      return (gap > Math.max(12, part.height * 1.2) ? '\t' : ' ') + part.text;
    }).join('');
  }).join('\n');
}

async function readPDFItems(page: import('pdfjs-dist').PDFPageProxy, signal: AbortSignal) {
  // getTextContent buffers a whole page. Stream it so compressed text cannot grow without a cap.
  const reader = page.streamTextContent({ disableNormalization: false }).getReader();
  const items: unknown[] = [];
  let characters = 0;
  let finished = false;
  const abort = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', abort, { once: true });
  try {
    for (;;) {
      const chunk = await guard(reader.read(), signal);
      if (chunk.done) { finished = true; break; }
      for (const item of chunk.value.items) {
        if ('str' in item) characters += item.str.length;
        if (characters > VISUAL_IMPORT_LIMITS.textCharacters || items.length >= VISUAL_IMPORT_LIMITS.textLines * 8) {
          throw new Error('This PDF page contains too much text. Import a smaller section.');
        }
        items.push(item);
      }
    }
    return items;
  } finally {
    signal.removeEventListener('abort', abort);
    if (!finished) void reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

async function extractPDF(bytes: Uint8Array, options: VisualImportOptions, signal: AbortSignal): Promise<VisualImportResult> {
  const pageNumber = options.page ?? 1;
  if (!Number.isInteger(pageNumber) || pageNumber < 1 || pageNumber > VISUAL_IMPORT_LIMITS.pdfPages) throw new Error('Choose a PDF page from 1 to 200.');
  options.onProgress?.('Opening PDF', 0.05);
  const pdfjs = await guard(import('pdfjs-dist'), signal);
  pdfjs.GlobalWorkerOptions.workerSrc = '/import-assets/pdf.worker.min.mjs';
  // An explicit native port prevents PDF.js from falling back to main-thread parsing.
  const nativeWorker = new Worker('/import-assets/pdf.worker.min.mjs', { type: 'module' });
  const pdfWorker = pdfjs.PDFWorker.create({ port: nativeWorker });
  let loading: ReturnType<typeof pdfjs.getDocument>;
  try {
    // PDF.js 6 has no runtime eval support. No viewer, annotation scripts, links, or XFA are used.
    loading = pdfjs.getDocument({
    data: bytes,
    worker: pdfWorker,
    enableXfa: false,
    disableAutoFetch: true,
    disableStream: true,
    disableRange: true,
    disableFontFace: true,
    useSystemFonts: true,
    useWorkerFetch: false,
    useWasm: false,
    cMapUrl: '/import-assets/pdf-cmaps/',
    cMapPacked: true,
    standardFontDataUrl: '/import-assets/pdf-fonts/',
    wasmUrl: '/import-assets/pdf-wasm/',
    stopAtErrors: true,
    maxImageSize: VISUAL_IMPORT_LIMITS.imagePixels,
    canvasMaxAreaInBytes: VISUAL_IMPORT_LIMITS.renderPixels * 4,
    verbosity: 0,
    });
  } catch (error) {
    pdfWorker.destroy(); nativeWorker.terminate(); throw error;
  }
  let surface: HTMLCanvasElement | null = null;
  let render: { cancel: () => void } | null = null;
  const abort = () => {
    render?.cancel();
    void loading.destroy().catch(() => {});
    pdfWorker.destroy();
    nativeWorker.terminate();
  };
  signal.addEventListener('abort', abort, { once: true });
  try {
    const document = await guard(loading.promise, signal);
    if (document.numPages > VISUAL_IMPORT_LIMITS.pdfPages) throw new Error('Use a PDF with 200 pages or fewer. Export the contender or first-round pages into a smaller PDF.');
    if (pageNumber > document.numPages) throw new Error(`This PDF has ${document.numPages} page${document.numPages === 1 ? '' : 's'}. Choose a page that exists.`);
    options.onProgress?.(`Reading PDF page ${pageNumber}`, 0.2);
    const page = await guard(document.getPage(pageNumber), signal);
    const items = await readPDFItems(page, signal);
    const lines = pdfTextLines(items, pageNumber);
    let text = boundVisualText(textFromPDFLines(lines));
    const warnings: string[] = [];
    if (document.numPages > 1) warnings.push(`Only page ${pageNumber} of ${document.numPages} was read. Choose another page if its entries are the ones you need.`);
    if (!text || options.ocr === true) {
      if (options.ocr === false) throw new Error('This PDF page has no selectable text. Enable snapshot recognition to read a scanned page.');
      options.onProgress?.(`Preparing scanned page ${pageNumber}`, 0.3);
      const base = page.getViewport({ scale: 1 });
      if (!Number.isFinite(base.width) || !Number.isFinite(base.height) || base.width <= 0 || base.height <= 0) throw new Error('This PDF page has invalid dimensions.');
      // Render at up to 2x, with a hard canvas pixel cap on mobile and desktop.
      const size = visualRenderSize(base.width * 2, base.height * 2);
      const viewport = page.getViewport({ scale: size.width / base.width });
      const drawing = canvas(Math.max(1, Math.floor(viewport.width)), Math.max(1, Math.floor(viewport.height)));
      surface = drawing.surface;
      const rendering = page.render({ canvas: surface, canvasContext: drawing.context, viewport, annotationMode: pdfjs.AnnotationMode.DISABLE });
      render = rendering;
      await guard(rendering.promise, signal);
      const blob = await canvasBlob(surface, signal);
      const recognized = await recognize(blob, signal, options.onProgress);
      text = boundVisualText(recognized.text);
      if (!text) throw new Error('No readable names were found on this page. Try another page or a sharper snapshot.');
      warnings.push(OCR_REVIEW_WARNING, 'Scanned-page recognition currently reads English text.');
      if (recognized.confidence < 65) warnings.push('Recognition confidence is low. Check every extracted name carefully.');
      options.onProgress?.('PDF page ready for review', 1);
      return { text, warnings, pageCount: document.numPages, lines: recognized.lines.map(line => ({ ...line, page: pageNumber })) };
    }
    warnings.push('PDF text order may differ from the visual bracket layout. Review names, columns, and matchup order before applying them.');
    options.onProgress?.('PDF page ready for review', 1);
    return { text, warnings, pageCount: document.numPages, lines };
  } catch (error) {
    if (signal.aborted) cancelled(signal);
    if (error instanceof Error && /password|encrypted/i.test(error.name + error.message)) throw new Error('Password-protected PDFs cannot be imported. Export an unlocked copy first.');
    throw error;
  } finally {
    signal.removeEventListener('abort', abort);
    render?.cancel();
    // Destroy directly instead of waiting on a potentially stalled worker response.
    void loading.destroy().catch(() => {});
    pdfWorker.destroy();
    nativeWorker.terminate();
    if (surface) { surface.width = 0; surface.height = 0; }
  }
}

export async function extractVisualImport(file: File, options: VisualImportOptions = {}): Promise<VisualImportResult> {
  if (typeof window === 'undefined' || typeof Worker === 'undefined') throw new Error('Snapshot and PDF imports need a browser that supports web workers.');
  const controller = new AbortController();
  const propagateAbort = () => controller.abort(options.signal?.reason ?? new DOMException('Import cancelled.', 'AbortError'));
  options.signal?.addEventListener('abort', propagateAbort, { once: true });
  if (options.signal?.aborted) propagateAbort();
  const timer = setTimeout(() => controller.abort(new Error('Import stopped after two minutes. Try a smaller crop or page, or import text instead.')), VISUAL_IMPORT_LIMITS.operationMilliseconds);
  try {
    const bytes = await bytesFor(file, controller.signal);
    const result = isPDF(bytes) ? await extractPDF(bytes, options, controller.signal) : await extractSnapshot(bytes, options, controller.signal);
    checkSignal(controller.signal);
    return result;
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener('abort', propagateAbort);
  }
}
