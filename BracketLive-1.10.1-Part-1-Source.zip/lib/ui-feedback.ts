/** Small, locally synthesized cues. Audio is never fetched or started on page load. */
type FeedbackSound='vote'|'undo';
type FeedbackMatch={id:string;status:string;myVote?:string|null};
let context:AudioContext|null=null;
const playing=new Set<OscillatorNode>();
let removeListeners:(()=>void)|null=null;
let preferenceMuted:boolean|undefined;

export function voteFeedbackFor(matches:FeedbackMatch[],matchId:string,entryId:string|null){
 const match=matches.find(item=>item.id===matchId);
 if(!match||(entryId===null?!!match.myVote:match.myVote!==entryId))return null;
 if(entryId===null)return {kind:'undo' as const,complete:false};
 const open=matches.filter(item=>item.status==='open');
 return {kind:'vote' as const,complete:open.length>0&&open.every(item=>!!item.myVote)};
}

export function isFeedbackMuted():boolean{
 if(typeof window==='undefined')return true;
 if(preferenceMuted!==undefined)return preferenceMuted;
 try{return ['1','true'].includes(window.localStorage.getItem('bl_muted')??'')||document.documentElement.dataset.muted==='true';}
 catch{return document.documentElement.dataset.muted==='true';}
}

function stopPlaying(){
 for(const oscillator of playing){try{oscillator.stop();oscillator.disconnect();}catch{}}
 playing.clear();
}

/** Called synchronously from the vote gesture, before its network request. */
export function primeFeedbackAudio(){
 if(typeof window==='undefined'||isFeedbackMuted())return;
 // Programmatic tools, timers and server events must never unlock browser audio.
 if(typeof navigator!=='undefined'&&navigator.userActivation&&!navigator.userActivation.isActive)return;
 try{
  if(!removeListeners){
   const preferences=(event:Event)=>{
    const muted=(event as CustomEvent<{muted?:boolean}>).detail?.muted;
    preferenceMuted=typeof muted==='boolean'?muted:undefined;
    if(isFeedbackMuted())stopPlaying();
   };
   const storage=(event:StorageEvent)=>{if(event.key===null||event.key==='bl_muted'){preferenceMuted=undefined;if(isFeedbackMuted())stopPlaying();}};
   const visibility=()=>{if(document.hidden)stopPlaying();};
   window.addEventListener('bl-preferences-change',preferences);
   window.addEventListener('storage',storage);
   document.addEventListener('visibilitychange',visibility);
   removeListeners=()=>{window.removeEventListener('bl-preferences-change',preferences);window.removeEventListener('storage',storage);document.removeEventListener('visibilitychange',visibility);};
  }
  const Constructor=window.AudioContext||(window as typeof window&{webkitAudioContext?:typeof AudioContext}).webkitAudioContext;
  if(!Constructor)return;
  if(!context||context.state==='closed')context=new Constructor();
  if(context.state==='suspended')void context.resume().catch(()=>{});
 }catch{/* Optional audio never interrupts voting. */}
}

/** A cue is played only after the server confirms the vote or undo. */
export function playFeedbackSound(kind:FeedbackSound){
 if(isFeedbackMuted()||typeof document==='undefined'||document.hidden||!context||context.state!=='running')return;
 try{
  stopPlaying();
  const now=context.currentTime;
  const notes=kind==='vote'?[{frequency:523.25,offset:0},{frequency:659.25,offset:.065}]:[{frequency:392,offset:0}];
  for(const note of notes){
   const oscillator=context.createOscillator(),gain=context.createGain(),start=now+note.offset,end=start+.21;
   oscillator.type='sine';oscillator.frequency.setValueAtTime(note.frequency,start);
   gain.gain.setValueAtTime(0,start);gain.gain.linearRampToValueAtTime(kind==='vote'?.018:.013,start+.018);gain.gain.exponentialRampToValueAtTime(.0001,end);
   oscillator.connect(gain);gain.connect(context.destination);playing.add(oscillator);
   oscillator.onended=()=>{playing.delete(oscillator);oscillator.disconnect();gain.disconnect();};
   oscillator.start(start);oscillator.stop(end+.01);
  }
 }catch{/* Audio can be unavailable, suspended or blocked without affecting a vote. */}
}

export function disposeFeedbackAudio(){
 stopPlaying();removeListeners?.();removeListeners=null;preferenceMuted=undefined;
 const previous=context;context=null;
 if(previous&&previous.state!=='closed'){try{void previous.close().catch(()=>{});}catch{}}
}
