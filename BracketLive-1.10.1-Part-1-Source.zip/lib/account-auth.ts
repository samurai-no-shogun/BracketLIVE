import {env} from 'cloudflare:workers';
import {ApiError,anonymousIdentity,db,hash,json,limitedBody,sqlNow,token} from './server';

const SESSION_SECONDS=30*24*60*60, FLOW_SECONDS=15*60;
const SESSION_COOKIE='bl_account',FLOW_COOKIE='bl_auth_flow';
const encoder=new TextEncoder();
export type AccountUser={id:string;name:string;email:string};
type AccountRow=AccountUser&{identity_id:string};
type Challenge={token_hash:string;kind:string;browser_hash:string;source_identity:string;subject_hash:string;payload:string;return_to:string;created_at:number;expires_at:number;consumed_at:number|null;claim:string|null};
const config=()=>env as Cloudflare.Env;
function cookie(request:Request,name:string){
 const values=(request.headers.get('cookie')??'').split(';').map(x=>x.trim()).filter(x=>x.startsWith(name+'='));
 if(values.length>1)throw new ApiError(400,'Conflicting account cookies. Clear this site’s cookies and sign in again.');
 const value=values[0]?.slice(name.length+1);return value&&/^[a-f0-9]{64}$/.test(value)?value:null;
}
function setCookie(request:Request,name:string,value:string|null,seconds:number){return `${name}=${value??''}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${value?seconds:0}${new URL(request.url).protocol==='https:'?'; Secure':''}`;}
function publicUser(row:AccountRow):AccountUser{return {id:row.id,name:row.name,email:row.email};}
export function authOrigin(){
 try{const value=config().AUTH_ORIGIN?.trim();if(!value)return null;const url=new URL(value);if(url.origin!==value||url.username||url.password)return null;if(url.protocol!=='https:'&&!(url.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(url.hostname)))return null;return url.origin;}catch{return null;}
}
export function accountProviders(request:Request){const valid=authOrigin()===new URL(request.url).origin,c=config();return {google:!!(valid&&c.GOOGLE_CLIENT_ID?.trim()&&c.GOOGLE_CLIENT_SECRET?.trim()),email:!!(valid&&c.RESEND_API_KEY?.trim()&&c.AUTH_EMAIL_FROM?.trim())};}
export function safeReturnTo(value:unknown){if(typeof value!=='string'||value.length>1024||!value.startsWith('/')||value.startsWith('//')||/[\\\r\n\u0000]/.test(value))return '/account';try{const url=new URL(value,'https://bracket.invalid');if(url.origin!=='https://bracket.invalid'||url.pathname.startsWith('/api/')||url.pathname.startsWith('/account/verify'))return '/account';return url.pathname+url.search;}catch{return '/account';}}
export function normalizeEmail(value:unknown){if(typeof value!=='string')throw new ApiError(400,'Enter a valid email address.');const email=value.trim().toLowerCase();if(email.length>254||! /^[a-z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)+$/.test(email))throw new ApiError(400,'Enter a valid email address.');return email;}
export async function accountBody(request:Request){let value:unknown;try{value=JSON.parse(new TextDecoder().decode(await limitedBody(request,2048)));}catch(error){if(error instanceof ApiError)throw error;throw new ApiError(400,'Invalid account request.');}if(!value||typeof value!=='object'||Array.isArray(value))throw new ApiError(400,'Invalid account request.');return value as Record<string,unknown>;}
export function accountOriginCheck(request:Request){const url=new URL(request.url);if(request.headers.get('origin')!==url.origin||['cross-site','same-site'].includes(request.headers.get('sec-fetch-site')??''))throw new ApiError(403,'This action must come from this site.');}
export async function currentAccount(request:Request):Promise<AccountRow|null>{const value=cookie(request,SESSION_COOKIE);if(!value)return null;return db().prepare('SELECT a.id,a.name,a.email,a.identity_id FROM account_sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token_hash=? AND s.expires_at>?').bind(await hash(value),Date.now()).first<AccountRow>();}
export async function accountIdentity(request:Request){return (await currentAccount(request))?.identity_id??null;}
export async function getAccount(request:Request){const row=await currentAccount(request),anonymous=await anonymousIdentity(request);return json({user:row?publicUser(row):null,providers:accountProviders(request)},200,anonymous.cookie);}
export async function updateAccount(request:Request){accountOriginCheck(request);const row=await currentAccount(request);if(!row)throw new ApiError(401,'Sign in to edit your profile.');const data=await accountBody(request),name=typeof data.name==='string'?data.name.trim():'';if(!name||name.length>80||/[\u0000-\u001f\u007f]/.test(name))throw new ApiError(400,'Use a display name between 1 and 80 characters.');await db().prepare('UPDATE accounts SET name=? WHERE id=?').bind(name,row.id).run();return json({user:{...publicUser(row),name}});}
async function cleanExpired(){const now=Date.now();await db().batch([db().prepare('DELETE FROM account_sessions WHERE expires_at<?').bind(now),db().prepare('DELETE FROM account_challenges WHERE created_at<?').bind(now-24*60*60*1000)]);}
async function newFlow(request:Request){if(await currentAccount(request))throw new ApiError(409,'Sign out before choosing a different account.');const anonymous=await anonymousIdentity(request);return {anonymous,secret:token(),created:Date.now()};}
function flowResponse(request:Request,response:Response,flow:{secret:string;anonymous:{cookie:string|null}}){response.headers.append('Set-Cookie',setCookie(request,FLOW_COOKIE,flow.secret,FLOW_SECONDS));if(flow.anonymous.cookie)response.headers.append('Set-Cookie',flow.anonymous.cookie);return response;}
export async function requestEmail(request:Request){
 accountOriginCheck(request);if(!accountProviders(request).email)throw new ApiError(503,'Email sign-in is not configured yet. The site owner needs to connect an email provider.');
 const data=await accountBody(request),email=normalizeEmail(data.email),flow=await newFlow(request),secret=token(),subject=await hash(email),secretHash=await hash(secret);
 await cleanExpired();
 // Atomic per-mailbox cap and cooldown, in addition to the Worker’s network cap.
 const created=await db().prepare(`INSERT INTO account_challenges(token_hash,kind,browser_hash,source_identity,subject_hash,payload,return_to,created_at,expires_at) SELECT ?,'email',?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM account_challenges WHERE kind='email' AND subject_hash=? AND created_at>?)<5 AND NOT EXISTS(SELECT 1 FROM account_challenges WHERE kind='email' AND subject_hash=? AND created_at>?)`).bind(secretHash,await hash(flow.secret),flow.anonymous.id,subject,JSON.stringify({email}),safeReturnTo(data.returnTo),flow.created,flow.created+FLOW_SECONDS*1000,subject,flow.created-3600000,subject,flow.created-60000).run();
 if(!created.meta.changes)return json({ok:true,message:'If a link can be sent, it will arrive shortly. Use the most recent link, or wait a minute before trying again.'});
 const link=`${authOrigin()}/account/verify#token=${secret}`,c=config();
 let sent=false;
 try{const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${c.RESEND_API_KEY}`,'Content-Type':'application/json','Idempotency-Key':`bracketlive-signin-${secretHash}`},body:JSON.stringify({from:c.AUTH_EMAIL_FROM,to:[email],subject:'Your BracketLive sign-in link',text:`Sign in to BracketLive\n\n${link}\n\nOpen this link in the same browser where you requested it, then choose Confirm sign-in. It expires in 15 minutes and can be used once.\n\nIf you did not request this link, you can ignore this email.`}),signal:AbortSignal.timeout(10000)});sent=response.ok;await response.body?.cancel();}catch{/* Do not log provider responses or authentication tokens. */}
 if(!sent){await db().prepare('UPDATE account_challenges SET consumed_at=? WHERE token_hash=?').bind(Date.now(),secretHash).run();throw new ApiError(503,'We could not send your sign-in email. Please try again shortly.');}
 return flowResponse(request,json({ok:true,message:'Check your email for a sign-in link. Open it in this browser within 15 minutes.'}),flow);
}
async function consumeChallenge(request:Request,secret:string,kind:string){
 if(!/^[a-f0-9]{64}$/.test(secret))throw new ApiError(400,'This sign-in link is invalid. Request a new one.');
 if(await currentAccount(request))throw new ApiError(409,'You are already signed in. Sign out first to choose a different account.');
 const browser=cookie(request,FLOW_COOKIE);if(!browser)throw new ApiError(403,'Open the link in the browser where you requested it, or request a new link here.');
 const anonymous=await anonymousIdentity(request),now=Date.now(),claim=token();
 const row=await db().prepare(`UPDATE account_challenges SET consumed_at=?,claim=? WHERE token_hash=? AND kind=? AND browser_hash=? AND source_identity=? AND consumed_at IS NULL AND expires_at>? RETURNING *`).bind(now,claim,await hash(secret),kind,await hash(browser),anonymous.id,now).first<Challenge>();
 if(!row)throw new ApiError(400,'This sign-in link expired, was already used, or belongs to another browser. Request a new one.');return row;
}
async function accountForCredential(provider:'email'|'google',subject:string,email:string,name:string,authoritativeEmail=false){
 const database=db(),subjectHash=await hash(subject),emailHash=await hash(email);
 let row=await database.prepare('SELECT a.* FROM accounts a JOIN account_credentials c ON c.account_id=a.id WHERE c.provider=? AND c.subject_hash=?').bind(provider,subjectHash).first<AccountRow>();if(row)return row;
 const id=crypto.randomUUID(),identity=await hash('bracketlive:account:'+id),now=Date.now();
 const cleanName=name.replace(/[\u0000-\u001f\u007f]/g,'').trim().slice(0,80)||'Bracket fan';
 const statements=[database.prepare('INSERT OR IGNORE INTO accounts(id,identity_id,name,email,created_at) VALUES(?,?,?,?,?)').bind(id,identity,cleanName,email,now),provider==='google'&&authoritativeEmail?database.prepare("INSERT OR IGNORE INTO account_credentials(provider,subject_hash,account_id) VALUES(?,?,COALESCE((SELECT account_id FROM account_credentials WHERE provider='email' AND subject_hash=?),?))").bind(provider,subjectHash,emailHash,id):database.prepare('INSERT OR IGNORE INTO account_credentials(provider,subject_hash,account_id) VALUES(?,?,?)').bind(provider,subjectHash,id)];
 if(provider==='google'&&authoritativeEmail)statements.push(database.prepare("INSERT OR IGNORE INTO account_credentials(provider,subject_hash,account_id) SELECT 'email',?,account_id FROM account_credentials WHERE provider='google' AND subject_hash=?").bind(emailHash,subjectHash));
 statements.push(database.prepare('DELETE FROM accounts WHERE id=? AND NOT EXISTS(SELECT 1 FROM account_credentials WHERE account_id=?)').bind(id,id));
 await database.batch(statements);
 row=await database.prepare('SELECT a.* FROM accounts a JOIN account_credentials c ON c.account_id=a.id WHERE c.provider=? AND c.subject_hash=?').bind(provider,subjectHash).first<AccountRow>();if(!row)throw new ApiError(503,'Could not create your account. Please try signing in again.');return row;
}
async function finishLogin(request:Request,row:AccountRow,challenge:Challenge){
 const database=db(),session=token(),now=Date.now(),source=challenge.source_identity,target=row.identity_id;
 // Every migration statement rechecks the once-only identity claim in this transaction.
 // A stolen/stale pre-login browser token never becomes an account login credential.
 const guard='EXISTS(SELECT 1 FROM account_identity_claims WHERE identity_id=? AND account_id=?)',bindings=[source,row.id];
 await database.batch([
  database.prepare('INSERT OR IGNORE INTO account_identity_claims(identity_id,account_id,created_at) VALUES(?,?,?)').bind(source,row.id,now),
  database.prepare(`INSERT OR IGNORE INTO managers(bracket_id,identity_id) SELECT bracket_id,? FROM managers WHERE identity_id=? AND ${guard}`).bind(target,source,...bindings),
  database.prepare(`INSERT OR IGNORE INTO season_managers(season_id,identity_id) SELECT season_id,? FROM season_managers WHERE identity_id=? AND ${guard}`).bind(target,source,...bindings),
  database.prepare(`UPDATE brackets SET owner_id=? WHERE owner_id=? AND ${guard}`).bind(target,source,...bindings),
  database.prepare(`UPDATE seasons SET owner_id=? WHERE owner_id=? AND ${guard}`).bind(target,source,...bindings),
  database.prepare(`UPDATE media SET owner_id=? WHERE owner_id=? AND ${guard}`).bind(target,source,...bindings),
  // Reconcile duplicate choices only while voting is still open. Historical
  // tallies must not change after a round closes, even when a profile had voted
  // from two formerly anonymous devices. UPDATE OR IGNORE moves nonconflicts.
  database.prepare(`DELETE FROM votes WHERE voter_id=? AND ${guard} AND EXISTS(SELECT 1 FROM votes account_vote WHERE account_vote.match_id=votes.match_id AND account_vote.voter_id=?) AND EXISTS(SELECT 1 FROM matches m JOIN brackets b ON b.id=m.bracket_id WHERE m.id=votes.match_id AND m.status='open' AND b.status='live' AND m.round=b.current_round AND (b.round_closes_at IS NULL OR b.round_closes_at>${sqlNow}))`).bind(source,...bindings,target),
  database.prepare(`UPDATE OR IGNORE votes SET voter_id=? WHERE voter_id=? AND ${guard}`).bind(target,source,...bindings),
  database.prepare(`DELETE FROM managers WHERE identity_id=? AND ${guard}`).bind(source,...bindings),
  database.prepare(`DELETE FROM season_managers WHERE identity_id=? AND ${guard}`).bind(source,...bindings),
  database.prepare('INSERT INTO account_sessions(token_hash,account_id,created_at,expires_at) VALUES(?,?,?,?)').bind(await hash(session),row.id,now,now+SESSION_SECONDS*1000),
  // Keep at most ten active devices. This also bounds session accumulation.
  database.prepare('DELETE FROM account_sessions WHERE account_id=? AND token_hash<>? AND token_hash NOT IN (SELECT token_hash FROM account_sessions WHERE account_id=? AND token_hash<>? ORDER BY created_at DESC,token_hash DESC LIMIT 9)').bind(row.id,await hash(session),row.id,await hash(session)),
 ]);
 const response=json({ok:true,user:publicUser(row),returnTo:challenge.return_to});
 response.headers.append('Set-Cookie',setCookie(request,SESSION_COOKIE,session,SESSION_SECONDS));
 response.headers.append('Set-Cookie',setCookie(request,'bl_voter',token(),31536000));
 response.headers.append('Set-Cookie',setCookie(request,FLOW_COOKIE,null,0));return response;
}
export async function verifyEmail(request:Request){accountOriginCheck(request);const data=await accountBody(request),challenge=await consumeChallenge(request,typeof data.token==='string'?data.token:'','email'),payload=JSON.parse(challenge.payload) as {email:string};return finishLogin(request,await accountForCredential('email',payload.email,payload.email,'Bracket fan'),challenge);}
export async function logoutAccount(request:Request){accountOriginCheck(request);const value=cookie(request,SESSION_COOKIE);if(value)await db().prepare('DELETE FROM account_sessions WHERE token_hash=?').bind(await hash(value)).run();const response=json({ok:true});response.headers.append('Set-Cookie',setCookie(request,SESSION_COOKIE,null,0));response.headers.append('Set-Cookie',setCookie(request,FLOW_COOKIE,null,0));response.headers.append('Set-Cookie',setCookie(request,'bl_voter',token(),31536000));return response;}
function base64url(bytes:Uint8Array){return btoa(String.fromCharCode(...bytes)).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');}
function decode64(value:string){if(!/^[A-Za-z0-9_-]+$/.test(value))throw new Error('Invalid token encoding');const text=atob(value.replace(/-/g,'+').replace(/_/g,'/'));return Uint8Array.from(text,c=>c.charCodeAt(0));}
export async function googleStart(request:Request){
 if(!accountProviders(request).google)throw new ApiError(503,'Google sign-in is not configured yet. The site owner needs to connect Google.');
 if(['cross-site','same-site'].includes(request.headers.get('sec-fetch-site')??''))throw new ApiError(403,'Start sign-in from BracketLive.');
 const flow=await newFlow(request),state=token(),verifier=token(),nonce=token(),c=config(),returnTo=safeReturnTo(new URL(request.url).searchParams.get('returnTo'));
 await cleanExpired();
 await db().prepare('INSERT INTO account_challenges(token_hash,kind,browser_hash,source_identity,payload,return_to,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)').bind(await hash(state),'google',await hash(flow.secret),flow.anonymous.id,JSON.stringify({verifier,nonce}),returnTo,flow.created,flow.created+FLOW_SECONDS*1000).run();
 const url=new URL('https://accounts.google.com/o/oauth2/v2/auth');url.search=new URLSearchParams({client_id:c.GOOGLE_CLIENT_ID!,redirect_uri:`${authOrigin()}/api/auth/google/callback`,response_type:'code',scope:'openid email profile',state,nonce,code_challenge:base64url(new Uint8Array(await crypto.subtle.digest('SHA-256',encoder.encode(verifier)))),code_challenge_method:'S256',prompt:'select_account'}).toString();
 return flowResponse(request,new Response(null,{status:302,headers:{Location:url.href,'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}}),flow);
}
type GoogleClaims={iss:string;aud:string;azp?:string;sub:string;email:string;email_verified:boolean;hd?:string;name?:string;exp:number;iat:number;nonce:string};
type GoogleKey=JsonWebKey&{kid?:string;alg?:string};
let jwks:{keys:GoogleKey[];expires:number}|null=null;
async function googleKeys(){if(jwks&&jwks.expires>Date.now())return jwks.keys;const response=await fetch('https://www.googleapis.com/oauth2/v3/certs',{signal:AbortSignal.timeout(10000)});if(!response.ok)throw new ApiError(503,'Google sign-in is temporarily unavailable.');const data=await response.json() as {keys:GoogleKey[]};if(!Array.isArray(data.keys)||data.keys.length>20)throw new ApiError(503,'Google sign-in is temporarily unavailable.');const age=Number(response.headers.get('cache-control')?.match(/max-age=(\d+)/)?.[1]??300);jwks={keys:data.keys,expires:Date.now()+Math.min(3600,Math.max(60,age))*1000};return data.keys;}
export function validateGoogleClaims(value:unknown,audience:string,nonce:string,now=Math.floor(Date.now()/1000)):GoogleClaims{
 const c=value as Partial<GoogleClaims>|null;
 if(!c||!['https://accounts.google.com','accounts.google.com'].includes(c.iss??'')||c.aud!==audience||(c.azp!==undefined&&c.azp!==audience)||typeof c.exp!=='number'||!Number.isFinite(c.exp)||c.exp<=now||typeof c.iat!=='number'||!Number.isFinite(c.iat)||c.iat>now+60||c.iat<now-3600||c.exp-c.iat>7200||c.nonce!==nonce||typeof c.sub!=='string'||!c.sub||c.sub.length>255||! /^[\x21-\x7e]+$/.test(c.sub)||c.email_verified!==true)throw new ApiError(401,'Google could not verify this sign-in. Please try again.');
 normalizeEmail(c.email);return c as GoogleClaims;
}
export function googleAuthoritativeEmail(claims:GoogleClaims){return claims.email_verified===true&&(claims.email.toLowerCase().endsWith('@gmail.com')||(typeof claims.hd==='string'&&claims.hd.length>0));}
async function verifyGoogleToken(value:unknown,nonce:string){
 if(typeof value!=='string'||value.length>20000)throw new ApiError(401,'Google returned an invalid sign-in token.');
 try{const parts=value.split('.');if(parts.length!==3)throw new Error('Invalid JWT');const header=JSON.parse(new TextDecoder().decode(decode64(parts[0]))) as {alg:string;kid:string};if(header.alg!=='RS256'||typeof header.kid!=='string')throw new Error('Invalid algorithm');let keys=await googleKeys(),jwk=keys.find(k=>k.kid===header.kid&&k.kty==='RSA'&&(!k.alg||k.alg==='RS256')&&(!k.use||k.use==='sig'));if(!jwk){jwks=null;keys=await googleKeys();jwk=keys.find(k=>k.kid===header.kid&&k.kty==='RSA'&&(!k.alg||k.alg==='RS256')&&(!k.use||k.use==='sig'));}if(!jwk)throw new Error('Unknown signing key');const key=await crypto.subtle.importKey('jwk',jwk,{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['verify']);if(!await crypto.subtle.verify('RSASSA-PKCS1-v1_5',key,decode64(parts[2]),encoder.encode(parts[0]+'.'+parts[1])))throw new Error('Invalid signature');return validateGoogleClaims(JSON.parse(new TextDecoder().decode(decode64(parts[1]))),config().GOOGLE_CLIENT_ID!,nonce);}catch(error){if(error instanceof ApiError)throw error;throw new ApiError(401,'Google could not verify this sign-in. Please try again.');}
}
export async function googleCallback(request:Request){
 if(!accountProviders(request).google)throw new ApiError(503,'Google sign-in is not configured.');
 const url=new URL(request.url),challenge=await consumeChallenge(request,url.searchParams.get('state')??'','google');if(url.searchParams.has('error'))throw new ApiError(400,'Google sign-in was cancelled.');
 const code=url.searchParams.get('code');if(!code||code.length>4096)throw new ApiError(400,'Google did not return a valid sign-in code.');
 const payload=JSON.parse(challenge.payload) as {verifier:string;nonce:string},c=config();
 const response=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({client_id:c.GOOGLE_CLIENT_ID!,client_secret:c.GOOGLE_CLIENT_SECRET!,code,code_verifier:payload.verifier,grant_type:'authorization_code',redirect_uri:`${authOrigin()}/api/auth/google/callback`}),signal:AbortSignal.timeout(10000)});
 if(!response.ok){await response.body?.cancel();throw new ApiError(401,'Google sign-in could not be completed. Please try again.');}
 const data=await response.json() as {id_token?:unknown},claims=await verifyGoogleToken(data.id_token,payload.nonce),email=normalizeEmail(claims.email),row=await accountForCredential('google',claims.sub,email,typeof claims.name==='string'?claims.name:'Bracket fan',googleAuthoritativeEmail(claims));
 const login=await finishLogin(request,row,challenge);login.headers.set('Location',new URL(challenge.return_to,authOrigin()!).href);login.headers.set('Referrer-Policy','no-referrer');return new Response(null,{status:303,headers:login.headers});
}
