/** Slot order is kept separate from basketball seeds, which repeat in each region. */
export const basketballSeeds=[1,16,8,9,5,12,4,13,6,11,3,14,7,10,2,15] as const;
export const basketballRegions=['East','West','South','Midwest'] as const;
export const basketballRounds=['Round of 64','Round of 32','Sweet 16','Elite Eight','Final Four','Championship'] as const;
export function basketballSlot(slot:number){
 if(!Number.isInteger(slot)||slot<1||slot>64)return null;
 return {region:basketballRegions[Math.floor((slot-1)/16)],seed:basketballSeeds[(slot-1)%16]};
}
export function basketballEntries(){return Array.from({length:64},(_,i)=>{
 const slot=basketballSlot(i+1)!;
 return {name:`${slot.region} ${slot.seed}`,subtitle:`${slot.region} · Seed ${slot.seed}`,image:null,seed:i+1};
});}
