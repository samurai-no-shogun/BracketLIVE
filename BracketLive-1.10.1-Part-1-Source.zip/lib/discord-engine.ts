import {reviewedAnimeImage} from './anime-roster';
import {draftBracket,type Bracket,type Draft} from './bracket';
export type ActivityState = {bracket:Bracket;roundMinutes:number;blocked:string|null};
export type ActivityVote = {match_id:string;entry_id:string;user_id:string};
export function newActivityState(draft:Draft,id:string,roundMinutes=0,now=Date.now()):ActivityState {
 const bracket=draftBracket(draft);
 Object.assign(bracket,{id,status:'live',created_at:now,started_at:now,current_round:0,listed:false,round_closes_at:roundMinutes?now+roundMinutes*60000:null});
 bracket.matches.forEach(m=>{if(m.round===0)m.status='open';});
 return {bracket,roundMinutes,blocked:null};
}
export function activitySnapshot(state:ActivityState,votes:ActivityVote[],userId:string,owner:boolean,now=Date.now()):Bracket {
 const b=structuredClone(state.bracket); b.isOwner=owner;b.totalVotes=votes.length;b.entries=b.entries.map(e=>({...e,image:reviewedAnimeImage(e)}));
 b.schedule_blocked=!!state.blocked;b.schedule_blocked_reason=state.blocked;
 for(const m of b.matches){
  const choices=votes.filter(v=>v.match_id===m.id);m.myVote=choices.find(v=>v.user_id===userId)?.entry_id??null;
  const reveal=owner||!!m.myVote||m.status==='closed'||(m.round===b.current_round&&b.round_closes_at!==null&&now>=b.round_closes_at);
  m.counts=reveal?Object.fromEntries([m.a_id,m.b_id].filter(Boolean).map(id=>[id!,choices.filter(v=>v.entry_id===id).length])):null;
  m.total=reveal?choices.length:null;
 }
 return b;
}
export function votingMatch(state:ActivityState,matchId:string,entryId:string|null,now=Date.now()) {
 const b=state.bracket,m=b.matches.find(m=>m.id===matchId);
 if(b.status!=='live'||!m||m.round!==b.current_round||m.status!=='open'||!m.a_id||!m.b_id||b.round_closes_at!==null&&now>=b.round_closes_at)throw Error('Voting for this match is closed.');
 if(entryId!==null&&entryId!==m.a_id&&entryId!==m.b_id)throw Error('Choose a contender in this match.');
 return m;
}
export function advanceActivity(state:ActivityState,votes:ActivityVote[],ties:Record<string,string>={},now=Date.now()):ActivityState {
 const next=structuredClone(state),b=next.bracket;
 if(b.status!=='live')throw Error('This tournament is already complete.');
 const current=b.matches.filter(m=>m.round===b.current_round);
 for(const m of current){
  if(!m.a_id||!m.b_id)throw Error('This round is not ready.');
  const a=votes.filter(v=>v.match_id===m.id&&v.entry_id===m.a_id).length,c=votes.filter(v=>v.match_id===m.id&&v.entry_id===m.b_id).length;
  let winner=a>c?m.a_id:c>a?m.b_id:ties[m.id];
  if(!winner||winner!==m.a_id&&winner!==m.b_id)throw Error('Tied or unvoted matches need the creator to select a winner.');
  m.winner_id=winner;m.status='closed';m.decided_by=a===c?'creator_tiebreak':'votes';
  const target=b.matches.find(x=>x.round===m.round+1&&x.position===Math.floor(m.position/2));
  if(target){if(m.position%2===0)target.a_id=winner;else target.b_id=winner;target.status='open';}
 }
 next.blocked=null;
 if(current.length===1){b.status='completed';b.round_closes_at=null;}
 else{b.current_round++;b.round_closes_at=next.roundMinutes?now+next.roundMinutes*60000:null;}
 return next;
}
