/** This worker receives local pixel blobs only; it never accepts input URLs. */
type OCRRequest = { type: 'recognize'; blob: Blob; origin: string };
type WorkerScope = {
  onmessage: ((event: MessageEvent<OCRRequest>) => void) | null;
  postMessage: (message: unknown) => void;
  location: { origin: string };
};
const scope = globalThis as unknown as WorkerScope;
let started = false;
scope.onmessage = async event => {
  if (started || event.data?.type !== 'recognize' || !(event.data.blob instanceof Blob)) return;
  started = true;
  let worker: Awaited<ReturnType<typeof import('tesseract.js')['createWorker']>> | undefined;
  try {
    // The origin comes from the app, never from imported text. Reject any cross-origin override.
    if (event.data.origin !== scope.location.origin) throw new Error('Invalid OCR origin.');
    const { createWorker, PSM } = await import('tesseract.js');
    worker = await createWorker('eng', 1, {
      workerPath: `${scope.location.origin}/import-assets/tesseract-worker.min.js`,
      corePath: `${scope.location.origin}/import-assets/tesseract-core`,
      langPath: `${scope.location.origin}/import-assets/tesseract-lang`,
      workerBlobURL: false,
      cacheMethod: 'none',
      gzip: true,
      logger: message => scope.postMessage({
        type: 'progress',
        message: message.status === 'recognizing text' ? 'Reading snapshot text' : 'Loading text recognition',
        progress: message.status === 'recognizing text' ? 0.35 + Math.max(0, Math.min(1, message.progress)) * 0.6 : 0.15,
      }),
      errorHandler: () => scope.postMessage({ type: 'error' }),
    });
    await worker.setParameters({ tessedit_pageseg_mode: PSM.AUTO, preserve_interword_spaces: '1' });
    const recognized = await worker.recognize(event.data.blob, {}, { text: true, blocks: true });
    const lines = (recognized.data.blocks ?? []).flatMap(block => block.paragraphs.flatMap(paragraph => paragraph.lines.map(line => ({
      text: line.text,
      page: 1,
      x: line.bbox.x0,
      y: line.bbox.y0,
      width: line.bbox.x1 - line.bbox.x0,
      height: line.bbox.y1 - line.bbox.y0,
      confidence: line.confidence,
    }))));
    scope.postMessage({ type: 'result', result: { text: recognized.data.text, confidence: recognized.data.confidence, lines } });
  } catch {
    scope.postMessage({ type: 'error' });
  } finally {
    await worker?.terminate().catch(() => {});
  }
};
