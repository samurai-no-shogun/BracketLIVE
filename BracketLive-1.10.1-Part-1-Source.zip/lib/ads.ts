// Placements are deliberately inactive until an ad provider is configured.
// No advertising scripts, requests, or impressions run while disabled.
export const adPlacements=[
 {id:'hub-sidebar',name:'Tournament hub sidebar',width:300,height:250},
 {id:'tournament-footer',name:'Below tournament results',width:728,height:90},
] as const;
export type AdPlacement=typeof adPlacements[number]['id'];
export const advertisingEnabled=false;
