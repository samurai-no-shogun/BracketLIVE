import {db} from './server';

export const FEATURED_BRACKET_KEY='featured_bracket_id';
export type FeaturedBracket={id:string;title:string;description:string;size:number;status:'live'|'complete';current_round:number};

// A setting is never permission to disclose a draft or a private test. Recheck
// visibility on every read, including when the setting points at a removed row.
export async function getFeaturedBracket():Promise<FeaturedBracket|null>{
 return db().prepare("SELECT b.id,b.title,b.description,b.size,b.status,b.current_round FROM site_settings s JOIN brackets b ON b.id=s.value WHERE s.key=? AND b.is_test=0 AND b.status IN ('live','complete')").bind(FEATURED_BRACKET_KEY).first<FeaturedBracket>();
}
export async function getFeaturedBracketId():Promise<string|null>{
 return (await getFeaturedBracket())?.id??null;
}
