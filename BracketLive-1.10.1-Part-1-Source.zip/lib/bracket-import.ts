import {Inflate} from 'fflate';

/** Local, review-first roster import. Files, formulas and image URLs are never executed. */
export type ImportKind='csv'|'tsv'|'txt'|'json'|'xlsx'|'ods'|'docx';
export type ImportEntry={name:string;subtitle:string;image:null;seed:number;sourceRow:number};
export type ImportIssue={row:number;message:string};
export type ImportMapping={mode:'roster'|'paired';startRow:number;nameColumn:number;subtitleColumn:number|null;seedColumn:number|null;opponentColumn:number|null;opponentSubtitleColumn:number|null;opponentSeedColumn:number|null};
export type ImportTable={id:string;name:string;rows:string[][];suggested:ImportMapping;headerRow:number|null};
export type ImportDocument={kind:ImportKind;title?:string;tables:ImportTable[];warnings:string[]};
export type ImportFile={name:string;size:number;arrayBuffer():Promise<ArrayBuffer>};
export const IMPORT_LIMITS={fileBytes:10*1024*1024,expandedBytes:32*1024*1024,xmlBytes:8*1024*1024,files:512,tables:32,rows:1000,columns:64,cellCharacters:2000,textCharacters:2_000_000,xmlNodes:100_000,entries:128} as const;
const ignoredArtwork='Only the roster and its source order are imported. Add pictures in the entry editor; embedded artwork and image URLs are not imported.';
const formulaNotice='Formula cells were left blank. Export their values as CSV or replace formulas with text before importing.';
const utf8=new TextDecoder('utf-8',{fatal:true});
function fail(message:string):never{throw new Error(message);}
function boundText(value:string){if(value.length>IMPORT_LIMITS.textCharacters)fail('This file contains too much text. Export only the roster or first-round matchups.');return value.replace(/^\uFEFF/,'');}
function cell(value:string){if(value.length>IMPORT_LIMITS.cellCharacters)fail('A cell is too long. Keep each imported cell below 2,000 characters.');return value.replace(/\u0000/g,'');}
function nonempty(row:string[]){return row.some(value=>value.trim().length>0);}
function blankMapping():ImportMapping{return {mode:'roster',startRow:0,nameColumn:0,subtitleColumn:null,seedColumn:null,opponentColumn:null,opponentSubtitleColumn:null,opponentSeedColumn:null};}
const normalized=(value:string)=>value.trim().toLowerCase().replace(/[^a-z0-9]/g,'');
function suggest(rows:string[][]):{mapping:ImportMapping;headerRow:number|null}{
 const mapping=blankMapping(),index=rows.findIndex(nonempty);if(index<0)return {mapping,headerRow:null};
 const headers=rows[index].map(normalized),pick=(aliases:string[])=>{const found=headers.findIndex(header=>aliases.includes(header));return found<0?null:found;};
 const b=pick(['contenderb','opponentb','teamb','nameb','participant2','team2','competitor2']);
 const a=pick(['name','entrant','entry','participant','contestant','team','competitor',...(b!==null?['contendera','opponenta','teama','namea','participant1','team1','competitor1']:[])]);
 if(a!==null){mapping.nameColumn=a;mapping.startRow=index+1;mapping.subtitleColumn=pick(['subtitle','description','series','details','subtitleta','subtitlea','descriptiona']);mapping.seedColumn=pick(['seed','rank','seeda','ranka']);if(b!==null){mapping.mode='paired';mapping.opponentColumn=b;mapping.opponentSubtitleColumn=pick(['subtitleb','descriptionb','detailsb']);mapping.opponentSeedColumn=pick(['seedb','rankb']);}return {mapping,headerRow:index};}
 mapping.startRow=index;return {mapping,headerRow:null};
}
function table(name:string,rows:string[][],index:number):ImportTable{
 if(rows.length>IMPORT_LIMITS.rows)fail('A table has more than 1,000 rows. Export just the roster or first-round matchups.');
 if(rows.some(row=>row.length>IMPORT_LIMITS.columns))fail('A table has more than 64 columns. Export only the columns you need.');
 const {mapping,headerRow}=suggest(rows);return {id:`table-${index}`,name:name.slice(0,100),rows,suggested:mapping,headerRow};
}
function document(kind:ImportKind,tables:ImportTable[],warnings:string[]=[],title?:string):ImportDocument{
 if(tables.length>IMPORT_LIMITS.tables)fail('This file has too many sheets or tables. Export only the roster you want.');
 if(!tables.some(t=>t.rows.some(nonempty)))fail('No readable roster text was found. Use a roster table with names or first-round opponents.');
 return {kind,tables,warnings:[...new Set(warnings)],...(title?{title:title.slice(0,100)}:{})};
}

/** Strict quoted CSV/TSV parser: embedded newlines and doubled quotes are preserved. */
export function parseDelimitedImport(text:string,delimiter=","):string[][]{
 text=boundText(text);if(delimiter!==','&&delimiter!=='\t')fail('Unsupported column delimiter.');
 const rows:string[][]=[];let row:string[]=[],value='',quoted=false,closed=false;
 const finishCell=()=>{row.push(cell(value));value='';closed=false;if(row.length>IMPORT_LIMITS.columns)fail('This file has more than 64 columns.');};
 const finishRow=()=>{finishCell();rows.push(row);row=[];if(rows.length>IMPORT_LIMITS.rows)fail('This file has more than 1,000 rows. Export only the roster.');};
 for(let i=0;i<text.length;i++){
  const ch=text[i];
  if(quoted){if(ch==='"'){if(text[i+1]==='"'){value+='"';i++;}else{quoted=false;closed=true;}}else value+=ch;}
  else if(ch===delimiter)finishCell();
  else if(ch==='\r'||ch==='\n'){if(ch==='\r'&&text[i+1]==='\n')i++;finishRow();}
  else if(ch==='"'){if(value.length||closed)fail('A CSV quote is misplaced. Export the sheet as CSV again.');quoted=true;}
  else {if(closed){if(ch===' '||ch==='\t')continue;fail('Text follows a closing CSV quote. Export the sheet as CSV again.');}value+=ch;}
  if(value.length>IMPORT_LIMITS.cellCharacters)fail('An imported cell exceeds 2,000 characters.');
 }
 if(quoted)fail('An imported CSV value has an unclosed quote.');
 if(value.length||row.length||closed)finishRow();
 return rows;
}

export function parseImportText(text:string,kind:'csv'|'tsv'|'txt'|'json'='txt'):ImportDocument{
 text=boundText(text);
 if(kind==='json'){
  let raw:unknown;try{raw=JSON.parse(text);}catch{fail('This JSON is not valid. Import a BracketLive JSON snapshot.');}
  if(!raw||typeof raw!=='object'||Array.isArray(raw))fail('Import a BracketLive JSON snapshot with a roster.');
  const snapshot=raw as Record<string,unknown>;if(snapshot.schema!=='bracketlive.snapshot.v1'||!Array.isArray(snapshot.entries))fail('Import a BracketLive JSON snapshot with a roster.');
  if(snapshot.entries.length>IMPORT_LIMITS.entries)fail('A bracket can contain at most 128 entries.');
  const rows=[['Name','Subtitle','Seed'],...snapshot.entries.map((entry:unknown)=>{
   if(!entry||typeof entry!=='object'||Array.isArray(entry))fail('The snapshot contains an invalid roster entry.');
   const e=entry as Record<string,unknown>;if(typeof e.name!=='string'||(e.subtitle!==undefined&&typeof e.subtitle!=='string'))fail('The snapshot contains an invalid roster entry.');
   return [cell(e.name),cell(typeof e.subtitle==='string'?e.subtitle:''),cell(e.seed===undefined?'':typeof e.seed==='number'||typeof e.seed==='string'?String(e.seed):'invalid')];
  })];
  const tournament=snapshot.tournament&&typeof snapshot.tournament==='object'?snapshot.tournament as Record<string,unknown>:null;
  return document(kind,[table('Snapshot roster',rows,0)],[ignoredArtwork,'A new roster is created. Old votes, winners, deadlines, accounts, and organizer access are not imported.'],typeof tournament?.title==='string'?tournament.title:undefined);
 }
 if(kind==='csv'||kind==='tsv')return document(kind,[table('Imported roster',parseDelimitedImport(text,kind==='tsv'?'\t':','),0)]);
 if(text.includes('\t'))return document(kind,[table('Imported text',parseDelimitedImport(text,'\t'),0)]);
 const lines=text.split(/\r\n|\n|\r/).map(line=>cell(line));if(lines.length>IMPORT_LIMITS.rows)fail('This file has more than 1,000 rows.');
 const pipeLines=lines.filter(line=>line.trim());if(pipeLines.length>1&&pipeLines.every(line=>line.includes('|'))){const widths=pipeLines.map(line=>line.split('|').length);if(widths.every(width=>width===widths[0]))return document(kind,[table('Imported text',lines.map(line=>line.trim()?line.split('|').map(part=>part.trim()):[]),0)]);}
 const active=lines.filter(line=>line.trim()),pairs=active.map(line=>line.match(/^(.+?)\s+(?:vs\.?|versus|v\.)\s+(.+)$/i));
 const paired=active.length>0&&pairs.every(Boolean),rows=paired?pairs.map(pair=>[pair![1].trim(),pair![2].trim()]):lines.map(line=>[line]);
 const imported=table('Imported text',rows,0);if(paired)imported.suggested={...blankMapping(),mode:'paired',opponentColumn:1};
 return document(kind,[imported]);
}

/** Central-directory metadata is checked, then actual inflate output is bounded. */
type ZipRecord={name:string;method:number;compressed:number;expanded:number;crc:number;offset:number};
function zipRecords(bytes:Uint8Array):ZipRecord[]{
 if(bytes.length<22)fail('This archive is not a valid spreadsheet or document.');
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;
 for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--)if(view.getUint32(i,true)===0x06054b50&&i+22+view.getUint16(i+20,true)===bytes.length){end=i;break;}
 if(end<0)fail('This archive is damaged or unsupported. Export a fresh XLSX, ODS, or DOCX file.');
 const count=view.getUint16(end+10,true),centralSize=view.getUint32(end+12,true),start=view.getUint32(end+16,true);
 if(view.getUint16(end+4,true)||view.getUint16(end+6,true)||view.getUint16(end+8,true)!==count||count===65535||start===0xffffffff||centralSize===0xffffffff)fail('Multi-part and ZIP64 archives are not supported. Export a smaller roster file.');
 if(count>IMPORT_LIMITS.files||start+centralSize>end)fail('The archive has too many files or an invalid index.');
 let offset=start,total=0;const records:ZipRecord[]=[],names=new Set<string>();
 for(let i=0;i<count;i++){
  if(offset+46>start+centralSize||view.getUint32(offset,true)!==0x02014b50)fail('The archive index is damaged.');
  const flags=view.getUint16(offset+8,true),method=view.getUint16(offset+10,true),compressed=view.getUint32(offset+20,true),expanded=view.getUint32(offset+24,true),nameSize=view.getUint16(offset+28,true),extra=view.getUint16(offset+30,true),comment=view.getUint16(offset+32,true),local=view.getUint32(offset+42,true),next=offset+46+nameSize+extra+comment;
  if(next>start+centralSize||flags&1||![0,8].includes(method)||compressed===0xffffffff||expanded===0xffffffff||local===0xffffffff)fail('Encrypted, ZIP64, or unsupported archive entries cannot be imported.');
  let name:string;try{name=utf8.decode(bytes.subarray(offset+46,offset+46+nameSize));}catch{fail('An archive entry has an invalid file name.');}
  if(name.includes('\\')||name.includes('\0')||name.startsWith('/')||name.split('/').some(part=>part==='..')||names.has(name))fail('The archive contains invalid or duplicate file paths.');
  if(/(?:^|\/)(?:vbaProject\.bin|vbaData\.xml)$/i.test(name)||/\.(?:xlsm|xltm|docm|dotm)$/i.test(name))fail('Macro-enabled documents are not imported. Export as XLSX, DOCX, or CSV without macros.');
  names.add(name);total+=expanded;if(total>IMPORT_LIMITS.expandedBytes)fail('The expanded archive is too large. Export only the roster.');
  if(local+30>start||view.getUint32(local,true)!==0x04034b50||view.getUint16(local+8,true)!==method||(view.getUint16(local+6,true)&1))fail('The archive contains an invalid file header.');
  const localName=view.getUint16(local+26,true),localExtra=view.getUint16(local+28,true),data=local+30+localName+localExtra;
  if(data+compressed>start||utf8.decode(bytes.subarray(local+30,local+30+localName))!==name)fail('The archive file headers do not match.');
  records.push({name,method,compressed,expanded,crc:view.getUint32(offset+16,true),offset:data});offset=next;
 }
 if(offset!==start+centralSize)fail('The archive index has unsupported trailing data.');
 return records;
}
function crc32(bytes:Uint8Array){let crc=0xffffffff;for(const value of bytes){crc^=value;for(let i=0;i<8;i++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^0xffffffff)>>>0;}
function extract(bytes:Uint8Array,record:ZipRecord,budget:{used:number}):Uint8Array{
 if(record.expanded>IMPORT_LIMITS.xmlBytes)fail('A document part is too large. Export a smaller roster file.');
 const chunks:Uint8Array[]=[];let size=0;
 const accept=(chunk:Uint8Array)=>{size+=chunk.length;budget.used+=chunk.length;if(size>IMPORT_LIMITS.xmlBytes||budget.used>IMPORT_LIMITS.expandedBytes)fail('This archive expands beyond the import limit.');chunks.push(chunk);};
 const compressed=bytes.subarray(record.offset,record.offset+record.compressed);
 if(record.method===0)accept(compressed);
 else {const inflater=new Inflate(chunk=>accept(chunk));try{for(let cursor=0;cursor<compressed.length;cursor+=8192)inflater.push(compressed.subarray(cursor,cursor+8192),cursor+8192>=compressed.length);}catch(error){if(error instanceof Error&&error.message.includes('import limit'))throw error;fail('A compressed document part is invalid or exceeds the import limit.');}}
 if(size!==record.expanded)fail('A document part has an invalid expanded size.');
 const output=new Uint8Array(size);let position=0;for(const chunk of chunks){output.set(chunk,position);position+=chunk.length;}
 if(crc32(output)!==record.crc)fail('A document part failed its integrity check. Export the file again.');return output;
}
function xml(text:string):Document{
 if(/<!\s*(?:DOCTYPE|ENTITY)\b/i.test(text))fail('Document type declarations and XML entities are not supported.');
 if(text.length>IMPORT_LIMITS.xmlBytes)fail('A document part contains too much text.');
 let nodes=0;for(let position=text.indexOf('<');position>=0;position=text.indexOf('<',position+1))if(++nodes>IMPORT_LIMITS.xmlNodes)fail('A document part has too many XML nodes.');
 if(typeof DOMParser==='undefined')fail('This browser cannot read document files. Use CSV or plain text instead.');
 const result=new DOMParser().parseFromString(text,'application/xml');if(!result.documentElement||result.getElementsByTagName('parsererror').length)fail('The document contains malformed XML. Export the file again.');
 if(result.getElementsByTagName('*').length>IMPORT_LIMITS.xmlNodes)fail('A document part has too many XML nodes.');return result;
}
// Cloudflare also declares an HTMLRewriter Element. The Node intersection
// keeps native XML nodes unambiguous in this mixed browser/Worker project.
type XmlElement=Element&ChildNode;
function descendants(parent:Document|XmlElement,name:string){return Array.from(parent.getElementsByTagNameNS('*',name)) as XmlElement[];}
function children(parent:XmlElement,name?:string){return Array.from(parent.childNodes).filter((node):node is XmlElement=>node.nodeType===1&&(!name||(node as XmlElement).localName===name));}
function attr(element:XmlElement,name:string){return element.getAttribute(name)??Array.from(element.attributes).find(attribute=>attribute.localName===name)?.value??'';}
function texts(element:XmlElement){return cell(descendants(element,'t').map(node=>node.textContent??'').join(''));}
function paragraphText(element:XmlElement,kind:'word'|'ods'){
 const pending:Node[]=Array.from(element.childNodes).reverse();let value='';
 while(pending.length){const node=pending.pop()!;
  if(node.nodeType===3&&kind==='ods')value+=node.nodeValue??'';
  if(node.nodeType===1){const child=node as XmlElement;
   if(kind==='word'&&child.localName==='t')value+=child.textContent??'';
   else if(kind==='word'&&child.localName==='tab'||kind==='ods'&&child.localName==='tab')value+='\t';
   else if(kind==='word'&&(child.localName==='br'||child.localName==='cr')||kind==='ods'&&child.localName==='line-break')value+='\n';
   else if(kind==='ods'&&child.localName==='s')value+=' '.repeat(repeated(attr(child,'c'),IMPORT_LIMITS.cellCharacters));
   else {const nodes=Array.from(child.childNodes);for(let i=nodes.length-1;i>=0;i--)pending.push(nodes[i]);}
  }
  if(value.length>IMPORT_LIMITS.cellCharacters)fail('An imported paragraph exceeds 2,000 characters.');
 }
 return cell(value);
}
function decode(bytes:Uint8Array){try{if(bytes[0]===0xff&&bytes[1]===0xfe)return new TextDecoder('utf-16le',{fatal:true}).decode(bytes);if(bytes[0]===0xfe&&bytes[1]===0xff)return new TextDecoder('utf-16be',{fatal:true}).decode(bytes);return utf8.decode(bytes);}catch{fail('The file has invalid text encoding. Export it as UTF-8 CSV, XLSX, or DOCX.');}}
function repeated(value:string,maximum:number){if(!value)return 1;if(!/^\d+$/.test(value))fail('The spreadsheet has an invalid repeated row or cell.');const repeat=Number(value);if(!Number.isSafeInteger(repeat)||repeat<1||repeat>maximum)fail('The spreadsheet has too many repeated rows or columns.');return repeat;}

function readXlsx(read:(name:string,required?:boolean)=>string|null,names:Set<string>):ImportDocument{
 const warnings:string[]=[ignoredArtwork],workbook=xml(read('xl/workbook.xml',true)!),rels=xml(read('xl/_rels/workbook.xml.rels',true)!);
 const relationships=new Map(descendants(rels,'Relationship').filter(r=>attr(r,'TargetMode')!=='External').map(r=>[attr(r,'Id'),attr(r,'Target')]));
 const sharedRaw=read('xl/sharedStrings.xml'),shared=sharedRaw?descendants(xml(sharedRaw),'si').map(texts):[];if(shared.length>IMPORT_LIMITS.rows*IMPORT_LIMITS.columns)fail('This workbook contains too many shared strings.');
 let formula=false;const sheets=descendants(workbook,'sheet');if(sheets.length>IMPORT_LIMITS.tables)fail('This workbook has too many sheets.');
 const tables=sheets.map((sheet,index)=>{
  const target=relationships.get(attr(sheet,'id'));if(!target)fail('A worksheet relationship is missing or external. Export the sheet as CSV.');
  const clean=target.replace(/^\//,'');const path=clean.startsWith('xl/')?clean:`xl/${clean}`;if(path.split('/').some(part=>part==='..')||!/^xl\/worksheets\/[^/]+\.xml$/.test(path)||!names.has(path))fail('A worksheet has an unsupported file path. Export it as CSV.');
  const source=xml(read(path,true)!),rows:string[][]=[],seenRows=new Set<number>();let fallback=0;
  for(const row of descendants(source,'row')){
   const ref=attr(row,'r'),number=ref?Number(ref):fallback+1;if(!/^\d+$/.test(ref||String(number))||!Number.isInteger(number)||number<1||number>IMPORT_LIMITS.rows)fail('A worksheet extends beyond 1,000 rows. Export only the roster.');fallback=number;
   if(seenRows.has(number))fail('A worksheet contains repeated row addresses.');seenRows.add(number);
   const result:string[]=[],seenColumns=new Set<number>();let column=0;
   for(const c of children(row,'c')){
    const reference=attr(c,'r'),match=reference.match(/^([A-Z]+)\d+$/);if(reference&&!match)fail('A worksheet has an invalid cell address.');
    if(match){column=0;for(const letter of match[1])column=column*26+letter.charCodeAt(0)-64;column--;}
    if(column>=IMPORT_LIMITS.columns)fail('A worksheet extends beyond 64 columns. Export only the columns you need.');
    if(match&&Number(reference.slice(match[1].length))!==number)fail('A worksheet cell does not match its row address.');if(seenColumns.has(column))fail('A worksheet contains repeated cell addresses.');seenColumns.add(column);
    while(result.length<column)result.push('');let value='';
    if(children(c,'f').length){formula=true;}
    else {const type=attr(c,'t'),v=children(c,'v')[0]?.textContent??'';if(type==='s'){if(!/^\d+$/.test(v)||Number(v)>=shared.length)fail('A worksheet references an invalid shared string.');value=shared[Number(v)];}else if(type==='inlineStr')value=texts(c);else if(type==='b')value=v==='1'?'TRUE':'FALSE';else if(type!=='e')value=cell(v);}
    result[column]=value;column++;
   }
   while(rows.length<number-1)rows.push([]);rows[number-1]=result;
  }
  if(descendants(source,'mergeCell').length)warnings.push('Merged cells were read from their top-left cell. Check the selected columns and row order.');
  if(attr(sheet,'state')==='hidden'||attr(sheet,'state')==='veryHidden')warnings.push('This workbook includes hidden sheets. Only the sheet you select is imported.');
  return table(attr(sheet,'name')||`Sheet ${index+1}`,rows,index);
 });if(formula)warnings.push(formulaNotice);return document('xlsx',tables,warnings);
}
function readOds(read:(name:string,required?:boolean)=>string|null):ImportDocument{
 const mime=read('mimetype');if(mime&&mime.trim()!=='application/vnd.oasis.opendocument.spreadsheet')fail('This ODS file is not a spreadsheet.');
 const source=xml(read('content.xml',true)!),warnings:string[]=[ignoredArtwork],sheets=descendants(source,'table').filter(t=>t.parentNode&&((t.parentNode as XmlElement).localName==='spreadsheet'));let formula=false;
 if(sheets.length>IMPORT_LIMITS.tables)fail('This spreadsheet has too many sheets.');
 const tables=sheets.map((sheet,index)=>{
  const rows:string[][]=[];
  const sourceRows=descendants(sheet,'table-row');
  for(const [rowIndex,row] of sourceRows.entries()){
   const values:string[]=[];
   const sourceCells=children(row).filter(c=>c.localName==='table-cell'||c.localName==='covered-table-cell');
   for(const [cellIndex,c] of sourceCells.entries()){
    let value='';if(attr(c,'formula'))formula=true;else {const paragraphs=descendants(c,'p');value=cell(paragraphs.length?paragraphs.map(p=>paragraphText(p,'ods')).join('\n'):attr(c,'string-value')||attr(c,'value'));}
    const countRaw=attr(c,'number-columns-repeated');
    // Large trailing empty repeats are formatting, not roster entries.
    if(!value.trim()&&!attr(c,'formula')&&countRaw&&/^\d+$/.test(countRaw)&&Number(countRaw)>IMPORT_LIMITS.columns-values.length&&cellIndex===sourceCells.length-1)continue;
    const count=repeated(countRaw,IMPORT_LIMITS.columns);if(values.length+count>IMPORT_LIMITS.columns)fail('A spreadsheet has more than 64 columns.');for(let i=0;i<count;i++)values.push(value);
   }
   const countRaw=attr(row,'number-rows-repeated');if(!nonempty(values)&&!sourceCells.some(c=>attr(c,'formula'))&&countRaw&&/^\d+$/.test(countRaw)&&Number(countRaw)>IMPORT_LIMITS.rows-rows.length&&rowIndex===sourceRows.length-1)continue;
   const count=repeated(countRaw,IMPORT_LIMITS.rows);if(rows.length+count>IMPORT_LIMITS.rows)fail('A spreadsheet has more than 1,000 rows.');for(let i=0;i<count;i++)rows.push([...values]);
  }
  return table(attr(sheet,'name')||`Sheet ${index+1}`,rows,index);
 });if(formula)warnings.push(formulaNotice);return document('ods',tables,warnings);
}
function readDocx(read:(name:string,required?:boolean)=>string|null):ImportDocument{
 const source=xml(read('word/document.xml',true)!),body=descendants(source,'body')[0];if(!body)fail('The document has no readable body.');
 const tables:ImportTable[]=[],paragraphs:string[]=[];
 for(const node of children(body)){
  if(node.localName==='p'){const text=paragraphText(node,'word');if(text.trim())paragraphs.push(text);}
  if(node.localName==='tbl'){
   const rows=children(node,'tr').map(row=>children(row,'tc').map(c=>cell(children(c,'p').map(p=>paragraphText(p,'word')).join('\n'))));tables.push(table(`Document table ${tables.length+1}`,rows,tables.length));
  }
 }
 if(paragraphs.length){const parsed=parseImportText(paragraphs.join('\n'),'txt').tables[0];tables.push({...parsed,id:`table-${tables.length}`,name:'Document paragraphs'});}
 return document('docx',tables,[ignoredArtwork,'Document tables and paragraphs are separate choices. Headers and notes can be excluded with the first data row setting.']);
}

export async function parseBracketImport(file:ImportFile):Promise<ImportDocument>{
 const extension=file.name.split('.').pop()?.toLowerCase();
 if(['xls','doc','xlsm','xltm','docm','dotm','xlsb'].includes(extension||''))fail('Legacy and macro-enabled files are not supported. Export the roster as XLSX, DOCX, ODS, or UTF-8 CSV.');
 if(!['csv','tsv','txt','json','xlsx','ods','docx'].includes(extension||''))fail('Choose CSV, TSV, TXT, XLSX, ODS, DOCX, or a BracketLive JSON snapshot.');
 if(!Number.isSafeInteger(file.size)||file.size<1||file.size>IMPORT_LIMITS.fileBytes)fail('Choose a file smaller than 10 MB.');
 const bytes=new Uint8Array(await file.arrayBuffer());if(bytes.length!==file.size||bytes.length>IMPORT_LIMITS.fileBytes)fail('The file size is invalid or exceeds 10 MB.');
 const kind=extension as ImportKind;if(kind==='csv'||kind==='tsv'||kind==='txt'||kind==='json')return parseImportText(decode(bytes),kind);
 const records=zipRecords(bytes),byName=new Map(records.map(record=>[record.name,record])),cache=new Map<string,string>(),budget={used:0};
 const read=(name:string,required=false)=>{if(cache.has(name))return cache.get(name)!;const record=byName.get(name);if(!record){if(required)fail(`A required ${kind.toUpperCase()} document part is missing. Export the file again.`);return null;}const value=decode(extract(bytes,record,budget));cache.set(name,value);return value;};
 const contentTypes=read('[Content_Types].xml');if(contentTypes&&/macroenabled|vbaProject/i.test(contentTypes))fail('Macro-enabled documents are not imported. Export a copy without macros.');
 return kind==='xlsx'?readXlsx(read,new Set(byName.keys())):kind==='ods'?readOds(read):readDocx(read);
}

export function mapImportTable(source:ImportTable,mapping:ImportMapping=source.suggested):{entries:ImportEntry[];warnings:string[];issues:ImportIssue[]}{
 const entries:ImportEntry[]=[],warnings:string[]=[],issues:ImportIssue[]=[];
 if(!Number.isInteger(mapping.startRow)||mapping.startRow<0||mapping.startRow>source.rows.length)fail('Choose a valid first data row.');
 const columns=[mapping.nameColumn,mapping.subtitleColumn,mapping.seedColumn,...(mapping.mode==='paired'?[mapping.opponentColumn,mapping.opponentSubtitleColumn,mapping.opponentSeedColumn]:[])];
 if(columns.some(index=>index!==null&&(!Number.isInteger(index)||index<0||index>=IMPORT_LIMITS.columns))||mapping.nameColumn===null||(mapping.mode==='paired'&&(mapping.opponentColumn===null||mapping.opponentColumn===mapping.nameColumn)))fail('Choose valid, different name columns.');
 let skipped=0;
 const add=(row:string[],rowIndex:number,nameColumn:number,subtitleColumn:number|null,seedColumn:number|null)=>{
  const name=(row[nameColumn]??'').trim(),subtitle=subtitleColumn===null?'':(row[subtitleColumn]??'').trim(),seedText=seedColumn===null?'':(row[seedColumn]??'').trim(),seed=seedText?Number(seedText):entries.length+1;
  if(!name)issues.push({row:rowIndex+1,message:`Row ${rowIndex+1}: add a name for this entry.`});
  if(name.length>100)issues.push({row:rowIndex+1,message:`Row ${rowIndex+1}: the name exceeds 100 characters.`});if(subtitle.length>100)issues.push({row:rowIndex+1,message:`Row ${rowIndex+1}: the subtitle exceeds 100 characters.`});
  if(seedText&&(!/^\d+$/.test(seedText)||!Number.isSafeInteger(seed)||seed<1||seed>128))issues.push({row:rowIndex+1,message:`Row ${rowIndex+1}: source seed must be a whole number from 1 to 128.`});
  entries.push({name,subtitle,image:null,seed:Number.isSafeInteger(seed)&&seed>0&&seed<=128?seed:entries.length+1,sourceRow:rowIndex+1});
 };
 for(let i=mapping.startRow;i<source.rows.length;i++){const row=source.rows[i];if(!nonempty(row)){skipped++;continue;}add(row,i,mapping.nameColumn,mapping.subtitleColumn,mapping.seedColumn);if(mapping.mode==='paired')add(row,i,mapping.opponentColumn!,mapping.opponentSubtitleColumn,mapping.opponentSeedColumn);}
 if(skipped)warnings.push(`${skipped} empty row${skipped===1?' was':'s were'} skipped.`);
 const counts=new Map<string,number>();for(const entry of entries){const key=entry.name.toLocaleLowerCase();counts.set(key,(counts.get(key)??0)+1);}if([...counts.values()].some(count=>count>1))warnings.push('Repeated names are kept as separate entries. Check that each occurrence is intentional.');
 if(mapping.seedColumn!==null||mapping.mode==='paired'&&mapping.opponentSeedColumn!==null)warnings.push('Source seeds are shown for reference. Bracket slots use the imported order; seeds do not rearrange opponents.');
 if(entries.length>128)issues.push({row:0,message:'A bracket can contain at most 128 entries. Select fewer rows or a smaller sheet.'});if(entries.length<2)issues.push({row:0,message:'Import at least two entries to create a bracket.'});
 return {entries,warnings,issues};
}
