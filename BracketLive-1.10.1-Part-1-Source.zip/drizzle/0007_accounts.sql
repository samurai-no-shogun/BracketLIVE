CREATE TABLE accounts (
 id TEXT PRIMARY KEY NOT NULL,
 identity_id TEXT NOT NULL UNIQUE,
 name TEXT NOT NULL,
 email TEXT NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE TABLE account_credentials (
 provider TEXT NOT NULL,
 subject_hash TEXT NOT NULL,
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 PRIMARY KEY(provider,subject_hash)
);
CREATE INDEX account_credentials_account ON account_credentials(account_id);
CREATE TABLE account_sessions (
 token_hash TEXT PRIMARY KEY NOT NULL,
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 created_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL
);
CREATE INDEX account_sessions_account ON account_sessions(account_id);
CREATE INDEX account_sessions_expiry ON account_sessions(expires_at);
CREATE TABLE account_challenges (
 token_hash TEXT PRIMARY KEY NOT NULL,
 kind TEXT NOT NULL,
 browser_hash TEXT NOT NULL,
 source_identity TEXT NOT NULL,
 subject_hash TEXT NOT NULL DEFAULT '',
 payload TEXT NOT NULL,
 return_to TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 expires_at INTEGER NOT NULL,
 consumed_at INTEGER,
 claim TEXT
);
CREATE INDEX account_challenges_quota ON account_challenges(kind,subject_hash,created_at);
CREATE INDEX account_challenges_expiry ON account_challenges(expires_at);
CREATE TABLE account_identity_claims (
 identity_id TEXT PRIMARY KEY NOT NULL,
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 created_at INTEGER NOT NULL
);
