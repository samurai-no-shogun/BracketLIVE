CREATE TABLE IF NOT EXISTS discord_media (
 id TEXT PRIMARY KEY, room_key TEXT NOT NULL, owner_id TEXT NOT NULL,
 type TEXT NOT NULL, bytes INTEGER NOT NULL, ready INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS discord_media_owner ON discord_media(owner_id,created_at);
CREATE TABLE IF NOT EXISTS discord_exports (
 id TEXT PRIMARY KEY, room_key TEXT NOT NULL, owner_id TEXT NOT NULL,
 type TEXT NOT NULL, bytes INTEGER NOT NULL, ready INTEGER NOT NULL DEFAULT 0,
 created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS discord_exports_expiry ON discord_exports(expires_at);
CREATE INDEX IF NOT EXISTS discord_exports_owner ON discord_exports(owner_id,created_at);
