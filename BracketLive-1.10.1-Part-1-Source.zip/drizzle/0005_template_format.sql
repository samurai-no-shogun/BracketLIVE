ALTER TABLE `brackets` ADD COLUMN `format` text NOT NULL DEFAULT 'standard';
