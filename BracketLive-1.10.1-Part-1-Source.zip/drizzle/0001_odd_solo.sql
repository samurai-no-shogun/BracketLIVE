ALTER TABLE `brackets` ADD `brand_color` text;--> statement-breakpoint
ALTER TABLE `brackets` ADD `brand_image` text;--> statement-breakpoint
ALTER TABLE `brackets` ADD `listed` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `brackets` ADD `is_test` integer DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `brackets` ADD `started_at` integer;--> statement-breakpoint
ALTER TABLE `brackets` ADD `ends_at` integer;--> statement-breakpoint
ALTER TABLE `brackets` ADD `round_closes_at` integer;--> statement-breakpoint
CREATE INDEX `brackets_directory` ON `brackets` (`listed`,`is_test`,`status`,`created_at`);--> statement-breakpoint
ALTER TABLE `matches` ADD `decided_by` text;