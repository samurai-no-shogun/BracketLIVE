CREATE TABLE `brackets` (
	`id` text PRIMARY KEY NOT NULL,
	`title` text NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`size` integer NOT NULL,
	`accent` text DEFAULT 'purple' NOT NULL,
	`status` text DEFAULT 'draft' NOT NULL,
	`current_round` integer DEFAULT 0 NOT NULL,
	`owner_id` text NOT NULL,
	`manage_hash` text NOT NULL,
	`advance_token` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `brackets_owner` ON `brackets` (`owner_id`);--> statement-breakpoint
CREATE TABLE `entries` (
	`id` text PRIMARY KEY NOT NULL,
	`bracket_id` text NOT NULL,
	`name` text NOT NULL,
	`subtitle` text DEFAULT '' NOT NULL,
	`image` text,
	`seed` integer NOT NULL,
	FOREIGN KEY (`bracket_id`) REFERENCES `brackets`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `entries_bracket` ON `entries` (`bracket_id`);--> statement-breakpoint
CREATE TABLE `managers` (
	`bracket_id` text NOT NULL,
	`identity_id` text NOT NULL,
	PRIMARY KEY(`bracket_id`, `identity_id`),
	FOREIGN KEY (`bracket_id`) REFERENCES `brackets`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `managers_identity` ON `managers` (`identity_id`);--> statement-breakpoint
CREATE TABLE `matches` (
	`id` text PRIMARY KEY NOT NULL,
	`bracket_id` text NOT NULL,
	`round` integer NOT NULL,
	`position` integer NOT NULL,
	`a_id` text,
	`b_id` text,
	`winner_id` text,
	`status` text NOT NULL,
	FOREIGN KEY (`bracket_id`) REFERENCES `brackets`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`a_id`) REFERENCES `entries`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`b_id`) REFERENCES `entries`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`winner_id`) REFERENCES `entries`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `matches_bracket_round` ON `matches` (`bracket_id`,`round`);--> statement-breakpoint
CREATE TABLE `media` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`content_type` text NOT NULL,
	`size` integer NOT NULL,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `media_owner_created` ON `media` (`owner_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `votes` (
	`match_id` text NOT NULL,
	`voter_id` text NOT NULL,
	`entry_id` text NOT NULL,
	`updated_at` integer NOT NULL,
	PRIMARY KEY(`match_id`, `voter_id`),
	FOREIGN KEY (`match_id`) REFERENCES `matches`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`entry_id`) REFERENCES `entries`(`id`) ON UPDATE no action ON DELETE no action
);
