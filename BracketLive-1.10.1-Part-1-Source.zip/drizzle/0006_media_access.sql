ALTER TABLE media ADD COLUMN validation_version INTEGER NOT NULL DEFAULT 0;
CREATE INDEX IF NOT EXISTS entries_image_idx ON entries(image);
CREATE INDEX IF NOT EXISTS brackets_brand_image_idx ON brackets(brand_image);
CREATE INDEX IF NOT EXISTS brackets_page_image_idx ON brackets(json_extract(appearance, '$.images.page_background'));
CREATE INDEX IF NOT EXISTS brackets_board_image_idx ON brackets(json_extract(appearance, '$.images.board_background'));
CREATE INDEX IF NOT EXISTS brackets_center_image_idx ON brackets(json_extract(appearance, '$.images.center_logo'));
CREATE INDEX IF NOT EXISTS brackets_champion_image_idx ON brackets(json_extract(appearance, '$.images.champion_logo'));
CREATE INDEX IF NOT EXISTS brackets_footer_image_idx ON brackets(json_extract(appearance, '$.images.footer_logo'));
