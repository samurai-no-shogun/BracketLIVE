CREATE TABLE IF NOT EXISTS seasons (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  points TEXT NOT NULL,
  entrants TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  manage_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  version INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS seasons_owner ON seasons(owner_id, created_at);
CREATE INDEX IF NOT EXISTS seasons_created ON seasons(created_at);
CREATE TABLE IF NOT EXISTS season_managers (
  season_id TEXT NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
  identity_id TEXT NOT NULL,
  PRIMARY KEY (season_id, identity_id)
);
CREATE INDEX IF NOT EXISTS season_managers_identity ON season_managers(identity_id);
CREATE TABLE IF NOT EXISTS season_events (
  id TEXT PRIMARY KEY NOT NULL,
  season_id TEXT NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  event_date TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'complete')),
  results TEXT NOT NULL DEFAULT '[]',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  version INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS season_events_season ON season_events(season_id, created_at);
