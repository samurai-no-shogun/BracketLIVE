ALTER TABLE brackets ADD COLUMN voting_schedule TEXT;
ALTER TABLE brackets ADD COLUMN schedule_revision INTEGER NOT NULL DEFAULT 0;
ALTER TABLE brackets ADD COLUMN schedule_blocked_reason TEXT;
ALTER TABLE brackets ADD COLUMN schedule_checked_at INTEGER NOT NULL DEFAULT 0;
CREATE INDEX brackets_due_schedule ON brackets(status,round_closes_at,schedule_checked_at);
CREATE TABLE creator_alert_settings (
 bracket_id TEXT PRIMARY KEY NOT NULL REFERENCES brackets(id) ON DELETE CASCADE,
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 enabled INTEGER NOT NULL DEFAULT 0,
 updated_at INTEGER NOT NULL
);
CREATE TABLE tournament_round_results (
 id TEXT PRIMARY KEY NOT NULL,
 bracket_id TEXT NOT NULL REFERENCES brackets(id) ON DELETE CASCADE,
 round INTEGER NOT NULL,
 kind TEXT NOT NULL,
 schedule_revision INTEGER NOT NULL,
 summary TEXT NOT NULL,
 created_at INTEGER NOT NULL,
 UNIQUE(bracket_id,round,kind,schedule_revision)
);
CREATE INDEX tournament_results_bracket ON tournament_round_results(bracket_id,created_at);
CREATE TABLE creator_alert_outbox (
 id TEXT PRIMARY KEY NOT NULL REFERENCES tournament_round_results(id) ON DELETE CASCADE,
 bracket_id TEXT NOT NULL REFERENCES brackets(id) ON DELETE CASCADE,
 account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
 status TEXT NOT NULL DEFAULT 'pending',
 payload TEXT,
 attempts INTEGER NOT NULL DEFAULT 0,
 next_attempt_at INTEGER NOT NULL DEFAULT 0,
 first_attempt_at INTEGER,
 lease_token TEXT,
 lease_until INTEGER,
 sent_at INTEGER,
 created_at INTEGER NOT NULL
);
CREATE INDEX creator_alert_outbox_due ON creator_alert_outbox(status,next_attempt_at,lease_until);
