CREATE TABLE `analytics_events` (
	`id` text PRIMARY KEY NOT NULL,
	`visitor_id` text NOT NULL,
	`kind` text NOT NULL,
	`path` text NOT NULL,
	`bracket_id` text,
	`source` text NOT NULL,
	`campaign` text DEFAULT '' NOT NULL,
	`device` text NOT NULL,
	`is_test` integer DEFAULT false NOT NULL,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`bracket_id`) REFERENCES `brackets`(`id`) ON UPDATE no action ON DELETE cascade
);
--> statement-breakpoint
CREATE INDEX `analytics_bracket_time` ON `analytics_events` (`bracket_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `analytics_time_kind` ON `analytics_events` (`created_at`,`kind`);--> statement-breakpoint
CREATE INDEX `analytics_visitor_time` ON `analytics_events` (`visitor_id`,`created_at`);