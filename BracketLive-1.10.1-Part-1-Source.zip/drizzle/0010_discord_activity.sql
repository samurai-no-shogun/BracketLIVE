-- Discord data is separate from public web brackets. Room keys come only from
-- Discord's server-verified Activity location, never a client-supplied channel.
CREATE TABLE IF NOT EXISTS discord_sessions (
 token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, display_name TEXT NOT NULL,
 instance_id TEXT NOT NULL, room_key TEXT NOT NULL, expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS discord_sessions_expiry ON discord_sessions(expires_at);
CREATE TABLE IF NOT EXISTS discord_tournaments (
 id TEXT PRIMARY KEY, room_key TEXT NOT NULL, owner_id TEXT NOT NULL,
 state_json TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0,
 mutation_id TEXT, created_at INTEGER NOT NULL, closes_at INTEGER
);
CREATE INDEX IF NOT EXISTS discord_tournaments_room ON discord_tournaments(room_key,created_at);
CREATE INDEX IF NOT EXISTS discord_tournaments_due ON discord_tournaments(closes_at);
CREATE TABLE IF NOT EXISTS discord_votes (
 tournament_id TEXT NOT NULL REFERENCES discord_tournaments(id) ON DELETE CASCADE,
 match_id TEXT NOT NULL, user_id TEXT NOT NULL, entry_id TEXT NOT NULL,
 PRIMARY KEY(tournament_id,match_id,user_id)
);
