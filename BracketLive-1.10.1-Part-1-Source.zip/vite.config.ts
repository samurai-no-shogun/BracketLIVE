import vinext from 'vinext';
import {defineConfig} from 'vite';

export default defineConfig(async()=>{
 process.env.CLOUDFLARE_CF_FETCH_ENABLED ??= 'false';
 process.env.WRANGLER_SEND_METRICS ??= 'false';
 const {cloudflare}=await import('@cloudflare/vite-plugin');
 return {plugins:[vinext(),cloudflare({
  viteEnvironment:{name:'rsc',childEnvironments:['ssr']},
  inspectorPort:false,
  // Read bindings and compatibility flags once from the install's Wrangler file.
  // Repeating its arrays here makes Vite concatenate duplicate bindings/flags.
  config:{main:'./build/worker.ts'}
 })]};
});
