# Bracket Live for Cloudflare Workers

Start with `README-CLOUDFLARE.txt`. The zip contains the complete source and a prebuilt Worker, so the initial deployment requires only Node and Wrangler.

For the 1.10.1 update, read `README-UPDATE.txt`. The Discord Activity now includes
Build, Import, Public templates, contender image uploads and PNG results exports.
Extract into a separate folder and open `START-PREVIEW.cmd` to preview before deployment.

This export is based on Bracket Live site version 10, source commit ed8730eee1cff2e36b5fa22d032e461a43dd5e9f.
