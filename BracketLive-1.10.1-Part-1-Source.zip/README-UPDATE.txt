BRACKETLIVE 1.10.1 — ACTIVITY WORKSPACE, IMPORTS & RESULTS

WHAT CHANGED
- Discord HTTP requests now send the required User-Agent and correct content type.
- Activity membership uses Discord's documented Activity Instance API endpoint.
- Sign-in failures identify the failing request and provide a safe diagnostic code;
  logs never include secrets, authorization codes, raw responses or Discord IDs.
- The public configuration check now includes version=1.10.1. configured=true
  confirms secret presence, not successful sign-in. No new migration is added.
- Clear navigation: My tournaments, Build, Import, Public templates.
- Full contender editor: names, descriptions, images and pairing order.
- Reviewed CSV/Excel imports with sheet, column and row selection. Also accepts
  TSV, ODS, Word tables, text and JSON rosters. XLSX is supported; legacy XLS is not.
- Public template gallery: original 64-entry Trial Bracket and real 2026 NCAA
  men's Round of 64 example. Each creates a separate editable tournament.
- 27 matching supplied HD originals replace the old anime sprite images.
  All 64 entries and pairings remain in order. Missing originals remain text-only.
  Blank, duplicate and mislabeled images were excluded. See docs/ANIME-ARTWORK.json.
- Dedicated champion screen with final percentage, runner-up and totals.
- Export a 1920 x 1080 results PNG or the entire bracket PNG at any stage.
- In Discord, exports have an explicit browser download link valid for 24 hours.
  Anyone who has that link can download the exported image. Uploaded contender
  photos remain accessible only to verified participants in their Discord channel.
- Responsive layout, light/dark controls, mute, voting feedback and undo remain.

PREVIEW BEFORE DEPLOYING
1. Extract this ZIP into a NEW folder, such as:
   C:\Users\mckeo\BracketLive-Preview-1.10.1
2. In that folder run: node scripts/preview-local.mjs
3. Keep PowerShell open. After Ready, open:
   http://127.0.0.1:8787/discord?demo=1
4. Build or import a roster, add an image, or run either public template.
   Cast votes, undo, close rounds and reach a champion. Export results and the
   whole bracket. Local practice is single-browser memory, not a shared Discord vote.
   The separate gallery URL is /discord?catalog=1.

PRODUCTION UPDATE
- Back up existing wrangler.json before extracting over your existing installation.
- This ZIP excludes Wrangler configuration, credentials, tokens and databases.
- Existing Discord client secret and bot token do not need to be entered again.
- Run configure-security.mjs, then configure-discord.mjs with your public app ID.
  Both preserve production database, bucket, routes and secrets. The ASSETS binding
  repair from 1.9.1 remains in place.
- Apply ALL D1 migrations, including the NEW 0011_discord_media.sql, BEFORE deploying.
  Stop if migrations fail. No new Cloudflare bucket is required.
- Built client and Worker files are included. A rebuild must run npm run build,
  which builds both the website and Activity client.
- Follow docs/DISCORD-SETUP.txt for a two-account Discord test after deployment.

FEATURE BOUNDARY
Existing website features remain. Activity elimination brackets now support roster
imports, contender image uploads, public templates and PNG/CSV exports. Points-based
seasons, full branding, the VS studio, Google/email profile linking, creator email
alerts and timezone/calendar schedules remain website features. They are not yet
exposed in this embedded Activity interface. Website and channel tournaments are
separate records. Do not claim full feature parity or verified live Discord voting.
