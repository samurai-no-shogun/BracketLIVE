import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {fileURLToPath} from 'node:url';
export default defineConfig({root:fileURLToPath(new URL('.',import.meta.url)),base:'/discord-activity/',publicDir:false,plugins:[react()],build:{outDir:'../dist/client/discord-activity',emptyOutDir:true}});
