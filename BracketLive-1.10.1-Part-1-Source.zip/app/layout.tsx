import type { Metadata } from "next";
import {cookies} from "next/headers";
import "./globals.css";
import "@/components/glass-shell.css";
import "@/components/workspace-glass.css";
import "@/components/hub-glass.css";
import "@/components/matchup-studio.css";
import AnalyticsTracker from "@/components/analytics-tracker";
import {SitePreferences} from "@/components/site-preferences";
import "@/components/featured-home.css";
import "@/components/vote-celebration.css";
import "@/components/account.css";
import "@/components/site-preferences.css";

export const metadata: Metadata = {
  title: "Bracket Live",
  description: "Create and brand your own tournament, share it, vote in live matchups, and follow the results.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const theme=(await cookies()).get('bl_theme')?.value==='dark'?'dark':'light';
  return (
    <html lang="en" data-theme={theme} className={theme==='dark'?'dark':undefined} suppressHydrationWarning>
      <body className="antialiased"><SitePreferences/>{children}<AnalyticsTracker/><footer className="platform-footer"><a href="/privacy">Privacy & analytics</a><a href="/admin">Site owner</a><span>Bracket Live</span></footer></body>
    </html>
  );
}
