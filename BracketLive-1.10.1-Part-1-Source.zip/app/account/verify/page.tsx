import AccountVerify from '@/components/account-verify';
export const metadata = { title: 'Confirm sign-in | Bracket Live', robots: { index: false, follow: false } };
export default function Page() { return <AccountVerify/>; }
