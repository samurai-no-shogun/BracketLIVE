import AccountDashboard from '@/components/account-dashboard';
export const metadata = { title: 'My tournaments & profile | Bracket Live', description: 'Save, manage, and share your brackets and points seasons.', robots: { index: false, follow: false } };
export default function Page() { return <AccountDashboard/>; }
