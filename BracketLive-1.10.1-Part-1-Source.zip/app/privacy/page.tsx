import {SiteHeader} from '@/components/tournament-ui';
import PrivacyPreferences from '@/components/privacy-preferences';

export default function Page(){return <div className="app"><SiteHeader/><main className="privacy-page">
 <span className="eyebrow">BRACKET LIVE</span><h1>Privacy & analytics</h1>
 <section className="analytics-panel"><h2>Voting and saved tournaments</h2>
  <p>A first-party browser cookie keeps track of guest votes, saved tournaments, and organizer access for up to one year. You can vote without an account. Signing in attaches this browser’s tournaments and votes to your profile so you can access them on another device. Keep a private organizer link for any tournament you have not saved to an account.</p>
  <p>Each saved vote contains a pseudonymous account or hashed browser identifier, matchup, selected contender, and the time it was last submitted or changed. Changing your vote replaces that record; undo removes it while voting is open. One vote is counted per signed-in account and matchup, or per browser for guests. When a guest signs in, duplicate votes in currently open matches are merged, with an existing account vote taking precedence. Closed results remain unchanged. Guest voting does not verify a person’s identity: another browser or cleared cookies can create another voter.</p>
  <p>Public tournaments reveal aggregate match results after you vote or when the match closes. Their organizers can see aggregate results while voting is open. Private test runs require organizer access and are excluded from site-wide reports.</p>
  <p>Tournament details, votes, and analytics records are stored in Cloudflare D1. Uploaded images are stored in Cloudflare R2, with file metadata and their uploader’s pseudonymous identifier in D1. Names and images you add to a published tournament are visible to its visitors. The “My picks” feature saves your predictions in this browser’s local storage; it does not submit public votes.</p>
 </section>
 <section className="analytics-panel"><h2>Optional profiles</h2>
  <p>Profiles store your email address, display name, and sign-in provider in Cloudflare D1. Google sign-in also stores Google’s account identifier. We request only basic identity information, not contacts, files, or mail access. Email sign-in uses a single-use link delivered through Resend; that provider receives your email address to deliver the message.</p>
  <p>Your profile email is not displayed on public brackets or analytics reports. Account sessions use a separate HttpOnly cookie. Signing out ends that session and starts a fresh guest browser identity. Theme and mute controls remain available beside your profile.</p>
  <p>Accounts are optional. Google and email sign-in are available only after the site owner configures those services. Private organizer links remain access credentials: share the public voting link when inviting voters.</p>
 </section>
 <section className="analytics-panel"><h2>Discord Activity</h2>
  <p>The Discord Activity requests basic identity only. Discord account IDs identify creators and votes. Temporary session records contain a display name, channel context, a hashed session token, and expiry. OAuth tokens are used for sign-in and are not stored in the tournament database. No email address, contacts, or chat history is requested.</p>
  <p>Activity tournaments and votes are separate from public website brackets and stored in Cloudflare D1. Participants verified in the same Discord channel can access its saved tournaments, including people who join that channel later. Creators see aggregate results, not a list of individual choices. Leaving Discord does not erase historical votes. Undo deletes your vote while the round is open.</p>
  <p>Contender images uploaded in the Activity are stored in Cloudflare R2. Their metadata includes the uploader’s Discord ID and channel context. Access requires a verified participant in that channel. When you export a PNG, a separate image and unguessable download link are created for 24 hours. Anyone with that link can download the exported image. Expired links stop working and exported files are removed by the scheduled cleanup. Spreadsheet imports are processed on your device; only the roster you review and use is submitted when you start a tournament.</p>
  <p>Activity sessions expire within eight hours. Saved tournaments and votes have no automatic deletion schedule. Theme and mute preferences stay on your device. Website visit analytics and advertising scripts do not run inside the Activity. Local practice mode keeps its tournament in browser memory only.</p>
 </section>
 <section className="analytics-panel"><h2>Visit analytics</h2>
  <p>Visit analytics is on by default. It records page views and successful voting-link copies or device-share actions using a pseudonymous account or hashed browser identifier. Each record includes the page, time, referring domain, general device type, and a campaign name when a link uses utm_campaign. Tracking currently covers the home page, Explore, bracket creation, and posted elimination brackets; points-season pages are not tracked.</p>
  <p>These analytics records do not store IP addresses, full user-agent strings, full referring URLs, or organizer-link tokens. The server reads browser headers to determine general device type and uses IP addresses for request rate limiting. This describes the app’s stored analytics records, not any separate hosting-provider operational logs.</p>
  <p>Creators see aggregate analytics for their own tournaments. The site owner sees aggregate platform reports. Unique visitors and voters mean recognized accounts or browsers, not verified people. No name or email address is requested to vote.</p>
  <p>Your browser’s Do Not Track or Global Privacy Control signal turns visit analytics off. You can also turn it off below. Opting out stops future visit and link-share records from this browser; it does not delete past records or the votes needed to run a tournament.</p>
 </section>
 <PrivacyPreferences/>
 <section className="analytics-panel"><h2>Storage and retention</h2>
  <p>Your sound, analytics preference, and personal picks are stored on this device. Light/dark appearance is stored on this device and in a first-party theme cookie so pages open in the mode you chose. There is currently no automatic deletion schedule for stored tournament or analytics data. The 7-, 30-, and 90-day report filters select what a report shows; they do not delete older records.</p>
 </section>
 <section className="analytics-panel"><h2>Advertising</h2>
  <p>No ad provider is currently connected, and no third-party advertising requests run. Reserved placements will be labeled “Advertisement.” Advertising and any needed privacy choices must be configured before a provider is activated.</p>
 </section>
 <a className="button" href="/">Back to tournaments</a>
</main></div>;}
