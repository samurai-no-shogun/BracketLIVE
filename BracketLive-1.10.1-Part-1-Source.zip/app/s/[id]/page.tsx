import SeasonApp from '@/components/season-app';
import { db } from '@/lib/server';
export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  try { const season = await db().prepare('SELECT title,description FROM seasons WHERE id=?').bind((await params).id).first<{ title: string; description: string }>();
    return season ? { title: `${season.title} | Bracket Live`, description: season.description || `Follow the live points standings for ${season.title}.` } : { title: 'Season standings | Bracket Live' };
  } catch { return { title: 'Season standings | Bracket Live' }; }
}
export default async function Page({ params }: { params: Promise<{ id: string }> }) { return <SeasonApp seasonId={(await params).id}/>; }
