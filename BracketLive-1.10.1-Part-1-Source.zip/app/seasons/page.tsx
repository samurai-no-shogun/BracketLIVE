import SeasonHub from '@/components/season-hub';
export const metadata = { title: 'Points-based seasons & standings | Bracket Live', description: 'Create a points-based championship, record event results, and share live standings.' };
export default async function Page({searchParams}:{searchParams:Promise<{create?:string}>}) { const {create}=await searchParams;return <SeasonHub startCreating={create==='1'}/>; }
