import BracketApp from '@/components/bracket-app';
import FeaturedHome from '@/components/featured-home';
import {getFeaturedBracketId} from '@/lib/featured-server';

export const dynamic='force-dynamic';
export default async function Page(){
 const id=await getFeaturedBracketId();
 return id?<BracketApp bracketId={id} featured/>:<FeaturedHome/>;
}
