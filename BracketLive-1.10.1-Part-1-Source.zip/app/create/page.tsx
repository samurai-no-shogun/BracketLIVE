import BracketApp from '@/components/bracket-app';
import TournamentChooser from '@/components/tournament-choices';
export default async function Page({searchParams}:{searchParams:Promise<{type?:string;template?:string;from?:string}>}){const {type,template,from}=await searchParams;if(type!=='elimination'&&!template&&!from)return <TournamentChooser/>;return <BracketApp template={template==='basketball'?'basketball':template==='trial'||template==='anime'?'trial':undefined} copyFrom={from}/>;}
