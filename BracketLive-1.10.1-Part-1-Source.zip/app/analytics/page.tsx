import AnalyticsDashboard from '@/components/analytics-dashboard';
export default async function Page({searchParams}:{searchParams:Promise<{bracket?:string}>}){const {bracket}=await searchParams;return <AnalyticsDashboard bracketId={bracket}/>;}
