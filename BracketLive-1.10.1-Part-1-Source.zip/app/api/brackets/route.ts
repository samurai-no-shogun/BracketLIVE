import {boundary,db,identity,json,saveDraft,settleExpired,sqlNow} from '@/lib/server';
export async function POST(req:Request){return boundary(()=>saveDraft(req));}
export async function GET(req:Request){return boundary(async()=>{
 const who=await identity(req);
 const owned=(await db().prepare(`SELECT b.id FROM brackets b JOIN managers m ON m.bracket_id=b.id WHERE m.identity_id=? AND b.status=? AND b.round_closes_at<=${sqlNow} ORDER BY b.round_closes_at,b.id LIMIT 1`).bind(who.id,'live').all<{id:string}>()).results;
 // Bound background expiry work; a direct bracket view catches up all its rounds.
 if(owned[0])await settleExpired(owned[0].id);
 const rows=await db().prepare(`SELECT b.id,b.title,b.description,b.size,b.format,b.status,b.current_round,b.created_at,b.accent,b.brand_color,b.brand_image,b.is_test,b.ends_at,b.round_closes_at,(SELECT COUNT(*) FROM votes v JOIN matches m ON m.id=v.match_id WHERE m.bracket_id=b.id) AS totalVotes,(SELECT e.name FROM matches m JOIN entries e ON e.id=m.winner_id WHERE m.bracket_id=b.id ORDER BY m.round DESC LIMIT 1) AS champion FROM brackets b JOIN managers mg ON mg.bracket_id=b.id WHERE mg.identity_id=? ORDER BY b.created_at DESC LIMIT 100`).bind(who.id).all();
 return json({brackets:rows.results},200,who.cookie);
});}
