import {boundary,getVotingSchedule,saveVotingSchedule} from '@/lib/server';
export async function GET(req:Request,c:{params:Promise<{id:string}>}){return boundary(async()=>getVotingSchedule(req,(await c.params).id));}
export async function PUT(req:Request,c:{params:Promise<{id:string}>}){return boundary(async()=>saveVotingSchedule(req,(await c.params).id));}
