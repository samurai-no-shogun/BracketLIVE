import {z} from 'zod';
import {ApiError,body,boundary,db,hash,identity,json,originCheck,requireOwner,token} from '@/lib/server';

const ManageRequest=z.object({token:z.string().regex(/^[a-f0-9]{64}$/).optional(),revokeOthers:z.boolean().default(false)})
 .refine(data=>!data.token||!data.revokeOthers,'Open your organizer link before resetting access.');

export async function POST(req:Request,c:{params:Promise<{id:string}>}){return boundary(async()=>{
 originCheck(req);
 const {id}=await c.params,who=await identity(req),data=ManageRequest.parse(await body(req)),database=db();
 if(data.token){
  // Verify and grant in the same statement so token rotation cannot race admission.
  const result=await database.prepare('INSERT INTO managers(bracket_id,identity_id) SELECT id,? FROM brackets WHERE id=? AND manage_hash=? ON CONFLICT(bracket_id,identity_id) DO UPDATE SET identity_id=excluded.identity_id')
   .bind(who.id,id,await hash(data.token)).run();
  if(!result.meta.changes)throw new ApiError(403,'This organizer link is invalid or has been replaced.');
  return json({ok:true},200,who.cookie);
 }
 await requireOwner(id,who.id);
 const fresh=token(),freshHash=await hash(fresh);
 const statements=[database.prepare('UPDATE brackets SET manage_hash=? WHERE id=? AND EXISTS(SELECT 1 FROM managers WHERE bracket_id=? AND identity_id=?)').bind(freshHash,id,id,who.id)];
 if(data.revokeOthers)statements.push(database.prepare('DELETE FROM managers WHERE bracket_id=? AND identity_id<>? AND EXISTS(SELECT 1 FROM brackets WHERE id=? AND manage_hash=?)').bind(id,who.id,id,freshHash));
 const results=await database.batch(statements);
 if(!results[0].meta.changes)throw new ApiError(403,'Your organizer access was reset in another browser. Open the current private organizer link.');
 return json({manageToken:fresh,revokedOthers:data.revokeOthers},200,who.cookie);
});}
