import {ApiError,advanceRound,body,boundary,identity,json,originCheck,requireOwner,snapshot} from '@/lib/server';
import {z} from 'zod';
export async function POST(req:Request,c:{params:Promise<{id:string}>}){return boundary(async()=>{
 originCheck(req);const {id}=await c.params;const who=await identity(req);await requireOwner(id,who.id);
 const {round,ties}=z.object({round:z.number().int().min(0).max(6),ties:z.record(z.string().max(100)).default({})}).parse(await body(req));
 const b=await snapshot(id,who.id);if(b.status!=='live'||b.current_round!==round)throw new ApiError(409,'The round has changed. Refresh to see the results.');
 if(!await advanceRound(id,round,ties,false,who.id)){await requireOwner(id,who.id);throw new ApiError(409,'Resolve every tied match before closing, or refresh if the deadline has passed.');}
 return json(await snapshot(id,who.id),200,who.cookie);
});}
