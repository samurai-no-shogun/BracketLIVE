import {boundary,saveAppearance} from '@/lib/server';
export async function PUT(req:Request,{params}:{params:Promise<{id:string}>}){return boundary(async()=>saveAppearance(req,(await params).id));}
