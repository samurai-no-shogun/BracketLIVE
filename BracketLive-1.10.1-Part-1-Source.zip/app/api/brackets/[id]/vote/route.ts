import {ApiError,body,boundary,db,identity,json,originCheck,requireOwner,settleExpired,snapshot,sqlNow} from '@/lib/server';
import {z} from 'zod';
export async function POST(req:Request,c:{params:Promise<{id:string}>}){return boundary(async()=>{
 originCheck(req);const {id}=await c.params;const who=await identity(req);
 const b=await db().prepare('SELECT is_test FROM brackets WHERE id=?').bind(id).first<{is_test:number}>();if(b?.is_test)await requireOwner(id,who.id);
 const {matchId,entryId}=z.object({matchId:z.string().max(100),entryId:z.string().max(100).nullable()}).parse(await body(req));
 await settleExpired(id);
 const gate=`m.status='open' AND b.status='live' AND b.schedule_blocked_reason IS NULL AND m.round=b.current_round AND (b.round_closes_at IS NULL OR b.round_closes_at>${sqlNow}) AND (b.is_test=0 OR EXISTS(SELECT 1 FROM managers WHERE bracket_id=b.id AND identity_id=?)) AND NOT EXISTS(SELECT 1 FROM account_identity_claims WHERE identity_id=?)`;
 let result;
 if(entryId===null)result=await db().prepare(`DELETE FROM votes WHERE match_id=? AND voter_id=? AND EXISTS(SELECT 1 FROM matches m JOIN brackets b ON b.id=m.bracket_id WHERE m.id=votes.match_id AND m.bracket_id=? AND ${gate})`).bind(matchId,who.id,id,who.id,who.id).run();
 else result=await db().prepare(`INSERT INTO votes(match_id,voter_id,entry_id,updated_at) SELECT m.id,?,?,? FROM matches m JOIN brackets b ON b.id=m.bracket_id WHERE m.id=? AND m.bracket_id=? AND ${gate} AND (?=m.a_id OR ?=m.b_id) ON CONFLICT(match_id,voter_id) DO UPDATE SET entry_id=excluded.entry_id,updated_at=excluded.updated_at`).bind(who.id,entryId,Date.now(),matchId,id,who.id,who.id,entryId,entryId).run();
 if(!result.meta.changes){const m=await db().prepare(`SELECT m.id FROM matches m JOIN brackets b ON b.id=m.bracket_id WHERE m.id=? AND m.bracket_id=? AND ${gate}`).bind(matchId,id,who.id,who.id).first();if(!m||entryId!==null)throw new ApiError(409,'Voting for this match is closed or the contender is unavailable. Refresh to see the results.');}
 return json(await snapshot(id,who.id),200,who.cookie);
});}
