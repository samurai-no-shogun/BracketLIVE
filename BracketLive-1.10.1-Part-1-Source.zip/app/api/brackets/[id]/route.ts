import {boundary,identity,json,saveDraft,snapshot} from '@/lib/server';
type C={params:Promise<{id:string}>};
export async function GET(req:Request,c:C){return boundary(async()=>{const who=await identity(req);return json(await snapshot((await c.params).id,who.id),200,who.cookie);});}
export async function PUT(req:Request,c:C){return boundary(async()=>saveDraft(req,(await c.params).id));}
