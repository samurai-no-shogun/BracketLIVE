import {ApiError,boundary,bucket,db,identity} from '@/lib/server';
import {ImageValidationError,validateImage} from '@/lib/image-validation';
export async function GET(req:Request,c:{params:Promise<{key:string}>}){return boundary(async()=>{
 const {key}=await c.params;
 const match=/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.(png|jpg|webp|gif)$/.exec(key);
 if(!match)throw new ApiError(404,'Image not found.');
 const who=await identity(req),record=await db().prepare('SELECT owner_id,validation_version FROM media WHERE id=?').bind(key).first<{owner_id:string;validation_version:number}>();
 if(!record)throw new ApiError(404,'Image not found.');
 let isPublic=false;
 if(record.owner_id!==who.id){
  const image=`/api/media/${key}`;
  const access=await db().prepare(`SELECT
   MAX(CASE WHEN b.status<>'draft' AND b.is_test=0 THEN 1 ELSE 0 END) AS public,
   MAX(CASE WHEN mg.identity_id IS NOT NULL THEN 1 ELSE 0 END) AS manager
   FROM brackets b LEFT JOIN managers mg ON mg.bracket_id=b.id AND mg.identity_id=?
   WHERE b.brand_image=?
    OR b.id IN (SELECT bracket_id FROM entries WHERE image=?)
    OR json_extract(b.appearance,'$.images.page_background')=?
    OR json_extract(b.appearance,'$.images.board_background')=?
    OR json_extract(b.appearance,'$.images.center_logo')=?
    OR json_extract(b.appearance,'$.images.champion_logo')=?
    OR json_extract(b.appearance,'$.images.footer_logo')=?
   `).bind(who.id,image,image,image,image,image,image,image).first<{public:number|null;manager:number|null}>();
  isPublic=!!access?.public;
  if(!isPublic&&!access?.manager)throw new ApiError(404,'Image not found.');
 }
 const object=await bucket().get(key);if(!object)throw new ApiError(404,'Image not found.');
 let content:BodyInit=object.body;
 if(record.validation_version!==1){
  // Older uploads predate dimension checks. Validate each once, without
  // rewriting or deleting the user's original image.
  if(object.size>5*1024*1024)throw new ApiError(400,'This image exceeds the supported size. Upload a smaller image.');
  const bytes=new Uint8Array(await object.arrayBuffer());
  if(bytes.length>5*1024*1024)throw new ApiError(400,'This image exceeds the supported size. Upload a smaller image.');
  try{if(validateImage(bytes).ext!==match[1])throw new ImageValidationError('This image format does not match its file name. Upload it again.');}catch(error){if(error instanceof ImageValidationError)throw new ApiError(400,error.message);throw error;}
  await db().prepare('UPDATE media SET validation_version=1 WHERE id=?').bind(key).run();
  content=bytes;
 }
 const types:Record<string,string>={png:'image/png',jpg:'image/jpeg',webp:'image/webp',gif:'image/gif'};
 return new Response(content,{headers:{
  'Content-Type':types[match[1]],
  'Cache-Control':isPublic?'public,max-age=300':'private,no-store',
  'Vary':'Cookie',
  'X-Content-Type-Options':'nosniff',
  'Content-Security-Policy':"default-src 'none'; sandbox",
  'Cross-Origin-Resource-Policy':'same-origin',
 }});
});}
