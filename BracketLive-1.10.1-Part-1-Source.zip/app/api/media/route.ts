import {ApiError,boundary,bucket,db,identity,json,limitedBody,originCheck} from '@/lib/server';
import {ImageValidationError,validateImage} from '@/lib/image-validation';
export async function POST(req:Request){return boundary(async()=>{
 originCheck(req);const who=await identity(req);
 const count=await db().prepare('SELECT COUNT(*) n FROM media WHERE owner_id=? AND created_at>?').bind(who.id,Date.now()-86400000).first<{n:number}>();
 if((count?.n??0)>=150)throw new ApiError(429,'Daily image limit reached. Try again tomorrow.');
 const bytes=await limitedBody(req,5*1024*1024);
 let image;try{image=validateImage(bytes);}catch(error){if(error instanceof ImageValidationError)throw new ApiError(400,error.message);throw error;}
 const {type,ext}=image,id=`${crypto.randomUUID()}.${ext}`;
 const now=Date.now();
 // Reserve quota atomically before touching R2; concurrent requests cannot
 // all pass the preliminary count and each consume another upload slot.
 const reserved=await db().prepare('INSERT INTO media(id,owner_id,content_type,size,created_at,validation_version) SELECT ?,?,?,?,?,1 WHERE (SELECT COUNT(*) FROM media WHERE owner_id=? AND created_at>?)<150').bind(id,who.id,type,bytes.byteLength,now,who.id,now-86400000).run();
 if(!reserved.meta.changes)throw new ApiError(429,'Daily image limit reached. Try again tomorrow.');
 try{await bucket().put(id,bytes,{httpMetadata:{contentType:type}});}catch(e){await db().prepare('DELETE FROM media WHERE id=? AND owner_id=?').bind(id,who.id).run();throw e;}
 return json({url:`/api/media/${id}`},201,who.cookie);
});}
