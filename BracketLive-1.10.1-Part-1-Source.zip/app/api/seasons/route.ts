import { boundary } from '@/lib/server';
import { createSeason, listSeasons } from '@/lib/standings-server';
export async function GET(req: Request) { return boundary(() => listSeasons(req)); }
export async function POST(req: Request) { return boundary(() => createSeason(req)); }
