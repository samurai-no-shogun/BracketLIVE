import { boundary } from '@/lib/server';
import { saveSeasonEvent, deleteSeasonEvent } from '@/lib/standings-server';
type Context = { params: Promise<{ id: string; eventId: string }> };
export async function PUT(req: Request, context: Context) { return boundary(async () => { const { id, eventId } = await context.params; return saveSeasonEvent(req, id, eventId); }); }
export async function DELETE(req: Request, context: Context) { return boundary(async () => { const { id, eventId } = await context.params; return deleteSeasonEvent(req, id, eventId); }); }
