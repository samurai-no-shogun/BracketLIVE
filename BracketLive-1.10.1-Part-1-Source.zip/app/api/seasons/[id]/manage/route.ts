import { boundary } from '@/lib/server';
import { manageSeason } from '@/lib/standings-server';
export async function POST(req: Request, context: { params: Promise<{ id: string }> }) {
  return boundary(async () => manageSeason(req, (await context.params).id));
}
