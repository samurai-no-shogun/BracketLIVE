import { boundary, identity, json } from '@/lib/server';
import { seasonSnapshot, updateSeason } from '@/lib/standings-server';
type Context = { params: Promise<{ id: string }> };
export async function GET(req: Request, context: Context) {
  return boundary(async () => { const who = await identity(req); return json(await seasonSnapshot((await context.params).id, who.id), 200, who.cookie); });
}
export async function PUT(req: Request, context: Context) { return boundary(async () => updateSeason(req, (await context.params).id)); }
