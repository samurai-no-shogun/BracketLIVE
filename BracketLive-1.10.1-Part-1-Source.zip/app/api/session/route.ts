import {boundary,identity,json} from '@/lib/server';
export async function GET(req:Request){return boundary(async()=>{const who=await identity(req);return json({ready:true},200,who.cookie);});}
