import {getFeaturedBracket} from '@/lib/featured-server';
import {boundary,json} from '@/lib/server';

export const dynamic='force-dynamic';
export async function GET(){return boundary(async()=>json({bracket:await getFeaturedBracket()}));}
