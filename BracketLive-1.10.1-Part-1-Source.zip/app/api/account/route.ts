import {boundary} from '@/lib/server';
import {getAccount,updateAccount} from '@/lib/account-auth';
export const dynamic='force-dynamic';
export async function GET(req:Request){return boundary(()=>getAccount(req));}
export async function PATCH(req:Request){return boundary(()=>updateAccount(req));}
