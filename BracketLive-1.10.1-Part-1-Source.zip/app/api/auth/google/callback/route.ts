import {ApiError} from '@/lib/server';
import {googleCallback} from '@/lib/account-auth';
export async function GET(req:Request){try{return await googleCallback(req);}catch(error){const message=error instanceof ApiError?error.message:'Google sign-in could not be completed. Please try again.';const url=new URL('/account',req.url);url.searchParams.set('authError',message);return new Response(null,{status:303,headers:{Location:url.href,'Cache-Control':'no-store','Referrer-Policy':'no-referrer'}});}}
