import {boundary} from '@/lib/server';
import {googleStart} from '@/lib/account-auth';
export async function GET(req:Request){return boundary(()=>googleStart(req));}
