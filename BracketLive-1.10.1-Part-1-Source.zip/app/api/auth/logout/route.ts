import {boundary} from '@/lib/server';
import {logoutAccount} from '@/lib/account-auth';
export async function POST(req:Request){return boundary(()=>logoutAccount(req));}
