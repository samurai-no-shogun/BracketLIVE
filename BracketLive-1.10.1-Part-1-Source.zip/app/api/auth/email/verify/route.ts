import {boundary} from '@/lib/server';
import {verifyEmail} from '@/lib/account-auth';
export async function POST(req:Request){return boundary(()=>verifyEmail(req));}
