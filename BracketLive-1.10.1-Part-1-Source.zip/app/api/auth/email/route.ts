import {boundary} from '@/lib/server';
import {requestEmail} from '@/lib/account-auth';
export async function POST(req:Request){return boundary(()=>requestEmail(req));}
