import {boundary,db,json,settleExpired,sqlNow} from '@/lib/server';
export async function GET(){return boundary(async()=>{
 const expired=(await db().prepare(`SELECT id FROM brackets WHERE listed=1 AND is_test=0 AND status='live' AND round_closes_at<=${sqlNow} ORDER BY round_closes_at,id LIMIT 1`).all<{id:string}>()).results;
 // Catch up one bracket per directory request; opening any bracket always settles it.
 // A large expiry backlog must not fan out into hundreds of database calls.
 if(expired[0])await settleExpired(expired[0].id);
 const rows=await db().prepare(`SELECT b.id,b.title,b.description,b.size,b.format,b.status,b.current_round,b.created_at,b.accent,b.brand_color,b.brand_image,b.is_test,b.ends_at,b.round_closes_at,(SELECT COUNT(*) FROM votes v JOIN matches m ON m.id=v.match_id WHERE m.bracket_id=b.id) AS totalVotes,(SELECT e.name FROM matches m JOIN entries e ON e.id=m.winner_id WHERE m.bracket_id=b.id ORDER BY m.round DESC LIMIT 1) AS champion FROM brackets b WHERE b.listed=1 AND b.is_test=0 AND b.status IN ('live','complete') ORDER BY b.created_at DESC LIMIT 100`).all();
 return json({brackets:rows.results});
});}
