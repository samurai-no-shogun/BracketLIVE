import {boundary} from '@/lib/server';
import {recordAnalytics} from '@/lib/analytics-server';
export async function POST(req:Request){return boundary(()=>recordAnalytics(req));}
