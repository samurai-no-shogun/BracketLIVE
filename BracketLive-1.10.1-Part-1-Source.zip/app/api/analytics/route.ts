import {boundary} from '@/lib/server';
import {analytics} from '@/lib/analytics-server';
export async function GET(req:Request){return boundary(()=>analytics(req));}
