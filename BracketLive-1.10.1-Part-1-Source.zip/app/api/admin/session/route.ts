import {adminConfigured,adminCookie,createAdminSession,verifyAdminKey} from '@/lib/admin-auth';
import {ApiError,boundary,json,limitedBody,originCheck} from '@/lib/server';

export const dynamic='force-dynamic';
export async function POST(req:Request){return boundary(async()=>{
 originCheck(req);
 if(!adminConfigured())throw new ApiError(503,'Owner access is not configured. Add the ADMIN_KEY secret in Cloudflare.');
 let data:unknown;
 try{data=JSON.parse(new TextDecoder().decode(await limitedBody(req,1024)));}catch(error){if(error instanceof ApiError)throw error;throw new ApiError(400,'Enter your owner access key.');}
 const key=typeof data==='object'&&data!==null&&'key' in data?data.key:undefined;
 if(typeof key!=='string'||!await verifyAdminKey(key))throw new ApiError(401,'That owner access key is not valid.');
 return json({ok:true},200,adminCookie(req,await createAdminSession()));
});}
export async function DELETE(req:Request){return boundary(async()=>{
 originCheck(req);return json({ok:true},200,adminCookie(req,null));
});}
