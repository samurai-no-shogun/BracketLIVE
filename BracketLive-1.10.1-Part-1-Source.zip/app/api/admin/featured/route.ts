import {z} from 'zod';
import {isSiteAdmin} from '@/lib/admin-auth';
import {FEATURED_BRACKET_KEY,getFeaturedBracket} from '@/lib/featured-server';
import {ApiError,boundary,db,json,limitedBody,originCheck} from '@/lib/server';

export const dynamic='force-dynamic';
async function requireAdmin(request:Request){if(!await isSiteAdmin(request))throw new ApiError(403,'Sign in to the site owner dashboard first.');}
export async function GET(request:Request){return boundary(async()=>{
 await requireAdmin(request);
 const [featured,choices]=await Promise.all([
  getFeaturedBracket(),
  db().prepare("SELECT id,title,size,status FROM brackets WHERE is_test=0 AND status IN ('live','complete') ORDER BY created_at DESC,id LIMIT 200").all(),
 ]);
 return json({featured,brackets:choices.results});
});}
export async function PUT(request:Request){return boundary(async()=>{
 originCheck(request);await requireAdmin(request);
 let input:unknown;
 try{input=JSON.parse(new TextDecoder().decode(await limitedBody(request,1024)));}catch(error){if(error instanceof ApiError)throw error;throw new ApiError(400,'Choose a published bracket.');}
 const {bracketId}=z.object({bracketId:z.string().uuid().nullable()}).strict().parse(input);
 if(bracketId===null){
  await db().prepare('DELETE FROM site_settings WHERE key=?').bind(FEATURED_BRACKET_KEY).run();
 }else{
  // The visibility gate and setting write are one statement to avoid a stale
  // selection publishing private content between a read and a later write.
  const saved=await db().prepare("INSERT INTO site_settings(key,value,updated_at) SELECT ?,id,? FROM brackets WHERE id=? AND is_test=0 AND status IN ('live','complete') ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at").bind(FEATURED_BRACKET_KEY,Date.now(),bracketId).run();
  if(!saved.meta.changes)throw new ApiError(400,'Choose a published bracket. Drafts and private tests cannot appear on the homepage.');
 }
 return json({featured:await getFeaturedBracket()});
});}
