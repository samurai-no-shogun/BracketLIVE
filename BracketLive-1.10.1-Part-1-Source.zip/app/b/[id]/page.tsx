import BracketApp from '@/components/bracket-app';
import {db} from '@/lib/server';
export async function generateMetadata({params}:{params:Promise<{id:string}>}){try{const {id}=await params;const b=await db().prepare("SELECT title,description FROM brackets WHERE id=? AND status<>'draft' AND is_test=0").bind(id).first<{title:string;description:string}>();return b?{title:`${b.title} | Bracket Live`,description:b.description||`Vote in ${b.title} and follow live tournament results.`}:{title:'Bracket Live'};}catch{return {title:'Bracket Live'};}}
export default async function Page({params}:{params:Promise<{id:string}>}){const {id}=await params;return <BracketApp bracketId={id}/>;}
