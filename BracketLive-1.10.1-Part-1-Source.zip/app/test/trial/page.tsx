import TestStart from '@/components/test-start';
export default function Page(){return <TestStart template="trial"/>;}
