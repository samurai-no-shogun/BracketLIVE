import AnalyticsDashboard from '@/components/analytics-dashboard';
import AdminLogin,{AdminLogout} from '@/components/admin-login';
import {adminConfigured,isSiteAdmin} from '@/lib/admin-auth';
import FeaturedBracketSettings from '@/components/featured-bracket-settings';
export const dynamic='force-dynamic';
export default async function Page(){if(!adminConfigured())return <main className="test-start"><h1>Owner access needs setup</h1><p>Add the ADMIN_KEY secret in Cloudflare to enable the owner dashboard.</p><a className="button" href="/">Back to tournaments</a></main>;if(!await isSiteAdmin())return <AdminLogin/>;return <AnalyticsDashboard ownerSettings={<><AdminLogout/><FeaturedBracketSettings/></>}/>;}
