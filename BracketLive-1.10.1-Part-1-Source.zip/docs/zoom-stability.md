# Zoom stability fix — 2026-10-05

Rounded client dimensions could make a fitted stage slightly larger than its scrollport. With automatic scrollbars, this alternated the measured width and height, repeatedly refitting and recentering the bracket. A fractional viewport of 1200.25 × 850.75 with 10px scrollbars reproduced two alternating positions that both displayed 31%.

The viewer now reserves both scrollbar axes, measures fractional dimensions conservatively, disables browser scroll anchoring within the viewer, and observes the outer viewport box. Resize updates are grouped into an animation frame and skipped when dimensions are unchanged, including in Fit all mode. Intentional zooming and navigation still preserve their requested anchor.

Verification:

- All 14 layout regression checks passed, including the original 31% alternating-position reproduction and the corrected stable case.
- TypeScript and whitespace validation passed.
- Managed browser preview: the 64-entry anime template fit without overflowing at 25%; zooming to 31% stayed steady. After zooming to 39% and back out to 31%, a second 20-sample observation also reported one identical position and scroll offset across every sample.
- The browser measured the 31% canvas at 1092.453125 × 828.765625, position (130.265625, 76.984375), with scroll offsets (0, 83), consistently in both observations.
- Screenshot: `bracket-zoom-stable.jpg`.

The standard production build runs before publication. Site access remains public.
