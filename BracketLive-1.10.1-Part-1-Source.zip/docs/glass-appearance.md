# Glass appearance

The hub, editor, tournament, analytics, bracket frame, and dialogs use translucent surfaces, a soft ambient tint, reflective edges, and layered shadows. The default is purple. Tournament Appearance contains Glass tint, Glass opacity (50–95%), Background blur (0–32px), and Reset glass. The tint follows the brand accent until explicitly customized.

The three optional settings live in the existing D1-backed appearance JSON. Existing tournaments use the new defaults without overwriting their colors, images, votes, or results. Portal dialogs receive the same theme variables as the page. Individual transformed board cards use a translucent sheen; the outer board handles blur to avoid adding 63 backdrop filters. Reduced motion suppresses card lift, and browsers without backdrop filters retain solid backing surfaces.

Validation on 2026-10-04:

- TypeScript validation passed.
- The actual server validation and JSON read path preserved a custom tint, opacity, zero blur, and existing color overrides. Reset restored defaults; old appearance JSON retained its colors and inherited the brand tint. Invalid tint, opacity, and blur values were rejected by the draft schema.
- Range control labels are passed to the interactive slider thumbs.
- Browser visual inspection and interactive save/reload verification were unavailable: the preview browser's current error-page protocol was blocked by browser URL policy. No screenshot from an earlier design is presented as verification of this change.

Production packaging runs the standard TypeScript and Sites build checks before saving the version.
