# Advertising integration points

Advertising is disabled. `lib/ads.ts` defines the two placement IDs and their intended desktop sizes; `components/ad-slot.tsx` owns their labels and sizing. Slots render nothing while disabled. Only the protected site dashboard can show placement previews, which are not ad impressions.

- `hub-sidebar`: 300 × 250 on the tournament directory, after the template and help cards.
- `tournament-footer`: 728 × 90 below all voting and results controls. Hidden for private tests and drafts. Supply a responsive mobile creative when connecting a provider.

When a provider is selected, add its supported rendering integration to `AdSlot`, reserve dimensions before loading creative, and lazy-load the below-content placement. Keep the Advertisement label. Do not insert advertising inside contenders, vote controls, result bars, or the champion announcement. Do not activate third-party requests until applicable visitor preferences have been resolved. Update the public privacy page to accurately describe the actual integration.

Impressions must count a provider-confirmed render or an observed, viewable sponsored creative, rather than component mounts. Report provider revenue and invalid-traffic adjustments from its authenticated reporting API; do not infer income from visits. Current dashboard ad fields intentionally display “Not connected” and no revenue estimates. Analytics starts with this release and has no invented historical traffic.

The site-wide dashboard at `/admin` uses dispatch-owned ChatGPT sign-in and a server-side `SITE_OWNER_EMAIL` allowlist. Production identity headers are supplied by the Sites dispatcher. Tournament dashboards require their existing organizer capability and never grant site-wide access. No client-provided owner flag grants access.
