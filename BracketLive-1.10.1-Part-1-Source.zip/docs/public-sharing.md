# Public voting and sharing — October 5, 2026

Private test runs now have a prominent **Publish for voting** action. It creates a new public bracket with the same ordered roster and appearance, zero votes, and the opening round active. The original test and its selections remain saved. The confirmation explains public directory listing and provides **Edit before publishing** for deadline or roster changes.

After publication, the sharing dialog opens with a selectable public link and a **Copy link** button. The organizer also sees a persistent **Copy voting link** panel. Organizer links are kept in a collapsed, clearly marked private section. Public visitors receive a short explanation of voting, live results, changing a selection, and undo. The anime template card now prioritizes creating a voting bracket; private testing remains a separate action.

## Verification

- TypeScript check passed.
- Browser preview: created a private 64-entry anime test, published a fresh public copy, and verified all 32 opening matches had zero votes.
- Copied the public link through the UI and checked it matched the visible link without an organizer key. Verified organizer access remained collapsed.
- Captured the publishing confirmation in `public-sharing-preview.jpg`.
- Ran `node --test scripts/test-public-voting.mjs`. This exercises the real API route handlers and database migrations using an isolated in-memory SQLite D1 adapter and two independent anonymous visitor sessions. It verifies private test restrictions, fresh public publication, ordered roster and appearance preservation, shared vote totals and percentages, SSE updates, vote changes, undo, organizer authorization, public hub listing, and preservation of the original test vote.

No production bracket data or votes were changed during verification. Production build and deployment are handled by the Sites publishing workflow. This update requires no database migration.
