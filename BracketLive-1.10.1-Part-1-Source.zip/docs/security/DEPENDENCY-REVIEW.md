# Dependency and deployment-asset review — 2026-10-05

This is a point-in-time review of the Bracket Live source and lockfile. It is not a claim that software has no unknown vulnerabilities. Changes below require a new production build and deployment.

## Scan results

The initial `pnpm audit --json` returned 54 advisory/version records: 1 critical, 27 high, 19 moderate, and 7 low. The scan after the changes returns **1 high** and no critical, moderate, or low records. The remaining advisory has no published patched version and concerns a build/lint dependency, described below. The separate `pnpm audit --prod --json` scan returned zero advisories; full scans are still necessary because framework renderers are compiled from dev dependencies. Counts are package-advisory records, not 54 confirmed exploitable website vulnerabilities.

Machine-readable evidence is included in `dependency-audit-before.json` and `dependency-audit-after.json`. Advisory metadata can change after this report.

## Runtime-relevant fixes

| Component | Previous | Updated | Reason and reachability |
| --- | --- | --- | --- |
| React, React DOM, React Server DOM | 19.2.6 | 19.2.8 | CVE-2026-44907 / GHSA-wx67-qw84-cm4g: server-function denial of service. This application uses RSC through vinext. A `devDependency` label does not make this code build-only: the renderer is compiled into the deployed Worker. |
| `@vitejs/plugin-rsc` | 0.5.26 | 0.5.29 | GHSA-p2w6-cmq4-qjfj: the plugin vendors its own vulnerable React Server DOM implementation. Updating only the separate React package would miss it. The installed vendor package was inspected and reports 19.2.8 after the upgrade. |
| Next.js; matching ESLint config | 16.3.4 | 16.3.6 | CVE-2026-94545 / GHSA-vcvr-r3jv-pc5j: Node `next/og` ImageResponse RCE. No `next/og` or ImageResponse usage was found in application source; the application serves through a Cloudflare Worker/vinext, so the particular Node image-generation condition was not found reachable. Updated anyway. |
| `image-size` | 2.0.2 | 2.0.3 | GHSA-5p2g-fcmc-qvqq and GHSA-w3rx-r6r6-pgpr: malformed image parser loops. Dependency of vinext; upgraded rather than relying on current absence of direct usage. |
| `fast-uri` | 3.1.7 | 3.1.8 | GHSA-hrr3-gc8f-f4qj: host normalization. Included through validation/tooling dependencies; no host authorization using this parser was found in app code. |

## Development/build dependency fixes

Exact tested overrides, retaining the existing package-manager release-age and build-script policies:

| Package | Previous | Updated |
| --- | --- | --- |
| Vite | 8.0.13 | 8.0.16 |
| esbuild | 0.18.20 / 0.27.3 / 0.28.0 | 0.28.1 |
| ws | 8.18.0 | 8.21.0 |
| undici | 7.24.8 | 7.29.1 |
| js-yaml | 4.1.1 | 4.3.2 |
| @babel/core | 7.29.0 | 7.29.6 |
| brace-expansion (1.x) | 1.1.14 | 1.1.21 |
| brace-expansion (5.x) | 5.0.6 | 5.0.12 |
| browserslist | 4.28.2 | 4.28.7 |
| fflate (0.7.x) | 0.7.4 | 0.7.5 |
| baseline-browser-mapping | 2.10.30 | 2.11.0 |

Vite CVE-2026-53571 affects a network-exposed development server on Windows, not the deployed compiled asset server. This matters for the owner's Windows development machine. The undici/ws advisories principally affect local Wrangler/Miniflare or build tooling in this deployment; production uses the platform's networking implementation. The other fixes cover known resource-exhaustion, file-read, and parser issues. Full advisory IDs and dependency paths are in the JSON evidence.

## Remaining known advisory

**braces 3.0.3 — CVE-2026-93687 / GHSA-vfj7-8cjw-p6xm (high).** At review time the upstream advisory lists no patched release. Deeply nested attacker-controlled glob patterns can overflow the parser/AST walker's stack.

Here it is reached through ESLint's `fast-glob` and vinext's build-time commonjs/dynamic-import plugins. Public tournament data, upload content, and request parameters are not provided to those build glob matchers. This is a build-environment risk, not an identified public request exploit. It was not hidden with an audit ignore or falsely marked fixed. Keep builds restricted to trusted source/configuration and replace it with the upstream patched version when released.

## Deployment-asset inspection

- No `.map` source-map files were found under the deployed `dist/client` asset root.
- No secret/configuration filenames were found under that asset root; the framework client-entry manifest is ordinary public build metadata.
- Server modules are under `dist/server`, separate from the configured public asset directory.
- The ZIP packager excludes Wrangler configuration, local admin keys, environment files, private key files, caches, dependencies, and symlinks. Existing owner configuration is retained by update installation.
- The example `examples/d1/app/api/notes/route.ts` is outside the actual `app` router and is not a deployed endpoint.
- Root code review additionally owns protection of framework internal request headers and endpoints. The project currently keeps vinext beta.5; later upstream releases include internal route/cache hardening. A broad framework migration was not performed just to remove version age without regression analysis.

## Verification and limits

Installation completed normally with the existing supply-chain policy. TypeScript checking passed. All previously existing tests passed in the dependency run; four new security-integrity tests added concurrently by the other audit work were still intentionally failing before those application fixes landed. Final combined tests, build and deployment verification belong to the overall audit report.

No live Cloudflare resources were modified by this dependency review. Account access controls, Cloudflare dashboard settings, billing limits, and private production secrets were not accessible for inspection.

## Primary sources

- React: https://github.com/react/react/security/advisories/GHSA-wx67-qw84-cm4g
- Vite RSC plugin: https://github.com/vitejs/vite-plugin-react/security/advisories/GHSA-p2w6-cmq4-qjfj
- Next.js: https://github.com/vercel/next.js/security/advisories/GHSA-vcvr-r3jv-pc5j
- Vite Windows path restriction: https://github.com/vitejs/vite/security/advisories/GHSA-fx2h-pf6j-xcff
- Undici example fixed advisory: https://github.com/nodejs/undici/security/advisories/GHSA-w293-vg96-wgc3
- Remaining braces advisory: https://github.com/advisories/GHSA-vfj7-8cjw-p6xm
- Upstream braces report: https://github.com/micromatch/braces/issues/70
- Vinext changelog: https://github.com/cloudflare/vinext/blob/main/packages/vinext/CHANGELOG.md
