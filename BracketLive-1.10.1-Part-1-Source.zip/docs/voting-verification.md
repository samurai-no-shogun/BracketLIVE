# Voting and advancement verification — October 4, 2026

Verified in the local application preview with the original 64-entry anime roster.

- Cast 32 opening-round votes through the Matchups interface, alternating sides.
- Verified the expanded bracket displayed 64 result labels, including percentages and vote counts, and all 63 matches still fit without overflow.
- Used **Advance winners** in the expanded bracket and compared every next-round contender with the actual selections, in order.
- Voted through the remaining rounds using the matchup dialog; verified undo, its effect on advancement readiness, and re-voting.
- Advanced 16, 8, 4, and 2 winners. Each round opened with the correct pairings and the bracket moved to the new round.
- Confirmed the final pick. The completed bracket showed Dying Will Flames as the expected test champion, 0 open matches, and results for all 126 contender positions across 63 matches.
- Captured the completed bracket in `bracket-champion-preview.jpg`.

TypeScript and production build checks run in the publishing workflow. The existing public-round majority and organizer tie-selection logic was reviewed; an additional public-creation browser check was blocked by the browser URL policy. No production votes were used for testing.
