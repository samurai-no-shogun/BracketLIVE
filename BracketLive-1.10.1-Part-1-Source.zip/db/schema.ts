import { integer, sqliteTable, text, primaryKey, index } from 'drizzle-orm/sqlite-core';
export const brackets=sqliteTable('brackets',{
 id:text('id').primaryKey(), title:text('title').notNull(), description:text('description').notNull().default(''),
 size:integer('size').notNull(), format:text('format').notNull().default('standard'), accent:text('accent').notNull().default('purple'), status:text('status').notNull().default('draft'),
 currentRound:integer('current_round').notNull().default(0), ownerId:text('owner_id').notNull(),
 manageHash:text('manage_hash').notNull(), advanceToken:text('advance_token'), createdAt:integer('created_at').notNull(),
 appearance:text('appearance').notNull().default('{}'), brandColor:text('brand_color'), brandImage:text('brand_image'), listed:integer('listed',{mode:'boolean'}).notNull().default(false),
 votingSchedule:text('voting_schedule'),scheduleBlockedReason:text('schedule_blocked_reason'),scheduleRevision:integer('schedule_revision').notNull().default(0),scheduleCheckedAt:integer('schedule_checked_at').notNull().default(0),
 isTest:integer('is_test',{mode:'boolean'}).notNull().default(false), startedAt:integer('started_at'), endsAt:integer('ends_at'), roundClosesAt:integer('round_closes_at'),
},t=>[index('brackets_owner').on(t.ownerId),index('brackets_directory').on(t.listed,t.isTest,t.status,t.createdAt)]);
export const managers=sqliteTable('managers',{
 bracketId:text('bracket_id').notNull().references(()=>brackets.id,{onDelete:'cascade'}), identityId:text('identity_id').notNull(),
},t=>[primaryKey({columns:[t.bracketId,t.identityId]}),index('managers_identity').on(t.identityId)]);
export const entries=sqliteTable('entries',{
 id:text('id').primaryKey(), bracketId:text('bracket_id').notNull().references(()=>brackets.id,{onDelete:'cascade'}),
 name:text('name').notNull(), subtitle:text('subtitle').notNull().default(''), image:text('image'), seed:integer('seed').notNull(),
},t=>[index('entries_bracket').on(t.bracketId)]);
export const matches=sqliteTable('matches',{
 id:text('id').primaryKey(), bracketId:text('bracket_id').notNull().references(()=>brackets.id,{onDelete:'cascade'}),
 round:integer('round').notNull(), position:integer('position').notNull(), aId:text('a_id').references(()=>entries.id),
 bId:text('b_id').references(()=>entries.id), winnerId:text('winner_id').references(()=>entries.id), status:text('status').notNull(), decidedBy:text('decided_by'),
},t=>[index('matches_bracket_round').on(t.bracketId,t.round)]);
export const votes=sqliteTable('votes',{
 matchId:text('match_id').notNull().references(()=>matches.id,{onDelete:'cascade'}), voterId:text('voter_id').notNull(),
 entryId:text('entry_id').notNull().references(()=>entries.id), updatedAt:integer('updated_at').notNull(),
},t=>[primaryKey({columns:[t.matchId,t.voterId]})]);
export const media=sqliteTable('media',{
 id:text('id').primaryKey(), ownerId:text('owner_id').notNull(), contentType:text('content_type').notNull(), size:integer('size').notNull(),createdAt:integer('created_at').notNull(),
 validationVersion:integer('validation_version').notNull().default(0),
},t=>[index('media_owner_created').on(t.ownerId,t.createdAt)]);
export const analyticsEvents=sqliteTable('analytics_events',{
 id:text('id').primaryKey(),visitorId:text('visitor_id').notNull(),kind:text('kind').notNull(),path:text('path').notNull(),
 bracketId:text('bracket_id').references(()=>brackets.id,{onDelete:'cascade'}),source:text('source').notNull(),campaign:text('campaign').notNull().default(''),device:text('device').notNull(),
 isTest:integer('is_test',{mode:'boolean'}).notNull().default(false),createdAt:integer('created_at').notNull(),
},t=>[index('analytics_bracket_time').on(t.bracketId,t.createdAt),index('analytics_time_kind').on(t.createdAt,t.kind),index('analytics_visitor_time').on(t.visitorId,t.createdAt)]);

export const seasons=sqliteTable('seasons',{
 id:text('id').primaryKey(),title:text('title').notNull(),description:text('description').notNull().default(''),
 points:text('points').notNull(),entrants:text('entrants').notNull(),ownerId:text('owner_id').notNull(),manageHash:text('manage_hash').notNull(),
 createdAt:integer('created_at').notNull(),updatedAt:integer('updated_at').notNull(),version:integer('version').notNull().default(1),
},t=>[index('seasons_owner').on(t.ownerId,t.createdAt),index('seasons_created').on(t.createdAt)]);
export const seasonManagers=sqliteTable('season_managers',{
 seasonId:text('season_id').notNull().references(()=>seasons.id,{onDelete:'cascade'}),identityId:text('identity_id').notNull(),
},t=>[primaryKey({columns:[t.seasonId,t.identityId]}),index('season_managers_identity').on(t.identityId)]);
export const seasonEvents=sqliteTable('season_events',{
 id:text('id').primaryKey(),seasonId:text('season_id').notNull().references(()=>seasons.id,{onDelete:'cascade'}),
 title:text('title').notNull(),eventDate:text('event_date').notNull().default(''),status:text('status').notNull().default('draft'),results:text('results').notNull().default('[]'),
 createdAt:integer('created_at').notNull(),updatedAt:integer('updated_at').notNull(),version:integer('version').notNull().default(1),
},t=>[index('season_events_season').on(t.seasonId,t.createdAt)]);

// Authentication records. Only opaque token hashes are persisted.
export const accounts=sqliteTable('accounts',{
 id:text('id').primaryKey(),identityId:text('identity_id').notNull().unique(),name:text('name').notNull(),email:text('email').notNull(),createdAt:integer('created_at').notNull(),
});
export const accountCredentials=sqliteTable('account_credentials',{
 provider:text('provider').notNull(),subjectHash:text('subject_hash').notNull(),accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),
},t=>[primaryKey({columns:[t.provider,t.subjectHash]}),index('account_credentials_account').on(t.accountId)]);
export const accountSessions=sqliteTable('account_sessions',{
 tokenHash:text('token_hash').primaryKey(),accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),createdAt:integer('created_at').notNull(),expiresAt:integer('expires_at').notNull(),
},t=>[index('account_sessions_account').on(t.accountId),index('account_sessions_expiry').on(t.expiresAt)]);
export const accountChallenges=sqliteTable('account_challenges',{
 tokenHash:text('token_hash').primaryKey(),kind:text('kind').notNull(),browserHash:text('browser_hash').notNull(),sourceIdentity:text('source_identity').notNull(),subjectHash:text('subject_hash').notNull().default(''),payload:text('payload').notNull(),returnTo:text('return_to').notNull(),createdAt:integer('created_at').notNull(),expiresAt:integer('expires_at').notNull(),consumedAt:integer('consumed_at'),claim:text('claim'),
},t=>[index('account_challenges_quota').on(t.kind,t.subjectHash,t.createdAt),index('account_challenges_expiry').on(t.expiresAt)]);
export const accountIdentityClaims=sqliteTable('account_identity_claims',{
 identityId:text('identity_id').primaryKey(),accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),createdAt:integer('created_at').notNull(),
});
export const siteSettings=sqliteTable('site_settings',{
 key:text('key').primaryKey(),value:text('value').notNull(),updatedAt:integer('updated_at').notNull(),
});

export const creatorAlertSettings=sqliteTable('creator_alert_settings',{
 bracketId:text('bracket_id').primaryKey().references(()=>brackets.id,{onDelete:'cascade'}),accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),enabled:integer('enabled',{mode:'boolean'}).notNull().default(false),updatedAt:integer('updated_at').notNull(),
});
export const tournamentRoundResults=sqliteTable('tournament_round_results',{
 id:text('id').primaryKey(),bracketId:text('bracket_id').notNull().references(()=>brackets.id,{onDelete:'cascade'}),round:integer('round').notNull(),kind:text('kind').notNull(),scheduleRevision:integer('schedule_revision').notNull(),summary:text('summary').notNull(),createdAt:integer('created_at').notNull(),
});
export const creatorAlertOutbox=sqliteTable('creator_alert_outbox',{
 id:text('id').primaryKey().references(()=>tournamentRoundResults.id,{onDelete:'cascade'}),bracketId:text('bracket_id').notNull().references(()=>brackets.id,{onDelete:'cascade'}),accountId:text('account_id').notNull().references(()=>accounts.id,{onDelete:'cascade'}),status:text('status').notNull().default('pending'),payload:text('payload'),attempts:integer('attempts').notNull().default(0),nextAttemptAt:integer('next_attempt_at').notNull().default(0),firstAttemptAt:integer('first_attempt_at'),leaseToken:text('lease_token'),leaseUntil:integer('lease_until'),sentAt:integer('sent_at'),createdAt:integer('created_at').notNull(),
});
