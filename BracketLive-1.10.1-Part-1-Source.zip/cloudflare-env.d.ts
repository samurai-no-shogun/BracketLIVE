declare namespace Cloudflare {
  interface Env {
    ASSETS?: Fetcher;
    DISCORD_APPLICATION_ID?: string;
    DISCORD_CLIENT_SECRET?: string;
    DISCORD_BOT_TOKEN?: string;
    SECURITY_READ_LIMIT?: RateLimit;
    SECURITY_WRITE_LIMIT?: RateLimit;
    SECURITY_AUTH_LIMIT?: RateLimit;
    SECURITY_CREATE_LIMIT?: RateLimit;
    SECURITY_UPLOAD_LIMIT?: RateLimit;
    AUTH_ORIGIN?: string;
    GOOGLE_CLIENT_ID?: string;
    GOOGLE_CLIENT_SECRET?: string;
    RESEND_API_KEY?: string;
    AUTH_EMAIL_FROM?: string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
