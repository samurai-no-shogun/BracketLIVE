BRACKET LIVE — CLOUDFLARE SETUP FOR WINDOWS

This package contains the built website and its source. The first deployment
does not require npm install or a local build. npx downloads Wrangler if needed.
Use your existing Cloudflare login. Node.js 24 is suitable.

The new address will be the workers.dev URL printed by Cloudflare. This does
not give you bracketlive.chatgpt.site. You can add a domain you own afterward.

This creates a separate website and database. Existing brackets, votes, uploads,
and organizer access from the ChatGPT-hosted site are not migrated. The saved
64-entry anime template and its included artwork are in this package, ready to
create a fresh tournament. Your original website remains available.

1. DOWNLOAD AND EXTRACT

Save BracketLive-Cloudflare.zip in your Downloads folder. Open PowerShell:

  Expand-Archive -Path "$env:USERPROFILE\Downloads\BracketLive-Cloudflare.zip" -DestinationPath "$env:USERPROFILE\BracketLive-Cloudflare"
  cd "$env:USERPROFILE\BracketLive-Cloudflare"

You should now see wrangler.json, dist, drizzle, and scripts in this folder.
Do not run these steps from C:\WINDOWS\system32 or inside the ZIP viewer.

2. CHECK YOUR CLOUDFLARE LOGIN

You already completed login. Confirm the account if you open a new terminal:

  npx.cmd --yes wrangler@4.147.0 whoami

If it says you are not logged in:

  npx.cmd --yes wrangler@4.147.0 login

3. CREATE THE DATABASE

  npx.cmd --yes wrangler@4.147.0 d1 create bracketlive --location enam --update-config=false

Keep the database_id value printed in the result. It is a UUID with hyphens.
Do not use your Cloudflare account ID. If the database name already exists,
use `npx.cmd --yes wrangler@4.147.0 d1 list` to find its UUID. Only reuse it if
it is the database you created for this application.

4. CREATE IMAGE STORAGE

  npx.cmd --yes wrangler@4.147.0 r2 bucket create bracketlive-media

If Cloudflare says R2 is not enabled, open https://dash.cloudflare.com/,
select your account, and open R2 Object Storage. Complete its activation and
review any billing terms Cloudflare shows, then rerun the command. This package
does not promise that usage is free. The bucket can stay private; the Worker
serves application images. If this exact bucket already exists from a previous
setup attempt for Bracket Live, you can reuse it.

5. CONFIGURE THE PACKAGE

  node scripts/configure-cloudflare.mjs

Paste the database_id from step 3 when prompted and press Enter.
This updates wrangler.json and creates .admin-key locally. Rerunning it keeps
the same key. Keep this file private: it grants access to site-wide analytics. It is ignored by git and is not a public website asset.

6. CREATE THE DATABASE TABLES

  npx.cmd --yes wrangler@4.147.0 d1 migrations apply DB --remote --config wrangler.json

Confirm applying the migrations when Wrangler asks. Do not skip this step.

7. DEPLOY THE WEBSITE

  npx.cmd --yes wrangler@4.147.0 deploy --config wrangler.json

If prompted to choose a workers.dev account subdomain, follow Wrangler's
instructions. Keep the actual HTTPS address printed at the end. The Worker
name is bracketlive, so the address normally has this shape:

  https://bracketlive.YOUR-ACCOUNT-SUBDOMAIN.workers.dev

No CPU-limit setting is included in this configuration.

8. ENABLE YOUR PRIVATE ADMIN DASHBOARD

After the Worker exists, upload your generated key:

  node scripts/upload-admin-key.mjs

The helper sends the key to Cloudflare through standard input. It does not
print the key or put it in a command argument. To copy your local key:

  Get-Content .\.admin-key | Set-Clipboard

Visit /admin on your actual deployed website, paste the key, and sign in.
Do not share .admin-key or a screenshot of it. Visitors do not need this key
to create brackets or vote. Each bracket has its own private organizer access.

9. CREATE AND SHARE YOUR FIRST VOTING BRACKET

Open the website. Choose Create a voting bracket on the anime template, or
create your own bracket. Review its title, colors, entries, and deadline, then
publish it. Use Copy voting link to share the public bracket link.

If you choose a private test first, click Publish for voting to create the
public copy with fresh votes. Private test links do not accept guest votes.

Keep the private organizer link for managing rounds and the final winner.
Share only the public voting link with voters. Test it in a private browser
window or on your phone: vote in a matchup, check the results, and undo/change
your vote. Organizer access should not appear for those separate visitors.

UPDATING THIS DEPLOYMENT

Keep your configured wrangler.json and .admin-key. When replacing built files,
back up those two files first. Reapply any new migrations before deploying the
updated build. Redeploying the Worker does not intentionally reset your D1
database or image bucket. Upload the administrator key again only if it is
missing or you intentionally replace it.

For source changes, install the locked development dependencies and run the
build as described by package.json. The source build reads the configured root
wrangler.json, so retain your actual database ID and storage names. Always
deploy with `--config wrangler.json` from this project folder.

TROUBLESHOOTING

- Stop at the first failed command. Copy the error text before continuing.
- Missing DB / BUCKET binding: use the root wrangler.json supplied here.
- Database not found: rerun configure-cloudflare.mjs with the correct database_id.
- No such table: apply step 6 migrations to the remote DB.
- R2 not enabled: finish activation in the Cloudflare dashboard, then retry.
- Admin sign-in fails: rerun step 8 after deployment and copy the same local key.
- New computer or browser: use the saved organizer link to recover control of
  a bracket. The site admin key is separate from bracket organizer access.
- An account or billing restriction is a Cloudflare account setting; this
  package does not change your plan or accept charges on your behalf.
