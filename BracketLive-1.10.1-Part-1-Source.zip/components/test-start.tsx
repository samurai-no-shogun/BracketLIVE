'use client';
import {useEffect,useRef,useState} from 'react';
import {FlaskConical,LoaderCircle} from 'lucide-react';
import {makeTemplateDraft,type Bracket} from '@/lib/bracket';
import {ensureSession} from '@/lib/client-session';
import {SiteHeader} from './tournament-ui';
export default function TestStart({template='trial'}:{template?:'trial'|'basketball'}){const started=useRef(false);const [busy,setBusy]=useState(true),[error,setError]=useState('');
 const start=async()=>{setBusy(true);setError('');try{await ensureSession();const r=await fetch('/api/brackets',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...makeTemplateDraft(template),publish:true,is_test:true,listed:false})});const data=await r.json() as {bracket:Bracket;error?:string};if(!r.ok)throw new Error(data.error);window.location.replace(`/b/${data.bracket.id}`);}catch(e){setError(e instanceof Error?e.message:'Could not start the test.');setBusy(false);}};
 useEffect(()=>{if(!started.current){started.current=true;void start();}},[]);
 return <div className="app theme-purple"><SiteHeader/><main className="test-start"><FlaskConical size={40}/><span className="eyebrow">PRIVATE TEST RUN</span><h1>Loading your {template==='basketball'?'2026 NCAA men’s practice bracket':'Trial Bracket'}</h1><p>{template==='basketball'?'The actual 2026 Round of 64 field, seeds, and matchups, including the four First Four winners.':'Your original 64 entries and all 32 opening matchups are ready.'} Pick winners, see the results, and advance through six rounds to a champion.</p><p>Your private test opens automatically. Choose each winner, then use Advance round to reach the final.</p>{error&&<p role="alert">{error}</p>}<button className="button primary" disabled={busy} onClick={start}>{busy?<LoaderCircle className="spin" size={18}/>:<FlaskConical size={18}/>}{busy?'Preparing your matchups…':'Try again'}</button><a href={`/create?template=${template}`} className="text-button">Edit the template first</a></main></div>;
}
