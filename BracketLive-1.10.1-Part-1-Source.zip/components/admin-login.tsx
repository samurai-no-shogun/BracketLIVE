'use client';
import {useState,type FormEvent} from 'react';

export default function AdminLogin(){
 const [key,setKey]=useState(''),[busy,setBusy]=useState(false),[error,setError]=useState('');
 async function login(event:FormEvent){
  event.preventDefault();setBusy(true);setError('');
  try{
   const response=await fetch('/api/admin/session',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key})});
   const data=await response.json() as {error?:string};
   if(!response.ok)throw new Error(data.error||'Could not sign in.');
   setKey('');window.location.replace('/admin');
  }catch(cause){setError(cause instanceof Error?cause.message:'Could not sign in.');setBusy(false);}
 }
 return <main className="test-start"><span className="eyebrow">SITE OWNER</span><h1>Owner sign in</h1><p>Enter the owner access key saved during setup to view site analytics.</p><form onSubmit={login}><label className="field">Owner access key<input type="password" autoComplete="current-password" value={key} onChange={event=>setKey(event.target.value)} required maxLength={512} disabled={busy}/></label>{error&&<p role="alert" className="hub-error">{error}</p>}<button className="button primary" type="submit" disabled={busy||!key}>{busy?'Signing in…':'Sign in'}</button></form><a className="text-button" href="/">Back to tournaments</a></main>;
}
export function AdminLogout(){
 const [busy,setBusy]=useState(false),[error,setError]=useState('');
 async function logout(){setBusy(true);setError('');try{const response=await fetch('/api/admin/session',{method:'DELETE'});if(!response.ok)throw new Error('Could not sign out. Try again.');window.location.replace('/admin');}catch(cause){setError(cause instanceof Error?cause.message:'Could not sign out.');setBusy(false);}}
 return <div className="owner-session-actions"><button className="button" disabled={busy} onClick={logout}>{busy?'Signing out…':'Sign out of owner dashboard'}</button>{error&&<p role="alert" className="hub-error">{error}</p>}</div>;
}
