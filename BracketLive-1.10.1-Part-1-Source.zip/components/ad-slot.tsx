import {adPlacements,advertisingEnabled,type AdPlacement} from '@/lib/ads';
export default function AdSlot({placement,preview=false}:{placement:AdPlacement;preview?:boolean}){
 const slot=adPlacements.find(s=>s.id===placement)!;
 if(!advertisingEnabled&&!preview)return null;
 return <aside className={`ad-slot ${preview?'ad-slot-preview':''}`} data-ad-placement={placement} aria-label="Advertisement" style={{maxWidth:slot.width}}><span>Advertisement{preview?' · placement preview':''}</span><div style={{aspectRatio:`${slot.width} / ${slot.height}`}}>{preview&&<p>{slot.width} × {slot.height}<small>{slot.name}</small></p>}</div></aside>;
}
