'use client';

import {useEffect,useId,useMemo,useRef,useState} from 'react';
import {Check,Download,ImagePlus,LoaderCircle,Monitor,RotateCcw,Smartphone,Square,Trash2} from 'lucide-react';
import type {Bracket,Entry,Match} from '@/lib/bracket';
import {roundName} from '@/lib/bracket';
import {resolvedColors} from '@/lib/appearance';
import {downloadMatchupImage,matchupSnapshot,prepareLocalMatchupImage,prepareMatchupArtwork,releaseLocalMatchupImage,renderMatchupSvg} from '@/lib/matchup-export';
import {EntryArt} from './bracket-board';

type Side=0|1;
type EntryChange=Partial<Pick<Entry,'name'|'subtitle'|'image'>>;
type Format='landscape'|'portrait'|'square';
type Artwork=Awaited<ReturnType<typeof prepareMatchupArtwork>>;
export type MatchupStudioProps={
 bracket:Bracket;
 match:Match;
 editable?:boolean;
 initialSide?:Side;
 onEntryChange?:(entryId:string,change:EntryChange)=>void;
 onUpload?:(file:File,entryId:string)=>Promise<void>;
 uploading?:boolean;
 ready?:boolean;
};

const formats=[
 {id:'landscape',label:'Landscape',size:'1920 × 1080',ratio:'16:9',Icon:Monitor},
 {id:'portrait',label:'Portrait',size:'1080 × 1920',ratio:'9:16',Icon:Smartphone},
 {id:'square',label:'Square',size:'1080 × 1080',ratio:'1:1',Icon:Square},
] as const;

export default function MatchupStudio({bracket,match,editable=false,initialSide=0,onEntryChange,onUpload,uploading=false,ready=true}:MatchupStudioProps){
 const uid=useId(),[side,setSide]=useState<Side>(initialSide),[format,setFormat]=useState<Format>('landscape');
 const [copies,setCopies]=useState<Record<Side,EntryChange>>({0:{},1:{}});
 const [title,setTitle]=useState<string|undefined>(),[label,setLabel]=useState<string|undefined>();
 const [accent,setAccent]=useState<string|undefined>(),[background,setBackground]=useState<string|undefined>();
 const [transparent,setTransparent]=useState(false),[showResults,setShowResults]=useState(false);
 const [assets,setAssets]=useState<{key:string;artwork:Artwork}|null>(null),[assetError,setAssetError]=useState('');
 const [busy,setBusy]=useState<'png'|'svg'|null>(null),[localUploading,setLocalUploading]=useState(false),[error,setError]=useState(''),[message,setMessage]=useState('');
 const [downloadReady,setDownloadReady]=useState<{url:string;filename:string}|null>(null);
 const exportUrl=useRef<string|null>(null);
 const localUrls=useRef<Partial<Record<Side,string>>>({}),mounted=useRef(true);
 const entries=[bracket.entries.find(e=>e.id===match.a_id),bracket.entries.find(e=>e.id===match.b_id)];
 const shownEntries=entries.map((entry,index)=>({...entry,...(!editable?copies[index as Side]:{}),name:(!editable?copies[index as Side].name:undefined)??entry?.name??'',subtitle:(!editable?copies[index as Side].subtitle:undefined)??entry?.subtitle??'',image:!editable&&Object.hasOwn(copies[index as Side],'image')?copies[index as Side].image:entry?.image??null}));
 const selected=shownEntries[side],selectedOfficial=entries[side];
 const canShowResults=match.counts!==null&&match.total!==null;
 const controlsDisabled=busy!==null||uploading||localUploading||!ready;
 const colors=resolvedColors(bracket),defaultLabel=`${roundName(match.round,bracket.size,bracket.format)} · Match ${match.position+1}`;
 const snapshot=useMemo(()=>matchupSnapshot(bracket,match,{title,label,accent,backgroundColor:background,...(!editable?{a:copies[0],b:copies[1]}:{})}),[bracket,match,title,label,accent,background,editable,copies]);
 // Artwork fetching is independent of text, colors, and the chosen export dimensions.
 const artworkKey=JSON.stringify([snapshot.a.image,snapshot.b.image,snapshot.background,snapshot.logo]);
 const artwork=assets?.key===artworkKey?assets.artwork:undefined;
 const options={format,transparent,showResults:showResults&&canShowResults};
 const rendered=useMemo(()=>renderMatchupSvg(snapshot,options,artwork),[snapshot,format,transparent,showResults,canShowResults,artwork]);
 const preview=useMemo(()=>`data:image/svg+xml;charset=utf-8,${encodeURIComponent(rendered.svg)}`,[rendered.svg]);
 useEffect(()=>{if(exportUrl.current){URL.revokeObjectURL(exportUrl.current);exportUrl.current=null;}setDownloadReady(null);setMessage('');},[rendered.svg]);

 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;if(exportUrl.current)URL.revokeObjectURL(exportUrl.current);for(const url of Object.values(localUrls.current))if(url)releaseLocalMatchupImage(url);localUrls.current={};};},[]);
 useEffect(()=>{
  let cancelled=false;setAssetError('');
  void prepareMatchupArtwork(snapshot).then(artwork=>{if(!cancelled)setAssets({key:artworkKey,artwork});}).catch(()=>{if(!cancelled)setAssetError('Some artwork could not be loaded. Names and matchup details will still export.');});
  return()=>{cancelled=true;};
 // Text and layout changes reuse the already prepared raster images.
 // eslint-disable-next-line react-hooks/exhaustive-deps
 },[artworkKey]);

 function clearLocalImages(){for(const url of Object.values(localUrls.current))if(url)releaseLocalMatchupImage(url);localUrls.current={};}
 function changeEntry(change:EntryChange){
  setMessage('');setError('');
  if(editable&&selectedOfficial){onEntryChange?.(selectedOfficial.id,change);return;}
  setCopies(previous=>({...previous,[side]:{...previous[side],...change}}));
 }
 async function selectImage(file:File){
  if(controlsDisabled)return;
  setError('');setMessage('');setLocalUploading(true);
  const targetSide=side,targetEntry=entries[side];
  try{
   if(file.size>5*1024*1024)throw new Error('Use an image smaller than 5 MB.');
   if(!file.size)throw new Error('Choose a PNG, JPG, WebP, or GIF image.');
   if(editable&&targetEntry){
    if(!onUpload)throw new Error('Image uploads are not available here.');
    await onUpload(file,targetEntry.id);
   }else{
    const image=await prepareLocalMatchupImage(file);
    if(!mounted.current){releaseLocalMatchupImage(image);return;}
    const old=localUrls.current[targetSide];if(old)releaseLocalMatchupImage(old);
    localUrls.current[targetSide]=image;
    setCopies(previous=>({...previous,[targetSide]:{...previous[targetSide],image}}));
   }
  }catch(e){if(mounted.current)setError(e instanceof Error?e.message:'This image could not be loaded.');}
  finally{if(mounted.current)setLocalUploading(false);}
 }
 function removeImage(){const old=localUrls.current[side];if(old){releaseLocalMatchupImage(old);delete localUrls.current[side];}changeEntry({image:null});}
 function resetDesign(){clearLocalImages();setCopies({0:{},1:{}});setTitle(undefined);setLabel(undefined);setAccent(undefined);setBackground(undefined);setTransparent(false);setShowResults(false);setMessage('Image design reset.');setError('');}
 async function save(kind:'png'|'svg'){
  if(controlsDisabled)return;setBusy(kind);setError('');setMessage('');
  try{
   const result=await downloadMatchupImage(snapshot,options,kind);
   if(mounted.current){if(exportUrl.current)URL.revokeObjectURL(exportUrl.current);const url=URL.createObjectURL(result.blob);exportUrl.current=url;setDownloadReady({url,filename:result.filename});}
   if(mounted.current)setMessage(result.warnings.length?`Saved with ${result.warnings.length} image${result.warnings.length===1?'':'s'} unavailable. Names and details are included.`:`${kind.toUpperCase()} saved · ${formats.find(item=>item.id===format)!.size}${transparent?' · transparent background':''}.`);
  }catch(e){if(mounted.current)setError(e instanceof Error?e.message:'The image could not be exported. Please try again.');}
  finally{if(mounted.current)setBusy(null);}
 }

 return <section className="matchup-studio" aria-label="Matchup image studio">
  <div className="matchup-studio-layout">
   <div className="matchup-studio-artboard">
    <div className="matchup-format-options" role="group" aria-label="Image format">{formats.map(({id,label,ratio,Icon})=><button key={id} type="button" aria-pressed={format===id} disabled={controlsDisabled} onClick={()=>setFormat(id)}><Icon size={16}/><span>{label}<small>{ratio}</small></span></button>)}</div>
    <div className={`matchup-preview-canvas ${transparent?'is-transparent':''}`} data-format={format}>
     <img className="matchup-preview-image" src={preview} width={rendered.width} height={rendered.height} alt={`Image preview: ${shownEntries[0].name||'Contender A'} versus ${shownEntries[1].name||'Contender B'}`}/>
     {!artwork&&!assetError&&<span className="matchup-artwork-loading" role="status"><LoaderCircle size={13} className="spin"/>Preparing artwork</span>}
    </div>
    <div className="matchup-preview-caption"><span>Live image preview</span><span>{formats.find(item=>item.id===format)!.size} px</span></div>
    <div className="matchup-export-toggles">
     <label><input type="checkbox" checked={transparent} disabled={controlsDisabled} onChange={e=>setTransparent(e.target.checked)}/><span>Transparent background<small>Overlay the matchup on your video</small></span></label>
     <label><input type="checkbox" checked={showResults&&canShowResults} disabled={controlsDisabled||!canShowResults} onChange={e=>setShowResults(e.target.checked)}/><span>Include results<small>{canShowResults?'Use the vote totals visible to you':'Available when results are revealed'}</small></span></label>
    </div>
   </div>
   <div className="matchup-studio-controls">
    <div className="matchup-editor-heading"><h3>{editable?'Edit this matchup':'Customize this image'}</h3><p>{editable?'Your changes also update the bracket draft.':'Image copy only — tournament entries and votes stay the same.'}</p></div>
    <div className="matchup-side-options" role="group" aria-label="Choose contender to edit">{shownEntries.map((entry,index)=><button key={index} type="button" aria-pressed={side===index} disabled={controlsDisabled} onClick={()=>setSide(index as Side)}><span className="matchup-side-letter">{index===0?'A':'B'}</span><span>{entry.name||`Contender ${index===0?'A':'B'}`}</span>{side===index&&<Check size={14}/>}</button>)}</div>
    <fieldset className="matchup-entry-fields" disabled={controlsDisabled}>
     <label className="matchup-field" htmlFor={`${uid}-name`}>Name<input id={`${uid}-name`} value={selected.name} maxLength={100} placeholder={`Contender ${side===0?'A':'B'}`} onChange={e=>changeEntry({name:e.target.value})}/></label>
     <label className="matchup-field" htmlFor={`${uid}-subtitle`}>Second line <span>Optional</span><input id={`${uid}-subtitle`} value={selected.subtitle} maxLength={100} placeholder="Team, series, or a short description" onChange={e=>changeEntry({subtitle:e.target.value})}/></label>
     <div className="matchup-image-field"><label className="matchup-image-upload" htmlFor={`${uid}-image`}>{selected.image?<EntryArt image={selected.image} alt="Selected contender image" className="matchup-image-thumb"/>:<span className="matchup-image-placeholder"><ImagePlus size={22}/></span>}<span><strong>{uploading||localUploading?'Loading image…':selected.image?'Change image':'Add an image'}</strong><small>PNG, JPG, WebP, GIF · 5 MB max</small></span><input id={`${uid}-image`} type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={e=>{const file=e.target.files?.[0];e.target.value='';if(file)void selectImage(file);}}/>{(uploading||localUploading)&&<LoaderCircle className="spin" size={18}/>}</label>{selected.image&&<button type="button" className="matchup-image-remove" aria-label="Remove contender image" title="Remove contender image" onClick={removeImage}><Trash2 size={17}/></button>}</div>
    </fieldset>
    <details className="matchup-image-settings"><summary>Image settings <span>Title & colors</span></summary><fieldset disabled={controlsDisabled}>
     <label className="matchup-field" htmlFor={`${uid}-title`}>Title on image<input id={`${uid}-title`} value={title??bracket.title} maxLength={120} onChange={e=>setTitle(e.target.value)}/></label>
     <label className="matchup-field" htmlFor={`${uid}-label`}>Matchup label<input id={`${uid}-label`} value={label??defaultLabel} maxLength={100} onChange={e=>setLabel(e.target.value)}/></label>
     <div className="matchup-color-fields"><label htmlFor={`${uid}-accent`}><input id={`${uid}-accent`} type="color" value={accent??colors.button} onChange={e=>setAccent(e.target.value)}/><span>Accent</span></label><label htmlFor={`${uid}-background`}><input id={`${uid}-background`} type="color" value={background??colors.page} disabled={transparent||controlsDisabled} onChange={e=>setBackground(e.target.value)}/><span>Background</span></label></div>
     <button type="button" className="matchup-reset" onClick={resetDesign}><RotateCcw size={14}/>Reset image {editable?'design':'copy'}</button>
    </fieldset></details>
   </div>
  </div>
  <div className="matchup-studio-footer"><p>Ready for your video, stream, or social post.<span>{editable?'Save the draft to keep contender changes.':'Image edits are temporary until you download.'}</span></p><div className="matchup-download-actions"><button type="button" className="button" disabled={controlsDisabled} onClick={()=>void save('svg')}>{busy==='svg'?<LoaderCircle className="spin" size={16}/>:<Download size={16}/>}SVG</button><button type="button" className="button primary" disabled={controlsDisabled} onClick={()=>void save('png')}>{busy==='png'?<LoaderCircle className="spin" size={17}/>:<Download size={17}/>}Download PNG</button></div></div>
  {(message||assetError)&&<p className="matchup-studio-status" role="status">{message||assetError}</p>}
  {downloadReady&&<a className="matchup-download-again" href={downloadReady.url} download={downloadReady.filename}>Save the prepared image again</a>}
  {error&&<p className="matchup-studio-error" role="alert">{error}</p>}
 </section>;
}
