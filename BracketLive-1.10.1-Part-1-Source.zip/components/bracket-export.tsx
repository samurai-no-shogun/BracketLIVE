'use client';
import {useState} from 'react';
import {Download,FileImage,FileJson,LoaderCircle,Printer,Table} from 'lucide-react';
import type {Bracket} from '@/lib/bracket';
import {bracketSnapshot,bracketSnapshotCsv,exportFilename,prepareExportArtwork,renderBracketSvg} from '@/lib/bracket-export';

type Format='png'|'svg'|'print'|'json'|'csv';
function download(blob:Blob,name:string){const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
async function pngBlob(svg:string,width:number,height:number){
 const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
 try{
  const image=new Image();image.decoding='sync';
  await new Promise<void>((resolve,reject)=>{image.onload=()=>resolve();image.onerror=()=>reject(new Error('Image rendering failed. Try the SVG download.'));image.src=url;});
  const scale=Math.min(1.5,Math.sqrt(20000000/(width*height)),8192/Math.max(width,height)),canvas=document.createElement('canvas');
  canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale);
  const ctx=canvas.getContext('2d');if(!ctx)throw new Error('This browser could not create an image. Try the SVG download.');
  ctx.drawImage(image,0,0,canvas.width,canvas.height);
  return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('PNG export failed. Try the SVG download.')),'image/png'));
 }finally{URL.revokeObjectURL(url);}
}
function printPreview(popup:Window,svg:string,title:string){
 const doc=popup.document;doc.title=`${title||'Bracket'} — Print`;
 doc.body.replaceChildren();
 const style=doc.createElement('style');style.textContent='*{box-sizing:border-box}body{margin:0;background:#e8e7ec;font:14px Arial,sans-serif;color:#15111d}.tools{display:flex;gap:12px;align-items:center;padding:16px}.tools button{cursor:pointer;padding:10px 16px;font:inherit}.sheet{width:100%;padding:16px}.sheet svg{display:block;width:100%;height:auto}@page{size:A3 landscape;margin:8mm}@media print{body{background:white}.tools{display:none}.sheet{padding:0;width:100%;height:280mm;break-inside:avoid;page-break-inside:avoid}.sheet svg{width:100%;height:100%;object-fit:contain;print-color-adjust:exact;-webkit-print-color-adjust:exact}}';
 doc.head.appendChild(style);
 const toolbar=doc.createElement('div');toolbar.className='tools';
 const button=doc.createElement('button');button.type='button';button.textContent='Print / Save as PDF';button.onclick=()=>popup.print();
 const note=doc.createElement('span');note.textContent='Whole bracket · choose “Save as PDF” in the print dialog. Landscape, A3 gives more room.';toolbar.appendChild(button);toolbar.appendChild(note);
 const sheet=doc.createElement('div');sheet.className='sheet';sheet.innerHTML=svg;doc.body.appendChild(toolbar);doc.body.appendChild(sheet);popup.focus();
}
export default function BracketExport({bracket,kind='results'}:{bracket:Bracket;kind?:'results'|'picks'}){
 const [expanded,setExpanded]=useState(false),[busy,setBusy]=useState<Format|null>(null),[message,setMessage]=useState(''),[error,setError]=useState('');
 async function save(format:Format){
  if(busy)return;
  const snapshot=bracketSnapshot(bracket,new Date(),kind);
  const popup=format==='print'?window.open('about:blank','_blank'):null;
  if(format==='print'&&!popup){setError('Allow pop-ups to open the print preview, or download the PNG or SVG.');return;}
  if(popup){popup.opener=null;popup.document.body.textContent='Preparing the whole bracket…';}
  setBusy(format);setError('');setMessage('');
  try{
   if(format==='json'){download(new Blob([JSON.stringify(snapshot,null,2)],{type:'application/json'}),exportFilename(snapshot,'json'));setMessage(kind==='picks'?'Personal picks snapshot saved. Includes your matchups and predicted winners.':'Snapshot saved. Includes entries, matches, revealed results, and your picks.');return;}
   if(format==='csv'){download(new Blob([bracketSnapshotCsv(snapshot)],{type:'text/csv;charset=utf-8'}),exportFilename(snapshot,'csv'));setMessage(kind==='picks'?'All your predicted winners exported.':'All match results exported. Unrevealed vote totals are blank.');return;}
   const artwork=await prepareExportArtwork(snapshot),{svg,width,height}=renderBracketSvg(snapshot,artwork);
   if(format==='print'){if(!popup||popup.closed)throw new Error('Print preview was closed. Open it again to export.');printPreview(popup,svg,bracket.title);}
   else if(format==='svg')download(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}),exportFilename(snapshot,'svg'));
   else download(await pngBlob(svg,width,height),exportFilename(snapshot,'png'));
   setMessage(artwork.warnings.length?`${artwork.warnings.length} image${artwork.warnings.length===1?' could':'s could'} not be loaded and ${artwork.warnings.length===1?'is':'are'} marked ×. All names and results are included.`:format==='print'?'Print preview opened. Use Print / Save as PDF to save the whole bracket.':kind==='picks'?'Your whole prediction bracket saved with a timestamp.':'Whole bracket saved with the current match results and a timestamp.');
  }catch(e){setError(e instanceof Error?e.message:'Export failed. Please try again.');if(popup&&!popup.closed)popup.document.body.textContent='Export could not be prepared. Close this tab and try again.';}
  finally{setBusy(null);}
 }
 return <section className="bracket-export" aria-label="Export bracket"><button type="button" className="button small" aria-expanded={expanded} onClick={()=>setExpanded(!expanded)}><Download size={16}/>{kind==='picks'?'Export my picks':'Export bracket'}</button>{expanded&&<div className="bracket-export-panel"><p className="bracket-export-note">{kind==='picks'?'Save your full prediction bracket with every pick and your chosen champion.':'Save the whole bracket at this stage, including every matchup and decided winner. Export again after each round.'}</p><div className="bracket-export-actions">{([['png','PNG image',FileImage],['svg','SVG image',FileImage],['print','Print / PDF',Printer],['json','Snapshot JSON',FileJson],['csv','Results CSV',Table]] as const).map(([format,label,Icon])=><button key={format} type="button" className="button small" onClick={()=>save(format)} disabled={busy!==null}>{busy===format?<LoaderCircle size={16} className="spin"/>:<Icon size={16}/>}<span>{busy===format?'Preparing…':label}</span></button>)}</div><p className="bracket-export-note">Images include your theme and artwork. {kind==='picks'?'Personal picks are labeled separately from community results.':'Unrevealed vote totals stay hidden.'} Snapshots are downloads; earlier stages are not stored automatically.</p></div>}{message&&<p className="bracket-export-note" role="status">{message}</p>}{error&&<p className="bracket-export-error" role="alert">{error}</p>}</section>;
}
