'use client';
import {useEffect,useRef} from 'react';
import {usePathname} from 'next/navigation';
import {ensureSession} from '@/lib/client-session';
export function trackingAllowed(){try{return localStorage.getItem('bl_analytics_opt_out')!=='1'&&navigator.doNotTrack!=='1'&&!(navigator as Navigator&{globalPrivacyControl?:boolean}).globalPrivacyControl;}catch{return false;}}
function eventId(){const bytes=crypto.getRandomValues(new Uint8Array(16));bytes[6]=(bytes[6]&15)|64;bytes[8]=(bytes[8]&63)|128;const h=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;}
export async function trackEvent(kind:'view'|'share',path=window.location.pathname){
 if(!trackingAllowed())return;
 try{await ensureSession();let source='direct';try{if(document.referrer)source=new URL(document.referrer).hostname;}catch{}
 const campaign=new URLSearchParams(window.location.search).get('utm_campaign')?.slice(0,100)||'';
 await fetch('/api/analytics/events',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:eventId(),kind,path,source,campaign}),keepalive:true});}catch{/* Analytics never blocks voting. */}
}
export default function AnalyticsTracker(){const path=usePathname(),previous=useRef('');useEffect(()=>{if(!path||previous.current===path||!(/^\/$|^\/explore$|^\/create$|^\/b\/[a-f0-9-]{36}$/.test(path)))return;previous.current=path;void trackEvent('view',path);},[path]);return null;}
