'use client';
import {ArrowRight,Check,LoaderCircle,Trophy} from 'lucide-react';
import {Progress} from '@/components/ui/progress';
import {type Bracket,roundName,votePercent} from '@/lib/bracket';

type Props={bracket:Bracket;busy:boolean;votingLocked?:boolean;onAdvance:()=>void;onNextUnvoted?:()=>void;onViewFinal?:()=>void;compact?:boolean};

export default function RoundFlow({bracket,busy,votingLocked=false,onAdvance,onNextUnvoted,onViewFinal,compact=false}:Props){
 const rounds=Math.log2(bracket.size),open=bracket.matches.filter(m=>m.status==='open');
 const voted=open.filter(m=>m.myVote).length,left=open.length-voted,ready=open.length>0&&left===0;
 const final=bracket.matches.find(m=>m.round===rounds-1),champion=bracket.entries.find(e=>e.id===final?.winner_id);
 const closing=bracket.current_round===rounds-1;
 const waiting=!!bracket.schedule_blocked,locked=votingLocked||waiting,tiePause=waiting&&(!bracket.schedule_blocked_reason||bracket.schedule_blocked_reason.startsWith('Resolve tied'));
 const blockedCopy=tiePause?bracket.isOwner?'Voting is closed. Resolve tied matches to open the next round.':'Voting is closed while the organizer decides tied winners.':bracket.isOwner?bracket.schedule_blocked_reason||'Update the voting schedule to reopen this round.':'Voting is paused while the organizer updates the schedule.';
 const roundCopy=locked?(waiting?blockedCopy:'Voting has closed. Winners are being advanced; this usually takes up to a minute.'):bracket.isOwner?bracket.is_test?ready?closing?'Confirm your final pick to crown the champion.':`${open.length} winners are ready for ${roundName(bracket.current_round+1,bracket.size,bracket.format)}.`:closing?'Vote for your champion.':`Pick ${left} more ${left===1?'winner':'winners'} to advance.`:closing?'Close voting to crown the winner of the final.':'Close this round to advance the vote leaders.':bracket.round_closes_at?'Winners advance when this round closes.':'The organizer advances the winners when voting closes.';

 if(bracket.status==='complete'&&champion&&final)return <section className={`round-flow complete ${compact?'compact':''}`} aria-label="Tournament champion">
  <Trophy size={28}/><div className="round-flow-copy"><span>Tournament champion</span><strong>{champion.name||`Entry ${champion.seed}`}</strong><p>{votePercent(final,champion.id)}% in the final · {final.counts?.[champion.id]??0} of {final.total??0} votes</p></div>
  {onViewFinal&&<button className="button small" type="button" onClick={onViewFinal}>View final results</button>}
 </section>;
 if(bracket.status!=='live')return null;

 return <section className={`round-flow ${ready?'ready':''} ${compact?'compact':''}`} aria-label="Round progress">
  <div className="round-flow-marker" aria-hidden="true">{ready?<Check size={19}/>:<span>{bracket.current_round+1}<small>/{rounds}</small></span>}</div><div className="round-flow-copy"><span>{roundName(bracket.current_round,bracket.size,bracket.format)}<span className="round-flow-open">{locked?waiting?'Decision needed':'Voting closed':'Voting open'}</span></span><strong>{ready?<><Check size={16}/>{open.length===1?'Final vote saved':`All ${open.length} matchups voted`}</>:`${voted} of ${open.length} matchups voted`}</strong><p>{roundCopy}</p><Progress value={open.length?voted/open.length*100:0} className="round-flow-progress" aria-label="Your votes this round"/></div>
  <div className="round-flow-actions">{left>0&&onNextUnvoted&&!locked&&<button className="button small" type="button" disabled={busy} onClick={onNextUnvoted}>Continue voting<ArrowRight size={15}/></button>}{bracket.isOwner&&<button className="button primary advance-winners" type="button" disabled={busy||(bracket.is_test&&!ready)} onClick={onAdvance}>{busy?<LoaderCircle className="spin" size={16}/>:closing?<Trophy size={16}/>:null}{busy?'Updating…':waiting?(tiePause?'Resolve ties':'Advance winners'):closing?'Confirm champion':'Advance winners'}</button>}</div>
 </section>;
}
