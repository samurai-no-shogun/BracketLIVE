'use client';

import {useEffect,type CSSProperties} from 'react';
import {Check} from 'lucide-react';

export type VoteCelebrationEvent={sequence:number;matchId:string;complete:boolean};

/** One short acknowledgement per confirmed selection; never blocks the next vote. */
export default function VoteCelebration({event,onDone}:{event:VoteCelebrationEvent|null;onDone:()=>void}){
 useEffect(()=>{
  if(!event)return;
  const timer=window.setTimeout(onDone,2800);
  return()=>window.clearTimeout(timer);
 },[event,onDone]);
 return <div className="vote-reward-region" role="status" aria-live="polite" aria-atomic="true">
  {event&&<div key={event.sequence} className="vote-reward">
   <span className="vote-reward-check" aria-hidden="true"><Check size={19}/></span>
   <span className="vote-reward-copy"><strong>Thanks for voting!</strong><span>{event.complete?'You’ve voted in every open matchup.':'Your vote is counted. The results are live.'}</span></span>
   <span className="vote-confetti" aria-hidden="true">{Array.from({length:14},(_,i)=><i key={i} style={{'--piece-x':`${(i-6.5)*18}px`,'--piece-y':`${-42-(i%4)*11}px`,'--piece-turn':`${(i%2?1:-1)*(100+i*23)}deg`,'--piece-delay':`${(i%4)*.025}s`,'--piece-color':i%3===0?'#a995dc':i%3===1?'#b8d7ca':'#e0d2ad'} as CSSProperties}/>)}</span>
  </div>}
 </div>;
}
