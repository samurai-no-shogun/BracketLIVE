'use client';
import {useEffect,useMemo,useState} from 'react';
import {Check,ChevronRight,RotateCcw,Trophy} from 'lucide-react';
import {type Bracket,displaySeed,roundName} from '@/lib/bracket';
import {changeBracketPick,parseStoredPicks,picksStorageKey,projectBracketPicks,serializeStoredPicks,type BracketPicks} from '@/lib/bracket-picks';
import {appearanceStyle} from '@/lib/appearance';
import BracketBoard,{EntryImage} from './bracket-board';
import BracketExport from './bracket-export';
import {Dialog,DialogContent,DialogDescription,DialogHeader,DialogTitle} from './ui/dialog';
import {Progress} from './ui/progress';

export default function PersonalBracketPicks({bracket}:{bracket:Bracket}){
 const key=picksStorageKey(bracket.id);
 const [saved,setSaved]=useState<{key:string;picks:BracketPicks;ready:boolean}>({key,picks:{},ready:false});
 const [storageError,setStorageError]=useState(''),[selected,setSelected]=useState<string|null>(null),[reset,setReset]=useState(false);
 const rosterKey=JSON.stringify([bracket.size,bracket.entries.map(e=>[e.id,e.seed]),bracket.matches.filter(m=>m.round===0).map(m=>[m.id,m.a_id,m.b_id])]);
 useEffect(()=>{
  const load=()=>{try{const raw=parseStoredPicks(localStorage.getItem(key));setSaved({key,picks:projectBracketPicks(bracket,raw).picks,ready:true});setStorageError('');}catch{setSaved({key,picks:{},ready:true});setStorageError('Device storage is unavailable. Export your picks to keep a copy.');}};
  load();setSelected(null);
  const sync=(event:StorageEvent)=>{if(event.key===key||event.key===null)load();};
  window.addEventListener('storage',sync);return()=>window.removeEventListener('storage',sync);
 },[key,rosterKey]);
 const ready=saved.ready&&saved.key===key;
 const projection=useMemo(()=>projectBracketPicks(bracket,ready?saved.picks:{}),[bracket,ready,saved.picks]);
 const projected=projection.bracket,match=projected.matches.find(m=>m.id===selected),next=projected.matches.find(m=>m.status==='open');
 const championId=projected.matches.at(-1)?.winner_id,champion=projected.entries.find(e=>e.id===championId);
 function save(picks:BracketPicks){
  setSaved({key,picks,ready:true});
  try{localStorage.setItem(key,serializeStoredPicks(picks));setStorageError('');}catch{setStorageError('Your changes could not be saved on this device. Export your picks to keep a copy.');}
 }
 function choose(entryId:string|null){if(match&&ready)save(changeBracketPick(bracket,projection.picks,match.id,entryId));}
 if(!ready)return <p className="share-note" role="status">Loading your picks…</p>;
 const progress=<section className={`round-flow ${champion?'complete':''}`} aria-label="Personal bracket progress">
  {champion&&<Trophy size={28}/>}
  <div className="round-flow-copy"><span>My picks · {projection.completed} of {bracket.size-1} {bracket.size===2?'match':'matches'}</span><strong>{champion?`${champion.name||'Your pick'} is your champion`:'Choose your path to the championship'}</strong><p>{storageError||'Saved on this device. Your picks are separate from community voting.'}</p><Progress className="round-flow-progress" value={projection.completed/(bracket.size-1)*100} aria-label="Your bracket completion"/></div>
  <div className="round-flow-actions">{next&&<button type="button" className="button small primary" onClick={()=>setSelected(next.id)}>Next unpicked<ChevronRight size={15}/></button>}<button type="button" className="button small" disabled={!projection.completed} onClick={()=>setReset(true)}><RotateCcw size={15}/>Clear picks</button></div>
 </section>;
 return <>
  <div className="personal-picks-export" style={{display:'flex',justifyContent:'flex-end',marginBottom:12}}><BracketExport bracket={projected} kind="picks"/></div>
  <div className="tournament-design-surface" style={appearanceStyle(projected)}><BracketBoard bracket={projected} onMatch={setSelected} mode="picks" roundControls={progress}/></div>
  <Dialog open={!!selected} onOpenChange={open=>!open&&setSelected(null)}><DialogContent className="match-dialog" style={appearanceStyle(projected)}><DialogHeader><DialogTitle>{match?`${roundName(match.round,bracket.size,bracket.format)} · Match ${match.position+1}`:'Your matchup'}</DialogTitle><DialogDescription>Pick who advances. Changing a winner clears any later picks that no longer fit.</DialogDescription></DialogHeader>
   {match&&<><article className={`match-card ${match.winner_id?'has-vote':''}`}><div className="versus-contenders">{[match.a_id,match.b_id].map((entryId,i)=>{const entry=projected.entries.find(e=>e.id===entryId),picked=!!entry&&match.winner_id===entry.id;return <div className="contender-wrap" key={i}><button type="button" className={`contender ${picked?'chosen':''}`} disabled={!entry||!match.a_id||!match.b_id} aria-pressed={picked} aria-label={entry?`Pick ${entry.name||`Entry ${displaySeed(entry,bracket.format)}`} to advance`:'Pick the previous round first'} onClick={()=>entry&&choose(entry.id)}>{entry?<><EntryImage entry={entry} large/><span className="contender-name">{entry.name||`Entry ${displaySeed(entry,bracket.format)}`}</span><span className="contender-subtitle">Seed {displaySeed(entry,bracket.format)}{entry.subtitle?` · ${entry.subtitle}`:''}</span>{picked&&<span className="winner-label"><Check size={16}/>Your pick</span>}</>:<><span className="contender-monogram">?</span><span className="contender-name">Previous round winner</span></>}</button></div>;})}<span className="versus">VS</span></div><div className="match-card-footer"><span>{match.winner_id?'Winner advances in your bracket':'Choose either contender to advance'}</span>{match.winner_id&&<button type="button" onClick={()=>choose(null)}><RotateCcw size={14}/>Undo pick</button>}</div></article><div className="dialog-actions"><button type="button" className="button" onClick={()=>setSelected(null)}>Back to bracket</button>{next?<button type="button" className="button primary" disabled={next.id===match.id} onClick={()=>setSelected(next.id)}>Next unpicked<ChevronRight size={16}/></button>:<button type="button" className="button primary" onClick={()=>setSelected(null)}><Trophy size={16}/>See my champion</button>}</div></>}
  </DialogContent></Dialog>
  <Dialog open={reset} onOpenChange={setReset}><DialogContent><DialogHeader><DialogTitle>Clear your personal picks?</DialogTitle><DialogDescription>All {projection.completed} picks on this device will be removed. Export a copy first if you want to keep them.</DialogDescription></DialogHeader><div className="dialog-actions"><button type="button" className="button" onClick={()=>setReset(false)}>Keep picks</button><button type="button" className="button primary" onClick={()=>{save({});setReset(false);setSelected(null);}}>Clear picks</button></div></DialogContent></Dialog>
 </>;
}
