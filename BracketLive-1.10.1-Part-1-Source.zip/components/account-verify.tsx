'use client';
import { useEffect, useRef, useState } from 'react';
import { ArrowRight, CircleCheck, Mail, ShieldCheck } from 'lucide-react';
import { SiteHeader } from './tournament-ui';
import { AccountSignIn } from './account-menu';
import { ensureSession } from '@/lib/client-session';
export default function AccountVerify() {
  const token = useRef('');
  const [ready, setReady] = useState(false), [busy, setBusy] = useState(false), [error, setError] = useState(''), [success, setSuccess] = useState(false), [signIn, setSignIn] = useState(false);
  useEffect(() => {
    const value = new URLSearchParams(window.location.hash.slice(1)).get('token');
    if (value) token.current = value;
    // The bearer token never goes in server request URLs, analytics, or referrers.
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
    setReady(true);
  }, []);
  const confirm = async () => {
    if (busy || !token.current) return; setBusy(true); setError('');
    try {
      await ensureSession();
      const response = await fetch('/api/auth/email/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: token.current }) });
      const data = await response.json() as { error?: string; returnTo?: string }; if (!response.ok) throw new Error(data.error || 'This sign-in link could not be verified. Request a new link and open it in the same browser.');
      token.current = ''; setSuccess(true);
      const target = typeof data.returnTo === 'string' && data.returnTo.startsWith('/') && !data.returnTo.startsWith('//') && !data.returnTo.includes('\\') ? data.returnTo : '/account';
      window.location.assign(target);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not confirm sign-in. Please request a new link.'); setBusy(false); }
  };
  return <div className="app theme-purple account-app"><SiteHeader/><main className="account-verify-wrap"><section className="account-verify-card"><span className="account-dialog-symbol">{success ? <CircleCheck size={32}/> : <ShieldCheck size={32}/>}</span><span className="account-eyebrow">YOUR BRACKET LIVE PROFILE</span><h1>{success ? 'You’re signed in.' : 'One click, and you’re in.'}</h1><p>{success ? 'Opening your workspace…' : 'Confirm that you want to sign in with this email link. Your saved tournaments will be ready for you.'}</p>{!ready ? <p role="status">Checking your link…</p> : !token.current && !success ? <p className="account-notice">This link is missing its sign-in code. Request a fresh link and open it in the same browser you used to request it.</p> : !success && <button className="button primary" onClick={() => void confirm()} disabled={busy}>{busy ? 'Signing you in…' : 'Confirm sign-in'}<ArrowRight size={17}/></button>}{error && <p className="account-error" role="alert">{error}</p>}{!success && <button type="button" className="account-text-button" onClick={() => setSignIn(true)}><Mail size={16}/>Send a new sign-in link</button>}<p className="account-privacy">Only confirm if you requested this link. <a href="/">Back to voting</a></p></section></main><AccountSignIn open={signIn} onOpenChange={setSignIn} returnTo="/account"/></div>;
}
