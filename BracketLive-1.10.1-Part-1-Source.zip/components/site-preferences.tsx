'use client';

import {useEffect,useState} from 'react';
import {Moon,Sun,Volume2,VolumeX} from 'lucide-react';

export type SitePreferences={theme:'light'|'dark';muted:boolean};
const defaults:SitePreferences={theme:'light',muted:false};
const changeEvent='bl-preferences-change';

function readPreferences():SitePreferences{
 if(typeof window==='undefined')return defaults;
 try{const theme=localStorage.getItem('bl_theme');return {theme:theme==='dark'||(theme!=='light'&&document.documentElement.dataset.theme==='dark')?'dark':'light',muted:['1','true'].includes(localStorage.getItem('bl_muted')??'')};}
 catch{return {...defaults,theme:document.documentElement.dataset.theme==='dark'?'dark':'light',muted:document.documentElement.dataset.muted==='true'};}
}
function applyPreferences(preferences:SitePreferences){
 const root=document.documentElement;
 root.dataset.theme=preferences.theme;
 root.dataset.muted=String(preferences.muted);
 root.classList.toggle('dark',preferences.theme==='dark');
}
function persistThemeCookie(theme:SitePreferences['theme']){
 // This non-sensitive preference lets the server paint the next page in the
 // right theme before hydration. Authentication cookies remain HttpOnly.
 try{document.cookie=`bl_theme=${theme}; Path=/; Max-Age=31536000; SameSite=Lax${window.location.protocol==='https:'?'; Secure':''}`;}catch{/* Storage-restricted browsers can still change the current page. */}
}
function savePreferences(preferences:SitePreferences){
 applyPreferences(preferences);
 persistThemeCookie(preferences.theme);
 try{localStorage.setItem('bl_theme',preferences.theme);localStorage.setItem('bl_muted',preferences.muted?'1':'0');}catch{/* Session preferences still work when browser storage is unavailable. */}
 window.dispatchEvent(new CustomEvent<SitePreferences>(changeEvent,{detail:preferences}));
}

/** Mount once in the root layout. No inline initializer is needed by the CSP. */
export function SitePreferences(){
 useEffect(()=>{
  const initial=readPreferences();applyPreferences(initial);persistThemeCookie(initial.theme);
  const sync=(event:StorageEvent)=>{if(event.key===null||event.key==='bl_theme'||event.key==='bl_muted'){const preferences=readPreferences();applyPreferences(preferences);persistThemeCookie(preferences.theme);window.dispatchEvent(new CustomEvent<SitePreferences>(changeEvent,{detail:preferences}));}};
  window.addEventListener('storage',sync);
  return()=>window.removeEventListener('storage',sync);
 },[]);
 return null;
}

/** Sound and appearance stay beside the account button, including on phones. */
export function SitePreferenceControls(){
 const [preferences,setPreferences]=useState<SitePreferences>(defaults);
 useEffect(()=>{
  setPreferences(readPreferences());
  const sync=(event:Event)=>{const detail=(event as CustomEvent<SitePreferences>).detail;setPreferences(detail?.theme==='light'||detail?.theme==='dark'?detail:readPreferences());};
  window.addEventListener(changeEvent,sync);
  return()=>window.removeEventListener(changeEvent,sync);
 },[]);
 const toggleTheme=()=>savePreferences({...preferences,theme:preferences.theme==='dark'?'light':'dark'});
 const toggleSound=()=>savePreferences({...preferences,muted:!preferences.muted});
 return <>
  <button type="button" className="site-preference-button" onClick={toggleTheme} aria-label={preferences.theme==='dark'?'Switch to light mode':'Switch to dark mode'} title={preferences.theme==='dark'?'Switch to light mode':'Switch to dark mode'}>{preferences.theme==='dark'?<Sun size={19}/>:<Moon size={19}/>}</button>
  <button type="button" className="site-preference-button" onClick={toggleSound} aria-label={preferences.muted?'Unmute sounds':'Mute sounds'} title={preferences.muted?'Unmute sounds':'Mute sounds'} aria-pressed={preferences.muted}>{preferences.muted?<VolumeX size={19}/>:<Volume2 size={19}/>}</button>
 </>;
}
