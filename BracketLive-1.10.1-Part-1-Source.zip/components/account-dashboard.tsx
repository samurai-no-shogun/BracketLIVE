'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { ArrowRight, Check, CircleUserRound, Flag, GitFork, Link, Plus, Search, Share2 } from 'lucide-react';
import { SiteHeader } from './tournament-ui';
import { AccountSignIn, announceAccountChange, useAccount } from './account-menu';
import { trackEvent } from './analytics-tracker';
import { ensureSession } from '@/lib/client-session';
import type { TournamentCard } from '@/lib/bracket';
import type { SeasonCard } from '@/lib/standings';

type Item = { id: string; title: string; description: string; kind: 'bracket' | 'season'; href: string; status: string; summary: string; public: boolean; createdAt: number };
export default function AccountDashboard() {
  const account = useAccount();
  const [signIn, setSignIn] = useState(false), [items, setItems] = useState<Item[]>([]), [query, setQuery] = useState(''), [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true), [error, setError] = useState(''), [authError, setAuthError] = useState(''), [copied, setCopied] = useState(''), [manualLink, setManualLink] = useState('');
  const [name, setName] = useState(''), [saving, setSaving] = useState(false), [profileMessage, setProfileMessage] = useState(''), [profileError, setProfileError] = useState('');
  useEffect(() => { setName(account.user?.name || ''); }, [account.user?.name]);
  useEffect(() => { let alive = true; const run = async () => {
    try {
      await ensureSession();
      const responses = await Promise.all([fetch('/api/brackets', { cache: 'no-store' }), fetch('/api/seasons?view=mine', { cache: 'no-store' })]);
      const [brackets, seasons] = await Promise.all([responses[0].json() as Promise<{ brackets: TournamentCard[]; error?: string }>, responses[1].json() as Promise<{ seasons: SeasonCard[]; error?: string }>]);
      if (!responses[0].ok || !responses[1].ok) throw new Error(brackets.error || seasons.error || 'Your tournaments could not be loaded.');
      const all: Item[] = [
        ...(brackets.brackets as TournamentCard[]).map(bracket => ({ id: bracket.id, title: bracket.title, description: bracket.description, kind: 'bracket' as const,
          href: `/b/${bracket.id}`, status: bracket.is_test ? 'Private test' : bracket.status === 'live' ? 'Voting open' : bracket.status === 'complete' ? 'Complete' : 'Draft',
          summary: `${bracket.size} contenders · ${bracket.totalVotes} votes`, public: !bracket.is_test && bracket.status !== 'draft', createdAt: bracket.created_at })),
        ...(seasons.seasons as SeasonCard[]).map(season => ({ id: season.id, title: season.title, description: season.description, kind: 'season' as const, href: `/s/${season.id}`, status: 'Points season',
          summary: `${season.entrantCount} entrants · ${season.completedCount}/${season.eventCount} events scored`, public: true, createdAt: season.createdAt }))
      ];
      if (alive) { setItems(all.sort((a, b) => b.createdAt - a.createdAt)); setError(''); }
    } catch (reason) { if (alive) setError(reason instanceof Error ? reason.message : 'Your tournaments could not be loaded.'); }
    finally { if (alive) setLoading(false); }
  }; void run(); return () => { alive = false; }; }, [account.user?.id]);
  useEffect(() => { const message = new URLSearchParams(window.location.search).get('authError'); if (message) setAuthError(message.slice(0, 300)); }, []);
  const share = async (item: Item) => {
    const url = new URL(item.kind === 'season' ? `/s/${item.id}` : `/b/${item.id}`, window.location.origin).href;
    setManualLink('');
    try {
      if (navigator.share) { await navigator.share({ title: item.title, text: item.kind === 'season' ? 'Follow the standings on Bracket Live.' : 'Pick your favorites on Bracket Live.', url }); }
      else { await navigator.clipboard.writeText(url); setCopied(item.id); }
      if (item.kind === 'bracket') void trackEvent('share', `/b/${item.id}`);
    } catch (reason) { if (!(reason instanceof DOMException && reason.name === 'AbortError')) setManualLink(url); }
  };
  const saveProfile = async (event: FormEvent) => {
    event.preventDefault(); if (saving) return; setSaving(true); setProfileMessage(''); setProfileError('');
    try {
      const response = await fetch('/api/account', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: name.trim() }) });
      const data = await response.json() as { error?: string }; if (!response.ok) throw new Error(data.error || 'Could not save your profile.');
      announceAccountChange(); setProfileMessage('Profile saved.');
    } catch (reason) { setProfileError(reason instanceof Error ? reason.message : 'Could not save your profile.'); }
    finally { setSaving(false); }
  };
  const visible = items.filter(item => (filter === 'all' || filter === item.kind) && `${item.title} ${item.description}`.toLowerCase().includes(query.toLowerCase()));
  return <div className="app theme-purple account-app"><SiteHeader/><main className="account-workspace"><section className="account-heading"><div><span className="account-eyebrow">YOUR WORKSPACE</span><h1>Make something<br/><span>worth rooting for.</span></h1><p>{account.user ? `Welcome back${account.user.name ? `, ${account.user.name}` : ''}. Your tournaments are all here.` : 'Your tournaments, ready for the next great matchup.'}</p></div><a className="button primary" href="/create"><Plus size={17}/>Create tournament</a></section>
    {!account.user && account.ready && <section className="account-connect"><span className="account-connect-icon"><CircleUserRound size={26}/></span><div><h2>A little space of your own</h2><p>Sign in to keep the tournaments from this browser with your profile and manage them on your other devices.</p></div><button className="button" onClick={() => setSignIn(true)}>Create a profile<ArrowRight size={16}/></button></section>}
    <section className="account-library" aria-labelledby="account-tournaments-title"><div className="account-section-heading"><div><h2 id="account-tournaments-title">{account.user ? 'My tournaments' : 'Tournaments in this browser'}</h2><p>Brackets and points seasons, together.</p></div><label className="account-search"><Search size={17}/><input type="search" aria-label="Search your tournaments" placeholder="Find a tournament" value={query} onChange={event => setQuery(event.target.value)}/></label></div>
      <div className="account-filter" role="group" aria-label="Tournament type">{[{ value: 'all', label: 'All tournaments' }, { value: 'bracket', label: 'Brackets' }, { value: 'season', label: 'Points seasons' }].map(option => <button key={option.value} aria-pressed={filter === option.value} onClick={() => setFilter(option.value)}>{option.label}</button>)}</div>
      {authError && <p className="account-error" role="alert">{authError}</p>}{error && <p className="account-error" role="alert">{error}</p>}
      {manualLink && <label className="account-manual-link">Copy this public link<input readOnly value={manualLink} onFocus={event => event.target.select()}/></label>}
      {loading ? <p className="account-empty" role="status">Loading your tournaments…</p> : visible.length ? <div className="account-tournament-grid">{visible.map(item => <article className="account-tournament" key={`${item.kind}-${item.id}`}><div className="account-tournament-top"><span className="account-tournament-icon">{item.kind === 'bracket' ? <GitFork size={23}/> : <Flag size={23}/>}</span><span className={`account-status ${item.status === 'Voting open' ? 'is-live' : ''}`}>{item.status}</span></div><h3><a href={item.href}>{item.title}</a></h3><p>{item.description || (item.kind === 'bracket' ? 'Every matchup has a story. Let yours unfold.' : 'Keep the competition going, one event at a time.')}</p><span className="account-tournament-summary">{item.summary}</span><div className="account-tournament-actions"><a className="account-open" href={item.href}>{item.status === 'Draft' ? 'Continue editing' : 'Open tournament'}<ArrowRight size={16}/></a>{item.public ? <button className="account-share" onClick={() => void share(item)} aria-label={`Share ${item.title}`}>{copied === item.id ? <Check size={17}/> : <Share2 size={17}/>}<span>{copied === item.id ? 'Copied' : 'Share'}</span></button> : <span className="account-private-note">{item.status === 'Draft' ? 'Publish to share' : 'Private test'}</span>}</div></article>)}</div> : <div className="account-empty"><GitFork size={30}/><h3>{query ? 'No matching tournaments' : 'A fresh page for your next idea'}</h3><p>{query ? 'Try a different name or tournament type.' : 'Create a bracket or a points season. Start small, or bring all 128 contenders.'}</p>{!query && <a className="button" href="/create">Create a tournament<Plus size={16}/></a>}</div>}
    </section>
    {account.user && <section className="account-profile" id="profile"><div><span className="account-eyebrow">PROFILE SETTINGS</span><h2>Your profile</h2><p>Your email is private and is used for signing in.</p></div><form onSubmit={saveProfile}><label>Display name<input name="name" type="text" autoComplete="name" value={name} onChange={event => setName(event.target.value)} maxLength={80} required/></label><label>Email address<input type="email" value={account.user.email} readOnly aria-readonly="true"/></label><div className="account-profile-save"><button className="button" type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save profile'}</button>{profileMessage && <span role="status"><Check size={15}/>{profileMessage}</span>}</div>{profileError && <p className="account-error" role="alert">{profileError}</p>}</form></section>}
    <p className="account-footnote"><Link size={14}/>Sharing sends a public viewing link. Organizer access stays with you. Personal “My picks” predictions stay in the browser where you made them.</p>
  </main><AccountSignIn open={signIn} onOpenChange={setSignIn} returnTo="/account"/></div>;
}
