'use client';
import { useState, type FormEvent } from 'react';
import { RotateCcw, Save, Trash2, X } from 'lucide-react';
import { motorsportPoints, parsePoints, type Season, type SeasonEvent } from '@/lib/standings';

type EventEditorProps = { season: Season; event: SeasonEvent; busy: boolean;
  onSave: (event: SeasonEvent) => Promise<void>; onDelete: (event: SeasonEvent) => Promise<void>; onClose: () => void };
export function SeasonEventEditor({ season, event, busy, onSave, onDelete, onClose }: EventEditorProps) {
  const [draft, setDraft] = useState<SeasonEvent>(() => ({ ...event, results: season.entrants.map(entrant =>
    event.results.find(result => result.entrantId === entrant.id) ?? { entrantId: entrant.id, position: null, adjustment: 0, note: '' }) }));
  const [confirmDelete, setConfirmDelete] = useState(false), [adjustments, setAdjustments] = useState<Record<string, string>>({});
  const change = (id: string, value: Partial<SeasonEvent['results'][number]>) => setDraft(previous => ({ ...previous,
    results: previous.results.map(result => result.entrantId === id ? { ...result, ...value } : result) }));
  const save = (form: FormEvent) => { form.preventDefault(); void onSave(draft); };
  return <section className="season-panel season-editor" id="season-event-editor"><div className="season-section-title"><h2>{event.version ? 'Edit event results' : 'Add an event'}</h2><button className="button small" onClick={onClose} disabled={busy} aria-label="Close event editor"><X size={17}/></button></div>
    <form onSubmit={save}><fieldset disabled={busy}><div className="season-event-inputs"><label className="field">Event name<input value={draft.title} onChange={form => setDraft({ ...draft, title: form.target.value })} maxLength={100} required/></label><label className="field">Event date <span className="optional">optional</span><input type="date" value={draft.date} onChange={form => setDraft({ ...draft, date: form.target.value })}/></label></div>
      <p className="season-help">Enter finishing places. Leave a place blank for an unclassified entrant. Bonuses add points; penalties subtract points. Each place can be used once.</p>
      <div className="season-table-scroll"><table className="season-table"><thead><tr><th scope="col">Entrant</th><th scope="col">Place</th><th scope="col">Bonus / penalty</th><th scope="col">Points</th><th scope="col">Note</th></tr></thead><tbody>{draft.results.map(result => {
        const entrant = season.entrants.find(entry => entry.id === result.entrantId)!;
        const earned = (result.position === null ? 0 : season.points[result.position - 1] ?? 0) + result.adjustment;
        return <tr key={entrant.id}><td className="season-name">{entrant.name}</td><td data-label="Place"><input inputMode="numeric" aria-label={`${entrant.name} finishing place`} type="number" min={1} max={season.entrants.length} step={1} value={result.position ?? ''} placeholder="—" onChange={form => change(entrant.id, { position: form.target.value === '' ? null : Number(form.target.value) })}/></td>
          <td data-label="Bonus / penalty"><input aria-label={`${entrant.name} bonus or penalty points`} type="number" min={-10000} max={10000} step={1} value={adjustments[entrant.id] ?? String(result.adjustment)} onChange={form => { setAdjustments(previous => ({ ...previous, [entrant.id]: form.target.value })); change(entrant.id, { adjustment: Number(form.target.value) }); }} onBlur={() => setAdjustments(previous => ({ ...previous, [entrant.id]: String(result.adjustment) }))}/></td>
          <td data-label="Points"><strong>{earned}</strong></td><td data-label="Note"><input className="season-note-input" aria-label={`${entrant.name} result note`} value={result.note} maxLength={160} onChange={form => change(entrant.id, { note: form.target.value })} placeholder="Optional reason"/></td></tr>;
      })}</tbody></table></div>
      <label className="season-complete-check"><input type="checkbox" checked={draft.status === 'complete'} onChange={form => setDraft({ ...draft, status: form.target.checked ? 'complete' : 'draft' })}/><span>Count this event in the standings<small>Uncheck to save it as a draft and remove its points from the totals.</small></span></label>
      <div className="season-form-footer"><div className="season-actions"><button type="button" className="button small" onClick={() => { setDraft(previous => ({ ...previous, status: 'draft', results: previous.results.map(result => ({ ...result, position: null, adjustment: 0, note: '' })) })); setAdjustments({}); }}><RotateCcw size={15}/>Clear entries</button>{event.version > 0 && <button className="button small season-danger" type="button" onClick={() => setConfirmDelete(true)}><Trash2 size={15}/>Remove event</button>}</div><button className="button primary" type="submit"><Save size={16}/>{busy ? 'Saving…' : draft.status === 'complete' ? 'Save & update standings' : 'Save draft event'}</button></div>
    </fieldset></form>{confirmDelete && <div className="season-remove-confirm"><p>Remove {event.title} and its points from the season? This event will be deleted.</p><div className="season-actions"><button className="button" onClick={() => setConfirmDelete(false)} disabled={busy}>Keep event</button><button className="button season-danger" onClick={() => void onDelete(event)} disabled={busy}>Remove event</button></div></div>}
  </section>;
}

export function SeasonSettings({ season, busy, onSave, onClose, onError }: { season: Season; busy: boolean;
  onSave: (data: Pick<Season, 'title' | 'description' | 'points' | 'entrants' | 'version'>) => Promise<void>; onClose: () => void; onError: (message: string) => void }) {
  const [title, setTitle] = useState(season.title), [description, setDescription] = useState(season.description), [points, setPoints] = useState(season.points.join(', '));
  const [entrants, setEntrants] = useState(season.entrants), [version] = useState(season.version);
  const save = (event: FormEvent) => { event.preventDefault(); try { void onSave({ title, description, points: parsePoints(points), entrants, version }); } catch (error) { onError(error instanceof Error ? error.message : 'Check the scoring values.'); } };
  return <section className="season-panel season-editor" id="season-settings"><div className="season-section-title"><h2>Season settings</h2><button className="button small" onClick={onClose} disabled={busy} aria-label="Close season settings"><X size={17}/></button></div><form onSubmit={save}><fieldset disabled={busy}>
    <div className="season-form-grid"><div><label className="field">Season name<input value={title} onChange={event => setTitle(event.target.value)} maxLength={100} required/></label><label className="field">Description<textarea value={description} onChange={event => setDescription(event.target.value)} maxLength={400} rows={3}/></label></div>
      <div><label className="field">Points by finishing place<input value={points} onChange={event => setPoints(event.target.value)} required/></label><p className="season-help">Changing these values recalculates every completed event. Individual event bonuses and penalties stay as entered.</p><button className="button small" type="button" onClick={() => setPoints(motorsportPoints.join(', '))}>Use motorsport preset</button></div></div>
    <details className="season-settings-roster"><summary>Rename entrants</summary><p className="season-help">Names can change without losing their results. Start a new season to change the roster size.</p><div className="season-setting-names">{entrants.map((entrant, index) => <label className="field" key={entrant.id}>Entrant {index + 1}<input value={entrant.name} maxLength={100} required onChange={event => setEntrants(previous => previous.map(entry => entry.id === entrant.id ? { ...entry, name: event.target.value } : entry))}/></label>)}</div></details>
    <div className="season-form-footer"><p className="season-help">Ties use the most wins, then most 2nd places, 3rd places, and so on. Identical records share a rank.</p><button className="button primary" type="submit"><Save size={16}/>{busy ? 'Saving…' : 'Save settings'}</button></div>
  </fieldset></form></section>;
}
