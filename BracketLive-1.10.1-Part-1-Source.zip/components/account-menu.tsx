'use client';
import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Check, ChevronDown, CircleUserRound, Layers, LogOut, Mail, Settings2, ArrowRight, LoaderCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle } from './ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from './ui/dropdown-menu';
import { ensureSession } from '@/lib/client-session';

export type AccountUser = { id: string; name: string; email: string };
export type AccountState = { user: AccountUser | null; providers: { google: boolean; email: boolean } };
const emptyAccount: AccountState = { user: null, providers: { google: false, email: false } };
let accountRequest: Promise<AccountState> | null = null;
async function loadAccount(): Promise<AccountState> {
  if (!accountRequest) accountRequest = (async () => {
    await ensureSession();
    const response = await fetch('/api/account', { cache: 'no-store' });
    const data = await response.json() as { error?: string; message?: string; user?: AccountUser; providers?: AccountState['providers'] };
    if (!response.ok) throw new Error(data.error || 'Your profile could not be loaded. Please try again.');
    return { user: data.user || null, providers: data.providers || { google: false, email: false } };
  })().finally(() => { accountRequest = null; });
  return accountRequest;
}
export function useAccount() {
  const [account, setAccount] = useState<AccountState>(emptyAccount);
  const [ready, setReady] = useState(false), [error, setError] = useState('');
  const refresh = useCallback(async () => {
    try { setAccount(await loadAccount()); setError(''); }
    catch (reason) { setError(reason instanceof Error ? reason.message : 'Your profile could not be loaded.'); }
    finally { setReady(true); }
  }, []);
  useEffect(() => { let alive = true; const update = () => { void loadAccount().then(value => { if (alive) { setAccount(value); setError(''); } }).catch(reason => { if (alive) setError(reason instanceof Error ? reason.message : 'Your profile could not be loaded.'); }).finally(() => { if (alive) setReady(true); }); }; update(); window.addEventListener('bracketlive-account-change', update); return () => { alive = false; window.removeEventListener('bracketlive-account-change', update); }; }, []);
  return { ...account, ready, error, refresh };
}
export function announceAccountChange() { window.dispatchEvent(new Event('bracketlive-account-change')); }
export async function signOut() {
  const response = await fetch('/api/auth/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  const data = await response.json() as { error?: string; message?: string; user?: AccountUser; providers?: AccountState['providers'] };
  if (!response.ok) throw new Error(data.error || 'Could not sign out. Please try again.');
  // A fresh page closes authenticated event streams and clears private UI state.
  window.location.assign('/');
}
function currentReturnTo() {
  return typeof window === 'undefined' ? '/account' : window.location.pathname + window.location.search;
}
function GoogleMark() { return <svg aria-hidden="true" viewBox="0 0 24 24" width="19" height="19"><path fill="currentColor" d="M21.6 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.38a4.61 4.61 0 0 1-1.99 3.02v2.51h3.23c1.89-1.74 2.98-4.31 2.98-7.36ZM12 22c2.7 0 4.97-.9 6.62-2.41l-3.23-2.51c-.9.6-2.05.96-3.39.96-2.6 0-4.81-1.76-5.6-4.13H3.06v2.59A10 10 0 0 0 12 22ZM6.4 13.91A6 6 0 0 1 6.09 12c0-.66.11-1.3.31-1.91V7.5H3.06A10 10 0 0 0 2 12c0 1.61.38 3.14 1.06 4.5l3.34-2.59ZM12 5.96c1.47 0 2.79.51 3.83 1.51l2.87-2.87A9.61 9.61 0 0 0 12 2a10 10 0 0 0-8.94 5.5l3.34 2.59C7.19 7.72 9.4 5.96 12 5.96Z"/></svg>; }

export function AccountSignIn({ open, onOpenChange, returnTo }: { open: boolean; onOpenChange: (open: boolean) => void; returnTo?: string }) {
  const account = useAccount();
  const [email, setEmail] = useState(''), [busy, setBusy] = useState(false), [error, setError] = useState(''), [sent, setSent] = useState(false), [sentMessage, setSentMessage] = useState('');
  const submit = async (event: FormEvent) => {
    event.preventDefault(); if (busy || !account.providers.email) return;
    setBusy(true); setError('');
    try {
      const response = await fetch('/api/auth/email', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: email.trim(), returnTo: returnTo || currentReturnTo() }) });
      const data = await response.json() as { error?: string; message?: string; user?: AccountUser; providers?: AccountState['providers'] };
      if (!response.ok) throw new Error(data.error || 'Could not send your sign-in link. Please try again.');
      setSentMessage(data.message || 'Look for your sign-in link. Open it in this browser within 15 minutes.');
      setSent(true);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not send your sign-in link.'); }
    finally { setBusy(false); }
  };
  return <Dialog open={open} onOpenChange={onOpenChange}><DialogContent className="account-dialog">
    <span className="account-dialog-symbol"><CircleUserRound size={29}/></span>
    <DialogTitle>{sent ? 'Check your inbox' : 'Make it your own'}</DialogTitle>
    <DialogDescription>{sent ? sentMessage : 'Save and manage your tournaments across devices. You can vote without an account.'}</DialogDescription>
    {sent ? <div className="account-sent"><span className="account-sent-icon"><Check size={22}/></span><p>Check {email.trim()}, including your spam folder. No password to remember.</p><button className="button" type="button" onClick={() => { setSent(false); setError(''); }}>Use a different email</button></div> : !account.ready ? <p className="account-helper" role="status">Loading sign-in options…</p> : account.error ? <div className="account-notice" role="alert"><p>{account.error}</p><button className="button small" onClick={() => void account.refresh()}>Try again</button></div> : <>
      {account.providers.google ? <a className="button account-google" href={`/api/auth/google?returnTo=${encodeURIComponent(returnTo || currentReturnTo())}`}><GoogleMark/>Continue with Google</a> : <div className="account-provider-off"><GoogleMark/><span>Google sign-in is not available yet.</span></div>}
      {account.providers.email ? <><div className="account-divider"><span>or use email</span></div><form onSubmit={submit} className="account-email-form"><label htmlFor="account-signin-email">Email address</label><div className="account-email-input"><Mail size={17}/><input id="account-signin-email" name="email" type="email" autoComplete="email" required maxLength={254} value={email} onChange={event => setEmail(event.target.value)} placeholder="you@example.com" disabled={busy}/></div><button className="button primary" disabled={busy} type="submit">{busy ? <><LoaderCircle size={17} className="account-spinner"/>Sending your link…</> : <>Send sign-in link<ArrowRight size={17}/></>}</button></form></> : <p className="account-provider-off"><Mail size={18}/>Email sign-in is not available yet.</p>}
      {!account.providers.google && !account.providers.email && <p className="account-helper">The site owner still needs to connect a sign-in provider. You can keep voting and building brackets in this browser.</p>}
    </>}
    {error && <p className="account-error" role="alert">{error}</p>}
    <p className="account-privacy">Your email stays private. <a href="/privacy">Privacy & data</a></p>
  </DialogContent></Dialog>;
}

export function AccountMenu() {
  const account = useAccount();
  const [signIn, setSignIn] = useState(false), [error, setError] = useState(''), [busy, setBusy] = useState(false);
  const logout = async () => { if (busy) return; setBusy(true); setError(''); try { await signOut(); } catch (reason) { setError(reason instanceof Error ? reason.message : 'Could not sign out.'); setBusy(false); } };
  return <><DropdownMenu><DropdownMenuTrigger asChild><button type="button" className="account-menu-trigger" aria-label={account.user ? `Profile settings for ${account.user.name || account.user.email}` : 'Profile and sign in'} title="Profile settings"><span className="account-avatar">{account.user ? (Array.from(account.user.name || account.user.email)[0] || '').toUpperCase() : <CircleUserRound size={22}/>}</span><ChevronDown size={13} className="account-menu-chevron"/></button></DropdownMenuTrigger><DropdownMenuContent align="end" sideOffset={10} className="account-menu-panel"><DropdownMenuLabel className="account-menu-identity"><strong>{account.user?.name || (account.user ? 'Your profile' : 'Your corner of the bracket')}</strong><span>{account.user?.email || 'Create, save, and share your tournaments.'}</span></DropdownMenuLabel><DropdownMenuSeparator/>
    {account.user ? <><DropdownMenuItem asChild><a href="/account"><Layers size={17}/>My tournaments</a></DropdownMenuItem><DropdownMenuItem asChild><a href="/account#profile"><Settings2 size={17}/>Profile settings</a></DropdownMenuItem><DropdownMenuSeparator/><DropdownMenuItem disabled={busy} onSelect={() => void logout()}><LogOut size={17}/>{busy ? 'Signing out…' : 'Sign out'}</DropdownMenuItem></> : <><DropdownMenuItem onSelect={() => setSignIn(true)}><CircleUserRound size={17}/>Sign in or create a profile</DropdownMenuItem><DropdownMenuItem asChild><a href="/account"><Layers size={17}/>My tournaments</a></DropdownMenuItem></>}
    </DropdownMenuContent></DropdownMenu><AccountSignIn open={signIn} onOpenChange={setSignIn}/>{error && <div className="account-header-error" role="alert">{error}<button aria-label="Dismiss sign-out error" onClick={() => setError('')}>×</button></div>}</>;
}
