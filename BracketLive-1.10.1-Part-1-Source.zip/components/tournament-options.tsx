'use client';
import type {Draft} from '@/lib/bracket';
import AppearanceEditor from './appearance-editor';
import type {ImageSlot} from '@/lib/appearance';
import VotingScheduleControls from './voting-schedule-controls';
export default function TournamentOptions({draft,onChange,onUpload,disabled,section='all',onScheduleValidation}:{section?:'all'|'design'|'voting';draft:Draft;onChange:(d:Draft)=>void;onUpload:(f:File,slot:ImageSlot)=>void;disabled:boolean;onScheduleValidation?:(message:string)=>void}){
 return <div className="tournament-options">{section!=='voting'&&<AppearanceEditor draft={draft} onChange={onChange} onUpload={onUpload} disabled={disabled}/>}
 {section!=='design'&&<><h2>Voting schedule</h2><VotingScheduleControls value={draft.voting_schedule} legacyEndsAt={draft.ends_at} size={draft.size} format={draft.format} disabled={disabled} onChange={schedule=>onChange({...draft,ends_at:null,voting_schedule:schedule})} onValidationChange={onScheduleValidation}/><p className="options-note">After posting, enable creator email alerts in Manage → Schedule & alerts.</p><label className="check-field"><input type="checkbox" checked={draft.listed} disabled={disabled} onChange={event=>onChange({...draft,listed:event.target.checked})}/><span>List on the public tournament hub</span></label><p className="options-note">Unlisted tournaments are still accessible through their voting link.</p></>}</div>;
}
