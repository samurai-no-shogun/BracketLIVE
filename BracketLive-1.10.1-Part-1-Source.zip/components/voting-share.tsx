'use client';
import {useState} from 'react';
import {Check,ChevronDown,Copy,Link,Share2} from 'lucide-react';
import type {Bracket} from '@/lib/bracket';

export default function VotingShare({bracket,url,onCopy,onShare}:{bracket:Bracket;url:string;onCopy:()=>void;onShare:()=>void}){
 const complete=bracket.status==='complete', [expanded,setExpanded]=useState(false);
 return <section className={`voting-share compact-share ${expanded?'is-open':''}`} aria-label="Public bracket link">
  <div className="compact-share-main"><span className="compact-share-icon"><Link size={18}/></span><div className="voting-share-copy"><strong>{complete?'Your results are ready to share':'Invite people to vote'}</strong><span><Check size={12}/>{complete?'Public results':'Public voting is open'} · Anyone with the link</span></div><div className="compact-share-actions"><button type="button" className="button small" onClick={onCopy}><Copy size={15}/><span>Copy link</span></button><button type="button" className="compact-share-disclosure" aria-label={expanded?'Hide sharing details':'Show sharing details'} aria-expanded={expanded} aria-controls="voting-share-details" onClick={()=>setExpanded(v=>!v)}><ChevronDown size={17}/></button></div></div>
  {expanded&&<div id="voting-share-details" className="voting-share-controls"><label className="field">{complete?'Results link':'Voting link'}<div className="copy-field"><input aria-label={complete?'Public results link':'Public voting link'} readOnly value={url} onFocus={e=>e.target.select()}/><button type="button" className="button" onClick={onShare}><Share2 size={16}/>Share options</button></div></label><p>{complete?'Anyone with this link can see the final results.':'People can vote on every open matchup, see live results, and change their vote until the round closes.'}</p></div>}
 </section>;
}
