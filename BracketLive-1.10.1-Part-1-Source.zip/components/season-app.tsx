'use client';
import { useEffect, useRef, useState } from 'react';
import { Copy, Download, Flag, Link as LinkIcon, Plus, Settings, Share2, Trophy } from 'lucide-react';
import { SiteHeader } from './tournament-ui';
import { SeasonEventEditor, SeasonSettings } from './season-editor';
import { ensureSession } from '@/lib/client-session';
import { calculateStandings, type Season, type SeasonEvent, type Standing } from '@/lib/standings';
import { seasonApi, seasonError } from '@/lib/standings-client';
import { csvCell } from '@/lib/csv';
import './season.css';

export default function SeasonApp({ seasonId }: { seasonId: string }) {
  const [season, setSeason] = useState<Season | null>(null), [error, setError] = useState(''), [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false), [connected, setConnected] = useState(false), [share, setShare] = useState(false), [managementToken, setManagementToken] = useState(''), [resettingAccess, setResettingAccess] = useState(false);
  const [editing, setEditing] = useState<SeasonEvent | null>(null), [settings, setSettings] = useState(false), [through, setThrough] = useState('');
  const mutation = useRef(0), busyRef = useRef(false);
  useEffect(() => {
    let cancelled = false, timer: ReturnType<typeof setTimeout> | undefined;
    const refresh = async () => {
      const generation = mutation.current;
      try {
        if (!document.hidden) {
          const value = await seasonApi<Season>(`/api/seasons/${seasonId}`);
          if (!cancelled && generation === mutation.current && !busyRef.current) { setSeason(value); setConnected(true); }
        }
      } catch { if (!cancelled) setConnected(false); }
      finally { if (!cancelled) timer = setTimeout(refresh, 5000); }
    };
    const load = async () => {
      try {
        await ensureSession();
        const key = new URLSearchParams(window.location.hash.slice(1)).get('manage');
        if (key) {
          await seasonApi(`/api/seasons/${seasonId}/manage`, { token: key });
          if (cancelled) return;
          setManagementToken(key); window.history.replaceState({}, '', `/s/${seasonId}`);
        }
        const value = await seasonApi<Season>(`/api/seasons/${seasonId}`);
        if (!cancelled) { setSeason(value); setConnected(true); timer = setTimeout(refresh, 5000); }
      } catch (reason) { if (!cancelled) setError(seasonError(reason)); }
    };
    void load(); return () => { cancelled = true; if (timer) clearTimeout(timer); };
  }, [seasonId]);
  useEffect(() => {
    if (!editing && !settings) return;
    const guard = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', guard); return () => window.removeEventListener('beforeunload', guard);
  }, [editing, settings]);
  useEffect(() => {
    if (editing) document.getElementById('season-event-editor')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    else if (settings) document.getElementById('season-settings')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [editing?.id, settings]);
  const act = async (path: string, data: unknown, method: string, success: string) => {
    if (busyRef.current) return; busyRef.current = true; mutation.current += 1; setBusy(true); setError(''); setMessage('');
    try {
      const value = await seasonApi<Season>(path, data, method);
      setSeason(value); setEditing(null); setSettings(false); setMessage(success); setConnected(true);
      if (through && !value.events.some(event => event.id === through && event.status === 'complete')) setThrough('');
    } catch (reason) { setError(seasonError(reason)); }
    finally { busyRef.current = false; mutation.current += 1; setBusy(false); }
  };
  const copy = async (value: string, privateLink = false) => {
    try { await navigator.clipboard.writeText(value); setMessage(privateLink ? 'Private organizer link copied. Keep it for managing this season.' : 'Public standings link copied.'); }
    catch { setShare(true); setError('Copy the link from the field below.'); }
  };
  const publicUrl = typeof window === 'undefined' ? '' : `${window.location.origin}/s/${seasonId}`;
  const organizerLink = async () => {
    try {
      let key = managementToken;
      if (!key) { key = (await seasonApi<{ manageToken: string }>(`/api/seasons/${seasonId}/manage`, {})).manageToken; setManagementToken(key); }
      await copy(`${publicUrl}#manage=${key}`, true);
    } catch (reason) { setError(seasonError(reason)); }
  };
  const resetOrganizerAccess = async () => {
    if (resettingAccess || !window.confirm('Reset organizer access? This replaces all old organizer links and removes organizer access from every other browser. This browser keeps access. Save the new private link afterward.')) return;
    setResettingAccess(true); setError('');
    try {
      const result = await seasonApi<{ manageToken: string }>(`/api/seasons/${seasonId}/manage`, { revokeOthers: true });
      setManagementToken(result.manageToken); setMessage('Other browsers have been signed out of organizer access. Save your new private link.');
    } catch (reason) { setError(seasonError(reason)); }
    finally { setResettingAccess(false); }
  };
  const startEvent = () => {
    if (!season) return; setSettings(false); setError(''); setEditing({ id: crypto.randomUUID(), title: `Event ${season.events.length + 1}`, date: '', status: 'complete', results: [], version: 0 });
  };
  const shownEvents = season ? through && season.events.some(event => event.id === through) ? season.events.slice(0, season.events.findIndex(event => event.id === through) + 1) : season.events : [];
  const standings = season ? through ? calculateStandings(season.entrants, shownEvents, season.points) : season.standings : [];
  const completed = shownEvents.filter(event => event.status === 'complete'), leader = standings.length && completed.length ? standings[0] : null;
  return <div className="app theme-purple season-app"><SiteHeader/><main className="season-main">
    {!season ? <section className="season-empty"><h1>{error ? 'Could not load this season.' : 'Loading standings…'}</h1>{error && <p role="alert">{error}</p>}{error && <button className="button" onClick={() => window.location.reload()}>Try again</button>}</section> : <>
      <section className="page-heading"><div><div className="eyebrow"><Flag size={14}/> POINTS SEASON</div><h1>{season.title}</h1><p>{season.description || 'Follow the event results and season standings.'}</p><span className="season-live"><span className={`live-dot ${connected ? '' : 'offline'}`}/>{connected ? 'Live standings · refresh every 5 seconds' : 'Reconnecting · showing last saved results'}</span></div>
        <div className="heading-actions">{season.isOwner && <button className="button" disabled={busy} onClick={() => { setEditing(null); setSettings(!settings); }}><Settings size={16}/>Settings</button>}<button className="button primary" onClick={() => setShare(!share)}><Share2 size={16}/>Share standings</button></div></section>
      {error && <div className="error-banner" role="alert">{error}</div>}{message && <div className="season-message" role="status">{message}</div>}
      {share && <section className="season-panel"><div className="season-section-title"><h2>Share this season</h2></div><p className="season-help">Anyone with this link can see the standings and event results.</p><div className="season-share-input"><input aria-label="Public standings link" readOnly value={publicUrl} onFocus={event => event.target.select()}/><button className="button primary" onClick={() => void copy(publicUrl)}><Copy size={16}/>Copy public link</button></div>
        {season.isOwner && <details className="season-private-link"><summary>Organizer access · private</summary><p className="season-help">Save this private link to edit the season on another device. Share the public link with spectators.</p><button className="button" disabled={resettingAccess} onClick={() => void organizerLink()}><LinkIcon size={16}/>Copy organizer link</button><button className="button" disabled={resettingAccess} onClick={() => void resetOrganizerAccess()}>{resettingAccess ? 'Resetting…' : 'Reset organizer access'}</button>{managementToken && <div className="season-share-input" style={{ marginTop: 12 }}><input aria-label="Private season organizer link" readOnly value={`${publicUrl}#manage=${managementToken}`} onFocus={event => event.target.select()}/></div>}</details>}</section>}
      {settings && season.isOwner && <SeasonSettings key={`settings-${seasonId}`} season={season} busy={busy} onSave={data => act(`/api/seasons/${seasonId}`, data, 'PUT', 'Settings saved. Standings recalculated.')} onClose={() => setSettings(false)} onError={setError}/>}
      {editing && season.isOwner && <SeasonEventEditor key={`${editing.id}:${editing.version}`} season={season} event={editing} busy={busy} onSave={data => act(`/api/seasons/${seasonId}/events/${data.id}`, data, 'PUT', data.status === 'complete' ? 'Event results saved. Standings updated.' : 'Draft saved. This event does not count toward standings.')} onDelete={data => act(`/api/seasons/${seasonId}/events/${data.id}`, { version: data.version }, 'DELETE', 'Event removed. Its points no longer count.')} onClose={() => setEditing(null)}/>}
      <div className="season-stats"><div className="season-panel season-stat"><span>Entrants</span><strong>{season.entrants.length}</strong></div><div className="season-panel season-stat"><span>Scored events</span><strong>{completed.length}</strong></div><div className="season-panel season-stat"><span>{leader && standings.filter(row => row.rank === 1).length > 1 ? 'Leaders tied on' : 'Leading points'}</span><strong>{leader?.points ?? '—'}</strong></div></div>
      <section className="season-panel"><div className="season-section-title"><h2><Trophy size={20} style={{ display: 'inline', marginRight: 9 }}/>Standings</h2><div className="season-actions"><select className="season-export-select" aria-label="Show standings through event" value={through} onChange={event => setThrough(event.target.value)}><option value="">Overall standings</option>{season.events.filter(event => event.status === 'complete').map(event => <option key={event.id} value={event.id}>Through {event.title}</option>)}</select><button className="button small" onClick={() => exportStandings(season, standings, completed, through)}><Download size={15}/>Export CSV</button></div></div>
        {through && <p className="season-asof">Results through {season.events.find(event => event.id === through)?.title}, using the current points rules and saved corrections.</p>}
        <div className="season-table-scroll"><table className="season-table"><thead><tr><th scope="col">Rank</th><th scope="col">Entrant</th><th scope="col">Points</th><th scope="col">Wins</th><th scope="col">Podiums</th><th scope="col">Classified events</th></tr></thead><tbody>{standings.map(row => <tr key={row.entrant.id}><td className="season-rank">{completed.length ? row.rank : '—'}</td><th className="season-name" scope="row" style={{ textTransform: 'none', letterSpacing: 0, color: 'var(--foreground)', fontSize: 14 }}>{row.entrant.name}</th><td className="season-score">{row.points}</td><td>{row.wins}</td><td>{row.podiums}</td><td>{row.starts}</td></tr>)}</tbody></table></div>
        <p className="season-help">Ties: most wins, then most 2nd places, 3rd places, and so on. Identical records share a rank. Only scored events contribute points.</p>
      </section>
      <section className="season-panel"><div className="season-section-title"><h2>Events & results</h2>{season.isOwner && <button className="button primary" disabled={busy || season.events.length >= 100} onClick={startEvent}><Plus size={16}/>Add event</button>}</div>
        {season.events.length ? <div className="season-event-grid">{season.events.map(event => <article className="season-event-card" key={event.id}><div className="season-section-title"><h3>{event.title}</h3><span className={`season-status ${event.status === 'complete' ? 'scored' : ''}`}>{event.status === 'complete' ? 'Scored' : 'Draft · not scored'}</span></div>{event.date && <p className="season-help">{new Date(`${event.date}T12:00:00`).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</p>}
          {season.isOwner && <button className="button small" disabled={busy} onClick={() => { setSettings(false); setEditing(event); setError(''); }}>Edit results</button>}
          <details><summary>{event.results.filter(result => result.position !== null || result.adjustment || result.note).length} recorded results</summary><ul className="season-event-results">{[...event.results].filter(result => result.position !== null || result.adjustment || result.note).sort((a, b) => (a.position ?? 1000) - (b.position ?? 1000)).map(result => <li key={result.entrantId}><span>{result.position ?? '—'}</span><span>{season.entrants.find(entrant => entrant.id === result.entrantId)?.name}</span><strong>{(result.position === null ? 0 : season.points[result.position - 1] ?? 0) + result.adjustment} pts</strong>{(result.adjustment !== 0 || result.note) && <small>{result.adjustment !== 0 ? `${result.adjustment > 0 ? '+' : ''}${result.adjustment} adjustment${result.note ? ' · ' : ''}` : ''}{result.note}</small>}</li>)}</ul></details></article>)}</div>
          : <p className="season-help">No events yet. {season.isOwner ? 'Add an event and enter finishing places to start the standings.' : 'The organizer has not recorded any events yet.'}</p>}
      </section>
      <section className="season-panel"><h2>Scoring rules</h2><div className="season-rule-points">{season.points.map((points, index) => <span key={index}>P{index + 1}<strong>{points} pts</strong></span>)}</div><p className="season-help">Other places earn 0 placement points. Organizers can record bonuses or penalties per entrant, per event. Updated results replace earlier results; they do not add points twice.</p></section>
      <a className="button" href="/seasons">Explore seasons</a>
    </>}
  </main></div>;
}

function exportStandings(season: Season, standings: Standing[], events: SeasonEvent[], through: string) {
  const rows: (string | number)[][] = [
    ['Season', season.title], ['Exported at', new Date().toISOString()], ['Scope', through ? `Through ${season.events.find(event => event.id === through)?.title}` : 'Overall standings'],
    ['Placement points', season.points.join(', ')], [], ['Rank', 'Entrant', 'Points', 'Wins', 'Podiums', 'Classified events', ...events.map(event => event.title)],
    ...standings.map(row => [events.length ? row.rank : '', row.entrant.name, row.points, row.wins, row.podiums, row.starts, ...events.map(event => row.eventPoints[event.id] ?? 0)])
  ];
  const blob = new Blob(['\uFEFF', rows.map(row => row.map(csvCell).join(',')).join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob), anchor = document.createElement('a'); anchor.href = url;
  anchor.download = `${season.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 60) || 'season'}-standings-${new Date().toISOString().slice(0, 10)}.csv`;
  anchor.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
