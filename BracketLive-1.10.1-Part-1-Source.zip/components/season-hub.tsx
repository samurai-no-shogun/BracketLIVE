'use client';
import { useEffect, useState, type FormEvent } from 'react';
import { ArrowRight, FileUp, Flag, Plus, Trophy, X } from 'lucide-react';
import { SiteHeader } from './tournament-ui';
import { ensureSession } from '@/lib/client-session';
import { motorsportPoints, parsePoints, type Season, type SeasonCard } from '@/lib/standings';
import { seasonApi, seasonError } from '@/lib/standings-client';
import './season.css';
import BracketImportDialog from './bracket-import-dialog';

export default function SeasonHub({startCreating=false}:{startCreating?:boolean}) {
  const [seasons, setSeasons] = useState<SeasonCard[]>([]), [mine, setMine] = useState(false), [ready, setReady] = useState(false);
  const [creating, setCreating] = useState(startCreating), [busy, setBusy] = useState(false), [error, setError] = useState('');
  const [title, setTitle] = useState(''), [description, setDescription] = useState(''), [roster, setRoster] = useState('');
  const [points, setPoints] = useState(motorsportPoints.join(', ')), [importOpen, setImportOpen] = useState(false);
  useEffect(() => { let cancelled = false; setReady(false);
    ensureSession().then(() => seasonApi<{ seasons: SeasonCard[] }>(`/api/seasons${mine ? '?view=mine' : ''}`))
      .then(value => { if (!cancelled) { setSeasons(value.seasons); setError(''); setReady(true); } })
      .catch(reason => { if (!cancelled) setError(seasonError(reason)); });
    return () => { cancelled = true; };
  }, [mine]);
  const create = async (event: FormEvent) => {
    event.preventDefault(); if (busy || !ready) return; setBusy(true); setError('');
    try {
      const result = await seasonApi<{ season: Season; manageToken: string }>('/api/seasons', { title, description,
        points: parsePoints(points), entrants: roster.split('\n').map(name => name.trim()).filter(Boolean) });
      window.location.assign(`/s/${result.season.id}#manage=${result.manageToken}`);
    } catch (reason) { setError(seasonError(reason)); setBusy(false); }
  };
  return <div className="app theme-purple season-app season-hub"><SiteHeader/><main className="season-main">
    <section className="page-heading"><div><div className="eyebrow"><Flag size={13}/>POINTS-BASED CHAMPIONSHIPS</div><h1>Every event.<br/><span>Every point.</span></h1>
      <p>Build a season, record the results, and follow the standings. Formula 1–style scoring or your own rules.</p></div>
      {!creating&&<button className="button primary" onClick={() => setCreating(true)}><Plus size={18}/>Create a points season</button>}</section>
    {error && <div className="error-banner" role="alert">{error}</div>}
    {creating && <section className="season-panel season-create"><div className="season-section-title"><div><span className="season-form-kicker">YOUR NEXT CHAMPIONSHIP</span><h2>Create a points season</h2></div><button className="button small" onClick={() => setCreating(false)} disabled={busy} aria-label="Close season form"><X size={17}/></button></div>
      <form onSubmit={create}><fieldset disabled={busy || !ready}>
        <div className="season-form-grid"><div><label className="field">Season name<input value={title} onChange={event => setTitle(event.target.value)} placeholder="Your league or championship" maxLength={100} required/></label>
          <label className="field">Description <span className="optional">optional</span><textarea value={description} onChange={event => setDescription(event.target.value)} maxLength={400} rows={2}/></label>
          <label className="field">Points by finishing place<input value={points} onChange={event => setPoints(event.target.value)} required aria-describedby="season-points-help"/></label>
          <p id="season-points-help" className="season-help">First number = 1st place, second = 2nd, and so on. Places beyond this list earn 0. You can change the scoring later.</p>
          <button className="button small" type="button" onClick={() => setPoints(motorsportPoints.join(', '))}><Flag size={14}/>Motorsport preset</button>
          <p className="season-help">Start with 25, 18, 15, 12, 10, 8, 6, 4, 2, 1 points, or use your own system. Add event bonuses or penalties when recording results.</p></div>
          <label className="field">Entrants · one per line<button className="button small" type="button" disabled={busy||!ready} onClick={()=>setImportOpen(true)}><FileUp size={15}/>Import from a file</button><textarea className="season-roster-input" value={roster} onChange={event => setRoster(event.target.value)} rows={10} maxLength={12928} placeholder={'Driver, player, or team names\nOne name per line'} required/><span className="season-help">2–128 entrants. Names can be edited later; the roster size stays fixed for this season.</span></label></div>
        <div className="season-form-footer"><p className="season-help">Your standings page will be public. Only organizers can enter results.</p><button className="button primary" type="submit">{busy ? 'Creating…' : 'Create season'}</button></div>
      </fieldset></form>
    </section>}
    <div className="season-section-title"><div className="season-tabs" aria-label="Season directory"><button className={`button ${!mine ? 'primary' : ''}`} onClick={() => setMine(false)}>Explore seasons</button><button className={`button ${mine ? 'primary' : ''}`} onClick={() => setMine(true)}>My seasons</button></div><span className="secondary">{seasons.length} seasons</span></div>
    {!ready && !error ? <p className="season-empty">Loading seasons…</p> : seasons.length ? <div className="season-card-grid">{seasons.map(season => <a className="season-panel season-card" key={season.id} href={`/s/${season.id}`}>
      <div className="season-section-title"><Trophy size={24}/>{season.isOwner && <span className="tag">Organizer</span>}</div><h2>{season.title}</h2>{season.description && <p>{season.description}</p>}
      <div className="season-card-foot"><span>{season.entrantCount} entrants · {season.completedCount}/{season.eventCount} events scored</span><ArrowRight size={18}/></div></a>)}</div>
      : <div className="season-panel season-empty"><Trophy size={28}/><h2>{mine ? 'Your next season starts here.' : 'A championship waiting to happen.'}</h2><p>Choose your entrants and scoring. Each new result brings the championship into focus.</p><button className="button" onClick={() => setCreating(true)}>Create season</button></div>}
  </main>{creating&&<BracketImportDialog open={importOpen} onOpenChange={setImportOpen} context="season" draft={{title,entries:roster.split('\n').map(name=>name.trim()).filter(Boolean).map((name,index)=>({name,subtitle:'',image:null,seed:index+1}))}} onApply={review=>{if(!ready||busy)return;setRoster(review.entries.map(entry=>entry.name).join('\n'));if(review.title)setTitle(review.title);setError('');}}/>}</div>;
}
