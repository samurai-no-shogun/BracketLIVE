import {ArrowRight,GitFork,Sparkles} from 'lucide-react';
import {makeTemplateDraft} from '@/lib/bracket';
import {EntryArt} from './bracket-board';
import {SiteHeader} from './tournament-ui';

// This is explicitly practice content until the owner selects a real public
// tournament. Visiting home must never create/publish a private test for them.
export default function FeaturedHome(){
 const trial=makeTemplateDraft('trial');
 return <div className="app featured-home"><SiteHeader/><main className="featured-home-main"><section className="featured-home-intro"><span className="featured-home-kicker"><Sparkles size={15}/>Make your pick</span><h1>Who takes<br/><span>the crown?</span></h1><p>Explore the Trial Bracket. Pick your favorites, see how voting works, and take it all the way to a champion.</p><a className="button primary featured-home-cta" href="/test/trial">Try the bracket<ArrowRight size={18}/></a><span className="featured-home-note">Private practice · Your picks stay in your test run</span></section><section className="featured-trial-preview" aria-labelledby="trial-preview-title"><div className="featured-preview-heading"><span className="status-pill">Practice preview</span><span>64 contenders · 6 rounds</span></div><h2 id="trial-preview-title">Trial Bracket</h2><div className="featured-preview-contenders">{trial.entries.slice(0,2).map(entry=><div className="featured-preview-contender" key={entry.seed}><EntryArt image={entry.image!} alt={entry.name} className="featured-entry-image"/><h3>{entry.name}</h3><p>{entry.subtitle}</p></div>)}<span className="featured-preview-vs">VS</span></div><a href="/test/trial" className="featured-preview-link">Open the full bracket<ArrowRight size={16}/></a></section><section className="featured-home-community"><GitFork size={24}/><div><h2>Have a matchup in mind?</h2><p>Create your own tournament and bring everyone into the vote.</p></div><a className="button" href="/create">Create a tournament<ArrowRight size={16}/></a><a className="text-button" href="/explore">Explore brackets</a></section></main></div>;
}
