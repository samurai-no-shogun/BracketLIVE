'use client';

import {useEffect,useMemo,useRef,useState} from 'react';
import {ArrowDown,ArrowUp,Check,FileUp,LoaderCircle,Plus,Trash2} from 'lucide-react';
import type {Draft} from '@/lib/bracket';
import type {ImportDocument,ImportEntry,ImportMapping,ImportTable} from '@/lib/bracket-import';
import {Dialog,DialogContent,DialogDescription,DialogHeader,DialogTitle} from './ui/dialog';
import './bracket-import.css';

type ReviewEntry=ImportEntry&{key:string;included:boolean};
type ImportReview={entries:Draft['entries'];size:number;title?:string};
const supported='.csv,.tsv,.xlsx,.ods,.txt,.docx,.pdf,.png,.jpg,.jpeg,.webp,.json';
const messageFor=(reason:unknown)=>reason instanceof Error?reason.message:'This file could not be read. Choose another file or paste your list.';
function columnLabel(index:number){let letter='',number=index+1;while(number>0){number--;letter=String.fromCharCode(65+number%26)+letter;number=Math.floor(number/26);}return letter;}
function isVisualFile(file:File){return /\.(pdf|png|jpe?g|webp)$/i.test(file.name);}
function isPdfFile(file:File){return /\.pdf$/i.test(file.name);}
function firstContentRow(table:ImportTable){return Math.max(0,table.rows.findIndex(row=>row.some(value=>value.trim())));}

export default function BracketImportDialog({open,onOpenChange,draft,onApply,context='bracket'}:{open:boolean;onOpenChange:(open:boolean)=>void;draft:Pick<Draft,'title'|'entries'>;onApply:(review:ImportReview)=>void;context?:'bracket'|'season'}){
 const season=context==='season';
 const fileInput=useRef<HTMLInputElement>(null),operation=useRef(0),reviewOperation=useRef(0),controller=useRef<AbortController|null>(null);
 const [file,setFile]=useState<File|null>(null),[source,setSource]=useState<ImportDocument|null>(null),[tableId,setTableId]=useState(''),[mapping,setMapping]=useState<ImportMapping|null>(null),[roster,setRoster]=useState<ReviewEntry[]>([]),[mappingWarnings,setMappingWarnings]=useState<string[]>([]),[issues,setIssues]=useState<string[]>([]),[error,setError]=useState(''),[reading,setReading]=useState(false),[mappingBusy,setMappingBusy]=useState(false),[progress,setProgress]=useState(''),[page,setPage]=useState(1),[pageCount,setPageCount]=useState(0),[useTitle,setUseTitle]=useState(false);
 const table=source?.tables.find(item=>item.id===tableId)??null;
 const selected=roster.filter(entry=>entry.included),slotNumbers=new Map(selected.map((entry,index)=>[entry.key,index+1])),count=selected.length,size=count>0?Math.max(2,2**Math.ceil(Math.log2(count))):2,padding=size-count;
 const emptyName=selected.some(entry=>!entry.name.trim()),longText=selected.some(entry=>entry.name.trim().length>100||(!season&&entry.subtitle.trim().length>100)),tooMany=count>128,duplicates=season&&new Set(selected.map(entry=>entry.name.trim().toLowerCase())).size!==count,lineBreaks=season&&selected.some(entry=>/[\r\n]/.test(entry.name));
 const warnings=useMemo(()=>[...new Set([...(source?.warnings??[]),...mappingWarnings])],[source,mappingWarnings]);
 const stopReading=()=>{operation.current++;reviewOperation.current++;controller.current?.abort();controller.current=null;setReading(false);setMappingBusy(false);};
 useEffect(()=>{if(!open){operation.current++;controller.current?.abort();controller.current=null;setReading(false);return;}setFile(null);setSource(null);setTableId('');setMapping(null);setRoster([]);setMappingWarnings([]);setIssues([]);setError('');setProgress('');setPage(1);setPageCount(0);setUseTitle(false);},[open]);
 useEffect(()=>()=>{operation.current++;controller.current?.abort();},[]);
 const close=()=>{stopReading();onOpenChange(false);};
 const reviewTable=async(nextTable:ImportTable,nextMapping=nextTable.suggested)=>{
  const current=operation.current,currentReview=++reviewOperation.current;setMappingBusy(true);
  try{const {mapImportTable}=await import('@/lib/bracket-import');if(current!==operation.current||currentReview!==reviewOperation.current)return;const result=mapImportTable(nextTable,nextMapping);setTableId(nextTable.id);setMapping({...nextMapping});setRoster(result.entries.map((entry,index)=>({...entry,key:`${nextTable.id}-${index}`,included:true})));setMappingWarnings(result.warnings);setIssues(result.issues.map(issue=>issue.row>0&&!/^Row \d+:/i.test(issue.message)?`Row ${issue.row}: ${issue.message}`:issue.message));setError('');}
  catch(reason){if(current===operation.current&&currentReview===reviewOperation.current)setError(messageFor(reason));}
  finally{if(current===operation.current&&currentReview===reviewOperation.current)setMappingBusy(false);}
 };
 const readFile=async(nextFile:File,nextPage=1,ocr=false)=>{
  stopReading();const current=operation.current,abort=new AbortController();controller.current=abort;
  setFile(nextFile);setReading(true);setError('');setProgress('Reading your file…');setSource(null);setTableId('');setMapping(null);setRoster([]);setIssues([]);setMappingWarnings([]);setUseTitle(false);setPage(nextPage);if(nextPage===1)setPageCount(0);
  try{
   const core=await import('@/lib/bracket-import');if(abort.signal.aborted||current!==operation.current)return;
   let document:ImportDocument;
   if(isVisualFile(nextFile)){
    const {extractVisualImport}=await import('@/lib/import-visual');
    const extracted=await extractVisualImport(nextFile,{signal:abort.signal,page:nextPage,...(ocr?{ocr:true}:{}),onProgress:message=>{if(current===operation.current)setProgress(message);}});
    if(abort.signal.aborted||current!==operation.current)return;
    document=core.parseImportText(extracted.text,'txt');document={...document,warnings:[...document.warnings,...extracted.warnings]};setPageCount(extracted.pageCount??0);
   }else document=await core.parseBracketImport(nextFile);
   if(abort.signal.aborted||current!==operation.current)return;
   setSource(document);if(!document.tables.length)throw new Error('No contender list was found. Try a table or a clear image of the first round.');
   await reviewTable(document.tables[0]);
  }catch(reason){if(!abort.signal.aborted&&current===operation.current)setError(messageFor(reason));}
  finally{if(current===operation.current){setReading(false);controller.current=null;}}
 };
 const changeMapping=(change:Partial<ImportMapping>)=>{if(table&&mapping)void reviewTable(table,{...mapping,...change});};
 const editEntry=(key:string,change:Partial<ReviewEntry>)=>setRoster(entries=>entries.map(entry=>entry.key===key?{...entry,...change}:entry));
 const moveEntry=(index:number,offset:number)=>setRoster(entries=>{const next=[...entries],target=index+offset;if(target<0||target>=entries.length)return entries;[next[index],next[target]]=[next[target],next[index]];return next;});
 const selectColumn=(label:string,key:keyof Pick<ImportMapping,'nameColumn'|'subtitleColumn'|'seedColumn'|'opponentColumn'|'opponentSubtitleColumn'|'opponentSeedColumn'>,optional=false)=>{
  if(!table||!mapping)return null;const width=Math.max(1,...table.rows.map(row=>row.length));
  return <label className="bracket-import-field" key={key}>{label}<select value={mapping[key]===null?'':String(mapping[key])} onChange={event=>changeMapping({[key]:event.target.value===''?null:Number(event.target.value)})}>
   {optional&&<option value="">None</option>}{Array.from({length:width},(_,index)=>{const header=mapping.startRow>0?table.rows[mapping.startRow-1]?.[index]:null;return <option key={index} value={index}>Column {columnLabel(index)}{header?` · ${header.slice(0,50)}`:''}</option>;})}
  </select></label>;
 };
 const apply=()=>{if(reading||mappingBusy||count<2||tooMany||emptyName||longText||duplicates||lineBreaks)return;const entries=selected.map(({name,subtitle},index)=>({name:name.trim(),subtitle:season?'':subtitle.trim(),image:null as string|null,seed:index+1}));while(!season&&entries.length<size)entries.push({name:'',subtitle:'',image:null,seed:entries.length+1});onApply({entries,size:season?count:size,...(useTitle&&source?.title?{title:source.title}:{})});close();};
 return <Dialog open={open} onOpenChange={next=>{if(!next)close();}}><DialogContent className="bracket-import-dialog"><DialogHeader><DialogTitle>{season?'Import season entrants':'Import your contenders'}</DialogTitle><DialogDescription>Bring a spreadsheet, document, roster image, or saved snapshot. Review everything before adding it.</DialogDescription></DialogHeader>
 <div className="bracket-import-body">
  <input ref={fileInput} type="file" className="sr-only" tabIndex={-1} accept={supported} aria-label="Choose bracket import file" onChange={event=>{const next=event.target.files?.[0];event.target.value='';if(next)void readFile(next);}}/>
  {!source&&!reading&&<button type="button" className="bracket-import-dropzone" onClick={()=>fileInput.current?.click()}><span className="bracket-import-file-icon"><FileUp size={26}/></span><strong>Choose a file</strong><span>CSV, TSV, Excel, ODS, TXT, Word, PDF, images, or JSON</span><small>The source file stays in your browser.</small></button>}
  {(source||reading)&&<div className="bracket-import-source"><FileUp size={20}/><div><strong>{file?.name}</strong><small>{reading?progress:'Review before applying'}</small></div><button type="button" className="button small" onClick={()=>fileInput.current?.click()} disabled={reading}>Change file</button></div>}
  {reading&&<div className="bracket-import-progress" role="status" aria-live="polite"><LoaderCircle size={22} className="spin"/><span>{progress}</span><button type="button" className="text-button" onClick={stopReading}>Cancel reading</button></div>}
  {error&&<p className="bracket-import-error" role="alert">{error}</p>}
  {!reading&&file&&isPdfFile(file)&&pageCount>0&&<div className="bracket-import-pdf-controls"><label className="bracket-import-field">PDF page<select value={page} onChange={event=>void readFile(file,Number(event.target.value))}>{Array.from({length:pageCount},(_,index)=><option value={index+1} key={index}>Page {index+1} of {pageCount}</option>)}</select></label><button type="button" className="button small" onClick={()=>void readFile(file,page,true)}>Read page as image</button></div>}
  {!reading&&source&&table&&mapping&&<>
   {isVisualFile(file!)&&<p className="bracket-import-note bracket-import-visual-note">Image and PDF reading can miss names or include later-round winners. Keep only the starting contenders, correct spelling, and review the matchup order.</p>}
   <details className="bracket-import-mapping" open={source.tables.length>1||issues.length>0||roster.length===0}><summary>Sheet & column settings</summary><div className="bracket-import-mapping-content">
    {source.tables.length>1&&<label className="bracket-import-field">Sheet or table<select value={table.id} onChange={event=>{const next=source.tables.find(item=>item.id===event.target.value);if(next)void reviewTable(next);}}>{source.tables.map(item=><option value={item.id} key={item.id}>{item.name}</option>)}</select></label>}
    <div className="bracket-import-mapping-top"><label className="bracket-import-field">List format<select value={mapping.mode} onChange={event=>changeMapping({mode:event.target.value as ImportMapping['mode'],opponentColumn:event.target.value==='paired'?(mapping.opponentColumn??Math.min(mapping.nameColumn+1,Math.max(...table.rows.map(row=>row.length))-1)):mapping.opponentColumn})}><option value="roster">One contender per row</option><option value="paired">Opponent A vs opponent B</option></select></label><label className="bracket-import-check"><input type="checkbox" checked={mapping.startRow>firstContentRow(table)} onChange={event=>changeMapping({startRow:firstContentRow(table)+(event.target.checked?1:0)})}/><span>First nonempty row is a header</span></label></div>
    <div className="bracket-import-columns">{selectColumn(mapping.mode==='paired'?'Opponent A':'Name','nameColumn')}{!season&&selectColumn(mapping.mode==='paired'?'A description':'Description','subtitleColumn',true)}{selectColumn(mapping.mode==='paired'?'A source seed':'Source seed','seedColumn',true)}{mapping.mode==='paired'&&<>{selectColumn('Opponent B','opponentColumn')}{!season&&selectColumn('B description','opponentSubtitleColumn',true)}{selectColumn('B source seed','opponentSeedColumn',true)}</>}</div>
    <p className="bracket-import-note">Column changes reset the review list. {season?'Only entrant names are added to your season; descriptions, seeds, and event results stay out of the import.':'Import order determines slots: 1 vs 2, 3 vs 4, and so on. Source seeds never reorder your entries.'}</p>
   </div></details>
   {(warnings.length>0||issues.length>0)&&<details className="bracket-import-warnings" open={issues.length>0}><summary>{issues.length?'Rows need review':`${warnings.length} import ${warnings.length===1?'note':'notes'}`}</summary><ul>{[...warnings,...issues].map((warning,index)=><li key={index}>{warning}</li>)}</ul></details>}
   {source.title&&<label className="bracket-import-check bracket-import-title"><input type="checkbox" checked={useTitle} onChange={event=>setUseTitle(event.target.checked)}/><span>Use imported title: <strong>{source.title}</strong></span></label>}
   <div className="bracket-import-review-heading"><div><h3>{season?'Review entrants':'Review contenders'}</h3><p>{count} selected{!season&&<> · {size<=128?`${size} bracket slots`: 'maximum 128 contenders'}</>}</p></div><div><button type="button" className="text-button" onClick={()=>setRoster(entries=>entries.map(entry=>({...entry,included:!entries.every(item=>item.included)})))}>{roster.every(entry=>entry.included)?'Deselect all':'Select all'}</button><button type="button" className="text-button" onClick={()=>setRoster(entries=>[...entries,{name:'',subtitle:'',image:null,seed:entries.length+1,sourceRow:0,key:`manual-${crypto.randomUUID()}`,included:true}])}><Plus size={15}/>Add row</button></div></div>
   {roster.length===0&&<p className="bracket-import-note">No contenders were found with these columns. Adjust the settings or add names below.</p>}
   <div className="bracket-import-roster">{roster.map((entry,index)=><div className={`bracket-import-row ${entry.included?'':'is-excluded'}`} key={entry.key}>
    <label className="bracket-import-include"><input type="checkbox" checked={entry.included} aria-label={`Include contender ${index+1}`} onChange={event=>editEntry(entry.key,{included:event.target.checked})}/><span title={season?'Imported order':'Imported slot'}>{entry.included?slotNumbers.get(entry.key):'—'}</span></label>
    <div className={`bracket-import-entry-fields ${season?'names-only':''}`}><input aria-label={`Contender ${index+1} name`} value={entry.name} maxLength={100} placeholder="Contender name" onChange={event=>editEntry(entry.key,{name:event.target.value})}/>{!season&&<input aria-label={`Contender ${index+1} description`} value={entry.subtitle} maxLength={100} placeholder="Description (optional)" onChange={event=>editEntry(entry.key,{subtitle:event.target.value})}/>}<small>{entry.sourceRow?`Source row ${entry.sourceRow}`:'Added by you'}{entry.seed?` · Source seed ${entry.seed}`:''}</small></div>
    <div className="bracket-import-row-actions"><button type="button" aria-label={`Move contender ${index+1} up`} disabled={index===0} onClick={()=>moveEntry(index,-1)}><ArrowUp size={16}/></button><button type="button" aria-label={`Move contender ${index+1} down`} disabled={index===roster.length-1} onClick={()=>moveEntry(index,1)}><ArrowDown size={16}/></button><button type="button" aria-label={`Remove contender ${index+1}`} onClick={()=>setRoster(entries=>entries.filter(item=>item.key!==entry.key))}><Trash2 size={16}/></button></div>
   </div>)}</div>
   <div className="bracket-import-apply-note"><Check size={18}/><p>This replaces {draft.entries.filter(entry=>entry.name||entry.image).length} {season?'entrants in your new season form':'existing draft contenders'}. {season?'Your points rules and description stay saved. Only names are imported; event results are not restored.':`Your branding, settings, and ${useTitle?'description':'title'} stay saved.`} {!season&&padding>0&&size<=128?`${padding} empty ${padding===1?'slot needs':'slots need'} filling before publishing. `:''}{season?'The season is created only when you choose Create season.':'The bracket is saved or published only when you choose to do so.'}</p></div>
   {tooMany&&<p className="bracket-import-error" role="alert">Select at most 128 {season?'entrants':'contenders'}. No rows will be silently dropped.</p>}{count<2&&<p className="bracket-import-note">Select at least two {season?'entrants':'contenders'}.</p>}{emptyName&&<p className="bracket-import-error" role="alert">Add a name to each selected row, or deselect empty rows.</p>}{longText&&<p className="bracket-import-error" role="alert">Shorten each selected name{!season&&' and description'} to 100 characters or fewer.</p>}{duplicates&&<p className="bracket-import-error" role="alert">Each season entrant needs a different name. Rename or deselect duplicates.</p>}{lineBreaks&&<p className="bracket-import-error" role="alert">Keep each entrant name on one line.</p>}
  </>}
 </div>
 <div className="bracket-import-actions"><button type="button" className="button" onClick={close}>Cancel</button><button type="button" className="button primary" disabled={reading||mappingBusy||!source||count<2||tooMany||emptyName||longText||duplicates||lineBreaks} onClick={apply}>Use {count||''} {season?'entrants':'contenders'}</button></div>
 </DialogContent></Dialog>;
}
